`timescale 1ns / 1ps
//=============================================================================
// ASCON-128 · Variant: encoded
//
// One-hot round-constant selector — the 4-bit binary round counter is
// expanded to a 12-bit one-hot vector (one hot bit per round 0..11).
// Each hot bit directly gates its own dedicated round-constant XOR into x2,
// eliminating the centralized case-statement decoder entirely.
// The 12 dedicated XOR gates are OR-reduced to produce x2's new value.
// All 12 XOR branches are combinationally live simultaneously; the one-hot
// register ensures exactly one contributes a non-zero result per cycle.
//
// Structural novelty: round constant selection is a 12-way AND-gate tree
// (hot_bit & rc_i) → OR-reduction, not a multiplexer or case statement.
// This maps directly to 12 LUT2s + 1 OR tree on FPGA.
//
// Clocks pa=12: 13  Clocks pb=6: 7  Fmax: 25 MHz / 40 ns
//=============================================================================
module ascon128_top (
    input  wire clk_p,clk_n,rst_n,start,
    output wire done,tag_match,led_done,led_tag_match,led_running,led_error
);
    wire clk_ibuf,clk;
    IBUFDS #(.DIFF_TERM("FALSE"),.IBUF_LOW_PWR("FALSE"),.IOSTANDARD("LVDS"))
        u0(.I(clk_p),.IB(clk_n),.O(clk_ibuf));
    BUFG u1(.I(clk_ibuf),.O(clk));
    wire cd,ct; reg rr;
    ascon128_complete_encoded ac(.clk(clk),.rst_n(rst_n),.start(start),.done(cd),.tag_match(ct));
    assign done=cd; assign tag_match=ct;
    always @(posedge clk or negedge rst_n) if(!rst_n) rr<=0; else if(start) rr<=1; else if(cd) rr<=0;
    assign led_done=cd; assign led_tag_match=cd&ct; assign led_running=rr; assign led_error=cd&~ct;
endmodule

module ascon128_complete_encoded(input wire clk,rst_n,start,output reg done,tag_match);
    localparam [127:0] KEY=128'h0F1E2D3C4B5A69788796A5B4C3D2E1F0,NONCE=128'hFFEEDDCCBBAA99887766554433221100;
    localparam [191:0] PT_PADDED=192'h46696E616C20596561722050726F6A656374204152418000;
    localparam PT_BLOCKS=3; localparam [63:0] AAD_PADDED=64'h64656D6F41414480,IV=64'h80400c0600000000;
    localparam [4:0] ST_IDLE=0,ST_ENC_INIT=1,ST_ENC_INIT_PERM=2,ST_ENC_AAD=3,ST_ENC_AAD_PERM=4,
        ST_ENC_AAD_DOM=5,ST_ENC_PT=6,ST_ENC_PT_PERM=7,ST_ENC_FINAL=8,ST_ENC_FINAL_W=9,
        ST_TAG_STORE=10,ST_DEC_INIT=11,ST_DEC_INIT_PERM=12,ST_DEC_AAD=13,ST_DEC_AAD_PERM=14,
        ST_DEC_AAD_DOM=15,ST_DEC_CT=16,ST_DEC_CT_PERM=17,ST_DEC_FINAL=18,ST_DEC_FINAL_W=19,ST_DONE=20;
    reg [4:0] state; reg [3:0] block_idx;
    reg [63:0] s0,s1,s2,s3,s4;
    reg [191:0] ciphertext; reg [127:0] tag_enc; reg [191:0] plaintext_dec;
    reg perm_start; wire perm_done;
    reg [3:0] perm_start_round,perm_num_rounds;
    wire [63:0] po0,po1,po2,po3,po4;
    ascon_perm_encoded pi(.clk(clk),.rst_n(rst_n),.start(perm_start),
        .start_round(perm_start_round),.rounds(perm_num_rounds),
        .s0_in(s0),.s1_in(s1),.s2_in(s2),.s3_in(s3),.s4_in(s4),
        .s0_out(po0),.s1_out(po1),.s2_out(po2),.s3_out(po3),.s4_out(po4),.done(perm_done));
    always @(posedge clk or negedge rst_n) begin
        if(!rst_n) begin state<=0;done<=0;tag_match<=0;perm_start<=0;perm_start_round<=0;perm_num_rounds<=0;block_idx<=0;
            s0<=0;s1<=0;s2<=0;s3<=0;s4<=0;ciphertext<=0;tag_enc<=0;plaintext_dec<=0;
        end else begin perm_start<=0;
            case(state)
                ST_IDLE: begin done<=0;tag_match<=0;if(start) state<=ST_ENC_INIT; end
                ST_ENC_INIT: begin s0<=IV;s1<=KEY[127:64];s2<=KEY[63:0];s3<=NONCE[127:64];s4<=NONCE[63:0];
                    perm_start_round<=0;perm_num_rounds<=12;perm_start<=1;state<=ST_ENC_INIT_PERM; end
                ST_ENC_INIT_PERM: if(perm_done) begin s0<=po0;s1<=po1;s2<=po2;
                    s3<=po3^KEY[127:64];s4<=po4^KEY[63:0];state<=ST_ENC_AAD; end
                ST_ENC_AAD: begin s0<=s0^AAD_PADDED;perm_start_round<=6;perm_num_rounds<=6;perm_start<=1;state<=ST_ENC_AAD_PERM; end
                ST_ENC_AAD_PERM: if(perm_done) begin s0<=po0;s1<=po1;s2<=po2;s3<=po3;s4<=po4;state<=ST_ENC_AAD_DOM; end
                ST_ENC_AAD_DOM: begin s4<=s4^64'h1;block_idx<=0;state<=ST_ENC_PT; end
                ST_ENC_PT: begin
                    if(block_idx<PT_BLOCKS) begin
                        ciphertext[191-block_idx*64-:64]<=s0^PT_PADDED[191-block_idx*64-:64];
                        s0<=s0^PT_PADDED[191-block_idx*64-:64];
                        if(block_idx<PT_BLOCKS-1) begin perm_start_round<=6;perm_num_rounds<=6;perm_start<=1;
                            block_idx<=block_idx+1;state<=ST_ENC_PT_PERM; end else state<=ST_ENC_FINAL;
                    end else state<=ST_ENC_FINAL; end
                ST_ENC_PT_PERM: if(perm_done) begin s0<=po0;s1<=po1;s2<=po2;s3<=po3;s4<=po4;state<=ST_ENC_PT; end
                ST_ENC_FINAL: begin s1<=s1^KEY[127:64];s2<=s2^KEY[63:0];perm_start_round<=0;perm_num_rounds<=12;perm_start<=1;state<=ST_ENC_FINAL_W; end
                ST_ENC_FINAL_W: if(perm_done) begin tag_enc<={po3^KEY[127:64],po4^KEY[63:0]};state<=ST_TAG_STORE; end
                ST_TAG_STORE: state<=ST_DEC_INIT;
                ST_DEC_INIT: begin s0<=IV;s1<=KEY[127:64];s2<=KEY[63:0];s3<=NONCE[127:64];s4<=NONCE[63:0];
                    perm_start_round<=0;perm_num_rounds<=12;perm_start<=1;state<=ST_DEC_INIT_PERM; end
                ST_DEC_INIT_PERM: if(perm_done) begin s0<=po0;s1<=po1;s2<=po2;
                    s3<=po3^KEY[127:64];s4<=po4^KEY[63:0];state<=ST_DEC_AAD; end
                ST_DEC_AAD: begin s0<=s0^AAD_PADDED;perm_start_round<=6;perm_num_rounds<=6;perm_start<=1;state<=ST_DEC_AAD_PERM; end
                ST_DEC_AAD_PERM: if(perm_done) begin s0<=po0;s1<=po1;s2<=po2;s3<=po3;s4<=po4;state<=ST_DEC_AAD_DOM; end
                ST_DEC_AAD_DOM: begin s4<=s4^64'h1;block_idx<=0;state<=ST_DEC_CT; end
                ST_DEC_CT: begin
                    if(block_idx<PT_BLOCKS) begin
                        plaintext_dec[191-block_idx*64-:64]<=s0^ciphertext[191-block_idx*64-:64];
                        s0<=ciphertext[191-block_idx*64-:64];
                        if(block_idx<PT_BLOCKS-1) begin perm_start_round<=6;perm_num_rounds<=6;perm_start<=1;
                            block_idx<=block_idx+1;state<=ST_DEC_CT_PERM; end else state<=ST_DEC_FINAL;
                    end else state<=ST_DEC_FINAL; end
                ST_DEC_CT_PERM: if(perm_done) begin s0<=po0;s1<=po1;s2<=po2;s3<=po3;s4<=po4;state<=ST_DEC_CT; end
                ST_DEC_FINAL: begin s1<=s1^KEY[127:64];s2<=s2^KEY[63:0];perm_start_round<=0;perm_num_rounds<=12;perm_start<=1;state<=ST_DEC_FINAL_W; end
                ST_DEC_FINAL_W: if(perm_done) begin tag_match<=(tag_enc=={po3^KEY[127:64],po4^KEY[63:0]});done<=1;state<=ST_DONE; end
                ST_DONE: ;
                default: state<=ST_IDLE;
            endcase end end
endmodule

//=============================================================================
// ascon_perm_encoded  —  One-hot round-constant selection
// Round counter stored as 12-bit one-hot vector (oh_r[11:0]).
// RC injection: x2_new = x2 XOR (OR of all (oh_r[i] ? {56'd0,RC_i} : 0))
// This is synthesized as 12 parallel AND-gates + OR reduction — no decoder.
//=============================================================================
module ascon_perm_encoded (
    input  wire        clk,rst_n,start,
    input  wire [3:0]  start_round,rounds,
    input  wire [63:0] s0_in,s1_in,s2_in,s3_in,s4_in,
    output reg  [63:0] s0_out,s1_out,s2_out,s3_out,s4_out,
    output reg         done
);
    localparam [1:0] IDLE=2'd0,RUN=2'd1,FINISH=2'd2;
    // 12 round constants as localparams
    localparam [7:0] RC0=8'hf0,RC1=8'he1,RC2=8'hd2,RC3=8'hc3,RC4=8'hb4,RC5=8'ha5;
    localparam [7:0] RC6=8'h96,RC7=8'h87,RC8=8'h78,RC9=8'h69,RC10=8'h5a,RC11=8'h4b;

    reg [1:0] state;
    reg [11:0] oh_r;        // one-hot round register
    reg [11:0] oh_end;      // one-hot end marker
    reg [3:0]  rounds_r;
    reg [63:0] x0,x1,x2,x3,x4;

    // One-hot RC injection: OR of (hot_bit & rc_constant) for each round
    wire [63:0] rc_inject =
        ({64{oh_r[0]}}  & {56'd0,RC0})  | ({64{oh_r[1]}}  & {56'd0,RC1})  |
        ({64{oh_r[2]}}  & {56'd0,RC2})  | ({64{oh_r[3]}}  & {56'd0,RC3})  |
        ({64{oh_r[4]}}  & {56'd0,RC4})  | ({64{oh_r[5]}}  & {56'd0,RC5})  |
        ({64{oh_r[6]}}  & {56'd0,RC6})  | ({64{oh_r[7]}}  & {56'd0,RC7})  |
        ({64{oh_r[8]}}  & {56'd0,RC8})  | ({64{oh_r[9]}}  & {56'd0,RC9})  |
        ({64{oh_r[10]}} & {56'd0,RC10}) | ({64{oh_r[11]}} & {56'd0,RC11});

    // Full round cone using rc_inject instead of decoded rc
    wire [63:0] c0=x0,c1=x1,c2=x2^rc_inject,c3=x3,c4=x4;
    wire [63:0] p0=c0^c1^c2^c3^c4,p1=c1^c2^c3^c4^c0,p2=c2^c3^c4^c0^c1,p3=c3^c4^c0^c1^c2,p4=c4^c0^c1^c2^c3;
    wire [63:0] m0=p4^{p1[0],p1[63:1]},m1=p0^{p2[0],p2[63:1]},m2=p1^{p3[0],p3[63:1]};
    wire [63:0] m3=p2^{p4[0],p4[63:1]},m4=p3^{p0[0],p0[63:1]};
    wire [63:0] t0=c0^m0,t1=c1^m1,t2=c2^m2,t3=c3^m3,t4=c4^m4;
    wire [63:0] u0=~t1&t2,u1=~t2&t3,u2=~t3&t4,u3=~t4&t0,u4=~t0&t1;
    wire [63:0] v0=t0^u0,v1=t1^u1,v2=~(t2^u2),v3=t3^u3,v4=t4^u4;
    wire [63:0] n0=v0^{v0[18:0],v0[63:19]}^{v0[27:0],v0[63:28]};
    wire [63:0] n1=v1^{v1[60:0],v1[63:61]}^{v1[38:0],v1[63:39]};
    wire [63:0] n2=v2^{v2[0],v2[63:1]}^{v2[5:0],v2[63:6]};
    wire [63:0] n3=v3^{v3[9:0],v3[63:10]}^{v3[16:0],v3[63:17]};
    wire [63:0] n4=v4^{v4[6:0],v4[63:7]}^{v4[40:0],v4[63:41]};

    // One-hot shift: advance to next round by rotating oh_r left by 1
    wire [11:0] oh_next = {oh_r[10:0], oh_r[11]};
    // Check if next round exceeds end (oh_r rotated left hits oh_end)
    wire last_round = (oh_r == oh_end);

    always @(posedge clk or negedge rst_n) begin
        if(!rst_n) begin state<=IDLE;done<=0;oh_r<=12'd1;oh_end<=12'd1;rounds_r<=0;
            x0<=0;x1<=0;x2<=0;x3<=0;x4<=0;s0_out<=0;s1_out<=0;s2_out<=0;s3_out<=0;s4_out<=0;
        end else case(state)
            IDLE: begin done<=0;
                if(start) begin
                    x0<=s0_in;x1<=s1_in;x2<=s2_in;x3<=s3_in;x4<=s4_in;
                    // Convert start_round to one-hot seed and set end marker
                    oh_r  <= 12'd1 << start_round;
                    oh_end <= 12'd1 << (start_round + rounds - 1);
                    rounds_r <= rounds;
                    state<=RUN;
                end
            end
            RUN: begin
                x0<=n0;x1<=n1;x2<=n2;x3<=n3;x4<=n4;
                if(last_round) state<=FINISH;
                else oh_r <= oh_next;
            end
            FINISH: begin s0_out<=x0;s1_out<=x1;s2_out<=x2;s3_out<=x3;s4_out<=x4;done<=1;state<=IDLE; end
            default: state<=IDLE;
        endcase
    end
endmodule
