#==============================================================================
# ASCON-128 · Variant: omega
# SDC for Cadence Genus Synthesis
# Architecture: 4-segment unrolled 3-round blocks; 1 cycle per segment
# Fmax: 8 MHz/120 ns   Clocks: pa=12:5   pb=6:3
#==============================================================================
create_clock -period 120.000 -name sys_clk -waveform {0.000 60.0000} [get_ports clk_p]
set_clock_uncertainty -setup 0.200 [get_clocks sys_clk]
set_clock_uncertainty -hold  0.100 [get_clocks sys_clk]
set_clock_transition  -rise  0.100 [get_clocks sys_clk]
set_clock_transition  -fall  0.100 [get_clocks sys_clk]
set_input_delay  -clock sys_clk -max 1.000 [get_ports rst_n]
set_input_delay  -clock sys_clk -min 0.200 [get_ports rst_n]
set_input_delay  -clock sys_clk -max 1.000 [get_ports start]
set_input_delay  -clock sys_clk -min 0.200 [get_ports start]
set_output_delay -clock sys_clk -max 1.000 [get_ports done]
set_output_delay -clock sys_clk -min 0.200 [get_ports done]
set_output_delay -clock sys_clk -max 1.000 [get_ports tag_match]
set_output_delay -clock sys_clk -min 0.200 [get_ports tag_match]
set_output_delay -clock sys_clk -max 1.000 [get_ports led_done]
set_output_delay -clock sys_clk -min 0.200 [get_ports led_done]
set_output_delay -clock sys_clk -max 1.000 [get_ports led_tag_match]
set_output_delay -clock sys_clk -min 0.200 [get_ports led_tag_match]
set_output_delay -clock sys_clk -max 1.000 [get_ports led_running]
set_output_delay -clock sys_clk -min 0.200 [get_ports led_running]
set_output_delay -clock sys_clk -max 1.000 [get_ports led_error]
set_output_delay -clock sys_clk -min 0.200 [get_ports led_error]
set_false_path -from [get_ports rst_n]
set_driving_cell -lib_cell INVX1 -no_design_rule [get_ports {start rst_n}]
set_load 2.0 [get_ports {done tag_match led_done led_tag_match led_running led_error}]
#==============================================================================
# END - ascon128_omega.sdc
#==============================================================================
