#==============================================================================
# ASCON-128  ·  Variant: s-box-elevated
# SDC for Cadence Genus Synthesis
#
# Permutation architecture: 8-stage registered pipeline per round.
#   Each pipeline stage isolates one ASCON sub-step:
#   CONST → THETA_A → THETA_B → THETA_C → CHI1 → CHI2 → LIN1 → LIN2
#
# Timing impact vs baseline:
#   - Critical path per cycle: ~2-4 XOR or 1 AND + 2 XOR levels.
#   - Clock period target: 5.000 ns (200 MHz) — 8× frequency uplift vs baseline
#   - Input/output delays kept at conservative 2.0/0.5 ns for board interface
#   - Multicycle paths: NOT needed — each round sub-stage takes exactly 1 cycle.
#
# Synthesis guidance for Genus:
#   Genus should achieve close to 200 MHz with std-cell XOR2/AND2/INV chains.
#   If targeting 250 MHz+, apply:
#     set_attribute retime true [get_db designs ascon_perm_elevated]
#==============================================================================

#------------------------------------------------------------------------------
# 1. CLOCK DEFINITION
#    200 MHz / 5 ns — elevated pipeline target
#------------------------------------------------------------------------------
create_clock -period 5.000 \
             -name sys_clk \
             -waveform {0.000 2.500} \
             [get_ports clk_p]

#------------------------------------------------------------------------------
# 2. CLOCK UNCERTAINTY
#    Tighter jitter budget expected at 200 MHz.
#------------------------------------------------------------------------------
set_clock_uncertainty -setup 0.150 [get_clocks sys_clk]
set_clock_uncertainty -hold  0.100 [get_clocks sys_clk]

#------------------------------------------------------------------------------
# 3. CLOCK TRANSITION
#    Short edge rate for high-frequency clock.
#------------------------------------------------------------------------------
set_clock_transition -rise 0.050 [get_clocks sys_clk]
set_clock_transition -fall 0.050 [get_clocks sys_clk]

#------------------------------------------------------------------------------
# 4. INPUT DELAYS
#    External I/O still operates at board speed; pads see relaxed constraints.
#    At 5 ns period, 2.0 ns setup + 0.15 uncertainty leaves 2.85 ns internal.
#------------------------------------------------------------------------------
set_input_delay -clock sys_clk -max 2.000 [get_ports rst_n]
set_input_delay -clock sys_clk -min 0.500 [get_ports rst_n]
set_input_delay -clock sys_clk -max 2.000 [get_ports start]
set_input_delay -clock sys_clk -min 0.500 [get_ports start]

#------------------------------------------------------------------------------
# 5. OUTPUT DELAYS
#------------------------------------------------------------------------------
set_output_delay -clock sys_clk -max 2.000 [get_ports done]
set_output_delay -clock sys_clk -min 0.500 [get_ports done]
set_output_delay -clock sys_clk -max 2.000 [get_ports tag_match]
set_output_delay -clock sys_clk -min 0.500 [get_ports tag_match]
set_output_delay -clock sys_clk -max 2.000 [get_ports led_done]
set_output_delay -clock sys_clk -min 0.500 [get_ports led_done]
set_output_delay -clock sys_clk -max 2.000 [get_ports led_tag_match]
set_output_delay -clock sys_clk -min 0.500 [get_ports led_tag_match]
set_output_delay -clock sys_clk -max 2.000 [get_ports led_running]
set_output_delay -clock sys_clk -min 0.500 [get_ports led_running]
set_output_delay -clock sys_clk -max 2.000 [get_ports led_error]
set_output_delay -clock sys_clk -min 0.500 [get_ports led_error]

#------------------------------------------------------------------------------
# 6. ASYNCHRONOUS RESET - FALSE PATH
#------------------------------------------------------------------------------
set_false_path -from [get_ports rst_n]

#------------------------------------------------------------------------------
# 7. PIPELINE STAGE PATH BUDGET
#    All inter-stage paths are single-cycle; no multicycle relaxation needed.
#    Per-stage budget: 5.000 - 0.150 (unc) - 0.050 (transition) = 4.800 ns
#    Heaviest stage is CHI1 (AND + XOR chain); Genus will focus effort there.
#
#    To guide Genus to the critical pipeline stage explicitly:
#------------------------------------------------------------------------------
# set_max_delay 4.800 -from [get_cells {t*_reg*}] -to [get_cells {u*_reg*}]

#------------------------------------------------------------------------------
# 8. RETIMING ENABLE (uncomment for 250 MHz+ targets)
#    Genus retiming can rebalance LIN1/LIN2 stage boundary if needed.
#------------------------------------------------------------------------------
# set_attribute retime true [get_db designs ascon_perm_elevated]

#------------------------------------------------------------------------------
# 9. DRIVING CELL / OUTPUT LOAD
#    High-drive outputs assumed; heavy fan-out on clock tree managed by CTS.
#------------------------------------------------------------------------------
set_driving_cell -no_design_rule [get_ports {start rst_n}]
set_load 5.0 [get_ports {done tag_match led_done led_tag_match led_running led_error}]

#------------------------------------------------------------------------------
# 10. OPERATING CONDITIONS
#     High-performance condition for maximum Fmax synthesis.
#     Uncomment and set library condition as appropriate.
#------------------------------------------------------------------------------
# set_operating_conditions -library <lib> FAST

#==============================================================================
# END - ascon128_elevated.sdc
#==============================================================================
