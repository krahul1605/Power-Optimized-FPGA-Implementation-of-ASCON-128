#==============================================================================
# ASCON-128 - Cadence Genus Synthesis Constraints (SDC)
#
# Converted from: ascon128_VERIFIED.xdc (Vivado/ZCU104 XDC)
# Target Tool   : Cadence Genus Synthesis Solution
#
# Notes:
#   - FPGA-specific commands (PACKAGE_PIN, IOSTANDARD, DRIVE, SLEW,
#     BITSTREAM.*, set_switching_activity, reset_switching_activity)
#     are NOT valid SDC and are omitted.
#   - IBUFDS/BUFG differential clock buffer is assumed to be either
#     instantiated in RTL or mapped by Genus. The clock is defined
#     on the post-buffer internal net [clk]. If your top-level port
#     is still differential (clk_p / clk_n), replace [get_ports clk]
#     with [get_ports clk_p] and Genus will propagate through the IBUFDS.
#   - Clock period : 40.000 ns (25 MHz) - preserved from XDC.
#   - Clock uncertainty: setup 0.500 ns, hold 0.200 ns (from XDC).
#   - rst_n is asynchronous; false path is preserved.
#   - I/O delays are translated directly from the XDC values.
#==============================================================================

#------------------------------------------------------------------------------
# 1. CLOCK DEFINITION
#    Source  : on-board 125 MHz LVDS oscillator, divided constraint -> 25 MHz
#    Period  : 40.000 ns  (= 1/25 MHz)
#    Waveform: rise at 0 ns, fall at 20 ns (50 % duty cycle)
#
#    If your RTL presents a single-ended clock port after IBUFDS (common
#    when the buffer is in RTL), use:
#        create_clock -period 40.000 -name sys_clk \
#                     -waveform {0.000 20.000} [get_ports clk]
#    If the differential pair is the top-level port, use clk_p below.
#------------------------------------------------------------------------------
create_clock -period 40.000 \
             -name sys_clk \
             -waveform {0.000 20.000} \
             [get_ports clk_p]

#------------------------------------------------------------------------------
# 2. CLOCK UNCERTAINTY
#    Accounts for jitter and skew.
#    setup -> 0.500 ns   hold -> 0.200 ns
#------------------------------------------------------------------------------
set_clock_uncertainty -setup 0.500 [get_clocks sys_clk]
set_clock_uncertainty -hold  0.200 [get_clocks sys_clk]

#------------------------------------------------------------------------------
# 3. CLOCK TRANSITION (typical values for ASIC/generic; adjust to library)
#    Genus needs rise/fall transition times on the clock for accurate analysis.
#    0.100 ns is a reasonable default; override with your library's spec.
#------------------------------------------------------------------------------
set_clock_transition -rise 0.100 [get_clocks sys_clk]
set_clock_transition -fall 0.100 [get_clocks sys_clk]

#------------------------------------------------------------------------------
# 4. INPUT DELAYS  (referenced to sys_clk)
#    rst_n : max 2.000 ns, min 0.500 ns
#    start : max 2.000 ns, min 0.500 ns
#
#    Note: rst_n also has a false path (Section 6); the input_delay is kept
#    for completeness but will be overridden by the false path for setup/hold.
#------------------------------------------------------------------------------
set_input_delay -clock sys_clk -max 2.000 [get_ports rst_n]
set_input_delay -clock sys_clk -min 0.500 [get_ports rst_n]

set_input_delay -clock sys_clk -max 2.000 [get_ports start]
set_input_delay -clock sys_clk -min 0.500 [get_ports start]

#------------------------------------------------------------------------------
# 5. OUTPUT DELAYS  (referenced to sys_clk)
#    done        : max 2.000 ns, min 0.500 ns
#    tag_match   : max 2.000 ns, min 0.500 ns
#    led_done    : max 2.000 ns, min 0.500 ns
#    led_tag_match: max 2.000 ns, min 0.500 ns
#    led_running : max 2.000 ns, min 0.500 ns
#    led_error   : max 2.000 ns, min 0.500 ns
#------------------------------------------------------------------------------
set_output_delay -clock sys_clk -max 2.000 [get_ports done]
set_output_delay -clock sys_clk -min 0.500 [get_ports done]

set_output_delay -clock sys_clk -max 2.000 [get_ports tag_match]
set_output_delay -clock sys_clk -min 0.500 [get_ports tag_match]

set_output_delay -clock sys_clk -max 2.000 [get_ports led_done]
set_output_delay -clock sys_clk -min 0.500 [get_ports led_done]

set_output_delay -clock sys_clk -max 2.000 [get_ports led_tag_match]
set_output_delay -clock sys_clk -min 0.500 [get_ports led_tag_match]

set_output_delay -clock sys_clk -max 2.000 [get_ports led_running]
set_output_delay -clock sys_clk -min 0.500 [get_ports led_running]

set_output_delay -clock sys_clk -max 2.000 [get_ports led_error]
set_output_delay -clock sys_clk -min 0.500 [get_ports led_error]

#------------------------------------------------------------------------------
# 6. ASYNCHRONOUS RESET - FALSE PATH
#    rst_n is async; no setup/hold analysis needed on this path.
#------------------------------------------------------------------------------
set_false_path -from [get_ports rst_n]

#------------------------------------------------------------------------------
# 7. INPUT DRIVE STRENGTH  (no external driver spec in XDC; use default)
#    Genus uses this for input transition estimation.
#    Remove or adjust if your testbench / board model specifies a driver.
#------------------------------------------------------------------------------
set_driving_cell -no_design_rule [get_ports {start rst_n}]

#------------------------------------------------------------------------------
# 8. OUTPUT LOAD  (no board capacitance specified in XDC; use typical value)
#    Adjust to match your PCB / package load model (pF).
#------------------------------------------------------------------------------
set_load 5.0 [get_ports {done tag_match led_done led_tag_match led_running led_error}]

#------------------------------------------------------------------------------
# 9. OPERATING CONDITIONS  (uncomment and set to match your target library)
#    set_operating_conditions -library <lib_name> <condition_name>
#------------------------------------------------------------------------------
# set_operating_conditions -library <lib> <condition>

#==============================================================================
# END - ascon128_genus.sdc
#==============================================================================
