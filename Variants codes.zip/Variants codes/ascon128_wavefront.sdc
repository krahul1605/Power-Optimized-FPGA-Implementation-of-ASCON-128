#==============================================================================
# ASCON-128  ·  Variant: wavefront
# SDC for Cadence Genus Synthesis
#
# Permutation architecture: Systolic word-parallel PE array.
#   Five dedicated PEs (one per 64-bit state word x0..x4) execute in four
#   phases per round. Inter-word dependencies are resolved through a
#   registered neighbour bus (nb0..nb4), forming a wavefront data flow:
#
#   WF_CONST  (phase 0): PE_2 XORs round constant locally. 1-2 gate levels.
#   WF_THETA  (phase 1): All 5 PEs compute theta simultaneously using shared
#                        combinational reads of all x*. Critical path:
#                        x*_reg -> 5-input XOR parity tree -> rotate XOR ->
#                        apply XOR -> x*_reg  (~8-10 gate levels)
#   WF_CHI    (phase 2): Each PE reads registered nb* (post-theta x[i+1]) +
#                        live x[i+2] for AND-NOT. Critical path:
#                        nb*_reg + x*_reg -> AND-NOT -> XOR -> x*_reg (~4-5 levels)
#   WF_LINEAR (phase 3): Each PE applies independent rotations. No cross-PE.
#                        Path: x*_reg -> rotate -> XOR -> x*_reg  (~3-4 levels)
#
# The common clock period is sized by the slowest phase: WF_THETA.
# Fmax target: 125 MHz / 8 ns.
#
# Clocks per pa=12 call : 12 × 4 = 48 + 1 FINISH = 49
# Clocks per pb=6  call :  6 × 4 = 24 + 1 FINISH = 25
#
# Synthesis notes:
#   - The five PE logic cones are structurally independent (separate always
#     blocks for each x* register update). Genus may parallelize their
#     placement across LUT columns.
#   - nb0..nb4 are the cross-PE registered buses. These should be in close
#     proximity to the corresponding x* PEs for short routing.
#   - WF_CHI reads both nb* (registered) and x[i+2] (combinational from x*
#     registers). The live x[i+2] read creates a combinational path through
#     the x*_reg directly; this is within the Chi phase budget (~5 ns).
#==============================================================================

#------------------------------------------------------------------------------
# 1. CLOCK DEFINITION
#    125 MHz / 8 ns — wavefront PE array (WF_THETA bottleneck)
#------------------------------------------------------------------------------
create_clock -period 8.000 \
             -name sys_clk \
             -waveform {0.000 4.000} \
             [get_ports clk_p]

#------------------------------------------------------------------------------
# 2. CLOCK UNCERTAINTY
#    Moderate jitter for 125 MHz on ZCU104 LVDS input.
#------------------------------------------------------------------------------
set_clock_uncertainty -setup 0.200 [get_clocks sys_clk]
set_clock_uncertainty -hold  0.100 [get_clocks sys_clk]

#------------------------------------------------------------------------------
# 3. CLOCK TRANSITION
#------------------------------------------------------------------------------
set_clock_transition -rise 0.100 [get_clocks sys_clk]
set_clock_transition -fall 0.100 [get_clocks sys_clk]

#------------------------------------------------------------------------------
# 4. INPUT DELAYS
#------------------------------------------------------------------------------
set_input_delay -clock sys_clk -max 2.000 [get_ports rst_n]
set_input_delay -clock sys_clk -min 0.500 [get_ports rst_n]
set_input_delay -clock sys_clk -max 2.000 [get_ports start]
set_input_delay -clock sys_clk -min 0.500 [get_ports start]

#------------------------------------------------------------------------------
# 5. OUTPUT DELAYS
#------------------------------------------------------------------------------
set_output_delay -clock sys_clk -max 2.000 [get_ports done]
set_output_delay -clock sys_clk -min 0.500 [get_ports done]
set_output_delay -clock sys_clk -max 2.000 [get_ports tag_match]
set_output_delay -clock sys_clk -min 0.500 [get_ports tag_match]
set_output_delay -clock sys_clk -max 2.000 [get_ports led_done]
set_output_delay -clock sys_clk -min 0.500 [get_ports led_done]
set_output_delay -clock sys_clk -max 2.000 [get_ports led_tag_match]
set_output_delay -clock sys_clk -min 0.500 [get_ports led_tag_match]
set_output_delay -clock sys_clk -max 2.000 [get_ports led_running]
set_output_delay -clock sys_clk -min 0.500 [get_ports led_running]
set_output_delay -clock sys_clk -max 2.000 [get_ports led_error]
set_output_delay -clock sys_clk -min 0.500 [get_ports led_error]

#------------------------------------------------------------------------------
# 6. ASYNCHRONOUS RESET - FALSE PATH
#------------------------------------------------------------------------------
set_false_path -from [get_ports rst_n]

#------------------------------------------------------------------------------
# 7. CRITICAL PATH BUDGET
#    WF_THETA phase sizes the period: 8.000 - 0.200 (unc) - 0.100 (trans)
#    = 7.700 ns available for the XOR parity tree + rotation mix + apply.
#    WF_CHI, WF_LINEAR, WF_CONST will have significant positive slack (~4-6 ns).
#
#    Optional: annotate phase-specific budgets for Genus reporting
#    (these are informational, not enforcement constraints)
#------------------------------------------------------------------------------
# set_max_delay 7.700 -from [get_cells {x*_reg*}] -to [get_cells {x*_reg*}]

#------------------------------------------------------------------------------
# 8. NEIGHBOUR BUS PLACEMENT HINT
#    nb0..nb4 are registered copies of adjacent PE state words.
#    They should be co-located with their source x* registers.
#    Use set_multicycle_path only if nb* and x* are physically far apart;
#    the registered read removes the combinational dependency in WF_CHI.
#------------------------------------------------------------------------------
# set_max_delay 5.000 -from [get_cells {nb*_reg*}] -to [get_cells {x*_reg*}]

#------------------------------------------------------------------------------
# 9. DRIVING CELL / OUTPUT LOAD
#------------------------------------------------------------------------------
set_driving_cell -lib_cell INVX1 -no_design_rule [get_ports {start rst_n}]
set_load 5.0 [get_ports {done tag_match led_done led_tag_match led_running led_error}]

#------------------------------------------------------------------------------
# 10. OPERATING CONDITIONS (uncomment and set for target library)
#------------------------------------------------------------------------------
# set_operating_conditions -library <lib> TYPICAL

#==============================================================================
# END - ascon128_wavefront.sdc
#==============================================================================
