#==============================================================================
# ASCON-128  ·  Variant: cascade
# SDC for Cadence Genus Synthesis
#
# Permutation architecture: Two-speed cascaded sub-engines.
#   FAST engine (3 stages/round): rounds where (cnt-start)%3 != 2
#     FC_THETA (Const+Theta fused), FC_CHI, FC_LIN
#     Critical path: FC_THETA ~8-10 gate levels
#   SLOW engine (6 stages/round): rounds where (cnt-start)%3 == 2
#     SC_CONST, SC_THA, SC_THB, SC_THC, SC_CHI, FC_LIN
#     Critical path: SC_THA ~4-6 gate levels (parity only)
#
#   Common clock period sized by FAST engine FC_THETA bottleneck.
#   Fmax target: 100 MHz / 10 ns
#
# Clocks pa=12: (8 fast × 3) + (4 slow × 6) = 48 + 1 = 49
# Clocks pb=6 : (4 fast × 3) + (2 slow × 6) = 24 + 1 = 25
#==============================================================================
create_clock -period 10.000 -name sys_clk -waveform {0.000 5.000} [get_ports clk_p]
set_clock_uncertainty -setup 0.200 [get_clocks sys_clk]
set_clock_uncertainty -hold  0.100 [get_clocks sys_clk]
set_clock_transition -rise 0.100 [get_clocks sys_clk]
set_clock_transition -fall 0.100 [get_clocks sys_clk]
set_input_delay -clock sys_clk -max 2.000 [get_ports rst_n]
set_input_delay -clock sys_clk -min 0.500 [get_ports rst_n]
set_input_delay -clock sys_clk -max 2.000 [get_ports start]
set_input_delay -clock sys_clk -min 0.500 [get_ports start]
set_output_delay -clock sys_clk -max 2.000 [get_ports done]
set_output_delay -clock sys_clk -min 0.500 [get_ports done]
set_output_delay -clock sys_clk -max 2.000 [get_ports tag_match]
set_output_delay -clock sys_clk -min 0.500 [get_ports tag_match]
set_output_delay -clock sys_clk -max 2.000 [get_ports led_done]
set_output_delay -clock sys_clk -min 0.500 [get_ports led_done]
set_output_delay -clock sys_clk -max 2.000 [get_ports led_tag_match]
set_output_delay -clock sys_clk -min 0.500 [get_ports led_tag_match]
set_output_delay -clock sys_clk -max 2.000 [get_ports led_running]
set_output_delay -clock sys_clk -min 0.500 [get_ports led_running]
set_output_delay -clock sys_clk -max 2.000 [get_ports led_error]
set_output_delay -clock sys_clk -min 0.500 [get_ports led_error]
set_false_path -from [get_ports rst_n]
set_driving_cell -lib_cell INVX1 -no_design_rule [get_ports {start rst_n}]
set_load 5.0 [get_ports {done tag_match led_done led_tag_match led_running led_error}]
# set_operating_conditions -library <lib> TYPICAL
#==============================================================================
# END - ascon128_cascade.sdc
#==============================================================================
