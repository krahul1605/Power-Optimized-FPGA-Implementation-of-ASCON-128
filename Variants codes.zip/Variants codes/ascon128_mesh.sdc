#==============================================================================
# ASCON-128 · Variant: mesh
# SDC for Cadence Genus Synthesis
# Architecture: 2D mesh compute+exchange 2-phase; round result passes through registered bus
# Fmax: 25 MHz/40 ns   Clocks: pa=12:25  pb=6:13
#==============================================================================
create_clock -period 40.000 -name sys_clk -waveform {0.000 20.0000} [get_ports clk_p]
set_clock_uncertainty -setup 0.200 [get_clocks sys_clk]
set_clock_uncertainty -hold  0.100 [get_clocks sys_clk]
set_clock_transition  -rise  0.100 [get_clocks sys_clk]
set_clock_transition  -fall  0.100 [get_clocks sys_clk]
set_input_delay  -clock sys_clk -max 1.000 [get_ports rst_n]
set_input_delay  -clock sys_clk -min 0.200 [get_ports rst_n]
set_input_delay  -clock sys_clk -max 1.000 [get_ports start]
set_input_delay  -clock sys_clk -min 0.200 [get_ports start]
set_output_delay -clock sys_clk -max 1.000 [get_ports done]
set_output_delay -clock sys_clk -min 0.200 [get_ports done]
set_output_delay -clock sys_clk -max 1.000 [get_ports tag_match]
set_output_delay -clock sys_clk -min 0.200 [get_ports tag_match]
set_output_delay -clock sys_clk -max 1.000 [get_ports led_done]
set_output_delay -clock sys_clk -min 0.200 [get_ports led_done]
set_output_delay -clock sys_clk -max 1.000 [get_ports led_tag_match]
set_output_delay -clock sys_clk -min 0.200 [get_ports led_tag_match]
set_output_delay -clock sys_clk -max 1.000 [get_ports led_running]
set_output_delay -clock sys_clk -min 0.200 [get_ports led_running]
set_output_delay -clock sys_clk -max 1.000 [get_ports led_error]
set_output_delay -clock sys_clk -min 0.200 [get_ports led_error]
set_false_path -from [get_ports rst_n]
set_driving_cell -lib_cell INVX1 -no_design_rule [get_ports {start rst_n}]
set_load 2.0 [get_ports {done tag_match led_done led_tag_match led_running led_error}]
#==============================================================================
# END - ascon128_mesh.sdc
#==============================================================================
