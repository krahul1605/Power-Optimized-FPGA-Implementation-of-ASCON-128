#==============================================================================
# actual_baseline.sdc
# Target Design : ascon128_top_menu
# Target Board  : Xilinx ZCU104  (Zynq UltraScale+)
# Synthesis Tool: Cadence Genus 21.x  /  Red Hat  /  45nm gsclib
#
# Clock Architecture (from RTL ascon128_top_menu.v):
#   Primary input  : 125 MHz LVDS differential  ->  clk_p / clk_n
#   IBUFDS         : clk_p/clk_n  ->  clk_ibuf
#   MMCME4_BASE    : CLKFBOUT_MULT_F=8.0, CLKIN1_PERIOD=8.0,
#                    CLKOUT0_DIVIDE_F=40.0, DIVCLK_DIVIDE=1
#                    VCO = 125 * 8 / 1 = 1000 MHz
#                    CLKOUT0 = 1000 / 40 = 25 MHz  (40.000 ns)
#   BUFG           : clk_25mhz  ->  clk   (system clock driving all logic)
#
# All design logic is clocked by the 25 MHz BUFG output.
# The 125 MHz input is constrained only to pass MMCM jitter checks.
#
# Top-level ports (from ascon128_top_menu.v + ascon128_top_menu_zcu104.xdc):
#   Inputs  : clk_p, clk_n, rst_n, uart_rx
#   Outputs : uart_tx, led_done, led_tag_match, led_running,
#             led_error, led_waiting, led_computing
#
# Fix applied: set_driving_cell -lib_cell INVX1  (Genus SDC-203 fix)
#==============================================================================


#------------------------------------------------------------------------------
# 1. PRIMARY CLOCK — 125 MHz LVDS input (Bank 28, F23/E23)
#    Period = 8.000 ns  |  Waveform: rise 0.000, fall 4.000 ns
#    This clock is consumed only by the MMCM; all downstream logic sees 25 MHz.
#------------------------------------------------------------------------------
create_clock -period 8.000 \
             -name clk_125mhz \
             -waveform {0.000 4.000} \
             [get_ports clk_p]

#------------------------------------------------------------------------------
# 2. GENERATED CLOCK — 25 MHz MMCM output (system clock for all logic)
#
#    MMCM parameters:
#      CLKFBOUT_MULT_F = 8.0
#      CLKIN1_PERIOD   = 8.0 ns
#      CLKOUT0_DIVIDE_F = 40.0
#      DIVCLK_DIVIDE   = 1
#    => CLKOUT0 = (125 MHz * 8.0) / (1 * 40.0) = 25 MHz  (40.000 ns)
#
#    Source: clk_p (through IBUFDS + MMCM + BUFG).
#    This is the clock that drives the ASCON core, UART controller,
#    TRNG, and all registered logic in the design.
#------------------------------------------------------------------------------
create_generated_clock -name clk_25mhz \
    -source      [get_ports clk_p] \
    -multiply_by 8 \
    -divide_by   40 \
    -master_clock clk_125mhz \
    [get_pins mmcm_inst/CLKOUT0]

#------------------------------------------------------------------------------
# 3. CLOCK UNCERTAINTY — 25 MHz system clock
#
#    At 25 MHz (40 ns period) jitter budget is generous.
#    MMCM output jitter (UltraScale+ PLL spec): ~50–80 ps typical.
#    Setup margin: 0.500 ns  (conservative; leaves 39.3 ns for logic)
#    Hold  margin: 0.200 ns
#------------------------------------------------------------------------------
set_clock_uncertainty -setup 0.500 [get_clocks clk_25mhz]
set_clock_uncertainty -hold  0.200 [get_clocks clk_25mhz]

#------------------------------------------------------------------------------
# 4. CLOCK UNCERTAINTY — 125 MHz input clock
#    Board-level LVDS clock from ZCU104 oscillator.
#    Typical board jitter: ~100–150 ps.
#------------------------------------------------------------------------------
set_clock_uncertainty -setup 0.200 [get_clocks clk_125mhz]
set_clock_uncertainty -hold  0.100 [get_clocks clk_125mhz]

#------------------------------------------------------------------------------
# 5. CLOCK TRANSITION — source and generated clocks
#    LVDS edge rate: ~0.100 ns (fast differential signalling)
#    BUFG output  : ~0.100 ns at 25 MHz
#------------------------------------------------------------------------------
set_clock_transition -rise 0.100 [get_clocks clk_125mhz]
set_clock_transition -fall 0.100 [get_clocks clk_125mhz]

set_clock_transition -rise 0.100 [get_clocks clk_25mhz]
set_clock_transition -fall 0.100 [get_clocks clk_25mhz]

#------------------------------------------------------------------------------
# 6. INPUT DELAYS — synchronous inputs relative to clk_25mhz
#
#    rst_n   : CPU_RESET SW20  (Bank 87, LVCMOS33, M11)
#              Active-HIGH push-button.  Treated as asynchronous by RTL
#              (rst_int_n = (~rst_n) & clk_locked).  Input delay specified
#              conservatively; false path exception applied below (§10).
#
#    uart_rx : UART2_TXD_FPGA_RXD  (Bank 28, LVCMOS18, A20)
#              Asynchronous serial data from CP2108 USB bridge.
#              False path exception applied below (§10).
#              Input delay specified for completeness; Genus will not
#              optimise this path after false_path annotation.
#
#    At 40 ns period with 2.0 ns max input delay and 0.5 ns uncertainty:
#      Internal setup budget = 40.0 - 2.0 - 0.5 = 37.5 ns  (very relaxed)
#------------------------------------------------------------------------------
set_input_delay -clock clk_25mhz -max 2.000 [get_ports rst_n]
set_input_delay -clock clk_25mhz -min 0.500 [get_ports rst_n]

set_input_delay -clock clk_25mhz -max 2.000 [get_ports uart_rx]
set_input_delay -clock clk_25mhz -min 0.500 [get_ports uart_rx]

#------------------------------------------------------------------------------
# 7. OUTPUT DELAYS — all outputs relative to clk_25mhz
#
#    uart_tx      : UART2_RXD_FPGA_TXD (Bank 28, LVCMOS18, C19)
#                   Serial output to CP2108 bridge.
#                   Asynchronous; false path exception applied below (§10).
#
#    led_done     : GPIO_LED_0_LS (Bank 88, LVCMOS33, D5)
#    led_tag_match: GPIO_LED_1_LS (Bank 88, LVCMOS33, D6)
#    led_running  : GPIO_LED_2_LS (Bank 88, LVCMOS33, A5)
#    led_error    : GPIO_LED_3_LS (Bank 88, LVCMOS33, B5)
#    led_waiting  : GPIO_DIP_SW0  (Bank 88, LVCMOS33, E4)
#    led_computing: GPIO_DIP_SW1  (Bank 88, LVCMOS33, D4)
#                   All LED outputs are slow human-readable indicators.
#                   False path exceptions applied below (§10).
#
#    Output delays set to standard board values; false paths below override
#    timing analysis so these values are for documentation only.
#------------------------------------------------------------------------------
set_output_delay -clock clk_25mhz -max 2.000 [get_ports uart_tx]
set_output_delay -clock clk_25mhz -min 0.500 [get_ports uart_tx]

set_output_delay -clock clk_25mhz -max 2.000 [get_ports led_done]
set_output_delay -clock clk_25mhz -min 0.500 [get_ports led_done]

set_output_delay -clock clk_25mhz -max 2.000 [get_ports led_tag_match]
set_output_delay -clock clk_25mhz -min 0.500 [get_ports led_tag_match]

set_output_delay -clock clk_25mhz -max 2.000 [get_ports led_running]
set_output_delay -clock clk_25mhz -min 0.500 [get_ports led_running]

set_output_delay -clock clk_25mhz -max 2.000 [get_ports led_error]
set_output_delay -clock clk_25mhz -min 0.500 [get_ports led_error]

set_output_delay -clock clk_25mhz -max 2.000 [get_ports led_waiting]
set_output_delay -clock clk_25mhz -min 0.500 [get_ports led_waiting]

set_output_delay -clock clk_25mhz -max 2.000 [get_ports led_computing]
set_output_delay -clock clk_25mhz -min 0.500 [get_ports led_computing]

#------------------------------------------------------------------------------
# 8. DRIVING CELL / OUTPUT LOAD
#
#    Driving cell: INVX1 from gsclib045 (required by Genus common_ui; SDC-203 fix).
#    Applied to the two functional inputs: rst_n and uart_rx.
#    clk_p/clk_n are differential and handled by the IBUFDS model — no
#    set_driving_cell required for differential clock ports.
#
#    Output load: 5.0 fF representative board trace + LED driver.
#    Applied to all driven outputs.
#------------------------------------------------------------------------------
set_driving_cell -lib_cell INVX1 -no_design_rule [get_ports {rst_n uart_rx}]

set_load 5.0 [get_ports {uart_tx
                         led_done led_tag_match led_running led_error
                         led_waiting led_computing}]

#------------------------------------------------------------------------------
# 9. MULTICYCLE PATH — ASCON permutation core
#
#    The ASCON permutation (ascon_perm_fast in ascon_permutation.v) is a
#    4-stage registered pipeline (CONST -> SBOX -> CHI -> LINEAR per round).
#    The permutation accepts a new 'start' pulse and runs autonomously for
#    12 rounds (pa) or 6 rounds (pb), signalling completion via 'done'.
#    The FSM in ascon128_complete_uart waits for done before proceeding;
#    there are no multicycle paths between the permutation and the FSM.
#
#    All register-to-register paths within the permutation pipeline are
#    single-cycle at 25 MHz (40 ns budget).  No multicycle relaxation needed.
#
#    UART baud rate reference:
#      CLK_FREQ = 25 000 000 Hz,  BAUD_RATE = 115 200 bps
#      CLKS_PER_BIT = 25 000 000 / 115 200 = 217 clocks/bit
#    UART state machine (uart_rx, uart_tx, uart_controller_menu) operates
#    on single-cycle register boundaries at 25 MHz; no multicycle needed.
#------------------------------------------------------------------------------
# No multicycle path constraints required for this design.

#------------------------------------------------------------------------------
# 10. FALSE PATHS — asynchronous and non-timing-critical signals
#
#    a) rst_n: Push-button input is asynchronous to the clock domain.
#       RTL uses: rst_int_n = (~rst_n) & clk_locked
#       The synthesis tool should not attempt to meet setup/hold on this path.
#
#    b) uart_rx: Asynchronous serial input. The uart_rx module uses a 2-FF
#       synchroniser internally (rx_sync1, rx_sync2). The pin-to-FF1 path
#       is asynchronous; false-path annotation prevents incorrect analysis.
#
#    c) uart_tx: Asynchronous serial output. Output is driven combinationally
#       or with a register inside uart_tx; the pad-to-board path has no
#       board-level setup/hold requirement.
#
#    d) LED outputs: All LEDs (led_done, led_tag_match, led_running,
#       led_error, led_waiting, led_computing) are human-readable status
#       indicators with no timing-critical destination on the board.
#
#    These annotations match the false_path directives in the XDC file.
#------------------------------------------------------------------------------
set_false_path -from [get_ports rst_n]

set_false_path -from [get_ports uart_rx]
set_false_path -to   [get_ports uart_tx]

set_false_path -to   [get_ports led_done]
set_false_path -to   [get_ports led_tag_match]
set_false_path -to   [get_ports led_running]
set_false_path -to   [get_ports led_error]
set_false_path -to   [get_ports led_waiting]
set_false_path -to   [get_ports led_computing]

#------------------------------------------------------------------------------
# 11. CLOCK DOMAIN CROSSING — MMCM LOCKED signal
#
#    The clk_locked signal from MMCME4_BASE is used in the reset network:
#      rst_int_n = (~rst_active) & clk_locked
#    This is a quasi-static signal (only changes during MMCM lock/unlock).
#    It is treated as part of the asynchronous reset path and covered by
#    the false_path on rst_n above (rst_int_n is derived combinationally).
#    No additional constraint needed.
#------------------------------------------------------------------------------

#==============================================================================
# END - actual_baseline.sdc
#
# Port-to-constraint mapping summary:
#   clk_p           -> create_clock (125 MHz primary)
#   clk_n           -> paired with clk_p (differential, no separate constraint)
#   MMCM CLKOUT0    -> create_generated_clock (25 MHz system clock)
#   rst_n           -> input_delay + false_path (asynchronous reset)
#   uart_rx         -> input_delay + false_path (async serial input)
#   uart_tx         -> output_delay + false_path (async serial output)
#   led_*  (x6)     -> output_delay + false_path (slow status outputs)
#==============================================================================
