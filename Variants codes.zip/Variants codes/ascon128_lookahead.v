`timescale 1ns / 1ps
//=============================================================================
// ASCON-128  ·  Variant: lookahead
//
// Visual treatment : Speculative lookahead pipeline — while the current round
//                    result is being registered, the combinational logic for
//                    the NEXT round is simultaneously computed speculatively
//                    from the (not-yet-committed) current output. The speculative
//                    next-round result is stored in a shadow register set
//                    (sx0..sx4). On the following cycle, the shadow result is
//                    directly committed as the new state without re-computing.
//
//                    Two-state register model:
//                      Main state  (x0..x4):    committed, current round result
//                      Shadow state (sx0..sx4): speculative, next-round result
//
//                    Execution pattern (steady state):
//                      Cycle N  : commit n* to x*; simultaneously compute
//                                 next round's result from n* into sx*
//                      Cycle N+1: commit sx* to x* (copy, no re-compute);
//                                 simultaneously compute NEXT round from sx*
//                                 into new sx*
//
//                    This creates a 2-deep speculative pipeline where:
//                      - Main state x* advances every cycle (same as baseline)
//                      - Shadow state sx* is ALWAYS one round ahead of x*
//                      - The "compute" and "commit" phases overlap: while
//                        current round commits, next round is already done
//
//                    Structural novelty: the combinational round logic runs
//                    continuously on BOTH x* and sx*:
//                      - Round cone A: driven from x* → produces round(x*) → feeds sx*
//                      - Round cone B: driven from sx* → produces round(sx*) → feeds nx*
//                    Every cycle, both cones are active. The FSM alternates
//                    which cone's output is committed:
//                      LA_RUN_A: commit cone_A output to x*; shadow uses cone_A
//                      LA_RUN_B: commit sx* (=cone_A from prev cycle) to x*;
//                                shadow advances using cone_B
//
//                    In practice, with a SINGLE-TOKEN design (no new rounds
//                    injected from outside while permutation runs), the
//                    lookahead pre-computes every round 1 cycle early.
//                    The effective latency is unchanged (12+1 or 6+1 clocks)
//                    because the speculative compute occupies the same cycle
//                    as the commit. However, the COMBINATIONAL DEPTH per cycle
//                    now covers TWO complete rounds (the current commit + the
//                    next speculative round), doubling the critical path to
//                    ~70-90 gate levels.
//
//                    This means Fmax is approximately HALF of baseline.
//                    The interest is purely structural/architectural: two
//                    independent full-round cones are instantiated and both
//                    active every cycle.
//
// Clocks per pa=12 call : 12 + 1 FINISH = 13 (same as baseline)
// Clocks per pb=6  call :  6 + 1 FINISH =  7 (same as baseline)
// Fmax target: 12 MHz / 80 ns (two full round cones in series)
//
// Note: The combinational depth is intentionally deep. This variant
// demonstrates the extreme end of the latency vs. frequency trade-off.
//=============================================================================

module ascon128_top (
    input  wire clk_p, clk_n, rst_n, start,
    output wire done, tag_match,
    output wire led_done, led_tag_match, led_running, led_error
);
    wire clk_ibuf, clk;
    IBUFDS #(.DIFF_TERM("FALSE"),.IBUF_LOW_PWR("FALSE"),.IOSTANDARD("LVDS"))
        clk_ibufds(.I(clk_p),.IB(clk_n),.O(clk_ibuf));
    BUFG clk_bufg(.I(clk_ibuf),.O(clk));
    wire core_done, core_tag_match;
    reg  running_r;
    ascon128_complete_lookahead ascon_core(.clk(clk),.rst_n(rst_n),.start(start),
        .done(core_done),.tag_match(core_tag_match));
    assign done=core_done; assign tag_match=core_tag_match;
    always @(posedge clk or negedge rst_n)
        if(!rst_n) running_r<=0;
        else if(start) running_r<=1;
        else if(core_done) running_r<=0;
    assign led_done=core_done; assign led_tag_match=core_done&core_tag_match;
    assign led_running=running_r; assign led_error=core_done&~core_tag_match;
endmodule

module ascon128_complete_lookahead (
    input  wire clk, rst_n, start,
    output reg  done, tag_match
);
    localparam [127:0] KEY   = 128'h0F1E2D3C4B5A69788796A5B4C3D2E1F0;
    localparam [127:0] NONCE = 128'hFFEEDDCCBBAA99887766554433221100;
    localparam [191:0] PT_PADDED  = 192'h46696E616C20596561722050726F6A656374204152418000;
    localparam         PT_BLOCKS  = 3;
    localparam [63:0]  AAD_PADDED = 64'h64656D6F41414480;
    localparam [63:0]  IV         = 64'h80400c0600000000;
    localparam [4:0]
        ST_IDLE=0,ST_ENC_INIT=1,ST_ENC_INIT_PERM=2,ST_ENC_AAD=3,ST_ENC_AAD_PERM=4,
        ST_ENC_AAD_DOM=5,ST_ENC_PT=6,ST_ENC_PT_PERM=7,ST_ENC_FINAL=8,ST_ENC_FINAL_W=9,
        ST_TAG_STORE=10,ST_DEC_INIT=11,ST_DEC_INIT_PERM=12,ST_DEC_AAD=13,
        ST_DEC_AAD_PERM=14,ST_DEC_AAD_DOM=15,ST_DEC_CT=16,ST_DEC_CT_PERM=17,
        ST_DEC_FINAL=18,ST_DEC_FINAL_W=19,ST_DONE=20;
    reg [4:0] state; reg [3:0] block_idx;
    reg [63:0] s0,s1,s2,s3,s4;
    reg [191:0] ciphertext; reg [127:0] tag_enc; reg [191:0] plaintext_dec;
    reg perm_start; wire perm_done;
    reg [3:0] perm_start_round, perm_num_rounds;
    wire [63:0] perm_out0,perm_out1,perm_out2,perm_out3,perm_out4;
    ascon_perm_lookahead perm_inst(
        .clk(clk),.rst_n(rst_n),.start(perm_start),
        .start_round(perm_start_round),.rounds(perm_num_rounds),
        .s0_in(s0),.s1_in(s1),.s2_in(s2),.s3_in(s3),.s4_in(s4),
        .s0_out(perm_out0),.s1_out(perm_out1),.s2_out(perm_out2),
        .s3_out(perm_out3),.s4_out(perm_out4),.done(perm_done));
    always @(posedge clk or negedge rst_n) begin
        if(!rst_n) begin
            state<=0;done<=0;tag_match<=0;perm_start<=0;
            perm_start_round<=0;perm_num_rounds<=0;block_idx<=0;
            s0<=0;s1<=0;s2<=0;s3<=0;s4<=0;ciphertext<=0;tag_enc<=0;plaintext_dec<=0;
        end else begin
            perm_start<=0;
            case(state)
                ST_IDLE: begin done<=0;tag_match<=0;if(start) state<=ST_ENC_INIT; end
                ST_ENC_INIT: begin s0<=IV;s1<=KEY[127:64];s2<=KEY[63:0];s3<=NONCE[127:64];s4<=NONCE[63:0];
                    perm_start_round<=0;perm_num_rounds<=12;perm_start<=1;state<=ST_ENC_INIT_PERM; end
                ST_ENC_INIT_PERM: if(perm_done) begin s0<=perm_out0;s1<=perm_out1;s2<=perm_out2;
                    s3<=perm_out3^KEY[127:64];s4<=perm_out4^KEY[63:0];state<=ST_ENC_AAD; end
                ST_ENC_AAD: begin s0<=s0^AAD_PADDED;perm_start_round<=6;perm_num_rounds<=6;
                    perm_start<=1;state<=ST_ENC_AAD_PERM; end
                ST_ENC_AAD_PERM: if(perm_done) begin s0<=perm_out0;s1<=perm_out1;s2<=perm_out2;
                    s3<=perm_out3;s4<=perm_out4;state<=ST_ENC_AAD_DOM; end
                ST_ENC_AAD_DOM: begin s4<=s4^64'h1;block_idx<=0;state<=ST_ENC_PT; end
                ST_ENC_PT: begin
                    if(block_idx<PT_BLOCKS) begin
                        ciphertext[191-block_idx*64-:64]<=s0^PT_PADDED[191-block_idx*64-:64];
                        s0<=s0^PT_PADDED[191-block_idx*64-:64];
                        if(block_idx<PT_BLOCKS-1) begin perm_start_round<=6;perm_num_rounds<=6;
                            perm_start<=1;block_idx<=block_idx+1;state<=ST_ENC_PT_PERM;
                        end else state<=ST_ENC_FINAL;
                    end else state<=ST_ENC_FINAL; end
                ST_ENC_PT_PERM: if(perm_done) begin s0<=perm_out0;s1<=perm_out1;s2<=perm_out2;
                    s3<=perm_out3;s4<=perm_out4;state<=ST_ENC_PT; end
                ST_ENC_FINAL: begin s1<=s1^KEY[127:64];s2<=s2^KEY[63:0];
                    perm_start_round<=0;perm_num_rounds<=12;perm_start<=1;state<=ST_ENC_FINAL_W; end
                ST_ENC_FINAL_W: if(perm_done) begin tag_enc<={perm_out3^KEY[127:64],perm_out4^KEY[63:0]};
                    state<=ST_TAG_STORE; end
                ST_TAG_STORE: state<=ST_DEC_INIT;
                ST_DEC_INIT: begin s0<=IV;s1<=KEY[127:64];s2<=KEY[63:0];s3<=NONCE[127:64];s4<=NONCE[63:0];
                    perm_start_round<=0;perm_num_rounds<=12;perm_start<=1;state<=ST_DEC_INIT_PERM; end
                ST_DEC_INIT_PERM: if(perm_done) begin s0<=perm_out0;s1<=perm_out1;s2<=perm_out2;
                    s3<=perm_out3^KEY[127:64];s4<=perm_out4^KEY[63:0];state<=ST_DEC_AAD; end
                ST_DEC_AAD: begin s0<=s0^AAD_PADDED;perm_start_round<=6;perm_num_rounds<=6;
                    perm_start<=1;state<=ST_DEC_AAD_PERM; end
                ST_DEC_AAD_PERM: if(perm_done) begin s0<=perm_out0;s1<=perm_out1;s2<=perm_out2;
                    s3<=perm_out3;s4<=perm_out4;state<=ST_DEC_AAD_DOM; end
                ST_DEC_AAD_DOM: begin s4<=s4^64'h1;block_idx<=0;state<=ST_DEC_CT; end
                ST_DEC_CT: begin
                    if(block_idx<PT_BLOCKS) begin
                        plaintext_dec[191-block_idx*64-:64]<=s0^ciphertext[191-block_idx*64-:64];
                        s0<=ciphertext[191-block_idx*64-:64];
                        if(block_idx<PT_BLOCKS-1) begin perm_start_round<=6;perm_num_rounds<=6;
                            perm_start<=1;block_idx<=block_idx+1;state<=ST_DEC_CT_PERM;
                        end else state<=ST_DEC_FINAL;
                    end else state<=ST_DEC_FINAL; end
                ST_DEC_CT_PERM: if(perm_done) begin s0<=perm_out0;s1<=perm_out1;s2<=perm_out2;
                    s3<=perm_out3;s4<=perm_out4;state<=ST_DEC_CT; end
                ST_DEC_FINAL: begin s1<=s1^KEY[127:64];s2<=s2^KEY[63:0];
                    perm_start_round<=0;perm_num_rounds<=12;perm_start<=1;state<=ST_DEC_FINAL_W; end
                ST_DEC_FINAL_W: if(perm_done) begin
                    tag_match<=(tag_enc=={perm_out3^KEY[127:64],perm_out4^KEY[63:0]});
                    done<=1;state<=ST_DONE; end
                ST_DONE: ;
                default: state<=ST_IDLE;
            endcase
        end
    end
endmodule

//=============================================================================
// ascon_perm_lookahead
//
// Two independent full-round combinational cones run in parallel each cycle:
//
//   Cone A: driven from x0..x4 with round constant rc_a (current round)
//           → produces n_a0..n_a4 (current round result)
//
//   Cone B: driven from shadow sx0..sx4 with rc_b (next round constant)
//           → produces n_b0..n_b4 (speculative NEXT round result)
//
// Cycle N operation:
//   1. x* is committed from previous cycle's shadow (sx* → x*)
//   2. Cone A runs on new x* to produce round N output
//   3. Simultaneously cone B runs on cone A's output (combinationally chained!)
//      to produce round N+1 speculatively into sx*
//
// Since cones are chained (B reads from A's combinational output, not from
// registered x*), the critical path is: x*_reg → ConeA → ConeB → sx*_reg
// = 2 × full_round_depth ≈ 70-90 gate levels.
//
// The CORRECT round counter management:
//   round_cnt: tracks which round cone A is computing
//   On each cycle: round_cnt advances by 1; cone A uses rc[round_cnt];
//                  cone B speculatively uses rc[round_cnt+1]
//=============================================================================
module ascon_perm_lookahead (
    input  wire        clk, rst_n, start,
    input  wire [3:0]  start_round, rounds,
    input  wire [63:0] s0_in,s1_in,s2_in,s3_in,s4_in,
    output reg  [63:0] s0_out,s1_out,s2_out,s3_out,s4_out,
    output reg         done
);
    localparam [1:0] IDLE=2'd0, RUN=2'd1, FINISH=2'd2;

    reg [1:0] state;
    reg [3:0] round_cnt, round_end;

    // Committed state
    reg [63:0] x0,x1,x2,x3,x4;

    // Shadow (speculative next-round) state
    (* keep = "true" *) reg [63:0] sx0,sx1,sx2,sx3,sx4;

    // Round constant for current round (cone A)
    reg [7:0] rc_a;
    always @(*) case(round_cnt)
        4'd0:rc_a=8'hf0; 4'd1:rc_a=8'he1; 4'd2:rc_a=8'hd2; 4'd3:rc_a=8'hc3;
        4'd4:rc_a=8'hb4; 4'd5:rc_a=8'ha5; 4'd6:rc_a=8'h96; 4'd7:rc_a=8'h87;
        4'd8:rc_a=8'h78; 4'd9:rc_a=8'h69; 4'd10:rc_a=8'h5a; 4'd11:rc_a=8'h4b;
        default:rc_a=8'h00;
    endcase

    // Round constant for NEXT round (cone B, speculative)
    wire [3:0] next_round = (round_cnt < round_end-1) ? round_cnt+4'd1 : 4'd0;
    reg [7:0] rc_b;
    always @(*) case(next_round)
        4'd0:rc_b=8'hf0; 4'd1:rc_b=8'he1; 4'd2:rc_b=8'hd2; 4'd3:rc_b=8'hc3;
        4'd4:rc_b=8'hb4; 4'd5:rc_b=8'ha5; 4'd6:rc_b=8'h96; 4'd7:rc_b=8'h87;
        4'd8:rc_b=8'h78; 4'd9:rc_b=8'h69; 4'd10:rc_b=8'h5a; 4'd11:rc_b=8'h4b;
        default:rc_b=8'h00;
    endcase

    // =========================================================================
    // CONE A: full round on committed x* with rc_a
    // =========================================================================
    wire [63:0] ac0=x0,ac1=x1,ac2=x2^{56'd0,rc_a},ac3=x3,ac4=x4;
    wire [63:0] ap0=ac0^ac1^ac2^ac3^ac4,ap1=ac1^ac2^ac3^ac4^ac0;
    wire [63:0] ap2=ac2^ac3^ac4^ac0^ac1,ap3=ac3^ac4^ac0^ac1^ac2,ap4=ac4^ac0^ac1^ac2^ac3;
    wire [63:0] am0=ap4^{ap1[0],ap1[63:1]},am1=ap0^{ap2[0],ap2[63:1]};
    wire [63:0] am2=ap1^{ap3[0],ap3[63:1]},am3=ap2^{ap4[0],ap4[63:1]};
    wire [63:0] am4=ap3^{ap0[0],ap0[63:1]};
    wire [63:0] at0=ac0^am0,at1=ac1^am1,at2=ac2^am2,at3=ac3^am3,at4=ac4^am4;
    wire [63:0] au0=~at1&at2,au1=~at2&at3,au2=~at3&at4,au3=~at4&at0,au4=~at0&at1;
    wire [63:0] av0=at0^au0,av1=at1^au1,av2=~(at2^au2),av3=at3^au3,av4=at4^au4;
    wire [63:0] an0=av0^{av0[18:0],av0[63:19]}^{av0[27:0],av0[63:28]};
    wire [63:0] an1=av1^{av1[60:0],av1[63:61]}^{av1[38:0],av1[63:39]};
    wire [63:0] an2=av2^{av2[0],   av2[63:1]} ^{av2[5:0], av2[63:6]};
    wire [63:0] an3=av3^{av3[9:0], av3[63:10]}^{av3[16:0],av3[63:17]};
    wire [63:0] an4=av4^{av4[6:0], av4[63:7]} ^{av4[40:0],av4[63:41]};

    // =========================================================================
    // CONE B: full round on CONE A OUTPUT (an*) with rc_b — CHAINED, NOT REGISTERED
    // This is the speculative lookahead: 2 rounds in one combinational cone
    // =========================================================================
    wire [63:0] bc0=an0,bc1=an1,bc2=an2^{56'd0,rc_b},bc3=an3,bc4=an4;
    wire [63:0] bp0=bc0^bc1^bc2^bc3^bc4,bp1=bc1^bc2^bc3^bc4^bc0;
    wire [63:0] bp2=bc2^bc3^bc4^bc0^bc1,bp3=bc3^bc4^bc0^bc1^bc2,bp4=bc4^bc0^bc1^bc2^bc3;
    wire [63:0] bm0=bp4^{bp1[0],bp1[63:1]},bm1=bp0^{bp2[0],bp2[63:1]};
    wire [63:0] bm2=bp1^{bp3[0],bp3[63:1]},bm3=bp2^{bp4[0],bp4[63:1]};
    wire [63:0] bm4=bp3^{bp0[0],bp0[63:1]};
    wire [63:0] bt0=bc0^bm0,bt1=bc1^bm1,bt2=bc2^bm2,bt3=bc3^bm3,bt4=bc4^bm4;
    wire [63:0] bu0=~bt1&bt2,bu1=~bt2&bt3,bu2=~bt3&bt4,bu3=~bt4&bt0,bu4=~bt0&bt1;
    wire [63:0] bv0=bt0^bu0,bv1=bt1^bu1,bv2=~(bt2^bu2),bv3=bt3^bu3,bv4=bt4^bu4;
    wire [63:0] bn0=bv0^{bv0[18:0],bv0[63:19]}^{bv0[27:0],bv0[63:28]};
    wire [63:0] bn1=bv1^{bv1[60:0],bv1[63:61]}^{bv1[38:0],bv1[63:39]};
    wire [63:0] bn2=bv2^{bv2[0],   bv2[63:1]} ^{bv2[5:0], bv2[63:6]};
    wire [63:0] bn3=bv3^{bv3[9:0], bv3[63:10]}^{bv3[16:0],bv3[63:17]};
    wire [63:0] bn4=bv4^{bv4[6:0], bv4[63:7]} ^{bv4[40:0],bv4[63:41]};

    always @(posedge clk or negedge rst_n) begin
        if(!rst_n) begin
            state<=IDLE;done<=0;round_cnt<=0;round_end<=0;
            x0<=0;x1<=0;x2<=0;x3<=0;x4<=0;
            sx0<=0;sx1<=0;sx2<=0;sx3<=0;sx4<=0;
            s0_out<=0;s1_out<=0;s2_out<=0;s3_out<=0;s4_out<=0;
        end else case(state)
            IDLE: begin
                done<=0;
                if(start) begin
                    x0<=s0_in;x1<=s1_in;x2<=s2_in;x3<=s3_in;x4<=s4_in;
                    round_cnt<=start_round;round_end<=start_round+rounds;
                    state<=RUN;
                end
            end
            RUN: begin
                // Commit cone A output to x* (current round)
                x0<=an0;x1<=an1;x2<=an2;x3<=an3;x4<=an4;
                // Store cone B output to shadow sx* (speculative next round)
                sx0<=bn0;sx1<=bn1;sx2<=bn2;sx3<=bn3;sx4<=bn4;
                if(round_cnt<round_end-1) round_cnt<=round_cnt+1;
                else state<=FINISH;
            end
            FINISH: begin
                s0_out<=x0;s1_out<=x1;s2_out<=x2;s3_out<=x3;s4_out<=x4;
                done<=1;state<=IDLE;
            end
            default: state<=IDLE;
        endcase
    end
endmodule
