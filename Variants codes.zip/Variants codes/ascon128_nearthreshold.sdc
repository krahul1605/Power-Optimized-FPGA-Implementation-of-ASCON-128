#==============================================================================
# SDC Constraints — ascon128_nearthreshold
# Target : Cadence Genus / Innovus with UPF/CPF multi-supply mode
# Period : 100 ns  →  10 MHz
#
# Rationale
# ---------
# The nearthreshold variant partitions logic into two voltage domains:
#
#   VDD_HIGH (1.0V): state registers (s*), FSM, clock tree
#   VDD_LOW  (0.72V): ascon_round_nt module (Const + Chi + Linear)
#
# At VDD_LOW = 0.72V and typical process corner (TSMC 28nm HVT assumed):
#   Cell delay derating factor ≈ 2.4–2.8× vs. 1.0V nominal
#   Full round path: ~35-45 levels × 0.65 ns × 2.6 = ~59-76 ns
#   Level-shifter insertion delay (LS_DOWN + LS_UP): ~3-4 ns each way
#   Total registered path: ~67-84 ns → conservative 100 ns period chosen
#
# The setup/hold timing must be checked at BOTH domain corners:
#   Launch FF (VDD_HIGH, 1.0V) → LS_DOWN → VDD_LOW logic → LS_UP → capture FF
#   This creates a mixed-supply path that Genus handles via supply-aware STA.
#==============================================================================

#-- Primary clock (VDD_HIGH domain)
create_clock -name clk -period 100.000 [get_ports clk_p]
set_clock_uncertainty 0.5 [get_clocks clk]

#-- Input/output timing
set_input_delay  -clock clk -max 2.0 [get_ports {rst_n start}]
set_output_delay -clock clk -max 5.0 [get_ports {done tag_match led_*}]

#-- Supply domains (requires UPF/CPF supplementary file — documented here)
# VDD_HIGH = 1.0V : top module + all registers
# VDD_LOW  = 0.72V: u_round instance (ascon_round_nt module)
#
# In a UPF flow, add to supplementary .upf:
#   create_supply_domain -name VDD_HIGH
#   create_supply_domain -name VDD_LOW
#   create_supply_net    VDD -domain VDD_HIGH
#   create_supply_net    VDD_LOW -domain VDD_LOW
#   set_domain_supply_net VDD_HIGH -primary_power_net VDD   -primary_ground_net VSS
#   set_domain_supply_net VDD_LOW  -primary_power_net VDD_LOW -primary_ground_net VSS
#   map_power_switch u_round -domain VDD_LOW
#   create_level_shifter ls_down -output VDD_LOW  -applies_to inputs
#   create_level_shifter ls_up   -output VDD_HIGH -applies_to outputs

#-- Path derating for near-threshold domain
# Genus multi-supply STA applies cell delay derating automatically when supply
# voltages are annotated via UPF.  For SDC-only flows, use derate factors:
set_timing_derate -cell_delay -late 2.6 [get_cells u_round/*]
set_timing_derate -cell_delay -early 0.9 [get_cells u_round/*]

#-- Level-shifter insertion delay budget
# LS_DOWN: ~3 ns; LS_UP: ~3 ns (from typical library characterisation)
# These are captured in the cell delay models when LS cells are inserted.
# Document maximum allowable LS delay to maintain timing closure:
# LS_DOWN + combinational + LS_UP ≤ 100 ns - 5 ns (reg setup) = 95 ns budget

#-- Fanout on cross-domain drivers
# s* (VDD_HIGH) drives LS_DOWN inputs: 320 bits each to ascon_round_nt
set_max_fanout 32 [get_nets {s0[*] s1[*] s2[*] s3[*] s4[*]}]

#-- Prevent synthesis from pushing level-shifter logic into wrong domain
# ascon_round_nt boundary must be preserved for UPF domain assignment
set_dont_touch [get_cells u_round]

#-- Multicycle constraint documentation:
# No multicycle paths — 1 round per cycle even at 10 MHz.
# The VDD_LOW path is long but the 100 ns period accommodates it.

#-- False paths
set_false_path -from [get_ports rst_n]
set_false_path -to   [get_ports led_*]

#-- Operating conditions — must specify BOTH supply corners for mixed domain
# VDD_HIGH domain: slow corner (high temp, low voltage = 0.95V for ss corner)
# VDD_LOW domain: slow corner (0.68V for ss corner at same temp)
set_operating_conditions -max_library slow -max slow

#-- Power analysis annotations
# For Voltus/Joules power analysis:
#   annotate switching activity (SAIF from simulation) on u_round outputs
#   separately from VDD_HIGH domain nets for accurate domain-split power reporting
