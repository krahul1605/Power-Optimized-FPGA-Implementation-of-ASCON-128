#==============================================================================
# ASCON-128  ·  Variant: pipelined
# SDC for Cadence Genus Synthesis
#
# Permutation architecture: Fully pipelined 8-stage — each of the 8 ASCON
#   sub-steps (CONST, THETA_A, THETA_B, THETA_C, CHI1, CHI2, LIN1, LIN2) is
#   isolated behind its own registered pipeline barrier. No two sub-steps share
#   a combinational cone. The round counter is pipelined as a sideband signal
#   through all 8 stages, ensuring the correct round constant is available at
#   the CONST stage for each round. This is the maximum register-insertion
#   variant — highest area, maximum Fmax.
#
# Timing impact vs elevated (8-stage predecessor):
#   - All 8 sub-steps are separated; no pair is ever merged.
#   - Critical path per stage: ONE sub-step only (~3-7 gate levels per stage).
#     CHI1 (AND-NOT × 5 words) ≈ 2-3 levels.
#     THETA_A (5-way XOR parity tree) ≈ 3-4 levels.
#     LIN1, LIN2 (rotation wiring + 1 XOR) ≈ 1-2 levels.
#   - Heaviest single stage: THETA_A — 5-input XOR across 64 bit positions.
#   - Clock period target: 5.000 ns (200 MHz) — shallowest stage fits comfortably.
#   - Multicycle paths: NOT needed within the 8-stage pipeline.
#
# Throughput:
#   pa=12 call: 12 rounds × 8 sub-steps = 96 cycles + 1 FINISH = 97 cycles
#   pb=6  call:  6 rounds × 8 sub-steps = 48 cycles + 1 FINISH = 49 cycles
#   At 200 MHz: pa≈485 ns, pb≈245 ns per permutation call.
#
# Pipeline register banks (intermediate, between sub-steps):
#   c0..c4   — after CONST   (5×64b)
#   p0..p4   — after THETA_A (5×64b)
#   m0..m4   — after THETA_B (5×64b)
#   t0..t4   — after THETA_C (5×64b)
#   u0..u4   — after CHI1    (5×64b, AND-NOT terms)
#   x0..x4   — after CHI2    (5×64b, new state)
#   ra*,rb*  — after LIN1    (10×64b, rotation operands)
#   (LIN2 writes directly to x0..x4 for next round)
#
# Synthesis guidance for Genus:
#   - Use HIGH effort: many intermediate registers give Genus strong retiming
#     flexibility; push timing aggressively for 200 MHz closure.
#   - keep_hierarchy on ascon_perm_pipelined to preserve stage boundaries.
#   - Pipeline sideband (round counter through 8 stages) must not be optimized
#     away — set dont_touch if needed.
#==============================================================================

#------------------------------------------------------------------------------
# 1. CLOCK DEFINITION
#    200 MHz / 5 ns — maximum Fmax; single sub-step per stage
#------------------------------------------------------------------------------
create_clock -period 5.000 \
             -name sys_clk \
             -waveform {0.000 2.500} \
             [get_ports clk_p]

#------------------------------------------------------------------------------
# 2. CLOCK UNCERTAINTY
#    Tight jitter budget for 200 MHz. ZCU104 PLL jitter ~100 ps peak-to-peak;
#    use 0.150 ns setup margin to absorb jitter + skew.
#------------------------------------------------------------------------------
set_clock_uncertainty -setup 0.150 [get_clocks sys_clk]
set_clock_uncertainty -hold  0.100 [get_clocks sys_clk]

#------------------------------------------------------------------------------
# 3. CLOCK TRANSITION
#    Fast edge rate for 200 MHz LVDS clock input.
#------------------------------------------------------------------------------
set_clock_transition -rise 0.050 [get_clocks sys_clk]
set_clock_transition -fall 0.050 [get_clocks sys_clk]

#------------------------------------------------------------------------------
# 4. INPUT DELAYS
#    2.0 ns setup leaves 2.85 ns internal budget — consistent with 200 MHz
#    board interface; input signals (start, rst_n) not on the critical path.
#------------------------------------------------------------------------------
set_input_delay -clock sys_clk -max 2.000 [get_ports rst_n]
set_input_delay -clock sys_clk -min 0.500 [get_ports rst_n]
set_input_delay -clock sys_clk -max 2.000 [get_ports start]
set_input_delay -clock sys_clk -min 0.500 [get_ports start]

#------------------------------------------------------------------------------
# 5. OUTPUT DELAYS
#------------------------------------------------------------------------------
set_output_delay -clock sys_clk -max 2.000 [get_ports done]
set_output_delay -clock sys_clk -min 0.500 [get_ports done]
set_output_delay -clock sys_clk -max 2.000 [get_ports tag_match]
set_output_delay -clock sys_clk -min 0.500 [get_ports tag_match]
set_output_delay -clock sys_clk -max 2.000 [get_ports led_done]
set_output_delay -clock sys_clk -min 0.500 [get_ports led_done]
set_output_delay -clock sys_clk -max 2.000 [get_ports led_tag_match]
set_output_delay -clock sys_clk -min 0.500 [get_ports led_tag_match]
set_output_delay -clock sys_clk -max 2.000 [get_ports led_running]
set_output_delay -clock sys_clk -min 0.500 [get_ports led_running]
set_output_delay -clock sys_clk -max 2.000 [get_ports led_error]
set_output_delay -clock sys_clk -min 0.500 [get_ports led_error]

#------------------------------------------------------------------------------
# 6. ASYNCHRONOUS RESET — FALSE PATH
#------------------------------------------------------------------------------
set_false_path -from [get_ports rst_n]

#------------------------------------------------------------------------------
# 7. CRITICAL PATH BUDGET
#    Eight independent inter-register paths (one per sub-step):
#
#      Stage path          Sub-step    Est. depth    Est. delay
#      c*_reg → p*_reg     THETA_A     ~4 XOR levels  ~1.5-2.0 ns  ← heaviest
#      p*_reg → m*_reg     THETA_B     ~2 XOR+ROT     ~0.8-1.2 ns
#      m*_reg → t*_reg     THETA_C     ~1 XOR          ~0.4-0.6 ns
#      t*_reg → u*_reg     CHI1        ~1 AND+NOT      ~0.5-0.8 ns
#      u*_reg → x*_reg     CHI2+INV    ~1 XOR+NOT      ~0.5-0.8 ns
#      x*_reg → ra/rb*     LIN1        ~0 (wire)       ~0.1-0.2 ns
#      ra/rb* → x*_reg     LIN2        ~1 XOR          ~0.4-0.6 ns
#      x*_reg → c*_reg     CONST       ~1 XOR          ~0.4-0.6 ns
#
#    Total available: 5.000 - 0.150 (unc) - 0.050 (trans) = 4.800 ns
#    THETA_A at ~2.0 ns is the bottleneck; all other stages well below 4.8 ns.
#    200 MHz closure expected with typical synthesis effort.
#
#    Constrain THETA_A stage explicitly to prevent over-optimization elsewhere:
#------------------------------------------------------------------------------
# set_max_delay 4.800 -from [get_cells {c*_reg*}] -to [get_cells {p*_reg*}]

#------------------------------------------------------------------------------
# 8. PIPELINE SIDEBAND — ROUND COUNTER
#    The round counter propagates as a sideband through all 8 pipeline stages.
#    Synthesis must not optimize this chain away. If needed:
#------------------------------------------------------------------------------
# set_dont_touch [get_cells {rc_pipe*}]

#------------------------------------------------------------------------------
# 9. RETIMING
#    All sub-step boundaries are already explicit pipeline registers; retiming
#    would only merge stages (degrading Fmax). Disable retiming on this module.
#------------------------------------------------------------------------------
# set_attribute retime false [get_db designs ascon_perm_pipelined]

#------------------------------------------------------------------------------
# 10. DRIVING CELL / OUTPUT LOAD
#------------------------------------------------------------------------------
set_driving_cell -lib_cell INVX1 -no_design_rule [get_ports {start rst_n}]
set_load 5.0 [get_ports {done tag_match led_done led_tag_match led_running led_error}]

#------------------------------------------------------------------------------
# 11. OPERATING CONDITIONS
#      High-performance corner for 200 MHz sign-off.
#      Uncomment and set library condition as appropriate.
#------------------------------------------------------------------------------
# set_operating_conditions -library <lib> FAST

#==============================================================================
# END - ascon128_pipelined.sdc
#==============================================================================
