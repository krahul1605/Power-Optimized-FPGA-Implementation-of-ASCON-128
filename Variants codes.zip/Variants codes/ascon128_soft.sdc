#==============================================================================
# ASCON-128  ·  Variant: s-box-soft
# SDC for Cadence Genus Synthesis
#
# Permutation architecture: 3-stage balanced pipeline per round.
#   STAGE_A : Constant + complete Theta  (parity + rotation + XOR-apply)
#   STAGE_B : Complete Chi               (AND-NOT + XOR, x2 inversion)
#   STAGE_C : Complete Linear            (rotation pairs + XOR)
#
# Timing characteristics:
#   - STAGE_A is the bottleneck: 6-8 XOR gate levels (5-input XOR + rotations)
#   - STAGE_B: ~3 gate levels (AND + XOR); fastest stage
#   - STAGE_C: ~3 XOR levels; similar depth to STAGE_B
#   - Clock period target: 10.000 ns (100 MHz)
#     Chosen to accommodate STAGE_A at typical-typical process corner.
#     At 28nm: may achieve 150 MHz+; at 65nm: 80-100 MHz typical.
#
# Multicycle paths: NOT required — each of the three stages is one cycle.
# Register count per round: 3 × 5 × 64b = 960 FFs (vs 2560 elevated, ~320 minimal)
#
# This SDC also includes per-stage path annotations to help Genus focus
# optimization effort on STAGE_A (the timing bottleneck).
#==============================================================================

#------------------------------------------------------------------------------
# 1. CLOCK DEFINITION
#    100 MHz / 10 ns — balanced pipeline target
#------------------------------------------------------------------------------
create_clock -period 10.000 \
             -name sys_clk \
             -waveform {0.000 5.000} \
             [get_ports clk_p]

#------------------------------------------------------------------------------
# 2. CLOCK UNCERTAINTY
#    Moderate jitter budget for 100 MHz operation.
#------------------------------------------------------------------------------
set_clock_uncertainty -setup 0.250 [get_clocks sys_clk]
set_clock_uncertainty -hold  0.150 [get_clocks sys_clk]

#------------------------------------------------------------------------------
# 3. CLOCK TRANSITION
#------------------------------------------------------------------------------
set_clock_transition -rise 0.080 [get_clocks sys_clk]
set_clock_transition -fall 0.080 [get_clocks sys_clk]

#------------------------------------------------------------------------------
# 4. INPUT DELAYS
#    Board-level constraints unchanged from baseline.
#    At 10 ns period: 2.0 + 0.25 = 2.25 ns consumed by input constraints,
#    leaving 7.75 ns for internal logic — ample for all stages.
#------------------------------------------------------------------------------
set_input_delay -clock sys_clk -max 2.000 [get_ports rst_n]
set_input_delay -clock sys_clk -min 0.500 [get_ports rst_n]
set_input_delay -clock sys_clk -max 2.000 [get_ports start]
set_input_delay -clock sys_clk -min 0.500 [get_ports start]

#------------------------------------------------------------------------------
# 5. OUTPUT DELAYS
#------------------------------------------------------------------------------
set_output_delay -clock sys_clk -max 2.000 [get_ports done]
set_output_delay -clock sys_clk -min 0.500 [get_ports done]
set_output_delay -clock sys_clk -max 2.000 [get_ports tag_match]
set_output_delay -clock sys_clk -min 0.500 [get_ports tag_match]
set_output_delay -clock sys_clk -max 2.000 [get_ports led_done]
set_output_delay -clock sys_clk -min 0.500 [get_ports led_done]
set_output_delay -clock sys_clk -max 2.000 [get_ports led_tag_match]
set_output_delay -clock sys_clk -min 0.500 [get_ports led_tag_match]
set_output_delay -clock sys_clk -max 2.000 [get_ports led_running]
set_output_delay -clock sys_clk -min 0.500 [get_ports led_running]
set_output_delay -clock sys_clk -max 2.000 [get_ports led_error]
set_output_delay -clock sys_clk -min 0.500 [get_ports led_error]

#------------------------------------------------------------------------------
# 6. ASYNCHRONOUS RESET - FALSE PATH
#------------------------------------------------------------------------------
set_false_path -from [get_ports rst_n]

#------------------------------------------------------------------------------
# 7. PER-STAGE PATH BUDGET ANNOTATIONS
#
# STAGE_A (Constant + Theta): longest path, budgeted 9.000 ns.
#   From x0..x4 registers to t0..t4 registers.
#   This is where Genus should spend most optimization effort.
#
# STAGE_B (Chi): budget 5.000 ns — lighter combo depth.
#   From t0..t4 registers to c0..c4 registers.
#
# STAGE_C (Linear): budget 5.000 ns — rotation XOR chains.
#   From c0..c4 registers back to x0..x4 registers.
#
# Uncomment when instantiating with hierarchy preserved in Genus:
#------------------------------------------------------------------------------
# set_max_delay 9.000 -from [get_cells {*x?_reg*}]  -to [get_cells {*t?_reg*}]
# set_max_delay 5.000 -from [get_cells {*t?_reg*}]  -to [get_cells {*c?_reg*}]
# set_max_delay 5.000 -from [get_cells {*c?_reg*}]  -to [get_cells {*x?_reg*}]

#------------------------------------------------------------------------------
# 8. STAGE_A OPTIMIZATION DIRECTIVE
#    Instruct Genus to apply extra compile effort to the Theta XOR tree.
#    The 5-input XOR (parity) is the critical sub-expression.
#------------------------------------------------------------------------------
# set_attribute compile_effort high [get_db instances *perm_inst*]

#------------------------------------------------------------------------------
# 9. KEEP HIERARCHY FOR STAGE ISOLATION
#    Useful for area/timing reports broken down by pipeline stage.
#------------------------------------------------------------------------------
# set_attribute keep_hierarchy true [get_db modules ascon_perm_soft]

#------------------------------------------------------------------------------
# 10. DRIVING CELL / OUTPUT LOAD
#------------------------------------------------------------------------------
set_driving_cell -no_design_rule [get_ports {start rst_n}]
set_load 5.0 [get_ports {done tag_match led_done led_tag_match led_running led_error}]

#------------------------------------------------------------------------------
# 11. OPERATING CONDITIONS
#     Typical-typical for balanced power/performance synthesis.
#     Uncomment and set library condition as appropriate.
#------------------------------------------------------------------------------
# set_operating_conditions -library <lib> TT

#==============================================================================
# END - ascon128_soft.sdc
#==============================================================================
