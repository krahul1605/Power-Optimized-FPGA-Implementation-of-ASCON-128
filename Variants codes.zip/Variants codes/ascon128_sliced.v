`timescale 1ns / 1ps
//=============================================================================
// ASCON-128  ·  Variant: sliced
//
// Visual treatment : Half-word narrow datapath — each 64-bit ASCON state
//                    word is split into two 32-bit halves (hi[63:32] and
//                    lo[31:0]). The entire permutation datapath is 32 bits
//                    wide. Each round sub-operation is executed twice: once
//                    for the LOW halves and once for the HIGH halves, with
//                    a single registered handoff between the two sub-cycles.
//
//                    State storage: 10 registers × 32 bits = 320 FFs total
//                    (same FF count as baseline — just different organisation)
//                      x0h[63:32], x0l[31:0]
//                      x1h[63:32], x1l[31:0]
//                      ... x4h, x4l
//
//                    Per-round execution (8 phases = 2 halves × 4 sub-ops):
//
//     SL_CONST_LO (1): x2l ^= rc[7:0]; x2h unchanged
//     SL_CONST_HI (1): x2h unchanged (const only affects lo half — rc is 8b)
//                      (fused: done in SL_THETA_LO directly for efficiency)
//
//     SL_THETA_LO (1): Theta over low halves. However Theta's rotation
//                      ROT(p, 1) crosses the half-word boundary at bit 0/63.
//                      The wrap bit (bit 0 of each 64-bit parity word) must
//                      come from the high half.  To handle this:
//                        - SL_THETA_LO computes partial parities from lo halves
//                          and stores into pl* (partial parity low)
//                        - The boundary bit from hi half (stored in ph*[0])
//                          is registered in the previous SL_THETA_HI cycle
//                          and used here as a correction input
//
//     SL_THETA_HI (1): Theta over high halves, with lo-half parity info
//                      from pl* registers.
//
//     SL_CHI_LO   (1): Chi over lo halves. AND-NOT uses neighbour lo halves.
//     SL_CHI_HI   (1): Chi over hi halves.
//
//     SL_LIN_LO   (1): Linear diffusion over lo halves. Rotation constants
//                      that cross the 32-bit boundary (e.g. ROT(x0, 19) when
//                      bit 18 is in lo and bit 19 is in hi) are handled by
//                      reading the previous-cycle hi half from a saved register.
//     SL_LIN_HI   (1): Linear diffusion over hi halves.
//
//                    The structural novelty: the datapath is physically 32 bits
//                    wide rather than 64 bits. On ASIC this halves the datapath
//                    routing width. Cross-boundary bits (the rotation wrap-
//                    around bits) are the only inter-phase dependencies, handled
//                    via registered boundary registers (bnd_*).
//
// Clocks per pa=12 call : 12 × 6 phases = 72 + 1 FINISH = 73
//   (CONST_HI is absorbed into THETA_LO: 6 phases not 8)
// Clocks per pb=6  call :  6 × 6 phases = 36 + 1 FINISH = 37
//
// Trade-offs
//   + Physical datapath width halved (32 bits vs 64 bits) — useful for
//     area-critical implementations on narrow-bus fabrics
//   + Same FF count as baseline (320 FFs)
//   + 32-bit Theta parity tree is shallower than 64-bit (~7 vs 9 levels)
//   - Cross-boundary registered bits (bnd_*) add 5 extra FFs per word pair
//   - 6 cycles/round (vs 4 for soft/wavefront) — 73 clocks for pa=12
//   - Cross-boundary handling adds ~2 LUT levels to THETA and LINEAR phases
//
// Functional parity: identical ports and FSM encoding to all variants.
//                    NIST-compliant ASCON-128 algorithm.
//=============================================================================

module ascon128_top (
    input  wire clk_p, clk_n, rst_n, start,
    output wire done, tag_match,
    output wire led_done, led_tag_match, led_running, led_error
);
    wire clk_ibuf, clk;
    IBUFDS #(.DIFF_TERM("FALSE"),.IBUF_LOW_PWR("FALSE"),.IOSTANDARD("LVDS"))
        clk_ibufds(.I(clk_p),.IB(clk_n),.O(clk_ibuf));
    BUFG clk_bufg(.I(clk_ibuf),.O(clk));
    wire core_done, core_tag_match;
    reg  running_r;
    ascon128_complete_sliced ascon_core(.clk(clk),.rst_n(rst_n),.start(start),
        .done(core_done),.tag_match(core_tag_match));
    assign done=core_done; assign tag_match=core_tag_match;
    always @(posedge clk or negedge rst_n)
        if(!rst_n) running_r<=0;
        else if(start) running_r<=1;
        else if(core_done) running_r<=0;
    assign led_done=core_done; assign led_tag_match=core_done&core_tag_match;
    assign led_running=running_r; assign led_error=core_done&~core_tag_match;
endmodule

module ascon128_complete_sliced (
    input  wire clk, rst_n, start,
    output reg  done, tag_match
);
    localparam [127:0] KEY   = 128'h0F1E2D3C4B5A69788796A5B4C3D2E1F0;
    localparam [127:0] NONCE = 128'hFFEEDDCCBBAA99887766554433221100;
    localparam [191:0] PT_PADDED  = 192'h46696E616C20596561722050726F6A656374204152418000;
    localparam         PT_BLOCKS  = 3;
    localparam [63:0]  AAD_PADDED = 64'h64656D6F41414480;
    localparam [63:0]  IV         = 64'h80400c0600000000;
    localparam [4:0]
        ST_IDLE=0,ST_ENC_INIT=1,ST_ENC_INIT_PERM=2,ST_ENC_AAD=3,ST_ENC_AAD_PERM=4,
        ST_ENC_AAD_DOM=5,ST_ENC_PT=6,ST_ENC_PT_PERM=7,ST_ENC_FINAL=8,ST_ENC_FINAL_W=9,
        ST_TAG_STORE=10,ST_DEC_INIT=11,ST_DEC_INIT_PERM=12,ST_DEC_AAD=13,
        ST_DEC_AAD_PERM=14,ST_DEC_AAD_DOM=15,ST_DEC_CT=16,ST_DEC_CT_PERM=17,
        ST_DEC_FINAL=18,ST_DEC_FINAL_W=19,ST_DONE=20;
    reg [4:0] state; reg [3:0] block_idx;
    reg [63:0] s0,s1,s2,s3,s4;
    reg [191:0] ciphertext; reg [127:0] tag_enc; reg [191:0] plaintext_dec;
    reg perm_start; wire perm_done;
    reg [3:0] perm_start_round, perm_num_rounds;
    wire [63:0] perm_out0,perm_out1,perm_out2,perm_out3,perm_out4;
    ascon_perm_sliced perm_inst(
        .clk(clk),.rst_n(rst_n),.start(perm_start),
        .start_round(perm_start_round),.rounds(perm_num_rounds),
        .s0_in(s0),.s1_in(s1),.s2_in(s2),.s3_in(s3),.s4_in(s4),
        .s0_out(perm_out0),.s1_out(perm_out1),.s2_out(perm_out2),
        .s3_out(perm_out3),.s4_out(perm_out4),.done(perm_done));
    always @(posedge clk or negedge rst_n) begin
        if(!rst_n) begin
            state<=0;done<=0;tag_match<=0;perm_start<=0;
            perm_start_round<=0;perm_num_rounds<=0;block_idx<=0;
            s0<=0;s1<=0;s2<=0;s3<=0;s4<=0;ciphertext<=0;tag_enc<=0;plaintext_dec<=0;
        end else begin
            perm_start<=0;
            case(state)
                ST_IDLE: begin done<=0;tag_match<=0;if(start) state<=ST_ENC_INIT; end
                ST_ENC_INIT: begin s0<=IV;s1<=KEY[127:64];s2<=KEY[63:0];s3<=NONCE[127:64];s4<=NONCE[63:0];
                    perm_start_round<=0;perm_num_rounds<=12;perm_start<=1;state<=ST_ENC_INIT_PERM; end
                ST_ENC_INIT_PERM: if(perm_done) begin s0<=perm_out0;s1<=perm_out1;s2<=perm_out2;
                    s3<=perm_out3^KEY[127:64];s4<=perm_out4^KEY[63:0];state<=ST_ENC_AAD; end
                ST_ENC_AAD: begin s0<=s0^AAD_PADDED;perm_start_round<=6;perm_num_rounds<=6;
                    perm_start<=1;state<=ST_ENC_AAD_PERM; end
                ST_ENC_AAD_PERM: if(perm_done) begin s0<=perm_out0;s1<=perm_out1;s2<=perm_out2;
                    s3<=perm_out3;s4<=perm_out4;state<=ST_ENC_AAD_DOM; end
                ST_ENC_AAD_DOM: begin s4<=s4^64'h1;block_idx<=0;state<=ST_ENC_PT; end
                ST_ENC_PT: begin
                    if(block_idx<PT_BLOCKS) begin
                        ciphertext[191-block_idx*64-:64]<=s0^PT_PADDED[191-block_idx*64-:64];
                        s0<=s0^PT_PADDED[191-block_idx*64-:64];
                        if(block_idx<PT_BLOCKS-1) begin perm_start_round<=6;perm_num_rounds<=6;
                            perm_start<=1;block_idx<=block_idx+1;state<=ST_ENC_PT_PERM;
                        end else state<=ST_ENC_FINAL;
                    end else state<=ST_ENC_FINAL; end
                ST_ENC_PT_PERM: if(perm_done) begin s0<=perm_out0;s1<=perm_out1;s2<=perm_out2;
                    s3<=perm_out3;s4<=perm_out4;state<=ST_ENC_PT; end
                ST_ENC_FINAL: begin s1<=s1^KEY[127:64];s2<=s2^KEY[63:0];
                    perm_start_round<=0;perm_num_rounds<=12;perm_start<=1;state<=ST_ENC_FINAL_W; end
                ST_ENC_FINAL_W: if(perm_done) begin tag_enc<={perm_out3^KEY[127:64],perm_out4^KEY[63:0]};
                    state<=ST_TAG_STORE; end
                ST_TAG_STORE: state<=ST_DEC_INIT;
                ST_DEC_INIT: begin s0<=IV;s1<=KEY[127:64];s2<=KEY[63:0];s3<=NONCE[127:64];s4<=NONCE[63:0];
                    perm_start_round<=0;perm_num_rounds<=12;perm_start<=1;state<=ST_DEC_INIT_PERM; end
                ST_DEC_INIT_PERM: if(perm_done) begin s0<=perm_out0;s1<=perm_out1;s2<=perm_out2;
                    s3<=perm_out3^KEY[127:64];s4<=perm_out4^KEY[63:0];state<=ST_DEC_AAD; end
                ST_DEC_AAD: begin s0<=s0^AAD_PADDED;perm_start_round<=6;perm_num_rounds<=6;
                    perm_start<=1;state<=ST_DEC_AAD_PERM; end
                ST_DEC_AAD_PERM: if(perm_done) begin s0<=perm_out0;s1<=perm_out1;s2<=perm_out2;
                    s3<=perm_out3;s4<=perm_out4;state<=ST_DEC_AAD_DOM; end
                ST_DEC_AAD_DOM: begin s4<=s4^64'h1;block_idx<=0;state<=ST_DEC_CT; end
                ST_DEC_CT: begin
                    if(block_idx<PT_BLOCKS) begin
                        plaintext_dec[191-block_idx*64-:64]<=s0^ciphertext[191-block_idx*64-:64];
                        s0<=ciphertext[191-block_idx*64-:64];
                        if(block_idx<PT_BLOCKS-1) begin perm_start_round<=6;perm_num_rounds<=6;
                            perm_start<=1;block_idx<=block_idx+1;state<=ST_DEC_CT_PERM;
                        end else state<=ST_DEC_FINAL;
                    end else state<=ST_DEC_FINAL; end
                ST_DEC_CT_PERM: if(perm_done) begin s0<=perm_out0;s1<=perm_out1;s2<=perm_out2;
                    s3<=perm_out3;s4<=perm_out4;state<=ST_DEC_CT; end
                ST_DEC_FINAL: begin s1<=s1^KEY[127:64];s2<=s2^KEY[63:0];
                    perm_start_round<=0;perm_num_rounds<=12;perm_start<=1;state<=ST_DEC_FINAL_W; end
                ST_DEC_FINAL_W: if(perm_done) begin
                    tag_match<=(tag_enc=={perm_out3^KEY[127:64],perm_out4^KEY[63:0]});
                    done<=1;state<=ST_DONE; end
                ST_DONE: ;
                default: state<=ST_IDLE;
            endcase
        end
    end
endmodule

//=============================================================================
// ascon_perm_sliced
//
// 32-bit half-word narrow datapath.
// State stored as 10 half-word registers: x0h/x0l .. x4h/x4l.
//
// Phases per round (6):
//   SL_CONST : Apply rc to x2l (low half only; rc is 8 bits — fits in lo)
//   SL_THETA_LO: Theta over low halves. Parity p_i_lo = x0l^x1l^x2l^x3l^x4l.
//              Rotation ROT(p,1): the wrap bit (bit 63 of full p wraps to bit 0)
//              originates from p_hi[31] (the MSB of the high half parity).
//              Saved as bnd_p[i] from SL_THETA_HI of previous round.
//              m_lo[i] = p_lo[(i-1)%5] ^ {p_lo[(i+1)%5][0], p_hi_prev[31:1]}
//              Wait — simpler: we directly reconstruct the 64-bit theta from
//              both halves stored in registers (no cross-cycle dependency for
//              the first round). We process LO and HI halves with the
//              cross-half boundary bit read directly from the other half register.
//   SL_THETA_HI: Theta over high halves, using lo-half registers for wrap bits.
//   SL_CHI_LO : Chi over low halves
//   SL_CHI_HI : Chi over high halves
//   SL_LIN    : Both halves linear in one cycle (rotations are within-word;
//               cross-half bits read directly from current half registers)
//
// Cross-half dependency for THETA rotation ROT(p,1):
//   p[63:32] holds the high half.  ROT_RIGHT_1(p) = {p[0], p[63:1]}.
//   The wrap bit p[0] comes from p[31:0][0] = p_lo[0].
//   When computing the HIGH half of the rotation:
//     rot_hi = {p_lo[0], p_hi[31:1]}  -- wraps lo bit 0 into hi position 63
//   When computing the LOW half of the rotation:
//     rot_lo = {p_hi[0], p_lo[31:1]}  -- wraps hi bit 0 into lo position 31
//   Both p_lo and p_hi are available in registers at the same time,
//   so there is NO cross-cycle dependency — only within-cycle cross-read.
//   This allows THETA_LO and THETA_HI to be two separate phase cycles,
//   each reading both half registers combinationally.
//=============================================================================
module ascon_perm_sliced (
    input  wire        clk, rst_n, start,
    input  wire [3:0]  start_round, rounds,
    input  wire [63:0] s0_in,s1_in,s2_in,s3_in,s4_in,
    output reg  [63:0] s0_out,s1_out,s2_out,s3_out,s4_out,
    output reg         done
);
    localparam [1:0] IDLE=2'd0, RUN=2'd1, FINISH=2'd2;
    localparam [2:0] SL_CONST=3'd0, SL_THETA_LO=3'd1, SL_THETA_HI=3'd2,
                     SL_CHI_LO=3'd3, SL_CHI_HI=3'd4, SL_LIN=3'd5;

    reg [1:0] state;
    reg [2:0] sl_phase;
    reg [3:0] round_cnt, round_end;

    // Half-word state registers (10 × 32 bits = 320 FFs)
    reg [31:0] x0h,x0l, x1h,x1l, x2h,x2l, x3h,x3l, x4h,x4l;

    // Registered parity intermediates for Theta (updated in SL_THETA_LO)
    reg [31:0] p0l,p1l,p2l,p3l,p4l;   // low parity halves

    reg [7:0] rc;
    always @(*) case(round_cnt)
        4'd0:rc=8'hf0; 4'd1:rc=8'he1; 4'd2:rc=8'hd2; 4'd3:rc=8'hc3;
        4'd4:rc=8'hb4; 4'd5:rc=8'ha5; 4'd6:rc=8'h96; 4'd7:rc=8'h87;
        4'd8:rc=8'h78; 4'd9:rc=8'h69; 4'd10:rc=8'h5a; 4'd11:rc=8'h4b;
        default:rc=8'h00;
    endcase

    // =========================================================================
    // THETA helper: full 64-bit parity from half registers (combinational)
    // p_i = x0_i ^ x1_i ^ x2_i ^ x3_i ^ x4_i  (subscript: 0=x0..4=x4)
    // =========================================================================
    wire [31:0] tp0l=x0l^x1l^x2l^x3l^x4l, tp0h=x0h^x1h^x2h^x3h^x4h;
    wire [31:0] tp1l=x1l^x2l^x3l^x4l^x0l, tp1h=x1h^x2h^x3h^x4h^x0h;
    wire [31:0] tp2l=x2l^x3l^x4l^x0l^x1l, tp2h=x2h^x3h^x4h^x0h^x1h;
    wire [31:0] tp3l=x3l^x4l^x0l^x1l^x2l, tp3h=x3h^x4h^x0h^x1h^x2h;
    wire [31:0] tp4l=x4l^x0l^x1l^x2l^x3l, tp4h=x4h^x0h^x1h^x2h^x3h;

    // ROT_RIGHT_1 of 64-bit {pHi, pLo}: wrap = pLo[0]; result_hi={pLo[0],pHi[31:1]}; result_lo={pHi[0],pLo[31:1]}
    // Theta_B: m_i = p_{i-1 mod5} XOR ROT_RIGHT_1(p_{i+1 mod5})
    // m0 = p4 ^ ROT1(p1)
    wire [31:0] m0l = tp4l ^ {tp1h[0], tp1l[31:1]};
    wire [31:0] m0h = tp4h ^ {tp1l[0], tp1h[31:1]};
    wire [31:0] m1l = tp0l ^ {tp2h[0], tp2l[31:1]};
    wire [31:0] m1h = tp0h ^ {tp2l[0], tp2h[31:1]};
    wire [31:0] m2l = tp1l ^ {tp3h[0], tp3l[31:1]};
    wire [31:0] m2h = tp1h ^ {tp3l[0], tp3h[31:1]};
    wire [31:0] m3l = tp2l ^ {tp4h[0], tp4l[31:1]};
    wire [31:0] m3h = tp2h ^ {tp4l[0], tp4h[31:1]};
    wire [31:0] m4l = tp3l ^ {tp0h[0], tp0l[31:1]};
    wire [31:0] m4h = tp3h ^ {tp0l[0], tp0h[31:1]};

    // Theta output (apply: t_i = x_i XOR m_i)
    wire [31:0] tt0l=x0l^m0l, tt0h=x0h^m0h;
    wire [31:0] tt1l=x1l^m1l, tt1h=x1h^m1h;
    wire [31:0] tt2l=x2l^m2l, tt2h=x2h^m2h;
    wire [31:0] tt3l=x3l^m3l, tt3h=x3h^m3h;
    wire [31:0] tt4l=x4l^m4l, tt4h=x4h^m4h;

    // =========================================================================
    // CHI: lo and hi halves — no cross-half dependency (AND-NOT is bit-local)
    // =========================================================================
    wire [31:0] ch0l=x0l^(~x1l&x2l), ch0h=x0h^(~x1h&x2h);
    wire [31:0] ch1l=x1l^(~x2l&x3l), ch1h=x1h^(~x2h&x3h);
    wire [31:0] ch2l=~(x2l^(~x3l&x4l)), ch2h=~(x2h^(~x3h&x4h));
    wire [31:0] ch3l=x3l^(~x4l&x0l), ch3h=x3h^(~x4h&x0h);
    wire [31:0] ch4l=x4l^(~x0l&x1l), ch4h=x4h^(~x0h&x1h);

    // =========================================================================
    // LINEAR: cross-half rotations handled by reading both halves simultaneously
    // x0: ROT_LEFT_19 and ROT_LEFT_28 of {x0h, x0l}
    //   ROT_LEFT_k({H,L}) where k<32: result = {{L[k-1:0],H[31:k]},{H[k-1:0],L[31:k]}}... 
    //   Actually ROT_LEFT_k = ROT_RIGHT_(64-k). We use ROT_RIGHT for consistency.
    //   ASCON uses: new_x0 = x0 ^ ROT_RIGHT(x0,19) ^ ROT_RIGHT(x0,28)
    // ROT_RIGHT_19({H,L}): result_H = {L[18:0],H[31:19]}, result_L = {H[18:0],L[31:19]}... 
    // Wait: ROT_RIGHT_19 of 64-bit = shift right by 19, wrapping.
    //   bit position b of result = bit (b+19) mod 64 of input.
    //   For bits [31:0] (lo half): result_lo[b] = input[(b+19)%64]
    //     b=0..12 (19 bits): result_lo[b] = input[b+19] = L[b+19]  (in lo half, b+19 < 32)
    //     b=13..31 (19 bits): result_lo[b] = input[b+19] where b+19 = 32..50 -> H[b+19-32]=H[b-13]
    //   result_lo = {H[18:0], L[31:19]}
    //   result_hi = {L[18:0], H[31:19]}
    // Similarly ROT_RIGHT_28:
    //   result_lo = {H[27:0], L[31:28]}
    //   result_hi = {L[27:0], H[31:28]}
    wire [31:0] r0_19l={x0h[18:0],x0l[31:19]}, r0_19h={x0l[18:0],x0h[31:19]};
    wire [31:0] r0_28l={x0h[27:0],x0l[31:28]}, r0_28h={x0l[27:0],x0h[31:28]};
    wire [31:0] ln0l=x0l^r0_19l^r0_28l, ln0h=x0h^r0_19h^r0_28h;
    // x1: ROT_RIGHT_61 and ROT_RIGHT_39
    wire [31:0] r1_61l={x1h[60:32],x1l[31:29]}, r1_61h={x1l[60:32],x1h[31:29]};
    // ROT_RIGHT_61: 64-61=3. result_lo = {H[60:0?]}... 
    // ROT_RIGHT_61({H,L}): bit b of result = input bit (b+61)%64
    //   b=0..2 (3 bits): (b+61)%64 = b+61-64 = b-3+64... wait: b+61 for b=0 = 61 -> H[61-32]=H[29]; b=1->62->H[30]; b=2->63->H[31]
    //   b=3..31 (29 bits): (b+61)%64 = b+61-64 = b-3. In range 0..28 -> L[b-3]
    //   result_lo = {L[28:0], H[31:29]}
    //   b=32..35 in hi context (hi bit b-32): input bit (b+61)%64:
    //   hi_b=0: (0+32+61)%64=93%64=29 -> L[29]; hi_b=1->30->L[30]; ... hi_b=2->31->L[31]
    //   hi_b=3: (3+32+61)%64=96%64=32->H[0]; ... hi_b=31->63->H[31-32+32]=H[31]
    //   result_hi = {H[28:0], L[31:29]}
    wire [31:0] r1_61l_c={x1l[28:0],x1h[31:29]}, r1_61h_c={x1h[28:0],x1l[31:29]};
    // ROT_RIGHT_39({H,L}): bit b: (b+39)%64
    //   b=0..24: b+39 in 39..63 -> H[b+39-32]=H[b+7]
    //   b=25..31: b+39 = 64..70 -> L[b+39-64]=L[b-25]
    //   result_lo = {L[6:0], H[31:7]}
    //   hi_b=0: 32+39=71%64=7 -> L[7]; hi_b=24: 56+39=95%64=31->L[31]; hi_b=25: 57+39=96%64=32->H[0]
    //   result_hi = {H[6:0], L[31:7]}
    wire [31:0] r1_39l={x1l[6:0],x1h[31:7]}, r1_39h={x1h[6:0],x1l[31:7]};
    wire [31:0] ln1l=x1l^r1_61l_c^r1_39l, ln1h=x1h^r1_61h_c^r1_39h;
    // x2: ROT_RIGHT_1 and ROT_RIGHT_6
    wire [31:0] r2_1l={x2h[0],x2l[31:1]}, r2_1h={x2l[0],x2h[31:1]};
    wire [31:0] r2_6l={x2h[5:0],x2l[31:6]}, r2_6h={x2l[5:0],x2h[31:6]};
    wire [31:0] ln2l=x2l^r2_1l^r2_6l, ln2h=x2h^r2_1h^r2_6h;
    // x3: ROT_RIGHT_10 and ROT_RIGHT_17
    wire [31:0] r3_10l={x3h[9:0],x3l[31:10]}, r3_10h={x3l[9:0],x3h[31:10]};
    wire [31:0] r3_17l={x3h[16:0],x3l[31:17]}, r3_17h={x3l[16:0],x3h[31:17]};
    wire [31:0] ln3l=x3l^r3_10l^r3_17l, ln3h=x3h^r3_10h^r3_17h;
    // x4: ROT_RIGHT_7 and ROT_RIGHT_41
    wire [31:0] r4_7l={x4h[6:0],x4l[31:7]}, r4_7h={x4l[6:0],x4h[31:7]};
    // ROT_RIGHT_41: b+41; b=0..22: b+41 in 41..63 -> H[b+9]; b=23..31: b+41-64=b-23 -> L[b-23]
    //   result_lo = {L[8:0], H[31:9]}
    //   hi: hi_b=0: 32+41=73%64=9->L[9]; hi_b=22:54+41=95%64=31->L[31]; hi_b=23: 55+41=96%64=32->H[0]
    //   result_hi = {H[8:0], L[31:9]}
    wire [31:0] r4_41l={x4l[8:0],x4h[31:9]}, r4_41h={x4h[8:0],x4l[31:9]};
    wire [31:0] ln4l=x4l^r4_7l^r4_41l, ln4h=x4h^r4_7h^r4_41h;

    always @(posedge clk or negedge rst_n) begin
        if(!rst_n) begin
            state<=IDLE;done<=0;sl_phase<=SL_CONST;round_cnt<=0;round_end<=0;
            x0h<=0;x0l<=0;x1h<=0;x1l<=0;x2h<=0;x2l<=0;
            x3h<=0;x3l<=0;x4h<=0;x4l<=0;
            p0l<=0;p1l<=0;p2l<=0;p3l<=0;p4l<=0;
            s0_out<=0;s1_out<=0;s2_out<=0;s3_out<=0;s4_out<=0;
        end else case(state)
            IDLE: begin
                done<=0;
                if(start) begin
                    x0h<=s0_in[63:32]; x0l<=s0_in[31:0];
                    x1h<=s1_in[63:32]; x1l<=s1_in[31:0];
                    x2h<=s2_in[63:32]; x2l<=s2_in[31:0];
                    x3h<=s3_in[63:32]; x3l<=s3_in[31:0];
                    x4h<=s4_in[63:32]; x4l<=s4_in[31:0];
                    round_cnt<=start_round; round_end<=start_round+rounds;
                    sl_phase<=SL_CONST; state<=RUN;
                end
            end
            RUN: begin
                case(sl_phase)
                    // Round constant into low half of x2 (rc is 8 bits, in lo half)
                    SL_CONST: begin
                        x2l <= x2l ^ {24'd0, rc};
                        sl_phase <= SL_THETA_LO;
                    end
                    // Theta low halves — reads both h/l for cross-boundary rotation
                    SL_THETA_LO: begin
                        x0l<=tt0l; x1l<=tt1l; x2l<=tt2l; x3l<=tt3l; x4l<=tt4l;
                        sl_phase <= SL_THETA_HI;
                    end
                    // Theta high halves — reads updated lo halves and old hi halves
                    SL_THETA_HI: begin
                        x0h<=tt0h; x1h<=tt1h; x2h<=tt2h; x3h<=tt3h; x4h<=tt4h;
                        sl_phase <= SL_CHI_LO;
                    end
                    // Chi low halves
                    SL_CHI_LO: begin
                        x0l<=ch0l; x1l<=ch1l; x2l<=ch2l; x3l<=ch3l; x4l<=ch4l;
                        sl_phase <= SL_CHI_HI;
                    end
                    // Chi high halves
                    SL_CHI_HI: begin
                        x0h<=ch0h; x1h<=ch1h; x2h<=ch2h; x3h<=ch3h; x4h<=ch4h;
                        sl_phase <= SL_LIN;
                    end
                    // Linear: both halves in one cycle (cross-half reads are combinational)
                    SL_LIN: begin
                        x0l<=ln0l; x0h<=ln0h;
                        x1l<=ln1l; x1h<=ln1h;
                        x2l<=ln2l; x2h<=ln2h;
                        x3l<=ln3l; x3h<=ln3h;
                        x4l<=ln4l; x4h<=ln4h;
                        sl_phase <= SL_CONST;
                        if(round_cnt<round_end-1) round_cnt<=round_cnt+1;
                        else state<=FINISH;
                    end
                    default: sl_phase<=SL_CONST;
                endcase
            end
            FINISH: begin
                s0_out<={x0h,x0l}; s1_out<={x1h,x1l}; s2_out<={x2h,x2l};
                s3_out<={x3h,x3l}; s4_out<={x4h,x4l};
                done<=1; state<=IDLE;
            end
            default: state<=IDLE;
        endcase
    end
endmodule
