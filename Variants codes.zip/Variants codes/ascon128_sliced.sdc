#==============================================================================
# ASCON-128  ·  Variant: sliced
# SDC for Cadence Genus Synthesis
#
# Permutation architecture: 32-bit half-word narrow datapath.
#   Each 64-bit word stored as {xNh[63:32], xNl[31:0]}. 10 half-word regs.
#   6 phases per round:
#     SL_CONST   : x2l ^= rc (32-bit path)               ~1 ns
#     SL_THETA_LO: Theta low halves + cross-half reads    ~7-8 ns (critical)
#     SL_THETA_HI: Theta high halves + cross-half reads   ~7-8 ns (critical)
#     SL_CHI_LO  : Chi 32-bit lo halves (no cross-half)   ~3-4 ns
#     SL_CHI_HI  : Chi 32-bit hi halves (no cross-half)   ~3-4 ns
#     SL_LIN     : Linear both halves, cross-half rot      ~5-6 ns
#
#   Critical path: SL_THETA_LO and SL_THETA_HI — 32-bit parity tree plus
#   cross-half single-bit wrapping. Slightly shorter than 64-bit Theta
#   (~7 vs ~9 gate levels) but similar ns due to cross-half mux overhead.
#   Fmax target: 125 MHz / 8 ns
#
# Clocks per pa=12 : 12 × 6 + 1 = 73   Clocks per pb=6 : 6 × 6 + 1 = 37
#==============================================================================
create_clock -period 8.000 -name sys_clk -waveform {0.000 4.000} [get_ports clk_p]
set_clock_uncertainty -setup 0.200 [get_clocks sys_clk]
set_clock_uncertainty -hold  0.100 [get_clocks sys_clk]
set_clock_transition -rise 0.100 [get_clocks sys_clk]
set_clock_transition -fall 0.100 [get_clocks sys_clk]
set_input_delay -clock sys_clk -max 2.000 [get_ports rst_n]
set_input_delay -clock sys_clk -min 0.500 [get_ports rst_n]
set_input_delay -clock sys_clk -max 2.000 [get_ports start]
set_input_delay -clock sys_clk -min 0.500 [get_ports start]
set_output_delay -clock sys_clk -max 2.000 [get_ports done]
set_output_delay -clock sys_clk -min 0.500 [get_ports done]
set_output_delay -clock sys_clk -max 2.000 [get_ports tag_match]
set_output_delay -clock sys_clk -min 0.500 [get_ports tag_match]
set_output_delay -clock sys_clk -max 2.000 [get_ports led_done]
set_output_delay -clock sys_clk -min 0.500 [get_ports led_done]
set_output_delay -clock sys_clk -max 2.000 [get_ports led_tag_match]
set_output_delay -clock sys_clk -min 0.500 [get_ports led_tag_match]
set_output_delay -clock sys_clk -max 2.000 [get_ports led_running]
set_output_delay -clock sys_clk -min 0.500 [get_ports led_running]
set_output_delay -clock sys_clk -max 2.000 [get_ports led_error]
set_output_delay -clock sys_clk -min 0.500 [get_ports led_error]
set_false_path -from [get_ports rst_n]
# Note: SL_LIN reads both xNh and xNl registers in the same cycle for
# cross-half rotations. This is combinational within the same clock period.
# No multicycle path required — both halves are stable before clock edge.
set_driving_cell -lib_cell INVX1 -no_design_rule [get_ports {start rst_n}]
set_load 5.0 [get_ports {done tag_match led_done led_tag_match led_running led_error}]
# set_operating_conditions -library <lib> TYPICAL
#==============================================================================
# END - ascon128_sliced.sdc
#==============================================================================
