#==============================================================================
# ASCON-128  ·  Variant: serialized
# SDC for Cadence Genus Synthesis
#
# Permutation architecture: Bit-serial s-box — minimum area implementation.
#   The ASCON 5-bit s-box is processed one bit-position at a time across
#   all 5 state words. A single bit-slice ALU operates on bit index [i] of
#   (x0[i], x1[i], x2[i], x3[i], x4[i]) per clock cycle, iterating i=0..63.
#   Linear layer (Theta, rotation, XOR) operates on full 64-bit words after
#   all 64 s-box iterations complete per round, stored in shift registers.
#
#   Sub-step schedule per round:
#     Cycles  0–63  : CONST+CHI bit-serial s-box scan (64 cycles)
#     Cycle   64    : THETA_A parity accumulation
#     Cycle   65    : THETA_B rotation mix
#     Cycle   66    : THETA_C theta application
#     Cycles  67–68 : LIN1 + LIN2 rotation and XOR
#   Total: 69 cycles per round.
#
# Architecture trade-offs:
#   + Absolute minimum combinational logic area (~3 gates for s-box ALU).
#   + Minimum register count: bit-slice shift regs + 5×64b state = ~345 FFs.
#   + Suitable for ultra-constrained area targets (IoT, smartcard).
#   - Highest latency of all variants: 69 cycles/round × 12 rounds = 828 cycles.
#   - Throughput extremely low; only suited to low-data-rate applications.
#
# Timing impact vs elevated:
#   - Critical path per cycle: 1 s-box operation on 5 bits (~3-5 gate levels).
#   - Clock period target: 100.000 ns (10 MHz) — dominated by shift-reg control.
#   - The short critical path means Fmax could be much higher; 10 MHz chosen to
#     bound power and match area-optimized cell drive strengths.
#   - Input/output delays: 2.0/0.5 ns standard board interface.
#   - Multicycle paths: NOT needed per sub-step, each bit-slice is 1 cycle.
#
# Clocks per pa=12 call : 12 × 69 = 828 + 1 FINISH = 829
# Clocks per pb=6  call :  6 × 69 = 414 + 1 FINISH = 415
#
# Synthesis guidance for Genus:
#   Compile with area optimization priority (set_max_area 0).
#   Bit-serial datapaths map well to minimum-drive-strength cells.
#   Avoid inserting buffers on the s-box bit-slice path — the design is
#   area-critical and has ample timing slack at 10 MHz.
#==============================================================================

#------------------------------------------------------------------------------
# 1. CLOCK DEFINITION
#    10 MHz / 100 ns — bit-serial s-box minimum-area architecture
#------------------------------------------------------------------------------
create_clock -period 100.000 \
             -name sys_clk \
             -waveform {0.000 50.000} \
             [get_ports clk_p]

#------------------------------------------------------------------------------
# 2. CLOCK UNCERTAINTY
#    Very relaxed jitter budget; 10 MHz period provides ample margin.
#------------------------------------------------------------------------------
set_clock_uncertainty -setup 1.000 [get_clocks sys_clk]
set_clock_uncertainty -hold  0.500 [get_clocks sys_clk]

#------------------------------------------------------------------------------
# 3. CLOCK TRANSITION
#    Relaxed edge rate for low-frequency, minimum-drive-strength clock tree.
#------------------------------------------------------------------------------
set_clock_transition -rise 0.500 [get_clocks sys_clk]
set_clock_transition -fall 0.500 [get_clocks sys_clk]

#------------------------------------------------------------------------------
# 4. INPUT DELAYS
#    At 100 ns period, 2.0 ns max delay leaves ~96.5 ns internal — very loose.
#------------------------------------------------------------------------------
set_input_delay -clock sys_clk -max 2.000 [get_ports rst_n]
set_input_delay -clock sys_clk -min 0.500 [get_ports rst_n]
set_input_delay -clock sys_clk -max 2.000 [get_ports start]
set_input_delay -clock sys_clk -min 0.500 [get_ports start]

#------------------------------------------------------------------------------
# 5. OUTPUT DELAYS
#------------------------------------------------------------------------------
set_output_delay -clock sys_clk -max 2.000 [get_ports done]
set_output_delay -clock sys_clk -min 0.500 [get_ports done]
set_output_delay -clock sys_clk -max 2.000 [get_ports tag_match]
set_output_delay -clock sys_clk -min 0.500 [get_ports tag_match]
set_output_delay -clock sys_clk -max 2.000 [get_ports led_done]
set_output_delay -clock sys_clk -min 0.500 [get_ports led_done]
set_output_delay -clock sys_clk -max 2.000 [get_ports led_tag_match]
set_output_delay -clock sys_clk -min 0.500 [get_ports led_tag_match]
set_output_delay -clock sys_clk -max 2.000 [get_ports led_running]
set_output_delay -clock sys_clk -min 0.500 [get_ports led_running]
set_output_delay -clock sys_clk -max 2.000 [get_ports led_error]
set_output_delay -clock sys_clk -min 0.500 [get_ports led_error]

#------------------------------------------------------------------------------
# 6. ASYNCHRONOUS RESET - FALSE PATH
#------------------------------------------------------------------------------
set_false_path -from [get_ports rst_n]

#------------------------------------------------------------------------------
# 7. CRITICAL PATH BUDGET — BIT-SERIAL S-BOX
#    Budget: 100.000 - 1.000 (unc) - 0.500 (transition) = 98.500 ns available.
#    Critical path: bit_idx_reg → s-box 5-bit ALU → shift_reg[i]_D.
#    This path is very short (~3-5 gate levels); enormous timing slack exists.
#    Slack can be traded for area: use set_max_area 0 aggressively.
#
#    To bound the s-box slice path and leave area optimizer room to downsize:
#------------------------------------------------------------------------------
# set_max_delay 10.000 -from [get_cells {bit_idx_reg*}] -to [get_cells {sbox_out_reg*}]
# set_max_area 0

#------------------------------------------------------------------------------
# 8. RETIMING
#    Not applicable: serialized architecture has no meaningful pipeline stages
#    to rebalance. Retiming is disabled to preserve shift-register semantics.
#------------------------------------------------------------------------------
# set_attribute retime false [get_db designs ascon_perm_serialized]

#------------------------------------------------------------------------------
# 9. DRIVING CELL / OUTPUT LOAD
#    Use minimum drive strength on all non-clock outputs for area savings.
#------------------------------------------------------------------------------
set_driving_cell -no_design_rule [get_ports {start rst_n}]
set_load 2.0 [get_ports {done tag_match led_done led_tag_match led_running led_error}]

#------------------------------------------------------------------------------
# 10. OPERATING CONDITIONS
#      Worst-case slow corner to bound shift-register hold paths.
#      Uncomment and set library condition as appropriate.
#------------------------------------------------------------------------------
# set_operating_conditions -library <lib> SLOW

#==============================================================================
# END - ascon128_serialized.sdc
#==============================================================================
