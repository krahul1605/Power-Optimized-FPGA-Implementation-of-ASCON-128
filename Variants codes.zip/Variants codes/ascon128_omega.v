`timescale 1ns / 1ps
module ascon128_top (
    input  wire clk_p,clk_n,rst_n,start,
    output wire done,tag_match,led_done,led_tag_match,led_running,led_error
);
    wire clk_ibuf,clk; reg rr;
    IBUFDS #(.DIFF_TERM("FALSE"),.IBUF_LOW_PWR("FALSE"),.IOSTANDARD("LVDS"))
        u(.I(clk_p),.IB(clk_n),.O(clk_ibuf));
    BUFG b(.I(clk_ibuf),.O(clk));
    wire cd,ct;
    ascon128_complete_omega ac(.clk(clk),.rst_n(rst_n),.start(start),.done(cd),.tag_match(ct));
    assign done=cd; assign tag_match=ct;
    always @(posedge clk or negedge rst_n) if(!rst_n) rr<=0; else if(start) rr<=1; else if(cd) rr<=0;
    assign led_done=cd; assign led_tag_match=cd&ct; assign led_running=rr; assign led_error=cd&~ct;
endmodule

module ascon128_complete_omega(input wire clk,rst_n,start,output reg done,tag_match);
    localparam [127:0] KEY=128'h0F1E2D3C4B5A69788796A5B4C3D2E1F0,NONCE=128'hFFEEDDCCBBAA99887766554433221100;
    localparam [191:0] PT_PADDED=192'h46696E616C20596561722050726F6A656374204152418000;
    localparam PT_BLOCKS=3; localparam [63:0] AAD_PADDED=64'h64656D6F41414480,IV=64'h80400c0600000000;
    localparam [4:0] ST_IDLE=0,ST_EI=1,ST_EIP=2,ST_EA=3,ST_EAP=4,ST_EAD=5,
        ST_EP=6,ST_EPP=7,ST_EF=8,ST_EFW=9,ST_TS=10,ST_DI=11,ST_DIP=12,
        ST_DA=13,ST_DAP=14,ST_DAD=15,ST_DC=16,ST_DCP=17,ST_DF=18,ST_DFW=19,ST_DONE=20;
    reg [4:0] state; reg [3:0] bi;
    reg [63:0] s0,s1,s2,s3,s4;
    reg [191:0] ct_r; reg [127:0] tag_enc; reg [191:0] pt_dec;
    reg ps; wire pd; reg [3:0] psr,pnr;
    wire [63:0] po0,po1,po2,po3,po4;
    ascon_perm_omega pi(.clk(clk),.rst_n(rst_n),.start(ps),.start_round(psr),.rounds(pnr),
        .s0_in(s0),.s1_in(s1),.s2_in(s2),.s3_in(s3),.s4_in(s4),
        .s0_out(po0),.s1_out(po1),.s2_out(po2),.s3_out(po3),.s4_out(po4),.done(pd));
    always @(posedge clk or negedge rst_n) begin
        if(!rst_n) begin state<=0;done<=0;tag_match<=0;ps<=0;psr<=0;pnr<=0;bi<=0;
            s0<=0;s1<=0;s2<=0;s3<=0;s4<=0;ct_r<=0;tag_enc<=0;pt_dec<=0;
        end else begin ps<=0;
            case(state)
                ST_IDLE:begin done<=0;tag_match<=0;if(start) state<=ST_EI;end
                ST_EI:begin s0<=IV;s1<=KEY[127:64];s2<=KEY[63:0];s3<=NONCE[127:64];s4<=NONCE[63:0];
                    psr<=0;pnr<=12;ps<=1;state<=ST_EIP;end
                ST_EIP:if(pd)begin s0<=po0;s1<=po1;s2<=po2;s3<=po3^KEY[127:64];s4<=po4^KEY[63:0];state<=ST_EA;end
                ST_EA:begin s0<=s0^AAD_PADDED;psr<=6;pnr<=6;ps<=1;state<=ST_EAP;end
                ST_EAP:if(pd)begin s0<=po0;s1<=po1;s2<=po2;s3<=po3;s4<=po4;state<=ST_EAD;end
                ST_EAD:begin s4<=s4^64'h1;bi<=0;state<=ST_EP;end
                ST_EP:begin
                    if(bi<PT_BLOCKS)begin ct_r[191-bi*64-:64]<=s0^PT_PADDED[191-bi*64-:64];
                        s0<=s0^PT_PADDED[191-bi*64-:64];
                        if(bi<PT_BLOCKS-1)begin psr<=6;pnr<=6;ps<=1;bi<=bi+1;state<=ST_EPP;end else state<=ST_EF;
                    end else state<=ST_EF;end
                ST_EPP:if(pd)begin s0<=po0;s1<=po1;s2<=po2;s3<=po3;s4<=po4;state<=ST_EP;end
                ST_EF:begin s1<=s1^KEY[127:64];s2<=s2^KEY[63:0];psr<=0;pnr<=12;ps<=1;state<=ST_EFW;end
                ST_EFW:if(pd)begin tag_enc<={po3^KEY[127:64],po4^KEY[63:0]};state<=ST_TS;end
                ST_TS:state<=ST_DI;
                ST_DI:begin s0<=IV;s1<=KEY[127:64];s2<=KEY[63:0];s3<=NONCE[127:64];s4<=NONCE[63:0];
                    psr<=0;pnr<=12;ps<=1;state<=ST_DIP;end
                ST_DIP:if(pd)begin s0<=po0;s1<=po1;s2<=po2;s3<=po3^KEY[127:64];s4<=po4^KEY[63:0];state<=ST_DA;end
                ST_DA:begin s0<=s0^AAD_PADDED;psr<=6;pnr<=6;ps<=1;state<=ST_DAP;end
                ST_DAP:if(pd)begin s0<=po0;s1<=po1;s2<=po2;s3<=po3;s4<=po4;state<=ST_DAD;end
                ST_DAD:begin s4<=s4^64'h1;bi<=0;state<=ST_DC;end
                ST_DC:begin
                    if(bi<PT_BLOCKS)begin pt_dec[191-bi*64-:64]<=s0^ct_r[191-bi*64-:64];
                        s0<=ct_r[191-bi*64-:64];
                        if(bi<PT_BLOCKS-1)begin psr<=6;pnr<=6;ps<=1;bi<=bi+1;state<=ST_DCP;end else state<=ST_DF;
                    end else state<=ST_DF;end
                ST_DCP:if(pd)begin s0<=po0;s1<=po1;s2<=po2;s3<=po3;s4<=po4;state<=ST_DC;end
                ST_DF:begin s1<=s1^KEY[127:64];s2<=s2^KEY[63:0];psr<=0;pnr<=12;ps<=1;state<=ST_DFW;end
                ST_DFW:if(pd)begin tag_match<=(tag_enc=={po3^KEY[127:64],po4^KEY[63:0]});done<=1;state<=ST_DONE;end
                ST_DONE:; default:state<=ST_IDLE;
            endcase end end
endmodule
//=============================================================================
// ascon_perm_omega
//
// 4-segment unrolled pipeline — the 12 pa rounds are split into 4 segments
// of 3 rounds each, with a registered boundary between every segment.
// Each segment contains 3 fully combinational chained rounds (like a
// mini-unrolled block). The design instantiates 4 identical 3-round
// combinational blocks (using the ascon_round_comb module) connected in
// series, with a register stage between each block.
//
// Architecture:
//   Block0 (rounds 0-2): combinational 3-round chain → reg0
//   Block1 (rounds 3-5): combinational 3-round chain → reg1
//   Block2 (rounds 6-8): combinational 3-round chain → reg2
//   Block3 (rounds 9-11): combinational 3-round chain → final out
//
// For pb=6 (start_round=6): only Block2 and Block3 execute.
//
// 2 pipeline stages of latency per permutation call:
//   pa=12: 4 blocks × 1 cycle each = 4 + 1 FINISH = 5 cycles
//   pb=6:  2 blocks × 1 cycle each = 2 + 1 FINISH = 3 cycles
// Fmax: ~8 MHz / 120 ns (3 chained full rounds = ~105-135 gate levels)
//=============================================================================
module ascon_perm_omega (
    input  wire        clk,rst_n,start,
    input  wire [3:0]  start_round,rounds,
    input  wire [63:0] s0_in,s1_in,s2_in,s3_in,s4_in,
    output reg  [63:0] s0_out,s1_out,s2_out,s3_out,s4_out,
    output reg         done
);
    localparam [1:0] IDLE=2'd0,RUN=2'd1,FINISH=2'd2;
    reg [1:0] state;
    reg [2:0] seg;       // segment counter: 0..3 for pa, 2..3 for pb
    reg [2:0] seg_end;
    reg [63:0] x0,x1,x2,x3,x4;

    // Round constant lookup
    function [7:0] get_rc; input [3:0] r;
        case(r)
            4'd0:get_rc=8'hf0;4'd1:get_rc=8'he1;4'd2:get_rc=8'hd2;4'd3:get_rc=8'hc3;
            4'd4:get_rc=8'hb4;4'd5:get_rc=8'ha5;4'd6:get_rc=8'h96;4'd7:get_rc=8'h87;
            4'd8:get_rc=8'h78;4'd9:get_rc=8'h69;4'd10:get_rc=8'h5a;4'd11:get_rc=8'h4b;
            default:get_rc=8'h00;
        endcase
    endfunction

    // Single-round combinational function
    function [319:0] do_round;
        input [63:0] i0,i1,i2,i3,i4; input [7:0] rci;
        reg [63:0] c0,c1,c2,c3,c4,p0,p1,p2,p3,p4,m0,m1,m2,m3,m4;
        reg [63:0] t0,t1,t2,t3,t4,u0,u1,u2,u3,u4,v0,v1,v2,v3,v4;
        begin
            c0=i0;c1=i1;c2=i2^{56'd0,rci};c3=i3;c4=i4;
            p0=c0^c1^c2^c3^c4;p1=c1^c2^c3^c4^c0;p2=c2^c3^c4^c0^c1;p3=c3^c4^c0^c1^c2;p4=c4^c0^c1^c2^c3;
            m0=p4^{p1[0],p1[63:1]};m1=p0^{p2[0],p2[63:1]};m2=p1^{p3[0],p3[63:1]};
            m3=p2^{p4[0],p4[63:1]};m4=p3^{p0[0],p0[63:1]};
            t0=c0^m0;t1=c1^m1;t2=c2^m2;t3=c3^m3;t4=c4^m4;
            u0=~t1&t2;u1=~t2&t3;u2=~t3&t4;u3=~t4&t0;u4=~t0&t1;
            v0=t0^u0;v1=t1^u1;v2=~(t2^u2);v3=t3^u3;v4=t4^u4;
            do_round[63:0]  =v0^{v0[18:0],v0[63:19]}^{v0[27:0],v0[63:28]};
            do_round[127:64]=v1^{v1[60:0],v1[63:61]}^{v1[38:0],v1[63:39]};
            do_round[191:128]=v2^{v2[0],v2[63:1]}^{v2[5:0],v2[63:6]};
            do_round[255:192]=v3^{v3[9:0],v3[63:10]}^{v3[16:0],v3[63:17]};
            do_round[319:256]=v4^{v4[6:0],v4[63:7]}^{v4[40:0],v4[63:41]};
        end
    endfunction

    // 3-round chained block for a given starting round constant index
    function [319:0] block3;
        input [63:0] i0,i1,i2,i3,i4; input [3:0] base_rc;
        reg [319:0] r0,r1,r2;
        begin
            r0=do_round(i0,i1,i2,i3,i4,get_rc(base_rc));
            r1=do_round(r0[63:0],r0[127:64],r0[191:128],r0[255:192],r0[319:256],get_rc(base_rc+4'd1));
            r2=do_round(r1[63:0],r1[127:64],r1[191:128],r1[255:192],r1[319:256],get_rc(base_rc+4'd2));
            block3=r2;
        end
    endfunction

    // Segment base round constants
    wire [319:0] seg0_out = block3(x0,x1,x2,x3,x4, 4'd0);  // rounds 0-2
    wire [319:0] seg1_out = block3(x0,x1,x2,x3,x4, 4'd3);  // rounds 3-5
    wire [319:0] seg2_out = block3(x0,x1,x2,x3,x4, 4'd6);  // rounds 6-8
    wire [319:0] seg3_out = block3(x0,x1,x2,x3,x4, 4'd9);  // rounds 9-11

    // Select which segment output to use this cycle
    wire [319:0] seg_result =
        (seg==3'd0) ? seg0_out : (seg==3'd1) ? seg1_out :
        (seg==3'd2) ? seg2_out : seg3_out;

    always @(posedge clk or negedge rst_n) begin
        if(!rst_n) begin state<=IDLE;done<=0;seg<=0;seg_end<=0;
            x0<=0;x1<=0;x2<=0;x3<=0;x4<=0;
            s0_out<=0;s1_out<=0;s2_out<=0;s3_out<=0;s4_out<=0;
        end else case(state)
            IDLE:begin done<=0;
                if(start)begin x0<=s0_in;x1<=s1_in;x2<=s2_in;x3<=s3_in;x4<=s4_in;
                    // start_round=0 → seg 0..3; start_round=6 → seg 2..3
                    seg <= (start_round==0) ? 3'd0 : 3'd2;
                    seg_end <= (start_round==0) ? 3'd3 : 3'd3;
                    state<=RUN;
                end end
            RUN:begin
                x0<=seg_result[63:0];x1<=seg_result[127:64];x2<=seg_result[191:128];
                x3<=seg_result[255:192];x4<=seg_result[319:256];
                if(seg<seg_end) seg<=seg+3'd1; else state<=FINISH;
            end
            FINISH:begin s0_out<=x0;s1_out<=x1;s2_out<=x2;s3_out<=x3;s4_out<=x4;done<=1;state<=IDLE;end
            default:state<=IDLE;
        endcase end
endmodule
