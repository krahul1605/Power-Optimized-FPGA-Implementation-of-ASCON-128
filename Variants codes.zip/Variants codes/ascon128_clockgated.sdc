#==============================================================================
# SDC Constraints — ascon128_clockgated
# Target : Cadence Genus / Innovus
# Period : 40 ns  →  25 MHz
#
# Rationale
# ---------
# The clockgated variant is structurally identical to the baseline in terms of
# combinational depth (one full round per cycle, ~35-45 gate levels), so the
# Fmax target is the same 25 MHz as baseline.  The innovation is power, not
# speed: 5 independent ICG (BUFGCE) cells create per-word gated clock sub-trees
# that eliminate toggle activity on words not modified in a given cycle.
#
# Constraint complexity is higher than baseline because:
#   1. Five derived clocks (clk_s0..clk_s4) must be defined as generated clocks
#   2. Clock gating checks (setup/hold on ICG enable pins) must pass timing
#   3. Cross-domain false paths between ICG sub-trees must be annotated
#   4. CTS must treat each BUFGCE output as a separate clock sink group
#==============================================================================

#-- Primary clock (LVDS input → IBUFDS → BUFG)
create_clock -name clk -period 40.000 [get_ports clk_p]
set_clock_uncertainty 0.3 [get_clocks clk]

#-- Generated clocks on BUFGCE outputs (one per word)
# Each is a gated version of clk — same period, potentially gated off.
create_generated_clock -name clk_s0 -source [get_pins u_bufg/O] \
    -divide_by 1 [get_pins u_icg0/O]
create_generated_clock -name clk_s1 -source [get_pins u_bufg/O] \
    -divide_by 1 [get_pins u_icg1/O]
create_generated_clock -name clk_s2 -source [get_pins u_bufg/O] \
    -divide_by 1 [get_pins u_icg2/O]
create_generated_clock -name clk_s3 -source [get_pins u_bufg/O] \
    -divide_by 1 [get_pins u_icg3/O]
create_generated_clock -name clk_s4 -source [get_pins u_bufg/O] \
    -divide_by 1 [get_pins u_icg4/O]

#-- Clock gating checks
# The ICG enable (CE pin of BUFGCE) is driven by combinational logic from the
# FSM state register.  Genus enforces a setup check: en must be stable before
# the falling edge of clk that latches into the ICG latch.
# Typical hold window: 2 ns before falling edge; setup window: 2 ns.
set_clock_gating_check -setup 2.0 -hold 0.5 [get_cells {u_icg0 u_icg1 u_icg2 u_icg3 u_icg4}]

#-- Inter-ICG false paths
# When two ICG sub-trees are simultaneously active (e.g., during a full round,
# all five are enabled), the paths are synchronous same-domain and must be
# analyzed.  When only one ICG is active (e.g., ST_ENC_AAD: only clk_s0
# enabled), paths from inactive clocks to inactive FFs are false.
# Document the always-false cases for power analysis accuracy:
set_false_path -from [get_clocks clk_s1] -to [get_clocks clk_s0]
set_false_path -from [get_clocks clk_s2] -to [get_clocks clk_s0]
set_false_path -from [get_clocks clk_s0] -to [get_clocks clk_s3]
set_false_path -from [get_clocks clk_s0] -to [get_clocks clk_s4]

#-- Input/output timing
set_input_delay  -clock clk -max 1.0 [get_ports {rst_n start}]
set_output_delay -clock clk -max 2.0 [get_ports {done tag_match led_*}]

#-- Load/drive
set_load        5.0 [get_ports {done tag_match led_done led_tag_match led_running led_error}]
set_drive       1.0 [get_ports {clk_p clk_n rst_n start}]

#-- Fanout on FSM state → enable signals (fan out to ICG CE pins only — 5 sinks)
# No max_fanout constraint needed; 5 sinks is trivially driveable.

#-- Power intent (for Voltus / UPF-aware synthesis)
# Annotate that ICG cells implement clock gating for power estimation.
# This hint allows Genus power analysis to correctly account for gated toggling.
# set_clock_gating true   ; # enable Genus clock gating inference check
# Note: explicit BUFGCE instantiation overrides automatic inference.

#-- False path on async reset
set_false_path -from [get_ports rst_n]
set_false_path -to   [get_ports led_*]

#-- Operating conditions
set_operating_conditions -max_library slow -max slow
