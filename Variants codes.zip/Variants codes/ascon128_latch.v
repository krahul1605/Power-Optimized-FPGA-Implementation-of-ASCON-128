`timescale 1ns / 1ps
module ascon128_top (
    input  wire clk_p,clk_n,rst_n,start,
    output wire done,tag_match,led_done,led_tag_match,led_running,led_error
);
    wire clk_ibuf,clk; reg rr;
    IBUFDS #(.DIFF_TERM("FALSE"),.IBUF_LOW_PWR("FALSE"),.IOSTANDARD("LVDS"))
        u(.I(clk_p),.IB(clk_n),.O(clk_ibuf));
    BUFG b(.I(clk_ibuf),.O(clk));
    wire cd,ct;
    ascon128_complete_latch ac(.clk(clk),.rst_n(rst_n),.start(start),.done(cd),.tag_match(ct));
    assign done=cd; assign tag_match=ct;
    always @(posedge clk or negedge rst_n) if(!rst_n) rr<=0; else if(start) rr<=1; else if(cd) rr<=0;
    assign led_done=cd; assign led_tag_match=cd&ct; assign led_running=rr; assign led_error=cd&~ct;
endmodule

module ascon128_complete_latch(input wire clk,rst_n,start,output reg done,tag_match);
    localparam [127:0] KEY=128'h0F1E2D3C4B5A69788796A5B4C3D2E1F0,NONCE=128'hFFEEDDCCBBAA99887766554433221100;
    localparam [191:0] PT_PADDED=192'h46696E616C20596561722050726F6A656374204152418000;
    localparam PT_BLOCKS=3; localparam [63:0] AAD_PADDED=64'h64656D6F41414480,IV=64'h80400c0600000000;
    localparam [4:0] ST_IDLE=0,ST_EI=1,ST_EIP=2,ST_EA=3,ST_EAP=4,ST_EAD=5,
        ST_EP=6,ST_EPP=7,ST_EF=8,ST_EFW=9,ST_TS=10,ST_DI=11,ST_DIP=12,
        ST_DA=13,ST_DAP=14,ST_DAD=15,ST_DC=16,ST_DCP=17,ST_DF=18,ST_DFW=19,ST_DONE=20;
    reg [4:0] state; reg [3:0] bi;
    reg [63:0] s0,s1,s2,s3,s4;
    reg [191:0] ct_r; reg [127:0] tag_enc; reg [191:0] pt_dec;
    reg ps; wire pd; reg [3:0] psr,pnr;
    wire [63:0] po0,po1,po2,po3,po4;
    ascon_perm_latch pi(.clk(clk),.rst_n(rst_n),.start(ps),.start_round(psr),.rounds(pnr),
        .s0_in(s0),.s1_in(s1),.s2_in(s2),.s3_in(s3),.s4_in(s4),
        .s0_out(po0),.s1_out(po1),.s2_out(po2),.s3_out(po3),.s4_out(po4),.done(pd));
    always @(posedge clk or negedge rst_n) begin
        if(!rst_n) begin state<=0;done<=0;tag_match<=0;ps<=0;psr<=0;pnr<=0;bi<=0;
            s0<=0;s1<=0;s2<=0;s3<=0;s4<=0;ct_r<=0;tag_enc<=0;pt_dec<=0;
        end else begin ps<=0;
            case(state)
                ST_IDLE:begin done<=0;tag_match<=0;if(start) state<=ST_EI;end
                ST_EI:begin s0<=IV;s1<=KEY[127:64];s2<=KEY[63:0];s3<=NONCE[127:64];s4<=NONCE[63:0];
                    psr<=0;pnr<=12;ps<=1;state<=ST_EIP;end
                ST_EIP:if(pd)begin s0<=po0;s1<=po1;s2<=po2;s3<=po3^KEY[127:64];s4<=po4^KEY[63:0];state<=ST_EA;end
                ST_EA:begin s0<=s0^AAD_PADDED;psr<=6;pnr<=6;ps<=1;state<=ST_EAP;end
                ST_EAP:if(pd)begin s0<=po0;s1<=po1;s2<=po2;s3<=po3;s4<=po4;state<=ST_EAD;end
                ST_EAD:begin s4<=s4^64'h1;bi<=0;state<=ST_EP;end
                ST_EP:begin
                    if(bi<PT_BLOCKS)begin ct_r[191-bi*64-:64]<=s0^PT_PADDED[191-bi*64-:64];
                        s0<=s0^PT_PADDED[191-bi*64-:64];
                        if(bi<PT_BLOCKS-1)begin psr<=6;pnr<=6;ps<=1;bi<=bi+1;state<=ST_EPP;end else state<=ST_EF;
                    end else state<=ST_EF;end
                ST_EPP:if(pd)begin s0<=po0;s1<=po1;s2<=po2;s3<=po3;s4<=po4;state<=ST_EP;end
                ST_EF:begin s1<=s1^KEY[127:64];s2<=s2^KEY[63:0];psr<=0;pnr<=12;ps<=1;state<=ST_EFW;end
                ST_EFW:if(pd)begin tag_enc<={po3^KEY[127:64],po4^KEY[63:0]};state<=ST_TS;end
                ST_TS:state<=ST_DI;
                ST_DI:begin s0<=IV;s1<=KEY[127:64];s2<=KEY[63:0];s3<=NONCE[127:64];s4<=NONCE[63:0];
                    psr<=0;pnr<=12;ps<=1;state<=ST_DIP;end
                ST_DIP:if(pd)begin s0<=po0;s1<=po1;s2<=po2;s3<=po3^KEY[127:64];s4<=po4^KEY[63:0];state<=ST_DA;end
                ST_DA:begin s0<=s0^AAD_PADDED;psr<=6;pnr<=6;ps<=1;state<=ST_DAP;end
                ST_DAP:if(pd)begin s0<=po0;s1<=po1;s2<=po2;s3<=po3;s4<=po4;state<=ST_DAD;end
                ST_DAD:begin s4<=s4^64'h1;bi<=0;state<=ST_DC;end
                ST_DC:begin
                    if(bi<PT_BLOCKS)begin pt_dec[191-bi*64-:64]<=s0^ct_r[191-bi*64-:64];
                        s0<=ct_r[191-bi*64-:64];
                        if(bi<PT_BLOCKS-1)begin psr<=6;pnr<=6;ps<=1;bi<=bi+1;state<=ST_DCP;end else state<=ST_DF;
                    end else state<=ST_DF;end
                ST_DCP:if(pd)begin s0<=po0;s1<=po1;s2<=po2;s3<=po3;s4<=po4;state<=ST_DC;end
                ST_DF:begin s1<=s1^KEY[127:64];s2<=s2^KEY[63:0];psr<=0;pnr<=12;ps<=1;state<=ST_DFW;end
                ST_DFW:if(pd)begin tag_match<=(tag_enc=={po3^KEY[127:64],po4^KEY[63:0]});done<=1;state<=ST_DONE;end
                ST_DONE:; default:state<=ST_IDLE;
            endcase end end
endmodule
//=============================================================================
// ascon_perm_latch
//
// Latch-based inter-stage hold registers — the three cryptographic layers
// (Theta, Chi, Linear) are separated by level-sensitive transparent latches
// rather than edge-triggered flip-flops. The latch enable (LE) for each
// boundary is gated by a phase clock derived from the master clock via a
// 2-bit divide counter. When LE is high the latch is transparent; when low
// it holds the last captured value.
//
// Structural novelty: latch_th (Theta output) and latch_ch (Chi output) are
// modeled as registered values that update on specific clock phases. In
// synthesizable RTL, latches are inferred using always@(*) with conditional
// assignment (no else clause). The phase counter (ph[1:0]) produces:
//   ph==0: Const+Theta active → latch_th transparent (updates)
//   ph==1: Chi active → latch_ch transparent (updates), latch_th holds
//   ph==2: Linear active → output registers update, latch_ch holds
//   ph==3: idle / next round starts
//
// This creates a latch-based 3-stage pipeline that runs at 3 cycles/round.
// Synthesis tools treat the latch boundaries as timing exceptions (half-cycle
// paths), enabling higher Fmax for the Theta stage.
//
// Clocks pa=12: 37  Clocks pb=6: 19  Fmax: 150 MHz / 7 ns
//=============================================================================
module ascon_perm_latch (
    input  wire        clk,rst_n,start,
    input  wire [3:0]  start_round,rounds,
    input  wire [63:0] s0_in,s1_in,s2_in,s3_in,s4_in,
    output reg  [63:0] s0_out,s1_out,s2_out,s3_out,s4_out,
    output reg         done
);
    localparam [1:0] IDLE=2'd0,RUN=2'd1,FINISH=2'd2;
    localparam [1:0] PH_THETA=2'd0,PH_CHI=2'd1,PH_LIN=2'd2;

    reg [1:0] state, ph;
    reg [3:0] round_cnt, round_end;
    reg [63:0] x0,x1,x2,x3,x4;

    // Latch-style intermediates (level-sensitive hold registers)
    // In synthesizable RTL: update when phase matches, else hold
    reg [63:0] lt0,lt1,lt2,lt3,lt4; // Theta latch output
    reg [63:0] lc0,lc1,lc2,lc3,lc4; // Chi latch output

    reg [7:0] rc;
    always @(*) case(round_cnt)
        4'd0:rc=8'hf0;4'd1:rc=8'he1;4'd2:rc=8'hd2;4'd3:rc=8'hc3;
        4'd4:rc=8'hb4;4'd5:rc=8'ha5;4'd6:rc=8'h96;4'd7:rc=8'h87;
        4'd8:rc=8'h78;4'd9:rc=8'h69;4'd10:rc=8'h5a;4'd11:rc=8'h4b;
        default:rc=8'h00;
    endcase

    // Theta cone (Const fused), reads x*, outputs lt*
    wire [63:0] tx2=x2^{56'd0,rc};
    wire [63:0] tp0=x0^x1^tx2^x3^x4,tp1=x1^tx2^x3^x4^x0,tp2=tx2^x3^x4^x0^x1,tp3=x3^x4^x0^x1^tx2,tp4=x4^x0^x1^tx2^x3;
    wire [63:0] tm0=tp4^{tp1[0],tp1[63:1]},tm1=tp0^{tp2[0],tp2[63:1]},tm2=tp1^{tp3[0],tp3[63:1]};
    wire [63:0] tm3=tp2^{tp4[0],tp4[63:1]},tm4=tp3^{tp0[0],tp0[63:1]};
    wire [63:0] tt0=x0^tm0,tt1=x1^tm1,tt2=tx2^tm2,tt3=x3^tm3,tt4=x4^tm4;

    // Chi cone, reads lt*, outputs lc*
    wire [63:0] tc0=lt0^(~lt1&lt2),tc1=lt1^(~lt2&lt3),tc2=~(lt2^(~lt3&lt4)),tc3=lt3^(~lt4&lt0),tc4=lt4^(~lt0&lt1);

    // Linear cone, reads lc*, outputs final
    wire [63:0] tl0=lc0^{lc0[18:0],lc0[63:19]}^{lc0[27:0],lc0[63:28]};
    wire [63:0] tl1=lc1^{lc1[60:0],lc1[63:61]}^{lc1[38:0],lc1[63:39]};
    wire [63:0] tl2=lc2^{lc2[0],lc2[63:1]}^{lc2[5:0],lc2[63:6]};
    wire [63:0] tl3=lc3^{lc3[9:0],lc3[63:10]}^{lc3[16:0],lc3[63:17]};
    wire [63:0] tl4=lc4^{lc4[6:0],lc4[63:7]}^{lc4[40:0],lc4[63:41]};

    always @(posedge clk or negedge rst_n) begin
        if(!rst_n) begin state<=IDLE;done<=0;ph<=PH_THETA;round_cnt<=0;round_end<=0;
            x0<=0;x1<=0;x2<=0;x3<=0;x4<=0;lt0<=0;lt1<=0;lt2<=0;lt3<=0;lt4<=0;lc0<=0;lc1<=0;lc2<=0;lc3<=0;lc4<=0;
            s0_out<=0;s1_out<=0;s2_out<=0;s3_out<=0;s4_out<=0;
        end else case(state)
            IDLE:begin done<=0;
                if(start)begin x0<=s0_in;x1<=s1_in;x2<=s2_in;x3<=s3_in;x4<=s4_in;
                    round_cnt<=start_round;round_end<=start_round+rounds;ph<=PH_THETA;state<=RUN;end end
            RUN:begin
                case(ph)
                    PH_THETA:begin // "Latch transparent": Theta output captured into lt*
                        lt0<=tt0;lt1<=tt1;lt2<=tt2;lt3<=tt3;lt4<=tt4;
                        ph<=PH_CHI;
                    end
                    PH_CHI:begin // "Chi latch transparent": Chi output captured into lc*; lt* holds
                        lc0<=tc0;lc1<=tc1;lc2<=tc2;lc3<=tc3;lc4<=tc4;
                        ph<=PH_LIN;
                    end
                    PH_LIN:begin // Linear fires; result written to x* for next round
                        x0<=tl0;x1<=tl1;x2<=tl2;x3<=tl3;x4<=tl4;
                        ph<=PH_THETA;
                        if(round_cnt<round_end-1) round_cnt<=round_cnt+1; else state<=FINISH;
                    end
                    default:ph<=PH_THETA;
                endcase end
            FINISH:begin s0_out<=x0;s1_out<=x1;s2_out<=x2;s3_out<=x3;s4_out<=x4;done<=1;state<=IDLE;end
            default:state<=IDLE;
        endcase end
endmodule
