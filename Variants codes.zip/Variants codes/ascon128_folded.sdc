#==============================================================================
# ASCON-128  ·  Variant: folded
# SDC for Cadence Genus Synthesis
#
# Permutation architecture: Folded datapath — a single registered compute
#   unit iterates through each of the 8 ASCON sub-steps (CONST, THETA_A,
#   THETA_B, THETA_C, CHI1, CHI2, LIN1, LIN2) sequentially, controlled by
#   a 3-bit sub-step counter. Intermediate state is held in a single set of
#   5×64-bit working registers that are written back each sub-step cycle.
#
# Architecture trade-offs:
#   + Minimum register count: only ONE set of 5×64b working regs (320 FFs)
#     plus sub-step control mux overhead.
#   + Smallest combinational logic area: shared ALU serves all sub-steps.
#   - Highest latency: 8 sub-step cycles × rounds + overhead.
#   - Mux-dominated critical path (8-way select on compute unit input).
#
# Timing impact vs elevated:
#   - Critical path per cycle: mux select + heaviest sub-step (CHI1, ~6 LUT).
#   - Clock period target: 20.000 ns (50 MHz) — mux overhead limits Fmax.
#   - Input/output delays: 2.0/0.5 ns standard board interface.
#   - Multicycle paths: NOT needed — folded design is single-cycle per sub-step.
#
# Clocks per pa=12 call : 12 rounds × 8 sub-steps = 96 + 1 FINISH = 97
# Clocks per pb=6  call :  6 rounds × 8 sub-steps = 48 + 1 FINISH = 49
#
# Synthesis guidance for Genus:
#   High-effort mapping recommended on the mux-dominated compute path.
#   The 8-way sub-step mux tree is the primary area/timing bottleneck.
#   Genus compile_ultra with structuring enabled helps collapse mux logic.
#==============================================================================

#------------------------------------------------------------------------------
# 1. CLOCK DEFINITION
#    50 MHz / 20 ns — folded single-ALU sub-step architecture
#------------------------------------------------------------------------------
create_clock -period 20.000 \
             -name sys_clk \
             -waveform {0.000 10.000} \
             [get_ports clk_p]

#------------------------------------------------------------------------------
# 2. CLOCK UNCERTAINTY
#    Moderate jitter budget for 50 MHz board-adjacent clock.
#------------------------------------------------------------------------------
set_clock_uncertainty -setup 0.300 [get_clocks sys_clk]
set_clock_uncertainty -hold  0.200 [get_clocks sys_clk]

#------------------------------------------------------------------------------
# 3. CLOCK TRANSITION
#    Moderate edge rate for 50 MHz operation.
#------------------------------------------------------------------------------
set_clock_transition -rise 0.100 [get_clocks sys_clk]
set_clock_transition -fall 0.100 [get_clocks sys_clk]

#------------------------------------------------------------------------------
# 4. INPUT DELAYS
#    At 20 ns period, 2.0 ns max input delay leaves 17.7 ns internal budget.
#------------------------------------------------------------------------------
set_input_delay -clock sys_clk -max 2.000 [get_ports rst_n]
set_input_delay -clock sys_clk -min 0.500 [get_ports rst_n]
set_input_delay -clock sys_clk -max 2.000 [get_ports start]
set_input_delay -clock sys_clk -min 0.500 [get_ports start]

#------------------------------------------------------------------------------
# 5. OUTPUT DELAYS
#------------------------------------------------------------------------------
set_output_delay -clock sys_clk -max 2.000 [get_ports done]
set_output_delay -clock sys_clk -min 0.500 [get_ports done]
set_output_delay -clock sys_clk -max 2.000 [get_ports tag_match]
set_output_delay -clock sys_clk -min 0.500 [get_ports tag_match]
set_output_delay -clock sys_clk -max 2.000 [get_ports led_done]
set_output_delay -clock sys_clk -min 0.500 [get_ports led_done]
set_output_delay -clock sys_clk -max 2.000 [get_ports led_tag_match]
set_output_delay -clock sys_clk -min 0.500 [get_ports led_tag_match]
set_output_delay -clock sys_clk -max 2.000 [get_ports led_running]
set_output_delay -clock sys_clk -min 0.500 [get_ports led_running]
set_output_delay -clock sys_clk -max 2.000 [get_ports led_error]
set_output_delay -clock sys_clk -min 0.500 [get_ports led_error]

#------------------------------------------------------------------------------
# 6. ASYNCHRONOUS RESET - FALSE PATH
#------------------------------------------------------------------------------
set_false_path -from [get_ports rst_n]

#------------------------------------------------------------------------------
# 7. CRITICAL PATH BUDGET - FOLDED MUX PATH
#    The folded architecture's critical path traverses:
#      sub_step_reg → 8-way mux select logic → ALU compute → x*_reg
#    Budget: 20.000 - 0.300 (unc) - 0.100 (transition) = 19.600 ns available.
#    CHI1 sub-step (AND-NOT) is the heaviest single ALU computation.
#    Mux overhead typically adds 1-2 LUT levels on top of the ALU path.
#
#    To guide Genus optimization on the mux-to-register path:
#------------------------------------------------------------------------------
# set_max_delay 19.600 -from [get_cells {sub_step_reg*}] -to [get_cells {x*_reg*}]

#------------------------------------------------------------------------------
# 8. RETIMING
#    Not recommended for folded architecture — retiming across the shared
#    compute unit would require structural refactoring beyond SDC control.
#------------------------------------------------------------------------------
# set_attribute retime false [get_db designs ascon_perm_folded]

#------------------------------------------------------------------------------
# 9. DRIVING CELL / OUTPUT LOAD
#------------------------------------------------------------------------------
set_driving_cell -no_design_rule [get_ports {start rst_n}]
set_load 5.0 [get_ports {done tag_match led_done led_tag_match led_running led_error}]

#------------------------------------------------------------------------------
# 10. OPERATING CONDITIONS
#      Typical corner for area-efficient folded synthesis study.
#      Uncomment and set library condition as appropriate.
#------------------------------------------------------------------------------
# set_operating_conditions -library <lib> TYPICAL

#==============================================================================
# END - ascon128_folded.sdc
#==============================================================================
