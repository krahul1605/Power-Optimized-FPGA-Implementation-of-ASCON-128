#==============================================================================
# ASCON-128  ·  Variant: bytelane
# SDC for Cadence Genus Synthesis
#
# Permutation architecture: Byte-lane parallel S-box.
#   Chi is decomposed into 8 independent 8-bit lanes (generate block).
#   Each lane handles bits [8k+7:8k] across all five 64-bit state words.
#   8 lane outputs are concatenated into the full 64-bit chi result.
#
#   BL_CONST: x2 ^= rc              Path: ~1-2 gate levels,  ~1-2 ns
#   BL_THETA: full Theta (64-bit)   Path: ~8-10 gate levels, ~8 ns (critical)
#   BL_CHI  : 8 × 8-bit lanes       Path: ~3-4 gate levels,  ~3-4 ns
#   BL_LIN  : full Linear (64-bit)  Path: ~4-5 gate levels,  ~4-5 ns
#
#   Fmax target: 100 MHz / 10 ns (BL_THETA bottleneck)
#
# Clocks per pa=12 : 48 + 1 = 49   Clocks per pb=6 : 24 + 1 = 25
#
# Synthesis note: The 8 BYTE_LANE generate instances are structurally
#   independent. Place them in proximity to maximize byte-slice locality.
#   The 8 lane outputs are simple wire assignments (no mux overhead).
#==============================================================================
create_clock -period 10.000 -name sys_clk -waveform {0.000 5.000} [get_ports clk_p]
set_clock_uncertainty -setup 0.200 [get_clocks sys_clk]
set_clock_uncertainty -hold  0.100 [get_clocks sys_clk]
set_clock_transition -rise 0.100 [get_clocks sys_clk]
set_clock_transition -fall 0.100 [get_clocks sys_clk]
set_input_delay -clock sys_clk -max 2.000 [get_ports rst_n]
set_input_delay -clock sys_clk -min 0.500 [get_ports rst_n]
set_input_delay -clock sys_clk -max 2.000 [get_ports start]
set_input_delay -clock sys_clk -min 0.500 [get_ports start]
set_output_delay -clock sys_clk -max 2.000 [get_ports done]
set_output_delay -clock sys_clk -min 0.500 [get_ports done]
set_output_delay -clock sys_clk -max 2.000 [get_ports tag_match]
set_output_delay -clock sys_clk -min 0.500 [get_ports tag_match]
set_output_delay -clock sys_clk -max 2.000 [get_ports led_done]
set_output_delay -clock sys_clk -min 0.500 [get_ports led_done]
set_output_delay -clock sys_clk -max 2.000 [get_ports led_tag_match]
set_output_delay -clock sys_clk -min 0.500 [get_ports led_tag_match]
set_output_delay -clock sys_clk -max 2.000 [get_ports led_running]
set_output_delay -clock sys_clk -min 0.500 [get_ports led_running]
set_output_delay -clock sys_clk -max 2.000 [get_ports led_error]
set_output_delay -clock sys_clk -min 0.500 [get_ports led_error]
set_false_path -from [get_ports rst_n]
set_driving_cell -lib_cell INVX1 -no_design_rule [get_ports {start rst_n}]
set_load 5.0 [get_ports {done tag_match led_done led_tag_match led_running led_error}]
# set_operating_conditions -library <lib> TYPICAL
#==============================================================================
# END - ascon128_bytelane.sdc
#==============================================================================
