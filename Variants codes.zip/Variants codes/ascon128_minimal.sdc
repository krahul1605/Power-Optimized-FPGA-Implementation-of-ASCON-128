#==============================================================================
# ASCON-128  ·  Variant: s-box-minimal
# SDC for Cadence Genus Synthesis
#
# Permutation architecture: single-cycle full round (Const+Theta+Chi+Linear
# in one combinational cloud, registered once per round).
#
# Timing impact vs baseline:
#   - Longest combinational path: full ASCON round (all 4 sub-steps chained).
#     Estimated 15-18 gate levels of XOR/AND depth.
#   - Clock period relaxed to 40.000 ns (25 MHz) — same as baseline because
#     the FPGA reference used 25 MHz; ASIC target may relax further.
#   - If targeting higher Fmax, increase period below and re-check hold.
#   - Input/output delays unchanged from baseline.
#   - No multicycle paths needed (single-cycle round is the unit of work).
#
# Synthesis guidance for Genus:
#   set_attribute retime true [get_db designs ascon_perm_minimal]
#   (optional: let Genus balance the combo chain if Fmax is critical)
#==============================================================================

#------------------------------------------------------------------------------
# 1. CLOCK DEFINITION
#    25 MHz / 40 ns — preserved from baseline XDC
#------------------------------------------------------------------------------
create_clock -period 40.000 \
             -name sys_clk \
             -waveform {0.000 20.000} \
             [get_ports clk_p]

#------------------------------------------------------------------------------
# 2. CLOCK UNCERTAINTY
#    Slightly increased setup margin for deep combinational path variance.
#------------------------------------------------------------------------------
set_clock_uncertainty -setup 0.600 [get_clocks sys_clk]
set_clock_uncertainty -hold  0.200 [get_clocks sys_clk]

#------------------------------------------------------------------------------
# 3. CLOCK TRANSITION
#------------------------------------------------------------------------------
set_clock_transition -rise 0.100 [get_clocks sys_clk]
set_clock_transition -fall 0.100 [get_clocks sys_clk]

#------------------------------------------------------------------------------
# 4. INPUT DELAYS
#------------------------------------------------------------------------------
set_input_delay -clock sys_clk -max 2.000 [get_ports rst_n]
set_input_delay -clock sys_clk -min 0.500 [get_ports rst_n]
set_input_delay -clock sys_clk -max 2.000 [get_ports start]
set_input_delay -clock sys_clk -min 0.500 [get_ports start]

#------------------------------------------------------------------------------
# 5. OUTPUT DELAYS
#------------------------------------------------------------------------------
set_output_delay -clock sys_clk -max 2.000 [get_ports done]
set_output_delay -clock sys_clk -min 0.500 [get_ports done]
set_output_delay -clock sys_clk -max 2.000 [get_ports tag_match]
set_output_delay -clock sys_clk -min 0.500 [get_ports tag_match]
set_output_delay -clock sys_clk -max 2.000 [get_ports led_done]
set_output_delay -clock sys_clk -min 0.500 [get_ports led_done]
set_output_delay -clock sys_clk -max 2.000 [get_ports led_tag_match]
set_output_delay -clock sys_clk -min 0.500 [get_ports led_tag_match]
set_output_delay -clock sys_clk -max 2.000 [get_ports led_running]
set_output_delay -clock sys_clk -min 0.500 [get_ports led_running]
set_output_delay -clock sys_clk -max 2.000 [get_ports led_error]
set_output_delay -clock sys_clk -min 0.500 [get_ports led_error]

#------------------------------------------------------------------------------
# 6. ASYNCHRONOUS RESET - FALSE PATH
#------------------------------------------------------------------------------
set_false_path -from [get_ports rst_n]

#------------------------------------------------------------------------------
# 7. COMBINATIONAL PATH BUDGET ANNOTATION
#    The full round path (ROUND state) spans the entire clock period.
#    Inform Genus of the expected critical path for accurate optimization.
#    Adjust <path_budget_ns> to (period - setup_margin - clock_uncertainty).
#    At 40 ns period: budget ≈ 40 - 2.0 - 0.6 = 37.4 ns
#------------------------------------------------------------------------------
# set_max_delay 37.400 -from [get_cells {x0_reg* x1_reg* x2_reg* x3_reg* x4_reg*}] \
#               -to   [get_cells {x0_reg* x1_reg* x2_reg* x3_reg* x4_reg*}]

#------------------------------------------------------------------------------
# 8. DRIVING CELL / OUTPUT LOAD
#------------------------------------------------------------------------------
set_driving_cell -no_design_rule [get_ports {start rst_n}]
set_load 5.0 [get_ports {done tag_match led_done led_tag_match led_running led_error}]

#------------------------------------------------------------------------------
# 9. AREA / POWER OPTIMIZATION HINTS (minimal variant)
#    Genus will prefer low-area cells since register count is reduced.
#    Uncomment and set library condition as appropriate.
#------------------------------------------------------------------------------
# set_attribute optimize_area true  [get_db designs ascon_perm_minimal]
# set_operating_conditions -library <lib> <condition>

#==============================================================================
# END - ascon128_minimal.sdc
#==============================================================================
