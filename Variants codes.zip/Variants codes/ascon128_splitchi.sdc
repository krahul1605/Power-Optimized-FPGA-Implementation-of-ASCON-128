#==============================================================================
# ASCON-128  ·  Variant: splitchi
# SDC for Cadence Genus Synthesis
#
# Permutation architecture: Split-Chi 2-stage pipeline — a single registered
#   cut is placed between CHI1 (the AND-NOT computation) and CHI2 (the XOR
#   completion and mandatory x2 inversion). All other sub-steps are fused into
#   the two stages around this cut:
#
#     Stage A:  CONST + THETA_A + THETA_B + THETA_C + CHI1
#               Inputs: x0..x4 (current state)
#               Outputs registered: t0..t4 (post-theta) and u0..u4 (CHI1 AND-NOT)
#
#     Stage B:  CHI2 + LIN1 + LIN2
#               Inputs: t0..t4 and u0..u4 (from Stage A register)
#               Outputs: updated x0..x4 (new round state)
#
# Rationale: The CHI1→CHI2 transition (AND-NOT → XOR → INV) is the single
#   deepest intra-round dependency chain. Splitting here breaks the AND-NOT
#   fanout from CHI2's XOR inputs, eliminating the longest gate-level chain
#   within a single-cycle baseline round. Stage A carries THETA (the dominant
#   logic) plus CHI1; Stage B carries the lighter CHI2 and linear layers.
#
# Timing impact:
#   - Stage A critical path: THETA_A parity tree → THETA_B rotate → THETA_C
#     XOR → CHI1 AND-NOT. Est. ~20-25 gate levels (~8-10 ns at typical library).
#   - Stage B critical path: CHI2 XOR+INV → LIN1 rotate (wire) → LIN2 XOR.
#     Est. ~5-8 gate levels (~2-4 ns). Stage B is significantly shorter.
#   - Clock period target: 20.000 ns (50 MHz) — Stage A dominates; Stage B
#     has comfortable slack and pulls the overall Fmax target lower than the
#     split suggests, because both stages must meet the same clock period.
#   - Multicycle paths: NOT needed — all paths are single-cycle within stages.
#   - Note: quarterpipe (2-stage, CHI+LIN in one stage) targets 67 MHz;
#     splitchi targets 50 MHz because Stage A contains more sub-steps
#     (THETA+CHI1 vs pure THETA in quarterpipe Stage 0).
#
# Throughput:
#   pa=12 call: 12 rounds × 2 stages = 24 cycles + 1 FINISH = 25 cycles
#   pb=6  call:  6 rounds × 2 stages = 12 cycles + 1 FINISH = 13 cycles
#   At 50 MHz: pa=500 ns, pb=260 ns per permutation call.
#
# Synthesis guidance for Genus:
#   - MEDIUM effort: Stage A combinational depth is the limiter; Genus should
#     focus optimization effort there. Stage B is easy to close at 50 MHz.
#   - Keep Stage A and Stage B as separate hierarchical blocks if possible.
#   - Fanout on u0..u4 (CHI1 AND-NOT output, 5×64b = 320 wires feeding Stage B)
#     may require buffering — allow Genus to insert buffers on u* nets.
#   - The inter-stage register (t0..t4, u0..u4) is 640 bits; ensure placement
#     groups Stage A drivers near Stage B receivers for minimal routing delay.
#==============================================================================

#------------------------------------------------------------------------------
# 1. CLOCK DEFINITION
#    50 MHz / 20 ns — Stage A (THETA+CHI1) is the critical bottleneck
#------------------------------------------------------------------------------
create_clock -period 20.000 \
             -name sys_clk \
             -waveform {0.000 10.000} \
             [get_ports clk_p]

#------------------------------------------------------------------------------
# 2. CLOCK UNCERTAINTY
#    Moderate jitter budget for 50 MHz. ZCU104 LVDS spec at 50 MHz is relaxed;
#    0.400 ns setup margin covers jitter and inter-clock skew.
#------------------------------------------------------------------------------
set_clock_uncertainty -setup 0.400 [get_clocks sys_clk]
set_clock_uncertainty -hold  0.200 [get_clocks sys_clk]

#------------------------------------------------------------------------------
# 3. CLOCK TRANSITION
#    Moderate edge rate; 50 MHz LVDS input, board-driven.
#------------------------------------------------------------------------------
set_clock_transition -rise 0.150 [get_clocks sys_clk]
set_clock_transition -fall 0.150 [get_clocks sys_clk]

#------------------------------------------------------------------------------
# 4. INPUT DELAYS
#    2.0 ns leaves 17.45 ns internal budget at 20 ns period — very comfortable.
#    Start and rst_n are not timing-critical for this variant.
#------------------------------------------------------------------------------
set_input_delay -clock sys_clk -max 2.000 [get_ports rst_n]
set_input_delay -clock sys_clk -min 0.500 [get_ports rst_n]
set_input_delay -clock sys_clk -max 2.000 [get_ports start]
set_input_delay -clock sys_clk -min 0.500 [get_ports start]

#------------------------------------------------------------------------------
# 5. OUTPUT DELAYS
#------------------------------------------------------------------------------
set_output_delay -clock sys_clk -max 2.000 [get_ports done]
set_output_delay -clock sys_clk -min 0.500 [get_ports done]
set_output_delay -clock sys_clk -max 2.000 [get_ports tag_match]
set_output_delay -clock sys_clk -min 0.500 [get_ports tag_match]
set_output_delay -clock sys_clk -max 2.000 [get_ports led_done]
set_output_delay -clock sys_clk -min 0.500 [get_ports led_done]
set_output_delay -clock sys_clk -max 2.000 [get_ports led_tag_match]
set_output_delay -clock sys_clk -min 0.500 [get_ports led_tag_match]
set_output_delay -clock sys_clk -max 2.000 [get_ports led_running]
set_output_delay -clock sys_clk -min 0.500 [get_ports led_running]
set_output_delay -clock sys_clk -max 2.000 [get_ports led_error]
set_output_delay -clock sys_clk -min 0.500 [get_ports led_error]

#------------------------------------------------------------------------------
# 6. ASYNCHRONOUS RESET — FALSE PATH
#------------------------------------------------------------------------------
set_false_path -from [get_ports rst_n]

#------------------------------------------------------------------------------
# 7. CRITICAL PATH BUDGET
#    Two inter-register paths per round:
#
#    Stage A (x*_reg → t*/u*_reg):
#      THETA_A parity XOR (5-input tree, ~3-4 lev) + THETA_B rotate (~1-2 lev)
#      + THETA_C XOR (~1 lev) + CHI1 AND-NOT (~1 lev) = ~20-25 gate levels.
#      Estimated timing: ~8-12 ns in typical library.
#      This is the bottleneck — sets the 20 ns clock period requirement.
#
#    Stage B (t*/u*_reg → x*_reg):
#      CHI2 XOR (~1 lev) + x2 INV (~1 lev) + LIN1 rotate (wire, ~0 lev)
#      + LIN2 XOR (~1 lev) = ~3-5 gate levels.
#      Estimated timing: ~2-4 ns — significantly lighter than Stage A.
#      Stage B will have ~14-16 ns of slack at 20 ns period; this slack
#      can be traded for area reduction (lower drive strength / fewer buffers).
#
#    Budget: 20.000 - 0.400 (unc) - 0.150 (trans) = 19.450 ns available.
#
#    Explicitly constrain Stage A (dominant path):
#------------------------------------------------------------------------------
# set_max_delay 19.450 -from [get_cells {x*_reg*}] -to [get_cells {t*_reg* u*_reg*}]

#------------------------------------------------------------------------------
# 8. STAGE B AREA OPTIMIZATION
#    Stage B is severely over-constrained at 20 ns (needs only ~4 ns).
#    Allow Genus to trade Stage B slack for area:
#------------------------------------------------------------------------------
# set_max_delay 19.450 -from [get_cells {t*_reg* u*_reg*}] -to [get_cells {x*_reg*}]
# set_attribute map_effort low [get_db hinsts {*/stage_b*}]

#------------------------------------------------------------------------------
# 9. FANOUT CONTROL ON INTER-STAGE WIRES (u0..u4, t0..t4)
#    The 640-bit inter-stage bus feeds from Stage A registers into Stage B.
#    High fanout on u* (CHI AND-NOT terms) may require buffering:
#------------------------------------------------------------------------------
set_max_fanout 16 [get_db designs ascon_perm_splitchi]

#------------------------------------------------------------------------------
# 10. RETIMING (DISABLED)
#     Do not retime across the CHI1/CHI2 split — that is the intentional
#     architectural boundary of this variant. Retiming would merge the stages
#     and defeat the purpose of the split.
#------------------------------------------------------------------------------
# set_attribute retime false [get_db designs ascon_perm_splitchi]

#------------------------------------------------------------------------------
# 11. DRIVING CELL / OUTPUT LOAD
#------------------------------------------------------------------------------
set_driving_cell -lib_cell INVX1 -no_design_rule [get_ports {start rst_n}]
set_load 5.0 [get_ports {done tag_match led_done led_tag_match led_running led_error}]

#------------------------------------------------------------------------------
# 12. OPERATING CONDITIONS
#      Typical corner for 50 MHz target — closure is not difficult at this
#      frequency; typical-corner synthesis is adequate.
#      Uncomment and set library condition as appropriate.
#------------------------------------------------------------------------------
# set_operating_conditions -library <lib> TYPICAL

#==============================================================================
# END - ascon128_splitchi.sdc
#==============================================================================
