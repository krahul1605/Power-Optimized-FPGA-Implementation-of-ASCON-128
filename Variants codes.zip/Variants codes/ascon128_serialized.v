`timescale 1ns / 1ps
//=============================================================================
// ASCON-128  ·  Variant: serialized
//
// Visual treatment : Bit-serial s-box — absolute minimum area implementation.
//                    The ASCON 5-bit s-box is evaluated one bit-position at
//                    a time. Each clock cycle processes bit index [i] across
//                    all five 64-bit state words simultaneously:
//                      sbox({x0[i],x1[i],x2[i],x3[i],x4[i]})
//                    A 6-bit bit-index counter (bit_idx, 0..63) drives the
//                    scan. After 64 s-box cycles the full chi layer is done;
//                    the linear layer (Theta + rotations) then executes on
//                    the complete 64-bit words in subsequent cycles.
//
// Per-round sub-step schedule (69 cycles total):
//   Cycle    0   : CONST_APPLY — XOR round constant into x2 (1 cycle)
//   Cycles  1–64 : CHI_SCAN   — bit-serial chi over all 64 bit-positions
//   Cycle   65   : CHI_INV    — bitwise invert x2 per ASCON chi spec
//   Cycle   66   : THETA_A    — column parity XOR (full 64-bit, 1 cycle)
//   Cycle   67   : THETA_B    — rotation-mixed parities (full 64-bit, 1 cycle)
//   Cycle   68   : THETA_C    — theta XOR application (full 64-bit, 1 cycle)
//   Cycle   69   : LIN1       — rotation operands computed (full 64-bit)
//   Cycle   70   : LIN2       — linear XOR completes new state (full 64-bit)
//
// Clocks per pa=12 call : 12 × 71 = 852 + 1 FINISH = 853
// Clocks per pb=6  call :  6 × 71 = 426 + 1 FINISH = 427
//
// Trade-offs
//   + Minimum combinational logic area: 5-bit s-box = ~10 gates
//   + Minimum register count: shift registers + 5×64b state = ~350 FFs
//   + Suitable for ultra-constrained IoT / smartcard targets
//   - Highest latency: 853 cycles for pa=12 at any clock frequency
//   - Low throughput; best at 10 MHz (100 ns) for minimum power
//
// Functional parity: identical ports, identical FSM encoding, identical
//                    ASCON-128 algorithm (NIST compliant).
//=============================================================================

module ascon128_top (
    input  wire clk_p,
    input  wire clk_n,
    input  wire rst_n,
    input  wire start,
    output wire done,
    output wire tag_match,
    output wire led_done,
    output wire led_tag_match,
    output wire led_running,
    output wire led_error
);

    wire clk_ibuf, clk;

    IBUFDS #(
        .DIFF_TERM("FALSE"), .IBUF_LOW_PWR("FALSE"), .IOSTANDARD("LVDS")
    ) clk_ibufds (.I(clk_p), .IB(clk_n), .O(clk_ibuf));

    BUFG clk_bufg (.I(clk_ibuf), .O(clk));

    wire core_done, core_tag_match;
    reg  running_r;

    ascon128_complete_serialized ascon_core (
        .clk(clk), .rst_n(rst_n), .start(start),
        .done(core_done), .tag_match(core_tag_match)
    );

    assign done = core_done; assign tag_match = core_tag_match;

    always @(posedge clk or negedge rst_n) begin
        if (!rst_n)         running_r <= 0;
        else if (start)     running_r <= 1;
        else if (core_done) running_r <= 0;
    end

    assign led_done=core_done; assign led_tag_match=core_done&core_tag_match;
    assign led_running=running_r; assign led_error=core_done&~core_tag_match;

endmodule


//=============================================================================
// ascon128_complete_serialized  — FSM (identical to all variants)
//=============================================================================
module ascon128_complete_serialized (
    input  wire clk, rst_n, start,
    output reg  done, tag_match
);
    localparam [127:0] KEY   = 128'h0F1E2D3C4B5A69788796A5B4C3D2E1F0;
    localparam [127:0] NONCE = 128'hFFEEDDCCBBAA99887766554433221100;
    localparam [191:0] PT_PADDED  = 192'h46696E616C20596561722050726F6A656374204152418000;
    localparam         PT_BLOCKS  = 3;
    localparam [63:0]  AAD_PADDED = 64'h64656D6F41414480;
    localparam [63:0]  IV         = 64'h80400c0600000000;

    localparam [4:0]
        ST_IDLE=0, ST_ENC_INIT=1, ST_ENC_INIT_PERM=2,
        ST_ENC_AAD=3, ST_ENC_AAD_PERM=4, ST_ENC_AAD_DOM=5,
        ST_ENC_PT=6, ST_ENC_PT_PERM=7, ST_ENC_FINAL=8,
        ST_ENC_FINAL_W=9, ST_TAG_STORE=10, ST_DEC_INIT=11,
        ST_DEC_INIT_PERM=12, ST_DEC_AAD=13, ST_DEC_AAD_PERM=14,
        ST_DEC_AAD_DOM=15, ST_DEC_CT=16, ST_DEC_CT_PERM=17,
        ST_DEC_FINAL=18, ST_DEC_FINAL_W=19, ST_DONE=20;

    reg [4:0] state; reg [3:0] block_idx;
    reg [63:0] s0,s1,s2,s3,s4;
    reg [191:0] ciphertext; reg [127:0] tag_enc; reg [191:0] plaintext_dec;
    reg perm_start; wire perm_done;
    reg [3:0] perm_start_round, perm_num_rounds;
    wire [63:0] perm_out0,perm_out1,perm_out2,perm_out3,perm_out4;

    ascon_perm_serialized perm_inst (
        .clk(clk), .rst_n(rst_n), .start(perm_start),
        .start_round(perm_start_round), .rounds(perm_num_rounds),
        .s0_in(s0),.s1_in(s1),.s2_in(s2),.s3_in(s3),.s4_in(s4),
        .s0_out(perm_out0),.s1_out(perm_out1),.s2_out(perm_out2),
        .s3_out(perm_out3),.s4_out(perm_out4),.done(perm_done)
    );

    always @(posedge clk or negedge rst_n) begin
        if (!rst_n) begin
            state<=0; done<=0; tag_match<=0; perm_start<=0;
            perm_start_round<=0; perm_num_rounds<=0; block_idx<=0;
            s0<=0;s1<=0;s2<=0;s3<=0;s4<=0;
            ciphertext<=0; tag_enc<=0; plaintext_dec<=0;
        end else begin
            perm_start<=0;
            case(state)
                ST_IDLE: begin done<=0; tag_match<=0; if(start) state<=ST_ENC_INIT; end
                ST_ENC_INIT: begin
                    s0<=IV; s1<=KEY[127:64]; s2<=KEY[63:0];
                    s3<=NONCE[127:64]; s4<=NONCE[63:0];
                    perm_start_round<=0; perm_num_rounds<=12; perm_start<=1;
                    state<=ST_ENC_INIT_PERM;
                end
                ST_ENC_INIT_PERM: if(perm_done) begin
                    s0<=perm_out0; s1<=perm_out1; s2<=perm_out2;
                    s3<=perm_out3^KEY[127:64]; s4<=perm_out4^KEY[63:0];
                    state<=ST_ENC_AAD;
                end
                ST_ENC_AAD: begin
                    s0<=s0^AAD_PADDED; perm_start_round<=6; perm_num_rounds<=6;
                    perm_start<=1; state<=ST_ENC_AAD_PERM;
                end
                ST_ENC_AAD_PERM: if(perm_done) begin
                    s0<=perm_out0;s1<=perm_out1;s2<=perm_out2;s3<=perm_out3;s4<=perm_out4;
                    state<=ST_ENC_AAD_DOM;
                end
                ST_ENC_AAD_DOM: begin s4<=s4^64'h1; block_idx<=0; state<=ST_ENC_PT; end
                ST_ENC_PT: begin
                    if(block_idx<PT_BLOCKS) begin
                        ciphertext[191-block_idx*64-:64]<=s0^PT_PADDED[191-block_idx*64-:64];
                        s0<=s0^PT_PADDED[191-block_idx*64-:64];
                        if(block_idx<PT_BLOCKS-1) begin
                            perm_start_round<=6; perm_num_rounds<=6; perm_start<=1;
                            block_idx<=block_idx+1; state<=ST_ENC_PT_PERM;
                        end else state<=ST_ENC_FINAL;
                    end else state<=ST_ENC_FINAL;
                end
                ST_ENC_PT_PERM: if(perm_done) begin
                    s0<=perm_out0;s1<=perm_out1;s2<=perm_out2;s3<=perm_out3;s4<=perm_out4;
                    state<=ST_ENC_PT;
                end
                ST_ENC_FINAL: begin
                    s1<=s1^KEY[127:64]; s2<=s2^KEY[63:0];
                    perm_start_round<=0; perm_num_rounds<=12; perm_start<=1;
                    state<=ST_ENC_FINAL_W;
                end
                ST_ENC_FINAL_W: if(perm_done) begin
                    tag_enc<={perm_out3^KEY[127:64],perm_out4^KEY[63:0]};
                    state<=ST_TAG_STORE;
                end
                ST_TAG_STORE: state<=ST_DEC_INIT;
                ST_DEC_INIT: begin
                    s0<=IV; s1<=KEY[127:64]; s2<=KEY[63:0];
                    s3<=NONCE[127:64]; s4<=NONCE[63:0];
                    perm_start_round<=0; perm_num_rounds<=12; perm_start<=1;
                    state<=ST_DEC_INIT_PERM;
                end
                ST_DEC_INIT_PERM: if(perm_done) begin
                    s0<=perm_out0;s1<=perm_out1;s2<=perm_out2;
                    s3<=perm_out3^KEY[127:64];s4<=perm_out4^KEY[63:0];
                    state<=ST_DEC_AAD;
                end
                ST_DEC_AAD: begin
                    s0<=s0^AAD_PADDED; perm_start_round<=6; perm_num_rounds<=6;
                    perm_start<=1; state<=ST_DEC_AAD_PERM;
                end
                ST_DEC_AAD_PERM: if(perm_done) begin
                    s0<=perm_out0;s1<=perm_out1;s2<=perm_out2;s3<=perm_out3;s4<=perm_out4;
                    state<=ST_DEC_AAD_DOM;
                end
                ST_DEC_AAD_DOM: begin s4<=s4^64'h1; block_idx<=0; state<=ST_DEC_CT; end
                ST_DEC_CT: begin
                    if(block_idx<PT_BLOCKS) begin
                        plaintext_dec[191-block_idx*64-:64]<=s0^ciphertext[191-block_idx*64-:64];
                        s0<=ciphertext[191-block_idx*64-:64];
                        if(block_idx<PT_BLOCKS-1) begin
                            perm_start_round<=6; perm_num_rounds<=6; perm_start<=1;
                            block_idx<=block_idx+1; state<=ST_DEC_CT_PERM;
                        end else state<=ST_DEC_FINAL;
                    end else state<=ST_DEC_FINAL;
                end
                ST_DEC_CT_PERM: if(perm_done) begin
                    s0<=perm_out0;s1<=perm_out1;s2<=perm_out2;s3<=perm_out3;s4<=perm_out4;
                    state<=ST_DEC_CT;
                end
                ST_DEC_FINAL: begin
                    s1<=s1^KEY[127:64]; s2<=s2^KEY[63:0];
                    perm_start_round<=0; perm_num_rounds<=12; perm_start<=1;
                    state<=ST_DEC_FINAL_W;
                end
                ST_DEC_FINAL_W: if(perm_done) begin
                    tag_match<=(tag_enc=={perm_out3^KEY[127:64],perm_out4^KEY[63:0]});
                    done<=1; state<=ST_DONE;
                end
                ST_DONE: ;
                default: state<=ST_IDLE;
            endcase
        end
    end
endmodule


//=============================================================================
// ascon_perm_serialized
//
// Bit-serial permutation core.
//
// Per-round state machine:
//   CONST_APPLY (1 cycle)  : x2 ^= {56'd0, rc}    [word-wide, not bit-serial]
//   CHI_SCAN    (64 cycles): bit-serial chi scan, bit_idx = 0..63
//   CHI_INV     (1 cycle)  : x2 = ~x2              [ASCON chi spec]
//   THETA_A     (1 cycle)  : column parities -> p*
//   THETA_B     (1 cycle)  : rotation-mixed parities -> p*
//   THETA_C     (1 cycle)  : x* ^= p*
//   LIN1        (1 cycle)  : xi ^ rotate_a(xi) -> p*
//   LIN2        (1 cycle)  : p* ^ rotate_b(x*) -> x*; advance round
//
// Total cycles per round: 1+64+1+1+1+1+1+1 = 71
// Total clocks pa=12: 852 + 1 FINISH = 853
// Total clocks pb=6 : 426 + 1 FINISH = 427
//
// Critical path: bit_idx_reg → b0..b4 extraction → 5 AND-NOT + 5 XOR →
//                bit-masked write-back → x*_reg  (~3-5 gate levels, 10 ns)
//=============================================================================
module ascon_perm_serialized (
    input  wire        clk, rst_n, start,
    input  wire [3:0]  start_round, rounds,
    input  wire [63:0] s0_in,s1_in,s2_in,s3_in,s4_in,
    output reg  [63:0] s0_out,s1_out,s2_out,s3_out,s4_out,
    output reg         done
);

    localparam [3:0]
        IDLE        = 4'd0,
        CONST_APPLY = 4'd1,
        CHI_SCAN    = 4'd2,
        CHI_INV     = 4'd3,
        THETA_A     = 4'd4,
        THETA_B     = 4'd5,
        THETA_C     = 4'd6,
        LIN1        = 4'd7,
        LIN2        = 4'd8,
        FINISH      = 4'd9;

    reg [3:0]  state;
    reg [5:0]  bit_idx;
    reg [3:0]  round_cnt, round_end;
    reg [63:0] x0,x1,x2,x3,x4;
    reg [63:0] p0,p1,p2,p3,p4;

    // Round constant decode
    reg [7:0] rc;
    always @(*) case(round_cnt)
        4'd0:rc=8'hf0; 4'd1:rc=8'he1; 4'd2:rc=8'hd2; 4'd3:rc=8'hc3;
        4'd4:rc=8'hb4; 4'd5:rc=8'ha5; 4'd6:rc=8'h96; 4'd7:rc=8'h87;
        4'd8:rc=8'h78; 4'd9:rc=8'h69; 4'd10:rc=8'h5a; 4'd11:rc=8'h4b;
        default:rc=8'h00;
    endcase

    // -----------------------------------------------------------------------
    // Bit-serial s-box slice (combinational)
    // Reads 5 bits at position [bit_idx] from x0..x4.
    // ASCON chi: new_bi = bi XOR (~b(i+1 mod 5) AND b(i+2 mod 5))
    // -----------------------------------------------------------------------
    wire b0 = x0[bit_idx];
    wire b1 = x1[bit_idx];
    wire b2 = x2[bit_idx];
    wire b3 = x3[bit_idx];
    wire b4 = x4[bit_idx];

    wire nb0 = b0 ^ (~b1 & b2);
    wire nb1 = b1 ^ (~b2 & b3);
    wire nb2 = b2 ^ (~b3 & b4);
    wire nb3 = b3 ^ (~b4 & b0);
    wire nb4 = b4 ^ (~b0 & b1);

    // Bit-masked write-back: update only bit [bit_idx] in each 64-bit word
    wire [63:0] mask   = 64'd1 << bit_idx;
    wire [63:0] x0_new = (x0 & ~mask) | ({64{nb0}} & mask);
    wire [63:0] x1_new = (x1 & ~mask) | ({64{nb1}} & mask);
    wire [63:0] x2_new = (x2 & ~mask) | ({64{nb2}} & mask);
    wire [63:0] x3_new = (x3 & ~mask) | ({64{nb3}} & mask);
    wire [63:0] x4_new = (x4 & ~mask) | ({64{nb4}} & mask);

    always @(posedge clk or negedge rst_n) begin
        if(!rst_n) begin
            state<=IDLE; done<=0; bit_idx<=0; round_cnt<=0; round_end<=0;
            x0<=0;x1<=0;x2<=0;x3<=0;x4<=0;
            p0<=0;p1<=0;p2<=0;p3<=0;p4<=0;
            s0_out<=0;s1_out<=0;s2_out<=0;s3_out<=0;s4_out<=0;
        end else case(state)
            IDLE: begin
                done<=0;
                if(start) begin
                    x0<=s0_in;x1<=s1_in;x2<=s2_in;x3<=s3_in;x4<=s4_in;
                    round_cnt<=start_round; round_end<=start_round+rounds;
                    bit_idx<=0; state<=CONST_APPLY;
                end
            end

            // CONST: XOR round constant into x2 word-wide (1 cycle)
            CONST_APPLY: begin
                x2<=x2^{56'd0,rc}; bit_idx<=0; state<=CHI_SCAN;
            end

            // CHI_SCAN: bit-serial chi, 64 cycles (bit_idx = 0..63)
            CHI_SCAN: begin
                x0<=x0_new; x1<=x1_new; x2<=x2_new; x3<=x3_new; x4<=x4_new;
                if(bit_idx==6'd63) state<=CHI_INV;
                else bit_idx<=bit_idx+1;
            end

            // CHI_INV: invert x2 per ASCON chi specification (1 cycle)
            CHI_INV: begin x2<=~x2; state<=THETA_A; end

            // THETA_A: column parity XOR (1 cycle)
            THETA_A: begin
                p0<=x0^x1^x2^x3^x4; p1<=x1^x2^x3^x4^x0;
                p2<=x2^x3^x4^x0^x1; p3<=x3^x4^x0^x1^x2;
                p4<=x4^x0^x1^x2^x3; state<=THETA_B;
            end

            // THETA_B: rotation-mixed parities (1 cycle)
            THETA_B: begin
                p0<=p4^{p1[0],p1[63:1]};
                p1<=p0^{p2[0],p2[63:1]};
                p2<=p1^{p3[0],p3[63:1]};
                p3<=p2^{p4[0],p4[63:1]};
                p4<=p3^{p0[0],p0[63:1]};
                state<=THETA_C;
            end

            // THETA_C: apply theta XOR (1 cycle)
            THETA_C: begin
                x0<=x0^p0; x1<=x1^p1; x2<=x2^p2;
                x3<=x3^p3; x4<=x4^p4; state<=LIN1;
            end

            // LIN1: xi ^ rotate_a(xi) -> p*, preserve x* for LIN2 (1 cycle)
            LIN1: begin
                p0<=x0^{x0[18:0],x0[63:19]};
                p1<=x1^{x1[60:0],x1[63:61]};
                p2<=x2^{x2[0],   x2[63:1]};
                p3<=x3^{x3[9:0], x3[63:10]};
                p4<=x4^{x4[6:0], x4[63:7]};
                state<=LIN2;
            end

            // LIN2: p* ^ rotate_b(x*) -> x*; advance round or go to FINISH
            LIN2: begin
                x0<=p0^{x0[27:0],x0[63:28]};
                x1<=p1^{x1[38:0],x1[63:39]};
                x2<=p2^{x2[5:0], x2[63:6]};
                x3<=p3^{x3[16:0],x3[63:17]};
                x4<=p4^{x4[40:0],x4[63:41]};
                if(round_cnt < round_end-1) begin
                    round_cnt<=round_cnt+1; bit_idx<=0; state<=CONST_APPLY;
                end else state<=FINISH;
            end

            FINISH: begin
                s0_out<=x0;s1_out<=x1;s2_out<=x2;
                s3_out<=x3;s4_out<=x4; done<=1; state<=IDLE;
            end

            default: state<=IDLE;
        endcase
    end
endmodule
