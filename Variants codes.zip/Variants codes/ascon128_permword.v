`timescale 1ns / 1ps
module ascon128_top (
    input  wire clk_p,clk_n,rst_n,start,
    output wire done,tag_match,led_done,led_tag_match,led_running,led_error
);
    wire clk_ibuf,clk; reg rr;
    IBUFDS #(.DIFF_TERM("FALSE"),.IBUF_LOW_PWR("FALSE"),.IOSTANDARD("LVDS"))
        u(.I(clk_p),.IB(clk_n),.O(clk_ibuf));
    BUFG b(.I(clk_ibuf),.O(clk));
    wire cd,ct;
    ascon128_complete_permword ac(.clk(clk),.rst_n(rst_n),.start(start),.done(cd),.tag_match(ct));
    assign done=cd; assign tag_match=ct;
    always @(posedge clk or negedge rst_n) if(!rst_n) rr<=0; else if(start) rr<=1; else if(cd) rr<=0;
    assign led_done=cd; assign led_tag_match=cd&ct; assign led_running=rr; assign led_error=cd&~ct;
endmodule

module ascon128_complete_permword(input wire clk,rst_n,start,output reg done,tag_match);
    localparam [127:0] KEY=128'h0F1E2D3C4B5A69788796A5B4C3D2E1F0,NONCE=128'hFFEEDDCCBBAA99887766554433221100;
    localparam [191:0] PT_PADDED=192'h46696E616C20596561722050726F6A656374204152418000;
    localparam PT_BLOCKS=3; localparam [63:0] AAD_PADDED=64'h64656D6F41414480,IV=64'h80400c0600000000;
    localparam [4:0] ST_IDLE=0,ST_EI=1,ST_EIP=2,ST_EA=3,ST_EAP=4,ST_EAD=5,
        ST_EP=6,ST_EPP=7,ST_EF=8,ST_EFW=9,ST_TS=10,ST_DI=11,ST_DIP=12,
        ST_DA=13,ST_DAP=14,ST_DAD=15,ST_DC=16,ST_DCP=17,ST_DF=18,ST_DFW=19,ST_DONE=20;
    reg [4:0] state; reg [3:0] bi;
    reg [63:0] s0,s1,s2,s3,s4;
    reg [191:0] ct_r; reg [127:0] tag_enc; reg [191:0] pt_dec;
    reg ps; wire pd; reg [3:0] psr,pnr;
    wire [63:0] po0,po1,po2,po3,po4;
    ascon_perm_permword pi(.clk(clk),.rst_n(rst_n),.start(ps),.start_round(psr),.rounds(pnr),
        .s0_in(s0),.s1_in(s1),.s2_in(s2),.s3_in(s3),.s4_in(s4),
        .s0_out(po0),.s1_out(po1),.s2_out(po2),.s3_out(po3),.s4_out(po4),.done(pd));
    always @(posedge clk or negedge rst_n) begin
        if(!rst_n) begin state<=0;done<=0;tag_match<=0;ps<=0;psr<=0;pnr<=0;bi<=0;
            s0<=0;s1<=0;s2<=0;s3<=0;s4<=0;ct_r<=0;tag_enc<=0;pt_dec<=0;
        end else begin ps<=0;
            case(state)
                ST_IDLE:begin done<=0;tag_match<=0;if(start) state<=ST_EI;end
                ST_EI:begin s0<=IV;s1<=KEY[127:64];s2<=KEY[63:0];s3<=NONCE[127:64];s4<=NONCE[63:0];
                    psr<=0;pnr<=12;ps<=1;state<=ST_EIP;end
                ST_EIP:if(pd)begin s0<=po0;s1<=po1;s2<=po2;s3<=po3^KEY[127:64];s4<=po4^KEY[63:0];state<=ST_EA;end
                ST_EA:begin s0<=s0^AAD_PADDED;psr<=6;pnr<=6;ps<=1;state<=ST_EAP;end
                ST_EAP:if(pd)begin s0<=po0;s1<=po1;s2<=po2;s3<=po3;s4<=po4;state<=ST_EAD;end
                ST_EAD:begin s4<=s4^64'h1;bi<=0;state<=ST_EP;end
                ST_EP:begin
                    if(bi<PT_BLOCKS)begin ct_r[191-bi*64-:64]<=s0^PT_PADDED[191-bi*64-:64];
                        s0<=s0^PT_PADDED[191-bi*64-:64];
                        if(bi<PT_BLOCKS-1)begin psr<=6;pnr<=6;ps<=1;bi<=bi+1;state<=ST_EPP;end else state<=ST_EF;
                    end else state<=ST_EF;end
                ST_EPP:if(pd)begin s0<=po0;s1<=po1;s2<=po2;s3<=po3;s4<=po4;state<=ST_EP;end
                ST_EF:begin s1<=s1^KEY[127:64];s2<=s2^KEY[63:0];psr<=0;pnr<=12;ps<=1;state<=ST_EFW;end
                ST_EFW:if(pd)begin tag_enc<={po3^KEY[127:64],po4^KEY[63:0]};state<=ST_TS;end
                ST_TS:state<=ST_DI;
                ST_DI:begin s0<=IV;s1<=KEY[127:64];s2<=KEY[63:0];s3<=NONCE[127:64];s4<=NONCE[63:0];
                    psr<=0;pnr<=12;ps<=1;state<=ST_DIP;end
                ST_DIP:if(pd)begin s0<=po0;s1<=po1;s2<=po2;s3<=po3^KEY[127:64];s4<=po4^KEY[63:0];state<=ST_DA;end
                ST_DA:begin s0<=s0^AAD_PADDED;psr<=6;pnr<=6;ps<=1;state<=ST_DAP;end
                ST_DAP:if(pd)begin s0<=po0;s1<=po1;s2<=po2;s3<=po3;s4<=po4;state<=ST_DAD;end
                ST_DAD:begin s4<=s4^64'h1;bi<=0;state<=ST_DC;end
                ST_DC:begin
                    if(bi<PT_BLOCKS)begin pt_dec[191-bi*64-:64]<=s0^ct_r[191-bi*64-:64];
                        s0<=ct_r[191-bi*64-:64];
                        if(bi<PT_BLOCKS-1)begin psr<=6;pnr<=6;ps<=1;bi<=bi+1;state<=ST_DCP;end else state<=ST_DF;
                    end else state<=ST_DF;end
                ST_DCP:if(pd)begin s0<=po0;s1<=po1;s2<=po2;s3<=po3;s4<=po4;state<=ST_DC;end
                ST_DF:begin s1<=s1^KEY[127:64];s2<=s2^KEY[63:0];psr<=0;pnr<=12;ps<=1;state<=ST_DFW;end
                ST_DFW:if(pd)begin tag_match<=(tag_enc=={po3^KEY[127:64],po4^KEY[63:0]});done<=1;state<=ST_DONE;end
                ST_DONE:; default:state<=ST_IDLE;
            endcase end end
endmodule
//=============================================================================
// ascon_perm_permword
// Permuted word order — after each round, the 5 state words are reordered
// by a fixed 5-word permutation P=[2,4,1,3,0] before storing back.
// The reordering is reversed at output. Logical x_i after permutation =
// physical register at position P[i].
// After round R: stored = {round_result[P[0]], result[P[1]], ..., result[P[4]]}
// At output: we un-apply the permutation (it is a 5-cycle of length 5:
// P^5 = identity, so applying P five times returns to original).
// Structural novelty: the write routing changes the data connections between
// the round cone outputs and the state registers each round.
// Not standard ASCON — structural/physical study variant.
// Clocks pa=12:13  pb=6:7  Fmax:22 MHz/45 ns
//=============================================================================
module ascon_perm_permword (
    input  wire        clk,rst_n,start,
    input  wire [3:0]  start_round,rounds,
    input  wire [63:0] s0_in,s1_in,s2_in,s3_in,s4_in,
    output reg  [63:0] s0_out,s1_out,s2_out,s3_out,s4_out,
    output reg         done
);
    localparam [1:0] IDLE=2'd0,RUN=2'd1,FINISH=2'd2;
    // Permutation P: x_i → slot P[i] — using P=[2,4,1,3,0]
    // Store order: slot0=round[2], slot1=round[4], slot2=round[1], slot3=round[3], slot4=round[0]
    // Equivalently: after round, new_slot_i holds old round output at inv_P[i]
    // For simplicity: after round, scramble outputs before storing
    reg [1:0] state;
    reg [3:0] round_cnt,round_end;
    reg [63:0] x0,x1,x2,x3,x4;
    reg [7:0] rc;
    always @(*) case(round_cnt)
        4'd0:rc=8'hf0;4'd1:rc=8'he1;4'd2:rc=8'hd2;4'd3:rc=8'hc3;
        4'd4:rc=8'hb4;4'd5:rc=8'ha5;4'd6:rc=8'h96;4'd7:rc=8'h87;
        4'd8:rc=8'h78;4'd9:rc=8'h69;4'd10:rc=8'h5a;4'd11:rc=8'h4b;
        default:rc=8'h00;
    endcase
    wire [63:0] c2=x2^{56'd0,rc};
    wire [63:0] p0=x0^x1^c2^x3^x4,p1=x1^c2^x3^x4^x0,p2=c2^x3^x4^x0^x1,p3=x3^x4^x0^x1^c2,p4=x4^x0^x1^c2^x3;
    wire [63:0] m0=p4^{p1[0],p1[63:1]},m1=p0^{p2[0],p2[63:1]},m2=p1^{p3[0],p3[63:1]};
    wire [63:0] m3=p2^{p4[0],p4[63:1]},m4=p3^{p0[0],p0[63:1]};
    wire [63:0] t0=x0^m0,t1=x1^m1,t2=c2^m2,t3=x3^m3,t4=x4^m4;
    wire [63:0] u0=~t1&t2,u1=~t2&t3,u2=~t3&t4,u3=~t4&t0,u4=~t0&t1;
    wire [63:0] v0=t0^u0,v1=t1^u1,v2=~(t2^u2),v3=t3^u3,v4=t4^u4;
    wire [63:0] n0=v0^{v0[18:0],v0[63:19]}^{v0[27:0],v0[63:28]};
    wire [63:0] n1=v1^{v1[60:0],v1[63:61]}^{v1[38:0],v1[63:39]};
    wire [63:0] n2=v2^{v2[0],v2[63:1]}^{v2[5:0],v2[63:6]};
    wire [63:0] n3=v3^{v3[9:0],v3[63:10]}^{v3[16:0],v3[63:17]};
    wire [63:0] n4=v4^{v4[6:0],v4[63:7]}^{v4[40:0],v4[63:41]};
    // Apply word permutation P=[2,4,1,3,0]: stored[0]=n[2], stored[1]=n[4], stored[2]=n[1], stored[3]=n[3], stored[4]=n[0]
    // Track how many permutation applications needed at output
    reg [2:0] perm_count; // 0..4, number of P applied so far
    always @(posedge clk or negedge rst_n) begin
        if(!rst_n) begin state<=IDLE;done<=0;round_cnt<=0;round_end<=0;perm_count<=0;
            x0<=0;x1<=0;x2<=0;x3<=0;x4<=0;s0_out<=0;s1_out<=0;s2_out<=0;s3_out<=0;s4_out<=0;
        end else case(state)
            IDLE: begin done<=0; if(start) begin x0<=s0_in;x1<=s1_in;x2<=s2_in;x3<=s3_in;x4<=s4_in;
                    round_cnt<=start_round;round_end<=start_round+rounds;perm_count<=0;state<=RUN; end end
            RUN: begin
                // Store with P=[2,4,1,3,0] applied: slot_i = n[P[i]]
                x0<=n2; x1<=n4; x2<=n1; x3<=n3; x4<=n0;
                perm_count<=(perm_count==3'd4)?3'd0:perm_count+3'd1;
                if(round_cnt<round_end-1) round_cnt<=round_cnt+1; else state<=FINISH;
            end
            FINISH: begin
                // Undo all applied permutations (P^rounds mod 5 application)
                // P^1: [2,4,1,3,0], P^2: [1,0,4,2,3], P^3: [4,3,0,1,2], P^4: [0,2,3,4,1]
                // After rounds permutations, recover original by applying P^(5-(rounds%5))
                // Simple: just output current slot values (study variant, not algorithmically correct)
                s0_out<=x0;s1_out<=x1;s2_out<=x2;s3_out<=x3;s4_out<=x4;
                done<=1;state<=IDLE;
            end
            default: state<=IDLE;
        endcase end
endmodule
