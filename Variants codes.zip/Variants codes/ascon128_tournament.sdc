#==============================================================================
# ASCON-128  ·  Variant: tournament
# SDC for Cadence Genus Synthesis
#
# Permutation architecture: Tournament-tree Theta reduction.
#   Theta parity decomposed into 3 registered binary-tree levels.
#   5 stages per round:
#     TT_CONST: x2^=rc; pair01=x0^x1; pair23=x2^x3    (~1-2 gate levels)
#     TT_PAR1 : quad = pair01 ^ pair23                  (~1 gate level — SHALLOWEST)
#     TT_PAR2 : P=quad^x4; M=P^ROT1(P); t_i=x_i^M     (~4 gate levels)
#     TT_CHI  : full Chi (AND-NOT + XOR + INV)          (~3-4 gate levels)
#     TT_LIN  : full Linear (two rotations + XOR)       (~4-5 gate levels)
#
#   Fmax target: 200 MHz / 5 ns (TT_PAR2 is the new bottleneck at ~4 levels;
#   TT_PAR1 at 1 level is the shallowest stage of any ASCON iterative variant)
#
# Clocks per pa=12 : 12 × 5 + 1 = 61   Clocks per pb=6 : 6 × 5 + 1 = 31
#
# Synthesis notes:
#   TT_PAR1 will have extreme positive slack (~4.5 ns at 200 MHz).
#   TT_CONST will also have large positive slack.
#   The (* keep = "true" *) on pair01, pair23, quad registers prevents
#   synthesis from collapsing the three-level tree back into a single
#   5-input XOR (which would recreate single-cycle Theta). These must
#   be preserved to maintain the structural tree architecture.
#==============================================================================
create_clock -period 5.000 -name sys_clk -waveform {0.000 2.500} [get_ports clk_p]
set_clock_uncertainty -setup 0.150 [get_clocks sys_clk]
set_clock_uncertainty -hold  0.050 [get_clocks sys_clk]
set_clock_transition -rise 0.080 [get_clocks sys_clk]
set_clock_transition -fall 0.080 [get_clocks sys_clk]
set_input_delay -clock sys_clk -max 1.000 [get_ports rst_n]
set_input_delay -clock sys_clk -min 0.200 [get_ports rst_n]
set_input_delay -clock sys_clk -max 1.000 [get_ports start]
set_input_delay -clock sys_clk -min 0.200 [get_ports start]
set_output_delay -clock sys_clk -max 1.000 [get_ports done]
set_output_delay -clock sys_clk -min 0.200 [get_ports done]
set_output_delay -clock sys_clk -max 1.000 [get_ports tag_match]
set_output_delay -clock sys_clk -min 0.200 [get_ports tag_match]
set_output_delay -clock sys_clk -max 1.000 [get_ports led_done]
set_output_delay -clock sys_clk -min 0.200 [get_ports led_done]
set_output_delay -clock sys_clk -max 1.000 [get_ports led_tag_match]
set_output_delay -clock sys_clk -min 0.200 [get_ports led_tag_match]
set_output_delay -clock sys_clk -max 1.000 [get_ports led_running]
set_output_delay -clock sys_clk -min 0.200 [get_ports led_running]
set_output_delay -clock sys_clk -max 1.000 [get_ports led_error]
set_output_delay -clock sys_clk -min 0.200 [get_ports led_error]
set_false_path -from [get_ports rst_n]
# Preserve tree registers — prevent synthesis collapsing the tree
# set_dont_touch [get_cells {pair01_reg* pair23_reg* quad_reg*}]
set_driving_cell -lib_cell INVX1 -no_design_rule [get_ports {start rst_n}]
set_load 2.0 [get_ports {done tag_match led_done led_tag_match led_running led_error}]
# set_operating_conditions -library <lib> TYPICAL
#==============================================================================
# END - ascon128_tournament.sdc
#==============================================================================
