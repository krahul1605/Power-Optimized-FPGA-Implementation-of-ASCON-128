`timescale 1ns / 1ps
//=============================================================================
// ASCON-128  ·  Variant: s-box-elevated
//
// Visual treatment : Maximum pipeline depth — every sub-step of the ASCON
//                    permutation (Constant, Theta-A, Theta-B, Theta-C,
//                    Chi1, Chi2, Lin1, Lin2) is given its OWN registered
//                    pipeline stage.  The permutation core processes one
//                    sub-step per cycle, achieving the highest achievable
//                    clock frequency at the cost of latency and register count.
//
// Clocks per pa=12 call : 12 rounds × 8 sub-stages = 96 + 1 FINISH = 97
// Clocks per pb=6  call :  6 rounds × 8 sub-stages = 48 + 1 FINISH = 49
//
// Trade-offs
//   + Shortest combinational path -> highest Fmax (target 200 MHz / 5 ns)
//   + Well-balanced, synthesis-friendly register boundary at each stage
//   - Highest register count (8 pipeline stages × 5×64b = 2560 FFs/stage)
//   - Higher latency per permutation call
//
// Functional parity: identical ports, identical FSM encoding, identical
//                    ASCON-128 algorithm (NIST compliant).
//=============================================================================

module ascon128_top (
    input  wire clk_p,
    input  wire clk_n,
    input  wire rst_n,
    input  wire start,
    output wire done,
    output wire tag_match,
    output wire led_done,
    output wire led_tag_match,
    output wire led_running,
    output wire led_error
);

    wire clk_ibuf, clk;

    IBUFDS #(
        .DIFF_TERM("FALSE"), .IBUF_LOW_PWR("FALSE"), .IOSTANDARD("LVDS")
    ) clk_ibufds (.I(clk_p), .IB(clk_n), .O(clk_ibuf));

    BUFG clk_bufg (.I(clk_ibuf), .O(clk));

    wire core_done, core_tag_match;
    reg  running_r;

    ascon128_complete_elevated ascon_core (
        .clk(clk), .rst_n(rst_n), .start(start),
        .done(core_done), .tag_match(core_tag_match)
    );

    assign done = core_done; assign tag_match = core_tag_match;

    always @(posedge clk or negedge rst_n) begin
        if (!rst_n)         running_r <= 0;
        else if (start)     running_r <= 1;
        else if (core_done) running_r <= 0;
    end

    assign led_done=core_done; assign led_tag_match=core_done&core_tag_match;
    assign led_running=running_r; assign led_error=core_done&~core_tag_match;

endmodule


//=============================================================================
// ascon128_complete_elevated  — FSM (identical to baseline)
//=============================================================================
module ascon128_complete_elevated (
    input  wire clk, rst_n, start,
    output reg  done, tag_match
);
    localparam [127:0] KEY   = 128'h0F1E2D3C4B5A69788796A5B4C3D2E1F0;
    localparam [127:0] NONCE = 128'hFFEEDDCCBBAA99887766554433221100;
    localparam [191:0] PT_PADDED  = 192'h46696E616C20596561722050726F6A656374204152418000;
    localparam         PT_BLOCKS  = 3;
    localparam [63:0]  AAD_PADDED = 64'h64656D6F41414480;
    localparam [63:0]  IV         = 64'h80400c0600000000;

    localparam [4:0]
        ST_IDLE=0, ST_ENC_INIT=1, ST_ENC_INIT_PERM=2,
        ST_ENC_AAD=3, ST_ENC_AAD_PERM=4, ST_ENC_AAD_DOM=5,
        ST_ENC_PT=6, ST_ENC_PT_PERM=7, ST_ENC_FINAL=8,
        ST_ENC_FINAL_W=9, ST_TAG_STORE=10, ST_DEC_INIT=11,
        ST_DEC_INIT_PERM=12, ST_DEC_AAD=13, ST_DEC_AAD_PERM=14,
        ST_DEC_AAD_DOM=15, ST_DEC_CT=16, ST_DEC_CT_PERM=17,
        ST_DEC_FINAL=18, ST_DEC_FINAL_W=19, ST_DONE=20;

    reg [4:0] state; reg [3:0] block_idx;
    reg [63:0] s0,s1,s2,s3,s4;
    reg [191:0] ciphertext; reg [127:0] tag_enc; reg [191:0] plaintext_dec;
    reg perm_start; wire perm_done;
    reg [3:0] perm_start_round, perm_num_rounds;
    wire [63:0] perm_out0,perm_out1,perm_out2,perm_out3,perm_out4;

    ascon_perm_elevated perm_inst (
        .clk(clk), .rst_n(rst_n), .start(perm_start),
        .start_round(perm_start_round), .rounds(perm_num_rounds),
        .s0_in(s0),.s1_in(s1),.s2_in(s2),.s3_in(s3),.s4_in(s4),
        .s0_out(perm_out0),.s1_out(perm_out1),.s2_out(perm_out2),
        .s3_out(perm_out3),.s4_out(perm_out4),.done(perm_done)
    );

    always @(posedge clk or negedge rst_n) begin
        if (!rst_n) begin
            state<=0; done<=0; tag_match<=0; perm_start<=0;
            perm_start_round<=0; perm_num_rounds<=0; block_idx<=0;
            s0<=0;s1<=0;s2<=0;s3<=0;s4<=0;
            ciphertext<=0; tag_enc<=0; plaintext_dec<=0;
        end else begin
            perm_start<=0;
            case(state)
                ST_IDLE: begin done<=0; tag_match<=0; if(start) state<=ST_ENC_INIT; end
                ST_ENC_INIT: begin
                    s0<=IV; s1<=KEY[127:64]; s2<=KEY[63:0];
                    s3<=NONCE[127:64]; s4<=NONCE[63:0];
                    perm_start_round<=0; perm_num_rounds<=12; perm_start<=1;
                    state<=ST_ENC_INIT_PERM;
                end
                ST_ENC_INIT_PERM: if(perm_done) begin
                    s0<=perm_out0; s1<=perm_out1; s2<=perm_out2;
                    s3<=perm_out3^KEY[127:64]; s4<=perm_out4^KEY[63:0];
                    state<=ST_ENC_AAD;
                end
                ST_ENC_AAD: begin
                    s0<=s0^AAD_PADDED; perm_start_round<=6; perm_num_rounds<=6;
                    perm_start<=1; state<=ST_ENC_AAD_PERM;
                end
                ST_ENC_AAD_PERM: if(perm_done) begin
                    s0<=perm_out0;s1<=perm_out1;s2<=perm_out2;s3<=perm_out3;s4<=perm_out4;
                    state<=ST_ENC_AAD_DOM;
                end
                ST_ENC_AAD_DOM: begin s4<=s4^64'h1; block_idx<=0; state<=ST_ENC_PT; end
                ST_ENC_PT: begin
                    if(block_idx<PT_BLOCKS) begin
                        ciphertext[191-block_idx*64-:64]<=s0^PT_PADDED[191-block_idx*64-:64];
                        s0<=s0^PT_PADDED[191-block_idx*64-:64];
                        if(block_idx<PT_BLOCKS-1) begin
                            perm_start_round<=6; perm_num_rounds<=6; perm_start<=1;
                            block_idx<=block_idx+1; state<=ST_ENC_PT_PERM;
                        end else state<=ST_ENC_FINAL;
                    end else state<=ST_ENC_FINAL;
                end
                ST_ENC_PT_PERM: if(perm_done) begin
                    s0<=perm_out0;s1<=perm_out1;s2<=perm_out2;s3<=perm_out3;s4<=perm_out4;
                    state<=ST_ENC_PT;
                end
                ST_ENC_FINAL: begin
                    s1<=s1^KEY[127:64]; s2<=s2^KEY[63:0];
                    perm_start_round<=0; perm_num_rounds<=12; perm_start<=1;
                    state<=ST_ENC_FINAL_W;
                end
                ST_ENC_FINAL_W: if(perm_done) begin
                    tag_enc<={perm_out3^KEY[127:64],perm_out4^KEY[63:0]};
                    state<=ST_TAG_STORE;
                end
                ST_TAG_STORE: state<=ST_DEC_INIT;
                ST_DEC_INIT: begin
                    s0<=IV; s1<=KEY[127:64]; s2<=KEY[63:0];
                    s3<=NONCE[127:64]; s4<=NONCE[63:0];
                    perm_start_round<=0; perm_num_rounds<=12; perm_start<=1;
                    state<=ST_DEC_INIT_PERM;
                end
                ST_DEC_INIT_PERM: if(perm_done) begin
                    s0<=perm_out0;s1<=perm_out1;s2<=perm_out2;
                    s3<=perm_out3^KEY[127:64];s4<=perm_out4^KEY[63:0];
                    state<=ST_DEC_AAD;
                end
                ST_DEC_AAD: begin
                    s0<=s0^AAD_PADDED; perm_start_round<=6; perm_num_rounds<=6;
                    perm_start<=1; state<=ST_DEC_AAD_PERM;
                end
                ST_DEC_AAD_PERM: if(perm_done) begin
                    s0<=perm_out0;s1<=perm_out1;s2<=perm_out2;s3<=perm_out3;s4<=perm_out4;
                    state<=ST_DEC_AAD_DOM;
                end
                ST_DEC_AAD_DOM: begin s4<=s4^64'h1; block_idx<=0; state<=ST_DEC_CT; end
                ST_DEC_CT: begin
                    if(block_idx<PT_BLOCKS) begin
                        plaintext_dec[191-block_idx*64-:64]<=s0^ciphertext[191-block_idx*64-:64];
                        s0<=ciphertext[191-block_idx*64-:64];
                        if(block_idx<PT_BLOCKS-1) begin
                            perm_start_round<=6; perm_num_rounds<=6; perm_start<=1;
                            block_idx<=block_idx+1; state<=ST_DEC_CT_PERM;
                        end else state<=ST_DEC_FINAL;
                    end else state<=ST_DEC_FINAL;
                end
                ST_DEC_CT_PERM: if(perm_done) begin
                    s0<=perm_out0;s1<=perm_out1;s2<=perm_out2;s3<=perm_out3;s4<=perm_out4;
                    state<=ST_DEC_CT;
                end
                ST_DEC_FINAL: begin
                    s1<=s1^KEY[127:64]; s2<=s2^KEY[63:0];
                    perm_start_round<=0; perm_num_rounds<=12; perm_start<=1;
                    state<=ST_DEC_FINAL_W;
                end
                ST_DEC_FINAL_W: if(perm_done) begin
                    tag_match<=(tag_enc=={perm_out3^KEY[127:64],perm_out4^KEY[63:0]});
                    done<=1; state<=ST_DONE;
                end
                ST_DONE: ;
                default: state<=ST_IDLE;
            endcase
        end
    end
endmodule


//=============================================================================
// ascon_perm_elevated
//
// Fully staged pipeline: 8 register barriers per round.
//   Stage 0 : CONST   — XOR round constant into x2
//   Stage 1 : THETA_A — column parities p0..p4
//   Stage 2 : THETA_B — rotation-mixed parities m0..m4
//   Stage 3 : THETA_C — theta output t0..t4
//   Stage 4 : CHI1    — AND-NOT terms u0..u4
//   Stage 5 : CHI2    — chi XOR (x2 inverted)
//   Stage 6 : LIN1    — rotation operands ra*/rb*
//   Stage 7 : LIN2    — final linear XOR -> new x0..x4
//   Stage 8 : FINISH  — latch outputs
//
// Total clocks per round: 8 (vs 9 in baseline, which also has FINISH).
// Critical path per stage: ~2-4 XOR/AND levels (Fmax target: 200 MHz / 5 ns)
//=============================================================================
module ascon_perm_elevated (
    input  wire        clk, rst_n, start,
    input  wire [3:0]  start_round, rounds,
    input  wire [63:0] s0_in,s1_in,s2_in,s3_in,s4_in,
    output reg  [63:0] s0_out,s1_out,s2_out,s3_out,s4_out,
    output reg         done
);

    localparam [3:0]
        IDLE    = 4'd0, CONST   = 4'd1, THETA_A = 4'd2, THETA_B = 4'd3,
        THETA_C = 4'd4, CHI1    = 4'd5, CHI2    = 4'd6,
        LIN1    = 4'd7, LIN2    = 4'd8, FINISH  = 4'd9;

    reg [3:0] state, round_cnt, round_end;
    reg [63:0] x0,x1,x2,x3,x4;
    reg [63:0] p0,p1,p2,p3,p4;
    reg [63:0] m0,m1,m2,m3,m4;
    reg [63:0] t0,t1,t2,t3,t4;
    reg [63:0] u0,u1,u2,u3,u4;
    reg [63:0] ra0,ra1,ra2,ra3,ra4;
    reg [63:0] rb0,rb1,rb2,rb3,rb4;

    // Round constant (combinational decode)
    reg [7:0] rc;
    always @(*) case(round_cnt)
        4'd0:rc=8'hf0; 4'd1:rc=8'he1; 4'd2:rc=8'hd2; 4'd3:rc=8'hc3;
        4'd4:rc=8'hb4; 4'd5:rc=8'ha5; 4'd6:rc=8'h96; 4'd7:rc=8'h87;
        4'd8:rc=8'h78; 4'd9:rc=8'h69; 4'd10:rc=8'h5a; 4'd11:rc=8'h4b;
        default:rc=8'h00;
    endcase

    always @(posedge clk or negedge rst_n) begin
        if(!rst_n) begin
            state<=IDLE; done<=0; round_cnt<=0; round_end<=0;
            x0<=0;x1<=0;x2<=0;x3<=0;x4<=0;
            p0<=0;p1<=0;p2<=0;p3<=0;p4<=0;
            m0<=0;m1<=0;m2<=0;m3<=0;m4<=0;
            t0<=0;t1<=0;t2<=0;t3<=0;t4<=0;
            u0<=0;u1<=0;u2<=0;u3<=0;u4<=0;
            ra0<=0;ra1<=0;ra2<=0;ra3<=0;ra4<=0;
            rb0<=0;rb1<=0;rb2<=0;rb3<=0;rb4<=0;
            s0_out<=0;s1_out<=0;s2_out<=0;s3_out<=0;s4_out<=0;
        end else case(state)
            IDLE: begin
                done<=0;
                if(start) begin
                    x0<=s0_in;x1<=s1_in;x2<=s2_in;x3<=s3_in;x4<=s4_in;
                    round_cnt<=start_round; round_end<=start_round+rounds;
                    state<=CONST;
                end
            end
            // Stage 0: constant addition
            CONST: begin x2<=x2^{56'd0,rc}; state<=THETA_A; end
            // Stage 1: column parities
            THETA_A: begin
                p0<=x0^x1^x2^x3^x4; p1<=x1^x2^x3^x4^x0;
                p2<=x2^x3^x4^x0^x1; p3<=x3^x4^x0^x1^x2; p4<=x4^x0^x1^x2^x3;
                state<=THETA_B;
            end
            // Stage 2: rotation mix
            THETA_B: begin
                m0<=p4^{p1[0],p1[63:1]}; m1<=p0^{p2[0],p2[63:1]};
                m2<=p1^{p3[0],p3[63:1]}; m3<=p2^{p4[0],p4[63:1]};
                m4<=p3^{p0[0],p0[63:1]}; state<=THETA_C;
            end
            // Stage 3: apply theta
            THETA_C: begin
                t0<=x0^m0; t1<=x1^m1; t2<=x2^m2; t3<=x3^m3; t4<=x4^m4;
                state<=CHI1;
            end
            // Stage 4: chi AND-NOT
            CHI1: begin
                u0<=~t1&t2; u1<=~t2&t3; u2<=~t3&t4; u3<=~t4&t0; u4<=~t0&t1;
                state<=CHI2;
            end
            // Stage 5: chi XOR (x2 inverted per ASCON spec)
            CHI2: begin
                x0<=t0^u0; x1<=t1^u1; x2<=~(t2^u2);
                x3<=t3^u3; x4<=t4^u4; state<=LIN1;
            end
            // Stage 6: rotation operands
            LIN1: begin
                ra0<={x0[18:0],x0[63:19]}; rb0<={x0[27:0],x0[63:28]};
                ra1<={x1[60:0],x1[63:61]}; rb1<={x1[38:0],x1[63:39]};
                ra2<={x2[0],   x2[63:1]};  rb2<={x2[5:0], x2[63:6]};
                ra3<={x3[9:0], x3[63:10]}; rb3<={x3[16:0],x3[63:17]};
                ra4<={x4[6:0], x4[63:7]};  rb4<={x4[40:0],x4[63:41]};
                state<=LIN2;
            end
            // Stage 7: linear XOR
            LIN2: begin
                x0<=x0^ra0^rb0; x1<=x1^ra1^rb1; x2<=x2^ra2^rb2;
                x3<=x3^ra3^rb3; x4<=x4^ra4^rb4;
                if(round_cnt < round_end-1) begin
                    round_cnt<=round_cnt+1; state<=CONST;
                end else state<=FINISH;
            end
            FINISH: begin
                s0_out<=x0;s1_out<=x1;s2_out<=x2;
                s3_out<=x3;s4_out<=x4; done<=1; state<=IDLE;
            end
            default: state<=IDLE;
        endcase
    end
endmodule
