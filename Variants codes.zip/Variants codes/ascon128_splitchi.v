`timescale 1ns / 1ps
//=============================================================================
// ASCON-128  ·  Variant: splitchi
//
// Visual treatment : Split-Chi pipeline — the CHI non-linear layer is the
//                    deepest sub-step (AND-NOT + XOR + INV). This variant
//                    surgically inserts a single registered cut between the
//                    CHI AND-NOT computation (CHI1) and the CHI XOR/invert
//                    completion (CHI2), leaving all other sub-steps fused.
//
//                    Pipeline stages per round (3 stages):
//                      Stage A: CONST + THETA_A + THETA_B + THETA_C + CHI1
//                               (compute AND-NOT terms u0..u4 → register)
//                      Stage B: CHI2 + LIN1 + LIN2
//                               (complete chi XOR/INV + full linear layer)
//                      Stage C: FINISH (handled by RUN→FINISH state in FSM)
//
// Clocks per pa=12 call : 12 rounds × 2 stages = 24 + 1 FINISH = 25
// Clocks per pb=6  call :  6 rounds × 2 stages = 12 + 1 FINISH = 13
//
// Trade-offs
//   + Targets the known bottleneck (CHI1→CHI2 AND-NOT chain)
//   + Higher Fmax than baseline by cutting the AND-NOT out of the long path
//   + Only 2 registered stages per round (fewer FFs than quarterpipe)
//   - Asymmetric stage depths: Stage A is still longer than Stage B
//   - Target 20 MHz / 50 ns  (Stage A still has THETA+CONST+CHI1)
//
// Functional parity: identical ports and FSM encoding to all variants.
//                    NIST-compliant ASCON-128 algorithm.
//=============================================================================

module ascon128_top (
    input  wire clk_p,
    input  wire clk_n,
    input  wire rst_n,
    input  wire start,
    output wire done,
    output wire tag_match,
    output wire led_done,
    output wire led_tag_match,
    output wire led_running,
    output wire led_error
);

    wire clk_ibuf, clk;

    IBUFDS #(
        .DIFF_TERM("FALSE"), .IBUF_LOW_PWR("FALSE"), .IOSTANDARD("LVDS")
    ) clk_ibufds (.I(clk_p), .IB(clk_n), .O(clk_ibuf));

    BUFG clk_bufg (.I(clk_ibuf), .O(clk));

    wire core_done, core_tag_match;
    reg  running_r;

    ascon128_complete_splitchi ascon_core (
        .clk(clk), .rst_n(rst_n), .start(start),
        .done(core_done), .tag_match(core_tag_match)
    );

    assign done = core_done; assign tag_match = core_tag_match;

    always @(posedge clk or negedge rst_n) begin
        if (!rst_n)         running_r <= 0;
        else if (start)     running_r <= 1;
        else if (core_done) running_r <= 0;
    end

    assign led_done=core_done; assign led_tag_match=core_done&core_tag_match;
    assign led_running=running_r; assign led_error=core_done&~core_tag_match;

endmodule


//=============================================================================
// ascon128_complete_splitchi  — FSM (identical structure to all variants)
//=============================================================================
module ascon128_complete_splitchi (
    input  wire clk, rst_n, start,
    output reg  done, tag_match
);
    localparam [127:0] KEY   = 128'h0F1E2D3C4B5A69788796A5B4C3D2E1F0;
    localparam [127:0] NONCE = 128'hFFEEDDCCBBAA99887766554433221100;
    localparam [191:0] PT_PADDED  = 192'h46696E616C20596561722050726F6A656374204152418000;
    localparam         PT_BLOCKS  = 3;
    localparam [63:0]  AAD_PADDED = 64'h64656D6F41414480;
    localparam [63:0]  IV         = 64'h80400c0600000000;

    localparam [4:0]
        ST_IDLE=0, ST_ENC_INIT=1, ST_ENC_INIT_PERM=2,
        ST_ENC_AAD=3, ST_ENC_AAD_PERM=4, ST_ENC_AAD_DOM=5,
        ST_ENC_PT=6, ST_ENC_PT_PERM=7, ST_ENC_FINAL=8,
        ST_ENC_FINAL_W=9, ST_TAG_STORE=10, ST_DEC_INIT=11,
        ST_DEC_INIT_PERM=12, ST_DEC_AAD=13, ST_DEC_AAD_PERM=14,
        ST_DEC_AAD_DOM=15, ST_DEC_CT=16, ST_DEC_CT_PERM=17,
        ST_DEC_FINAL=18, ST_DEC_FINAL_W=19, ST_DONE=20;

    reg [4:0] state; reg [3:0] block_idx;
    reg [63:0] s0,s1,s2,s3,s4;
    reg [191:0] ciphertext; reg [127:0] tag_enc; reg [191:0] plaintext_dec;
    reg perm_start; wire perm_done;
    reg [3:0] perm_start_round, perm_num_rounds;
    wire [63:0] perm_out0,perm_out1,perm_out2,perm_out3,perm_out4;

    ascon_perm_splitchi perm_inst (
        .clk(clk), .rst_n(rst_n), .start(perm_start),
        .start_round(perm_start_round), .rounds(perm_num_rounds),
        .s0_in(s0),.s1_in(s1),.s2_in(s2),.s3_in(s3),.s4_in(s4),
        .s0_out(perm_out0),.s1_out(perm_out1),.s2_out(perm_out2),
        .s3_out(perm_out3),.s4_out(perm_out4),.done(perm_done)
    );

    always @(posedge clk or negedge rst_n) begin
        if (!rst_n) begin
            state<=0; done<=0; tag_match<=0; perm_start<=0;
            perm_start_round<=0; perm_num_rounds<=0; block_idx<=0;
            s0<=0;s1<=0;s2<=0;s3<=0;s4<=0;
            ciphertext<=0; tag_enc<=0; plaintext_dec<=0;
        end else begin
            perm_start<=0;
            case(state)
                ST_IDLE: begin done<=0; tag_match<=0; if(start) state<=ST_ENC_INIT; end
                ST_ENC_INIT: begin
                    s0<=IV; s1<=KEY[127:64]; s2<=KEY[63:0];
                    s3<=NONCE[127:64]; s4<=NONCE[63:0];
                    perm_start_round<=0; perm_num_rounds<=12; perm_start<=1;
                    state<=ST_ENC_INIT_PERM;
                end
                ST_ENC_INIT_PERM: if(perm_done) begin
                    s0<=perm_out0; s1<=perm_out1; s2<=perm_out2;
                    s3<=perm_out3^KEY[127:64]; s4<=perm_out4^KEY[63:0];
                    state<=ST_ENC_AAD;
                end
                ST_ENC_AAD: begin
                    s0<=s0^AAD_PADDED; perm_start_round<=6; perm_num_rounds<=6;
                    perm_start<=1; state<=ST_ENC_AAD_PERM;
                end
                ST_ENC_AAD_PERM: if(perm_done) begin
                    s0<=perm_out0;s1<=perm_out1;s2<=perm_out2;s3<=perm_out3;s4<=perm_out4;
                    state<=ST_ENC_AAD_DOM;
                end
                ST_ENC_AAD_DOM: begin s4<=s4^64'h1; block_idx<=0; state<=ST_ENC_PT; end
                ST_ENC_PT: begin
                    if(block_idx<PT_BLOCKS) begin
                        ciphertext[191-block_idx*64-:64]<=s0^PT_PADDED[191-block_idx*64-:64];
                        s0<=s0^PT_PADDED[191-block_idx*64-:64];
                        if(block_idx<PT_BLOCKS-1) begin
                            perm_start_round<=6; perm_num_rounds<=6; perm_start<=1;
                            block_idx<=block_idx+1; state<=ST_ENC_PT_PERM;
                        end else state<=ST_ENC_FINAL;
                    end else state<=ST_ENC_FINAL;
                end
                ST_ENC_PT_PERM: if(perm_done) begin
                    s0<=perm_out0;s1<=perm_out1;s2<=perm_out2;s3<=perm_out3;s4<=perm_out4;
                    state<=ST_ENC_PT;
                end
                ST_ENC_FINAL: begin
                    s1<=s1^KEY[127:64]; s2<=s2^KEY[63:0];
                    perm_start_round<=0; perm_num_rounds<=12; perm_start<=1;
                    state<=ST_ENC_FINAL_W;
                end
                ST_ENC_FINAL_W: if(perm_done) begin
                    tag_enc<={perm_out3^KEY[127:64],perm_out4^KEY[63:0]};
                    state<=ST_TAG_STORE;
                end
                ST_TAG_STORE: state<=ST_DEC_INIT;
                ST_DEC_INIT: begin
                    s0<=IV; s1<=KEY[127:64]; s2<=KEY[63:0];
                    s3<=NONCE[127:64]; s4<=NONCE[63:0];
                    perm_start_round<=0; perm_num_rounds<=12; perm_start<=1;
                    state<=ST_DEC_INIT_PERM;
                end
                ST_DEC_INIT_PERM: if(perm_done) begin
                    s0<=perm_out0;s1<=perm_out1;s2<=perm_out2;
                    s3<=perm_out3^KEY[127:64];s4<=perm_out4^KEY[63:0];
                    state<=ST_DEC_AAD;
                end
                ST_DEC_AAD: begin
                    s0<=s0^AAD_PADDED; perm_start_round<=6; perm_num_rounds<=6;
                    perm_start<=1; state<=ST_DEC_AAD_PERM;
                end
                ST_DEC_AAD_PERM: if(perm_done) begin
                    s0<=perm_out0;s1<=perm_out1;s2<=perm_out2;s3<=perm_out3;s4<=perm_out4;
                    state<=ST_DEC_AAD_DOM;
                end
                ST_DEC_AAD_DOM: begin s4<=s4^64'h1; block_idx<=0; state<=ST_DEC_CT; end
                ST_DEC_CT: begin
                    if(block_idx<PT_BLOCKS) begin
                        plaintext_dec[191-block_idx*64-:64]<=s0^ciphertext[191-block_idx*64-:64];
                        s0<=ciphertext[191-block_idx*64-:64];
                        if(block_idx<PT_BLOCKS-1) begin
                            perm_start_round<=6; perm_num_rounds<=6; perm_start<=1;
                            block_idx<=block_idx+1; state<=ST_DEC_CT_PERM;
                        end else state<=ST_DEC_FINAL;
                    end else state<=ST_DEC_FINAL;
                end
                ST_DEC_CT_PERM: if(perm_done) begin
                    s0<=perm_out0;s1<=perm_out1;s2<=perm_out2;s3<=perm_out3;s4<=perm_out4;
                    state<=ST_DEC_CT;
                end
                ST_DEC_FINAL: begin
                    s1<=s1^KEY[127:64]; s2<=s2^KEY[63:0];
                    perm_start_round<=0; perm_num_rounds<=12; perm_start<=1;
                    state<=ST_DEC_FINAL_W;
                end
                ST_DEC_FINAL_W: if(perm_done) begin
                    tag_match<=(tag_enc=={perm_out3^KEY[127:64],perm_out4^KEY[63:0]});
                    done<=1; state<=ST_DONE;
                end
                ST_DONE: ;
                default: state<=ST_IDLE;
            endcase
        end
    end
endmodule


//=============================================================================
// ascon_perm_splitchi
//
// 2-stage pipeline per round, cut between CHI1 and CHI2:
//
//   Stage A (SA): CONST + THETA_A + THETA_B + THETA_C + CHI1
//     Input: x0..x4 + rc
//     Compute: full theta chain → AND-NOT terms u0..u4
//     Register: t0..t4 (theta result), u0..u4 (AND-NOT terms)
//
//   Stage B (SB): CHI2 + LIN1 + LIN2
//     Input: t0..t4, u0..u4
//     Compute: chi XOR/INV → rotation pairs → linear XOR
//     Register: x0..x4 (new state)
//
// The round counter increments in Stage B (end-of-round).
// Critical path: SA — THETA_A parity tree → THETA_B rotate → AND-NOT.
//                SB — XOR/INV → rotation → XOR merge.
//                Both stages ~20-25 gate levels; target 50 MHz / 20 ns.
//=============================================================================
module ascon_perm_splitchi (
    input  wire        clk, rst_n, start,
    input  wire [3:0]  start_round, rounds,
    input  wire [63:0] s0_in,s1_in,s2_in,s3_in,s4_in,
    output reg  [63:0] s0_out,s1_out,s2_out,s3_out,s4_out,
    output reg         done
);

    localparam [2:0] IDLE=3'd0, SA=3'd1, SB=3'd2, FINISH=3'd3;

    reg [2:0]  state;
    reg [3:0]  round_cnt, round_end;

    // Working state registers
    reg [63:0] x0,x1,x2,x3,x4;
    // Inter-stage registers: theta result and chi1 AND-NOT terms
    reg [63:0] t0,t1,t2,t3,t4;   // theta output
    reg [63:0] u0,u1,u2,u3,u4;   // CHI1 AND-NOT output

    // Round constant decode
    reg [7:0] rc;
    always @(*) case(round_cnt)
        4'd0:rc=8'hf0; 4'd1:rc=8'he1; 4'd2:rc=8'hd2; 4'd3:rc=8'hc3;
        4'd4:rc=8'hb4; 4'd5:rc=8'ha5; 4'd6:rc=8'h96; 4'd7:rc=8'h87;
        4'd8:rc=8'h78; 4'd9:rc=8'h69; 4'd10:rc=8'h5a; 4'd11:rc=8'h4b;
        default:rc=8'h00;
    endcase

    // -------------------------------------------------------------------------
    // Stage A combinational: CONST + THETA (A/B/C) + CHI1
    // -------------------------------------------------------------------------
    wire [63:0] c2_a = x2^{56'd0,rc};
    // THETA_A parities
    wire [63:0] pa0 = x0^x1^c2_a^x3^x4;
    wire [63:0] pa1 = x1^c2_a^x3^x4^x0;
    wire [63:0] pa2 = c2_a^x3^x4^x0^x1;
    wire [63:0] pa3 = x3^x4^x0^x1^c2_a;
    wire [63:0] pa4 = x4^x0^x1^c2_a^x3;
    // THETA_B rotation mix
    wire [63:0] ma0 = pa4^{pa1[0],pa1[63:1]};
    wire [63:0] ma1 = pa0^{pa2[0],pa2[63:1]};
    wire [63:0] ma2 = pa1^{pa3[0],pa3[63:1]};
    wire [63:0] ma3 = pa2^{pa4[0],pa4[63:1]};
    wire [63:0] ma4 = pa3^{pa0[0],pa0[63:1]};
    // THETA_C apply
    wire [63:0] ta0 = x0^ma0;
    wire [63:0] ta1 = x1^ma1;
    wire [63:0] ta2 = c2_a^ma2;
    wire [63:0] ta3 = x3^ma3;
    wire [63:0] ta4 = x4^ma4;
    // CHI1: AND-NOT
    wire [63:0] ua0 = ~ta1&ta2;
    wire [63:0] ua1 = ~ta2&ta3;
    wire [63:0] ua2 = ~ta3&ta4;
    wire [63:0] ua3 = ~ta4&ta0;
    wire [63:0] ua4 = ~ta0&ta1;

    // -------------------------------------------------------------------------
    // Stage B combinational: CHI2 + LIN1 + LIN2
    // -------------------------------------------------------------------------
    wire [63:0] v0_b = t0^u0;
    wire [63:0] v1_b = t1^u1;
    wire [63:0] v2_b = ~(t2^u2);
    wire [63:0] v3_b = t3^u3;
    wire [63:0] v4_b = t4^u4;
    // LIN1 + LIN2 fused
    wire [63:0] n0_b = v0_b^{v0_b[18:0],v0_b[63:19]}^{v0_b[27:0],v0_b[63:28]};
    wire [63:0] n1_b = v1_b^{v1_b[60:0],v1_b[63:61]}^{v1_b[38:0],v1_b[63:39]};
    wire [63:0] n2_b = v2_b^{v2_b[0],   v2_b[63:1]} ^{v2_b[5:0], v2_b[63:6]};
    wire [63:0] n3_b = v3_b^{v3_b[9:0], v3_b[63:10]}^{v3_b[16:0],v3_b[63:17]};
    wire [63:0] n4_b = v4_b^{v4_b[6:0], v4_b[63:7]} ^{v4_b[40:0],v4_b[63:41]};

    // -------------------------------------------------------------------------
    // FSM
    // -------------------------------------------------------------------------
    always @(posedge clk or negedge rst_n) begin
        if(!rst_n) begin
            state<=IDLE; done<=0; round_cnt<=0; round_end<=0;
            x0<=0;x1<=0;x2<=0;x3<=0;x4<=0;
            t0<=0;t1<=0;t2<=0;t3<=0;t4<=0;
            u0<=0;u1<=0;u2<=0;u3<=0;u4<=0;
            s0_out<=0;s1_out<=0;s2_out<=0;s3_out<=0;s4_out<=0;
        end else case(state)
            IDLE: begin
                done<=0;
                if(start) begin
                    x0<=s0_in;x1<=s1_in;x2<=s2_in;x3<=s3_in;x4<=s4_in;
                    round_cnt<=start_round; round_end<=start_round+rounds;
                    state<=SA;
                end
            end
            // Stage A: latch theta result and CHI1 AND-NOT terms
            SA: begin
                t0<=ta0; t1<=ta1; t2<=ta2; t3<=ta3; t4<=ta4;
                u0<=ua0; u1<=ua1; u2<=ua2; u3<=ua3; u4<=ua4;
                state<=SB;
            end
            // Stage B: latch new state, advance round
            SB: begin
                x0<=n0_b; x1<=n1_b; x2<=n2_b; x3<=n3_b; x4<=n4_b;
                if(round_cnt < round_end-1) begin
                    round_cnt<=round_cnt+1;
                    state<=SA;
                end else begin
                    state<=FINISH;
                end
            end
            FINISH: begin
                s0_out<=x0;s1_out<=x1;s2_out<=x2;
                s3_out<=x3;s4_out<=x4; done<=1; state<=IDLE;
            end
            default: state<=IDLE;
        endcase
    end
endmodule