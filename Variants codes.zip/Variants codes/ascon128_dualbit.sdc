#==============================================================================
# ASCON-128 · Variant: dualbit
# SDC for Cadence Genus Synthesis
# Architecture: 2-bit dual-serial Chi; 32 pair-phases per round; between nibbled(4b) and serialized(1b)
# Fmax: 150 MHz/7 ns   Clocks: pa=12:421 pb=6:211
#==============================================================================
create_clock -period 7.000 -name sys_clk -waveform {0.000 3.5000} [get_ports clk_p]
set_clock_uncertainty -setup 0.200 [get_clocks sys_clk]
set_clock_uncertainty -hold  0.100 [get_clocks sys_clk]
set_clock_transition  -rise  0.100 [get_clocks sys_clk]
set_clock_transition  -fall  0.100 [get_clocks sys_clk]
set_input_delay  -clock sys_clk -max 1.000 [get_ports rst_n]
set_input_delay  -clock sys_clk -min 0.200 [get_ports rst_n]
set_input_delay  -clock sys_clk -max 1.000 [get_ports start]
set_input_delay  -clock sys_clk -min 0.200 [get_ports start]
set_output_delay -clock sys_clk -max 1.000 [get_ports done]
set_output_delay -clock sys_clk -min 0.200 [get_ports done]
set_output_delay -clock sys_clk -max 1.000 [get_ports tag_match]
set_output_delay -clock sys_clk -min 0.200 [get_ports tag_match]
set_output_delay -clock sys_clk -max 1.000 [get_ports led_done]
set_output_delay -clock sys_clk -min 0.200 [get_ports led_done]
set_output_delay -clock sys_clk -max 1.000 [get_ports led_tag_match]
set_output_delay -clock sys_clk -min 0.200 [get_ports led_tag_match]
set_output_delay -clock sys_clk -max 1.000 [get_ports led_running]
set_output_delay -clock sys_clk -min 0.200 [get_ports led_running]
set_output_delay -clock sys_clk -max 1.000 [get_ports led_error]
set_output_delay -clock sys_clk -min 0.200 [get_ports led_error]
set_false_path -from [get_ports rst_n]
set_driving_cell -lib_cell INVX1 -no_design_rule [get_ports {start rst_n}]
set_load 2.0 [get_ports {done tag_match led_done led_tag_match led_running led_error}]
#==============================================================================
# END - ascon128_dualbit.sdc
#==============================================================================
