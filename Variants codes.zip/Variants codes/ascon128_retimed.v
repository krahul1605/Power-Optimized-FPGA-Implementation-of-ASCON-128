`timescale 1ns / 1ps
//=============================================================================
// ASCON-128  ·  Variant: retimed
//
// Visual treatment : Intra-Chi retimed pipeline — a register cut-point is
//                    inserted *inside* the Chi substitution layer, splitting
//                    it at the AND-NOT gate boundary. This creates an
//                    asymmetric 5-stage pipeline per round where the final
//                    Chi-XOR is fused with the entire Linear layer in one
//                    combined stage, forming a uniquely shaped critical path.
//
//                    Per-round pipeline stages:
//
//     STAGE_RC   (1 cycle): Round constant XOR into x2 only.
//                           Registered output: x0..x4 (x2 modified).
//                           Path: x2_reg -> XOR(rc) -> x2_reg  (~1 level)
//
//     STAGE_TH   (1 cycle): Full Theta layer (CONST already applied).
//                           Parities, rotation mix, theta apply — all
//                           fused combinationally into one registered stage.
//                           Path: x*_reg -> XOR tree -> rotate -> XOR ->
//                                 t*_reg  (~8-10 gate levels)
//
//     STAGE_AND  (1 cycle): Chi AND-NOT only — computes the five intermediate
//                           u[i] = ~x[i+1] & x[i+2] values. These are
//                           registered into u0..u4 (5 separate AND-NOT outputs).
//                           No XOR performed in this stage.
//                           Path: x*_reg -> AND-NOT -> u*_reg  (~2 gate levels)
//                           This is the shallowest stage in the pipeline.
//
//     STAGE_CL   (1 cycle): Chi-XOR fused with full Linear layer.
//                           xi' = xi ^ u[i] (Chi completion)
//                           Then immediately apply Linear rotations to xi'.
//                           The two computations are chained as one cone:
//                             x_chi = x ^ u  (Chi XOR, x2 inverted)
//                             x_lin = x_chi ^ ROT(x_chi, rA) ^ ROT(x_chi, rB)
//                           Path: x*_reg + u*_reg -> XOR -> [optional INV] ->
//                                 rotate -> XOR -> x*_reg  (~6-8 gate levels)
//                           This is the critical path (deeper than STAGE_TH
//                           if rotation+XOR exceeds parity tree depth, or
//                           similar depth — whichever is larger sizes Fmax).
//
//                    The structural novelty is the cut inside Chi: the AND-NOT
//                    result (u*) is a registered intermediate, breaking the
//                    standard Chi → Linear cascade. This prevents tools from
//                    merging Chi-AND with the theta path and forces a clean
//                    AND-NOT register bank (u0..u4) as a distinct physical
//                    boundary in the netlist.
//
// Clocks per pa=12 call : 12 rounds × 4 stages = 48 + 1 FINISH = 49
// Clocks per pb=6  call :  6 rounds × 4 stages = 24 + 1 FINISH = 25
//
// Trade-offs
//   + STAGE_AND is a shallow (2-level) cycle — very short combinational path
//   + STAGE_RC  is trivially short (1-level)
//   + Chi AND-NOT bank (u0..u4) is a distinct retiming register, useful for
//     power analysis (AND-NOT switching power isolated per stage)
//   + Fuses Chi-XOR + Linear into STAGE_CL: fewer total cycles than 5-separate
//   - STAGE_CL may be deeper than STAGE_TH if linear rotation adds levels
//   - Extra u0..u4 register bank (320 additional FFs)
//   - Asymmetric stage depths complicate static timing analysis reporting
//
// Functional parity: identical ports and FSM encoding to all variants.
//                    NIST-compliant ASCON-128 algorithm.
//=============================================================================

module ascon128_top (
    input  wire clk_p,
    input  wire clk_n,
    input  wire rst_n,
    input  wire start,
    output wire done,
    output wire tag_match,
    output wire led_done,
    output wire led_tag_match,
    output wire led_running,
    output wire led_error
);

    wire clk_ibuf, clk;

    IBUFDS #(
        .DIFF_TERM("FALSE"), .IBUF_LOW_PWR("FALSE"), .IOSTANDARD("LVDS")
    ) clk_ibufds (.I(clk_p), .IB(clk_n), .O(clk_ibuf));

    BUFG clk_bufg (.I(clk_ibuf), .O(clk));

    wire core_done, core_tag_match;
    reg  running_r;

    ascon128_complete_retimed ascon_core (
        .clk(clk), .rst_n(rst_n), .start(start),
        .done(core_done), .tag_match(core_tag_match)
    );

    assign done = core_done; assign tag_match = core_tag_match;

    always @(posedge clk or negedge rst_n) begin
        if (!rst_n)         running_r <= 0;
        else if (start)     running_r <= 1;
        else if (core_done) running_r <= 0;
    end

    assign led_done=core_done; assign led_tag_match=core_done&core_tag_match;
    assign led_running=running_r; assign led_error=core_done&~core_tag_match;

endmodule


//=============================================================================
// ascon128_complete_retimed  — FSM (identical structure to all variants)
//=============================================================================
module ascon128_complete_retimed (
    input  wire clk, rst_n, start,
    output reg  done, tag_match
);
    localparam [127:0] KEY   = 128'h0F1E2D3C4B5A69788796A5B4C3D2E1F0;
    localparam [127:0] NONCE = 128'hFFEEDDCCBBAA99887766554433221100;
    localparam [191:0] PT_PADDED  = 192'h46696E616C20596561722050726F6A656374204152418000;
    localparam         PT_BLOCKS  = 3;
    localparam [63:0]  AAD_PADDED = 64'h64656D6F41414480;
    localparam [63:0]  IV         = 64'h80400c0600000000;

    localparam [4:0]
        ST_IDLE=0, ST_ENC_INIT=1, ST_ENC_INIT_PERM=2,
        ST_ENC_AAD=3, ST_ENC_AAD_PERM=4, ST_ENC_AAD_DOM=5,
        ST_ENC_PT=6, ST_ENC_PT_PERM=7, ST_ENC_FINAL=8,
        ST_ENC_FINAL_W=9, ST_TAG_STORE=10, ST_DEC_INIT=11,
        ST_DEC_INIT_PERM=12, ST_DEC_AAD=13, ST_DEC_AAD_PERM=14,
        ST_DEC_AAD_DOM=15, ST_DEC_CT=16, ST_DEC_CT_PERM=17,
        ST_DEC_FINAL=18, ST_DEC_FINAL_W=19, ST_DONE=20;

    reg [4:0] state; reg [3:0] block_idx;
    reg [63:0] s0,s1,s2,s3,s4;
    reg [191:0] ciphertext; reg [127:0] tag_enc; reg [191:0] plaintext_dec;
    reg perm_start; wire perm_done;
    reg [3:0] perm_start_round, perm_num_rounds;
    wire [63:0] perm_out0,perm_out1,perm_out2,perm_out3,perm_out4;

    ascon_perm_retimed perm_inst (
        .clk(clk), .rst_n(rst_n), .start(perm_start),
        .start_round(perm_start_round), .rounds(perm_num_rounds),
        .s0_in(s0),.s1_in(s1),.s2_in(s2),.s3_in(s3),.s4_in(s4),
        .s0_out(perm_out0),.s1_out(perm_out1),.s2_out(perm_out2),
        .s3_out(perm_out3),.s4_out(perm_out4),.done(perm_done)
    );

    always @(posedge clk or negedge rst_n) begin
        if (!rst_n) begin
            state<=0; done<=0; tag_match<=0; perm_start<=0;
            perm_start_round<=0; perm_num_rounds<=0; block_idx<=0;
            s0<=0;s1<=0;s2<=0;s3<=0;s4<=0;
            ciphertext<=0; tag_enc<=0; plaintext_dec<=0;
        end else begin
            perm_start<=0;
            case(state)
                ST_IDLE: begin done<=0; tag_match<=0; if(start) state<=ST_ENC_INIT; end
                ST_ENC_INIT: begin
                    s0<=IV; s1<=KEY[127:64]; s2<=KEY[63:0];
                    s3<=NONCE[127:64]; s4<=NONCE[63:0];
                    perm_start_round<=0; perm_num_rounds<=12; perm_start<=1;
                    state<=ST_ENC_INIT_PERM;
                end
                ST_ENC_INIT_PERM: if(perm_done) begin
                    s0<=perm_out0; s1<=perm_out1; s2<=perm_out2;
                    s3<=perm_out3^KEY[127:64]; s4<=perm_out4^KEY[63:0];
                    state<=ST_ENC_AAD;
                end
                ST_ENC_AAD: begin
                    s0<=s0^AAD_PADDED; perm_start_round<=6; perm_num_rounds<=6;
                    perm_start<=1; state<=ST_ENC_AAD_PERM;
                end
                ST_ENC_AAD_PERM: if(perm_done) begin
                    s0<=perm_out0;s1<=perm_out1;s2<=perm_out2;s3<=perm_out3;s4<=perm_out4;
                    state<=ST_ENC_AAD_DOM;
                end
                ST_ENC_AAD_DOM: begin s4<=s4^64'h1; block_idx<=0; state<=ST_ENC_PT; end
                ST_ENC_PT: begin
                    if(block_idx<PT_BLOCKS) begin
                        ciphertext[191-block_idx*64-:64]<=s0^PT_PADDED[191-block_idx*64-:64];
                        s0<=s0^PT_PADDED[191-block_idx*64-:64];
                        if(block_idx<PT_BLOCKS-1) begin
                            perm_start_round<=6; perm_num_rounds<=6; perm_start<=1;
                            block_idx<=block_idx+1; state<=ST_ENC_PT_PERM;
                        end else state<=ST_ENC_FINAL;
                    end else state<=ST_ENC_FINAL;
                end
                ST_ENC_PT_PERM: if(perm_done) begin
                    s0<=perm_out0;s1<=perm_out1;s2<=perm_out2;s3<=perm_out3;s4<=perm_out4;
                    state<=ST_ENC_PT;
                end
                ST_ENC_FINAL: begin
                    s1<=s1^KEY[127:64]; s2<=s2^KEY[63:0];
                    perm_start_round<=0; perm_num_rounds<=12; perm_start<=1;
                    state<=ST_ENC_FINAL_W;
                end
                ST_ENC_FINAL_W: if(perm_done) begin
                    tag_enc<={perm_out3^KEY[127:64],perm_out4^KEY[63:0]};
                    state<=ST_TAG_STORE;
                end
                ST_TAG_STORE: state<=ST_DEC_INIT;
                ST_DEC_INIT: begin
                    s0<=IV; s1<=KEY[127:64]; s2<=KEY[63:0];
                    s3<=NONCE[127:64]; s4<=NONCE[63:0];
                    perm_start_round<=0; perm_num_rounds<=12; perm_start<=1;
                    state<=ST_DEC_INIT_PERM;
                end
                ST_DEC_INIT_PERM: if(perm_done) begin
                    s0<=perm_out0;s1<=perm_out1;s2<=perm_out2;
                    s3<=perm_out3^KEY[127:64];s4<=perm_out4^KEY[63:0];
                    state<=ST_DEC_AAD;
                end
                ST_DEC_AAD: begin
                    s0<=s0^AAD_PADDED; perm_start_round<=6; perm_num_rounds<=6;
                    perm_start<=1; state<=ST_DEC_AAD_PERM;
                end
                ST_DEC_AAD_PERM: if(perm_done) begin
                    s0<=perm_out0;s1<=perm_out1;s2<=perm_out2;s3<=perm_out3;s4<=perm_out4;
                    state<=ST_DEC_AAD_DOM;
                end
                ST_DEC_AAD_DOM: begin s4<=s4^64'h1; block_idx<=0; state<=ST_DEC_CT; end
                ST_DEC_CT: begin
                    if(block_idx<PT_BLOCKS) begin
                        plaintext_dec[191-block_idx*64-:64]<=s0^ciphertext[191-block_idx*64-:64];
                        s0<=ciphertext[191-block_idx*64-:64];
                        if(block_idx<PT_BLOCKS-1) begin
                            perm_start_round<=6; perm_num_rounds<=6; perm_start<=1;
                            block_idx<=block_idx+1; state<=ST_DEC_CT_PERM;
                        end else state<=ST_DEC_FINAL;
                    end else state<=ST_DEC_FINAL;
                end
                ST_DEC_CT_PERM: if(perm_done) begin
                    s0<=perm_out0;s1<=perm_out1;s2<=perm_out2;s3<=perm_out3;s4<=perm_out4;
                    state<=ST_DEC_CT;
                end
                ST_DEC_FINAL: begin
                    s1<=s1^KEY[127:64]; s2<=s2^KEY[63:0];
                    perm_start_round<=0; perm_num_rounds<=12; perm_start<=1;
                    state<=ST_DEC_FINAL_W;
                end
                ST_DEC_FINAL_W: if(perm_done) begin
                    tag_match<=(tag_enc=={perm_out3^KEY[127:64],perm_out4^KEY[63:0]});
                    done<=1; state<=ST_DONE;
                end
                ST_DONE: ;
                default: state<=ST_IDLE;
            endcase
        end
    end
endmodule


//=============================================================================
// ascon_perm_retimed
//
// Intra-Chi retimed pipeline: 4 stages per round.
//
// State machine: 3-bit stage counter (rt_stage) selects the active stage.
//
//   STAGE_RC  (rt_stage==3'd0):
//     Round constant XOR into x2 only.
//     x0,x1,x3,x4 pass through unchanged (registered).
//     Registered output: x0..x4 (x2 updated).
//
//   STAGE_TH  (rt_stage==3'd1):
//     Full Theta layer (Const already applied to x2 in STAGE_RC).
//     Column parities, rotation mix, theta apply — all fused.
//     Registered output: t0..t4 (theta result).
//     x0..x4 unchanged in this stage (t* is a separate register bank).
//
//   STAGE_AND (rt_stage==3'd2):
//     Chi AND-NOT layer ONLY.
//     u[i] = ~t[i+1] & t[i+2]  (indices mod 5)
//     Registered output: u0..u4 (AND-NOT intermediate).
//     t0..t4 held for next stage (needed for Chi-XOR).
//
//   STAGE_CL  (rt_stage==3'd3):
//     Chi-XOR fused with full Linear layer:
//       chi_i = t[i] ^ u[i]          (Chi completion; chi_2 inverted)
//       x_i   = chi_i ^ ROT(chi_i,rA) ^ ROT(chi_i,rB)   (Linear)
//     Registered output: x0..x4 (new round state).
//     After this: increment round_cnt or go to FINISH.
//
// Register banks present in this design:
//   x0..x4  : main state (320 FFs) — updated in STAGE_RC and STAGE_CL
//   t0..t4  : post-theta intermediate (320 FFs) — updated in STAGE_TH
//   u0..u4  : AND-NOT intermediate (320 FFs) — updated in STAGE_AND
//   Total: 960 FFs for permutation state (vs 320 in baseline, 640 in halfpipe)
//
// Critical path:
//   STAGE_CL: t*_reg + u*_reg -> XOR -> [INV for t2] ->
//             rotate(rA) -> XOR -> rotate(rB) -> XOR -> x*_reg
//             Two rotation levels + 3 XOR levels ≈ 5-7 gate levels (~6-8 ns)
//   STAGE_TH: x2_reg -> XOR(rc already applied) -> XOR tree -> x*_reg
//             (~8-10 gate levels — may also be critical depending on mapping)
//   Fmax target: 125 MHz / 8 ns
//=============================================================================
module ascon_perm_retimed (
    input  wire        clk, rst_n, start,
    input  wire [3:0]  start_round, rounds,
    input  wire [63:0] s0_in,s1_in,s2_in,s3_in,s4_in,
    output reg  [63:0] s0_out,s1_out,s2_out,s3_out,s4_out,
    output reg         done
);

    localparam [1:0] IDLE=2'd0, RUN=2'd1, FINISH=2'd2;

    localparam [1:0] STAGE_RC=2'd0, STAGE_TH=2'd1, STAGE_AND=2'd2, STAGE_CL=2'd3;

    reg [1:0]  state;
    reg [1:0]  rt_stage;        // 4-stage intra-round counter
    reg [3:0]  round_cnt, round_end;

    // Register bank 0: primary state (post-const in STAGE_RC, post-linear in STAGE_CL)
    reg [63:0] x0,x1,x2,x3,x4;

    // Register bank 1: post-theta intermediate
    (* keep = "true" *) reg [63:0] t0,t1,t2,t3,t4;

    // Register bank 2: AND-NOT intermediate (retiming register — the key structural feature)
    (* keep = "true" *) reg [63:0] u0,u1,u2,u3,u4;

    // -------------------------------------------------------------------------
    // Round constant decode
    // -------------------------------------------------------------------------
    reg [7:0] rc;
    always @(*) case(round_cnt)
        4'd0:rc=8'hf0; 4'd1:rc=8'he1; 4'd2:rc=8'hd2; 4'd3:rc=8'hc3;
        4'd4:rc=8'hb4; 4'd5:rc=8'ha5; 4'd6:rc=8'h96; 4'd7:rc=8'h87;
        4'd8:rc=8'h78; 4'd9:rc=8'h69; 4'd10:rc=8'h5a; 4'd11:rc=8'h4b;
        default:rc=8'h00;
    endcase

    // -------------------------------------------------------------------------
    // STAGE_TH combinational cone: Full Theta (x* post-const -> t*)
    // -------------------------------------------------------------------------
    // Column parities
    wire [63:0] tp0 = x0^x1^x2^x3^x4;
    wire [63:0] tp1 = x1^x2^x3^x4^x0;
    wire [63:0] tp2 = x2^x3^x4^x0^x1;
    wire [63:0] tp3 = x3^x4^x0^x1^x2;
    wire [63:0] tp4 = x4^x0^x1^x2^x3;
    // Rotation mix
    wire [63:0] tm0 = tp4^{tp1[0],tp1[63:1]};
    wire [63:0] tm1 = tp0^{tp2[0],tp2[63:1]};
    wire [63:0] tm2 = tp1^{tp3[0],tp3[63:1]};
    wire [63:0] tm3 = tp2^{tp4[0],tp4[63:1]};
    wire [63:0] tm4 = tp3^{tp0[0],tp0[63:1]};
    // Theta result (registered into t0..t4)
    wire [63:0] th0_w = x0^tm0;
    wire [63:0] th1_w = x1^tm1;
    wire [63:0] th2_w = x2^tm2;
    wire [63:0] th3_w = x3^tm3;
    wire [63:0] th4_w = x4^tm4;

    // -------------------------------------------------------------------------
    // STAGE_CL combinational cone: Chi-XOR fused with Linear (t* + u* -> x*)
    // -------------------------------------------------------------------------
    // Chi XOR completion (t[i] ^ u[i]), x2 inverted
    wire [63:0] chi0 = t0 ^ u0;
    wire [63:0] chi1 = t1 ^ u1;
    wire [63:0] chi2 = ~(t2 ^ u2);    // inverted per ASCON spec
    wire [63:0] chi3 = t3 ^ u3;
    wire [63:0] chi4 = t4 ^ u4;

    // Linear layer applied to Chi output (fused — no intermediate register)
    wire [63:0] cl0_w = chi0^{chi0[18:0],chi0[63:19]}^{chi0[27:0],chi0[63:28]};
    wire [63:0] cl1_w = chi1^{chi1[60:0],chi1[63:61]}^{chi1[38:0],chi1[63:39]};
    wire [63:0] cl2_w = chi2^{chi2[0],   chi2[63:1]} ^{chi2[5:0], chi2[63:6]};
    wire [63:0] cl3_w = chi3^{chi3[9:0], chi3[63:10]}^{chi3[16:0],chi3[63:17]};
    wire [63:0] cl4_w = chi4^{chi4[6:0], chi4[63:7]} ^{chi4[40:0],chi4[63:41]};

    // =========================================================================
    // FSM + 4-stage intra-round sequencer
    // =========================================================================
    always @(posedge clk or negedge rst_n) begin
        if(!rst_n) begin
            state<=IDLE; done<=0; rt_stage<=0; round_cnt<=0; round_end<=0;
            x0<=0;x1<=0;x2<=0;x3<=0;x4<=0;
            t0<=0;t1<=0;t2<=0;t3<=0;t4<=0;
            u0<=0;u1<=0;u2<=0;u3<=0;u4<=0;
            s0_out<=0;s1_out<=0;s2_out<=0;s3_out<=0;s4_out<=0;
        end else case(state)
            IDLE: begin
                done<=0;
                if(start) begin
                    x0<=s0_in;x1<=s1_in;x2<=s2_in;x3<=s3_in;x4<=s4_in;
                    round_cnt<=start_round; round_end<=start_round+rounds;
                    rt_stage<=STAGE_RC; state<=RUN;
                end
            end
            RUN: begin
                case(rt_stage)
                    // ----------------------------------------------------------
                    // STAGE_RC: Apply round constant to x2
                    // All other words registered unchanged
                    // ----------------------------------------------------------
                    STAGE_RC: begin
                        x2 <= x2 ^ {56'd0, rc};
                        // x0,x1,x3,x4 held — no assignment (synthesis preserves)
                        rt_stage <= STAGE_TH;
                    end
                    // ----------------------------------------------------------
                    // STAGE_TH: Full Theta using combinational cone th*_w
                    // Registers result into t0..t4
                    // ----------------------------------------------------------
                    STAGE_TH: begin
                        t0<=th0_w; t1<=th1_w; t2<=th2_w; t3<=th3_w; t4<=th4_w;
                        rt_stage <= STAGE_AND;
                    end
                    // ----------------------------------------------------------
                    // STAGE_AND: Chi AND-NOT ONLY — u[i] = ~t[i+1] & t[i+2]
                    // Registers intermediate AND-NOT results into u0..u4
                    // t0..t4 are unchanged (held for STAGE_CL)
                    // ----------------------------------------------------------
                    STAGE_AND: begin
                        u0 <= ~t1 & t2;
                        u1 <= ~t2 & t3;
                        u2 <= ~t3 & t4;
                        u3 <= ~t4 & t0;
                        u4 <= ~t0 & t1;
                        rt_stage <= STAGE_CL;
                    end
                    // ----------------------------------------------------------
                    // STAGE_CL: Chi-XOR fused with Linear
                    // Combinational cone: chi* = t* ^ u*; lin* = chi* ^ rot ^ rot
                    // Result registered into x0..x4 as new round state
                    // ----------------------------------------------------------
                    STAGE_CL: begin
                        x0<=cl0_w; x1<=cl1_w; x2<=cl2_w; x3<=cl3_w; x4<=cl4_w;
                        rt_stage <= STAGE_RC;
                        if(round_cnt < round_end-1) begin
                            round_cnt <= round_cnt + 1;
                        end else begin
                            state <= FINISH;
                        end
                    end
                    default: rt_stage <= STAGE_RC;
                endcase
            end
            FINISH: begin
                s0_out<=x0;s1_out<=x1;s2_out<=x2;
                s3_out<=x3;s4_out<=x4; done<=1; state<=IDLE;
            end
            default: state<=IDLE;
        endcase
    end
endmodule
