`timescale 1ns / 1ps
//=============================================================================
// ASCON-128  ·  Variant: nibbled
//
// Visual treatment : Nibble-serial Chi — the Chi substitution layer is
//                    computed 4 bits at a time (one nibble per cycle) over
//                    16 consecutive cycles. A 4-bit-wide S-box slice (4
//                    parallel 5-bit S-box instances, one per bit position
//                    within the nibble) processes nibble k of each 64-bit
//                    state word on cycle k, for k = 0..15.
//
//                    This sits architecturally BETWEEN the bit-serial variant
//                    (serialized: 1 bit/cycle, 64 cycles for Chi) and the
//                    bytelane variant (8 bits/cycle, 1 cycle for Chi).
//                    The nibble granularity (4 bits) maps directly to FPGA
//                    LUT4 primitives — a 4-input LUT can implement all
//                    combinational logic for one nibble position.
//
//                    Per-round phases:
//      NB_CONST   (1 cycle): x2 ^= rc
//      NB_THETA   (1 cycle): full Theta (parity + rotation + apply)
//      NB_CHI_k   (16 cycles, nibble_idx 0..15): nibble-serial Chi
//      NB_LIN     (1 cycle): full Linear diffusion
//      Total: 19 phases per round.
//
//                    Nibble k covers bits [4k+3:4k] of each state word.
//                    The 4-bit S-box for nibble k:
//                      y0[4k+3:4k] = x0[4k+3:4k] ^ (~x1[4k+3:4k] & x2[4k+3:4k])
//                      y1[4k+3:4k] = x1[4k+3:4k] ^ (~x2[4k+3:4k] & x3[4k+3:4k])
//                      y2[4k+3:4k] = ~(x2[4k+3:4k] ^ (~x3[4k+3:4k] & x4[4k+3:4k]))
//                      y3[4k+3:4k] = x3[4k+3:4k] ^ (~x4[4k+3:4k] & x0[4k+3:4k])
//                      y4[4k+3:4k] = x4[4k+3:4k] ^ (~x0[4k+3:4k] & x1[4k+3:4k])
//                    Write-back: nibble-masked update of x0..x4.
//
// Clocks per pa=12 : 12 × 19 + 1 = 229
// Clocks per pb=6  :  6 × 19 + 1 = 115
// Fmax target: 100 MHz / 10 ns (NB_THETA bottleneck)
//=============================================================================

module ascon128_top (
    input  wire clk_p, clk_n, rst_n, start,
    output wire done, tag_match,
    output wire led_done, led_tag_match, led_running, led_error
);
    wire clk_ibuf, clk;
    IBUFDS #(.DIFF_TERM("FALSE"),.IBUF_LOW_PWR("FALSE"),.IOSTANDARD("LVDS"))
        clk_ibufds(.I(clk_p),.IB(clk_n),.O(clk_ibuf));
    BUFG clk_bufg(.I(clk_ibuf),.O(clk));
    wire core_done, core_tag_match;
    reg  running_r;
    ascon128_complete_nibbled ascon_core(.clk(clk),.rst_n(rst_n),.start(start),
        .done(core_done),.tag_match(core_tag_match));
    assign done=core_done; assign tag_match=core_tag_match;
    always @(posedge clk or negedge rst_n)
        if(!rst_n) running_r<=0;
        else if(start) running_r<=1;
        else if(core_done) running_r<=0;
    assign led_done=core_done; assign led_tag_match=core_done&core_tag_match;
    assign led_running=running_r; assign led_error=core_done&~core_tag_match;
endmodule

module ascon128_complete_nibbled (
    input  wire clk, rst_n, start,
    output reg  done, tag_match
);
    localparam [127:0] KEY   = 128'h0F1E2D3C4B5A69788796A5B4C3D2E1F0;
    localparam [127:0] NONCE = 128'hFFEEDDCCBBAA99887766554433221100;
    localparam [191:0] PT_PADDED  = 192'h46696E616C20596561722050726F6A656374204152418000;
    localparam         PT_BLOCKS  = 3;
    localparam [63:0]  AAD_PADDED = 64'h64656D6F41414480;
    localparam [63:0]  IV         = 64'h80400c0600000000;
    localparam [4:0]
        ST_IDLE=0,ST_ENC_INIT=1,ST_ENC_INIT_PERM=2,ST_ENC_AAD=3,ST_ENC_AAD_PERM=4,
        ST_ENC_AAD_DOM=5,ST_ENC_PT=6,ST_ENC_PT_PERM=7,ST_ENC_FINAL=8,ST_ENC_FINAL_W=9,
        ST_TAG_STORE=10,ST_DEC_INIT=11,ST_DEC_INIT_PERM=12,ST_DEC_AAD=13,
        ST_DEC_AAD_PERM=14,ST_DEC_AAD_DOM=15,ST_DEC_CT=16,ST_DEC_CT_PERM=17,
        ST_DEC_FINAL=18,ST_DEC_FINAL_W=19,ST_DONE=20;
    reg [4:0] state; reg [3:0] block_idx;
    reg [63:0] s0,s1,s2,s3,s4;
    reg [191:0] ciphertext; reg [127:0] tag_enc; reg [191:0] plaintext_dec;
    reg perm_start; wire perm_done;
    reg [3:0] perm_start_round, perm_num_rounds;
    wire [63:0] perm_out0,perm_out1,perm_out2,perm_out3,perm_out4;
    ascon_perm_nibbled perm_inst(
        .clk(clk),.rst_n(rst_n),.start(perm_start),
        .start_round(perm_start_round),.rounds(perm_num_rounds),
        .s0_in(s0),.s1_in(s1),.s2_in(s2),.s3_in(s3),.s4_in(s4),
        .s0_out(perm_out0),.s1_out(perm_out1),.s2_out(perm_out2),
        .s3_out(perm_out3),.s4_out(perm_out4),.done(perm_done));
    always @(posedge clk or negedge rst_n) begin
        if(!rst_n) begin
            state<=0;done<=0;tag_match<=0;perm_start<=0;
            perm_start_round<=0;perm_num_rounds<=0;block_idx<=0;
            s0<=0;s1<=0;s2<=0;s3<=0;s4<=0;ciphertext<=0;tag_enc<=0;plaintext_dec<=0;
        end else begin
            perm_start<=0;
            case(state)
                ST_IDLE: begin done<=0;tag_match<=0;if(start) state<=ST_ENC_INIT; end
                ST_ENC_INIT: begin s0<=IV;s1<=KEY[127:64];s2<=KEY[63:0];s3<=NONCE[127:64];s4<=NONCE[63:0];
                    perm_start_round<=0;perm_num_rounds<=12;perm_start<=1;state<=ST_ENC_INIT_PERM; end
                ST_ENC_INIT_PERM: if(perm_done) begin s0<=perm_out0;s1<=perm_out1;s2<=perm_out2;
                    s3<=perm_out3^KEY[127:64];s4<=perm_out4^KEY[63:0];state<=ST_ENC_AAD; end
                ST_ENC_AAD: begin s0<=s0^AAD_PADDED;perm_start_round<=6;perm_num_rounds<=6;
                    perm_start<=1;state<=ST_ENC_AAD_PERM; end
                ST_ENC_AAD_PERM: if(perm_done) begin s0<=perm_out0;s1<=perm_out1;s2<=perm_out2;
                    s3<=perm_out3;s4<=perm_out4;state<=ST_ENC_AAD_DOM; end
                ST_ENC_AAD_DOM: begin s4<=s4^64'h1;block_idx<=0;state<=ST_ENC_PT; end
                ST_ENC_PT: begin
                    if(block_idx<PT_BLOCKS) begin
                        ciphertext[191-block_idx*64-:64]<=s0^PT_PADDED[191-block_idx*64-:64];
                        s0<=s0^PT_PADDED[191-block_idx*64-:64];
                        if(block_idx<PT_BLOCKS-1) begin perm_start_round<=6;perm_num_rounds<=6;
                            perm_start<=1;block_idx<=block_idx+1;state<=ST_ENC_PT_PERM;
                        end else state<=ST_ENC_FINAL;
                    end else state<=ST_ENC_FINAL; end
                ST_ENC_PT_PERM: if(perm_done) begin s0<=perm_out0;s1<=perm_out1;s2<=perm_out2;
                    s3<=perm_out3;s4<=perm_out4;state<=ST_ENC_PT; end
                ST_ENC_FINAL: begin s1<=s1^KEY[127:64];s2<=s2^KEY[63:0];
                    perm_start_round<=0;perm_num_rounds<=12;perm_start<=1;state<=ST_ENC_FINAL_W; end
                ST_ENC_FINAL_W: if(perm_done) begin tag_enc<={perm_out3^KEY[127:64],perm_out4^KEY[63:0]};
                    state<=ST_TAG_STORE; end
                ST_TAG_STORE: state<=ST_DEC_INIT;
                ST_DEC_INIT: begin s0<=IV;s1<=KEY[127:64];s2<=KEY[63:0];s3<=NONCE[127:64];s4<=NONCE[63:0];
                    perm_start_round<=0;perm_num_rounds<=12;perm_start<=1;state<=ST_DEC_INIT_PERM; end
                ST_DEC_INIT_PERM: if(perm_done) begin s0<=perm_out0;s1<=perm_out1;s2<=perm_out2;
                    s3<=perm_out3^KEY[127:64];s4<=perm_out4^KEY[63:0];state<=ST_DEC_AAD; end
                ST_DEC_AAD: begin s0<=s0^AAD_PADDED;perm_start_round<=6;perm_num_rounds<=6;
                    perm_start<=1;state<=ST_DEC_AAD_PERM; end
                ST_DEC_AAD_PERM: if(perm_done) begin s0<=perm_out0;s1<=perm_out1;s2<=perm_out2;
                    s3<=perm_out3;s4<=perm_out4;state<=ST_DEC_AAD_DOM; end
                ST_DEC_AAD_DOM: begin s4<=s4^64'h1;block_idx<=0;state<=ST_DEC_CT; end
                ST_DEC_CT: begin
                    if(block_idx<PT_BLOCKS) begin
                        plaintext_dec[191-block_idx*64-:64]<=s0^ciphertext[191-block_idx*64-:64];
                        s0<=ciphertext[191-block_idx*64-:64];
                        if(block_idx<PT_BLOCKS-1) begin perm_start_round<=6;perm_num_rounds<=6;
                            perm_start<=1;block_idx<=block_idx+1;state<=ST_DEC_CT_PERM;
                        end else state<=ST_DEC_FINAL;
                    end else state<=ST_DEC_FINAL; end
                ST_DEC_CT_PERM: if(perm_done) begin s0<=perm_out0;s1<=perm_out1;s2<=perm_out2;
                    s3<=perm_out3;s4<=perm_out4;state<=ST_DEC_CT; end
                ST_DEC_FINAL: begin s1<=s1^KEY[127:64];s2<=s2^KEY[63:0];
                    perm_start_round<=0;perm_num_rounds<=12;perm_start<=1;state<=ST_DEC_FINAL_W; end
                ST_DEC_FINAL_W: if(perm_done) begin
                    tag_match<=(tag_enc=={perm_out3^KEY[127:64],perm_out4^KEY[63:0]});
                    done<=1;state<=ST_DONE; end
                ST_DONE: ;
                default: state<=ST_IDLE;
            endcase
        end
    end
endmodule

//=============================================================================
// ascon_perm_nibbled — 19 phases/round
// Phase encoding via 5-bit nb_phase counter:
//   0        = NB_CONST
//   1        = NB_THETA
//   2..17    = NB_CHI nibble_idx = nb_phase - 2   (0..15)
//   18       = NB_LIN
//=============================================================================
module ascon_perm_nibbled (
    input  wire        clk, rst_n, start,
    input  wire [3:0]  start_round, rounds,
    input  wire [63:0] s0_in,s1_in,s2_in,s3_in,s4_in,
    output reg  [63:0] s0_out,s1_out,s2_out,s3_out,s4_out,
    output reg         done
);
    localparam [1:0] IDLE=2'd0, RUN=2'd1, FINISH=2'd2;
    localparam [4:0] NB_CONST=5'd0, NB_THETA=5'd1, NB_LIN=5'd18;

    reg [1:0] state;
    reg [4:0] nb_phase;
    reg [3:0] round_cnt, round_end;
    reg [63:0] x0,x1,x2,x3,x4;

    reg [7:0] rc;
    always @(*) case(round_cnt)
        4'd0:rc=8'hf0; 4'd1:rc=8'he1; 4'd2:rc=8'hd2; 4'd3:rc=8'hc3;
        4'd4:rc=8'hb4; 4'd5:rc=8'ha5; 4'd6:rc=8'h96; 4'd7:rc=8'h87;
        4'd8:rc=8'h78; 4'd9:rc=8'h69; 4'd10:rc=8'h5a; 4'd11:rc=8'h4b;
        default:rc=8'h00;
    endcase

    // Theta cone
    wire [63:0] tp0=x0^x1^x2^x3^x4,tp1=x1^x2^x3^x4^x0;
    wire [63:0] tp2=x2^x3^x4^x0^x1,tp3=x3^x4^x0^x1^x2,tp4=x4^x0^x1^x2^x3;
    wire [63:0] tm0=tp4^{tp1[0],tp1[63:1]},tm1=tp0^{tp2[0],tp2[63:1]};
    wire [63:0] tm2=tp1^{tp3[0],tp3[63:1]},tm3=tp2^{tp4[0],tp4[63:1]};
    wire [63:0] tm4=tp3^{tp0[0],tp0[63:1]};
    wire [63:0] tt0=x0^tm0,tt1=x1^tm1,tt2=x2^tm2,tt3=x3^tm3,tt4=x4^tm4;

    // Nibble-serial Chi: nibble_idx = nb_phase - 2 (valid when nb_phase in 2..17)
    wire [3:0] nibble_idx = nb_phase[3:0] - 4'd2;
    wire [4:0] nib_base   = {nibble_idx, 1'b0} * 2;  // = nibble_idx * 4

    // Extract 4-bit nibbles from each word
    wire [3:0] nb0 = x0[nibble_idx*4+3 -: 4];
    wire [3:0] nb1 = x1[nibble_idx*4+3 -: 4];
    wire [3:0] nb2 = x2[nibble_idx*4+3 -: 4];
    wire [3:0] nb3 = x3[nibble_idx*4+3 -: 4];
    wire [3:0] nb4 = x4[nibble_idx*4+3 -: 4];

    // 4-bit S-box per nibble
    wire [3:0] ny0 = nb0 ^ (~nb1 & nb2);
    wire [3:0] ny1 = nb1 ^ (~nb2 & nb3);
    wire [3:0] ny2 = ~(nb2 ^ (~nb3 & nb4));
    wire [3:0] ny3 = nb3 ^ (~nb4 & nb0);
    wire [3:0] ny4 = nb4 ^ (~nb0 & nb1);

    // 4-bit nibble mask for write-back
    wire [63:0] nibble_mask = 64'hF << (nibble_idx * 4);
    wire [63:0] nx0 = (x0 & ~nibble_mask) | ({60'd0, ny0} << (nibble_idx * 4));
    wire [63:0] nx1 = (x1 & ~nibble_mask) | ({60'd0, ny1} << (nibble_idx * 4));
    wire [63:0] nx2 = (x2 & ~nibble_mask) | ({60'd0, ny2} << (nibble_idx * 4));
    wire [63:0] nx3 = (x3 & ~nibble_mask) | ({60'd0, ny3} << (nibble_idx * 4));
    wire [63:0] nx4 = (x4 & ~nibble_mask) | ({60'd0, ny4} << (nibble_idx * 4));

    // Linear cone
    wire [63:0] ln0=x0^{x0[18:0],x0[63:19]}^{x0[27:0],x0[63:28]};
    wire [63:0] ln1=x1^{x1[60:0],x1[63:61]}^{x1[38:0],x1[63:39]};
    wire [63:0] ln2=x2^{x2[0],   x2[63:1]} ^{x2[5:0], x2[63:6]};
    wire [63:0] ln3=x3^{x3[9:0], x3[63:10]}^{x3[16:0],x3[63:17]};
    wire [63:0] ln4=x4^{x4[6:0], x4[63:7]} ^{x4[40:0],x4[63:41]};

    always @(posedge clk or negedge rst_n) begin
        if(!rst_n) begin
            state<=IDLE;done<=0;nb_phase<=0;round_cnt<=0;round_end<=0;
            x0<=0;x1<=0;x2<=0;x3<=0;x4<=0;
            s0_out<=0;s1_out<=0;s2_out<=0;s3_out<=0;s4_out<=0;
        end else case(state)
            IDLE: begin done<=0;
                if(start) begin x0<=s0_in;x1<=s1_in;x2<=s2_in;x3<=s3_in;x4<=s4_in;
                    round_cnt<=start_round;round_end<=start_round+rounds;nb_phase<=0;state<=RUN; end
            end
            RUN: begin
                case(nb_phase)
                    NB_CONST: begin x2<=x2^{56'd0,rc}; nb_phase<=NB_THETA; end
                    NB_THETA: begin x0<=tt0;x1<=tt1;x2<=tt2;x3<=tt3;x4<=tt4; nb_phase<=5'd2; end
                    NB_LIN: begin
                        x0<=ln0;x1<=ln1;x2<=ln2;x3<=ln3;x4<=ln4;
                        nb_phase<=NB_CONST;
                        if(round_cnt<round_end-1) round_cnt<=round_cnt+1; else state<=FINISH;
                    end
                    default: begin  // NB_CHI nibble phases 2..17
                        x0<=nx0;x1<=nx1;x2<=nx2;x3<=nx3;x4<=nx4;
                        nb_phase<=nb_phase+5'd1;
                    end
                endcase
            end
            FINISH: begin s0_out<=x0;s1_out<=x1;s2_out<=x2;s3_out<=x3;s4_out<=x4;done<=1;state<=IDLE; end
            default: state<=IDLE;
        endcase
    end
endmodule
