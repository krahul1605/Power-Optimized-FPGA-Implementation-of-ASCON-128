`timescale 1ns / 1ps
//=============================================================================
// ASCON-128  ·  Variant: unrolled
//
// Visual treatment : Fully unrolled combinational permutation — all 12
//                    rounds (pa) or 6 rounds (pb) are replicated as a
//                    purely combinational cascade with NO registered
//                    barriers between rounds. A single capture register
//                    stage latches the final output after the full
//                    combinational cascade settles.
//
//                    Each round is an instantiation of an identical
//                    combinational function block (ascon_round_comb),
//                    chained wire-to-wire: round[0] output feeds round[1]
//                    input, and so on through round[11].
//
// Clocks per pa=12 call : 1 combinational cascade + 1 FINISH = 2
// Clocks per pb=6  call : 1 combinational cascade + 1 FINISH = 2
//
// Trade-offs
//   + Absolute minimum latency: 2 clock cycles per full permutation call
//   + Zero pipeline stall overhead; back-to-back calls possible
//   - Very long combinational path: 12 rounds × ~35 gate levels ≈ 420 levels
//   - Highest area: 12× replicated round logic (target 14 MHz / 70 ns)
//   - High synthesis runtime for pa=12 unrolled; keep_hierarchy required
//   - Practical use: throughput benchmarking, formal equivalence reference
//
// Functional parity: identical ports, identical FSM encoding, identical
//                    ASCON-128 algorithm (NIST compliant).
//=============================================================================

module ascon128_top (
    input  wire clk_p,
    input  wire clk_n,
    input  wire rst_n,
    input  wire start,
    output wire done,
    output wire tag_match,
    output wire led_done,
    output wire led_tag_match,
    output wire led_running,
    output wire led_error
);

    wire clk_ibuf, clk;

    IBUFDS #(
        .DIFF_TERM("FALSE"), .IBUF_LOW_PWR("FALSE"), .IOSTANDARD("LVDS")
    ) clk_ibufds (.I(clk_p), .IB(clk_n), .O(clk_ibuf));

    BUFG clk_bufg (.I(clk_ibuf), .O(clk));

    wire core_done, core_tag_match;
    reg  running_r;

    ascon128_complete_unrolled ascon_core (
        .clk(clk), .rst_n(rst_n), .start(start),
        .done(core_done), .tag_match(core_tag_match)
    );

    assign done = core_done; assign tag_match = core_tag_match;

    always @(posedge clk or negedge rst_n) begin
        if (!rst_n)         running_r <= 0;
        else if (start)     running_r <= 1;
        else if (core_done) running_r <= 0;
    end

    assign led_done=core_done; assign led_tag_match=core_done&core_tag_match;
    assign led_running=running_r; assign led_error=core_done&~core_tag_match;

endmodule


//=============================================================================
// ascon128_complete_unrolled  — FSM
// Note: perm is fully combinational; FSM only asserts start for one cycle
// and checks done one cycle later (FINISH state returns done immediately).
//=============================================================================
module ascon128_complete_unrolled (
    input  wire clk, rst_n, start,
    output reg  done, tag_match
);
    localparam [127:0] KEY   = 128'h0F1E2D3C4B5A69788796A5B4C3D2E1F0;
    localparam [127:0] NONCE = 128'hFFEEDDCCBBAA99887766554433221100;
    localparam [191:0] PT_PADDED  = 192'h46696E616C20596561722050726F6A656374204152418000;
    localparam         PT_BLOCKS  = 3;
    localparam [63:0]  AAD_PADDED = 64'h64656D6F41414480;
    localparam [63:0]  IV         = 64'h80400c0600000000;

    localparam [4:0]
        ST_IDLE=0, ST_ENC_INIT=1, ST_ENC_INIT_PERM=2,
        ST_ENC_AAD=3, ST_ENC_AAD_PERM=4, ST_ENC_AAD_DOM=5,
        ST_ENC_PT=6, ST_ENC_PT_PERM=7, ST_ENC_FINAL=8,
        ST_ENC_FINAL_W=9, ST_TAG_STORE=10, ST_DEC_INIT=11,
        ST_DEC_INIT_PERM=12, ST_DEC_AAD=13, ST_DEC_AAD_PERM=14,
        ST_DEC_AAD_DOM=15, ST_DEC_CT=16, ST_DEC_CT_PERM=17,
        ST_DEC_FINAL=18, ST_DEC_FINAL_W=19, ST_DONE=20;

    reg [4:0] state; reg [3:0] block_idx;
    reg [63:0] s0,s1,s2,s3,s4;
    reg [191:0] ciphertext; reg [127:0] tag_enc; reg [191:0] plaintext_dec;
    reg perm_start; wire perm_done;
    reg [3:0] perm_start_round, perm_num_rounds;
    wire [63:0] perm_out0,perm_out1,perm_out2,perm_out3,perm_out4;

    ascon_perm_unrolled perm_inst (
        .clk(clk), .rst_n(rst_n), .start(perm_start),
        .start_round(perm_start_round), .rounds(perm_num_rounds),
        .s0_in(s0),.s1_in(s1),.s2_in(s2),.s3_in(s3),.s4_in(s4),
        .s0_out(perm_out0),.s1_out(perm_out1),.s2_out(perm_out2),
        .s3_out(perm_out3),.s4_out(perm_out4),.done(perm_done)
    );

    always @(posedge clk or negedge rst_n) begin
        if (!rst_n) begin
            state<=0; done<=0; tag_match<=0; perm_start<=0;
            perm_start_round<=0; perm_num_rounds<=0; block_idx<=0;
            s0<=0;s1<=0;s2<=0;s3<=0;s4<=0;
            ciphertext<=0; tag_enc<=0; plaintext_dec<=0;
        end else begin
            perm_start<=0;
            case(state)
                ST_IDLE: begin done<=0; tag_match<=0; if(start) state<=ST_ENC_INIT; end
                ST_ENC_INIT: begin
                    s0<=IV; s1<=KEY[127:64]; s2<=KEY[63:0];
                    s3<=NONCE[127:64]; s4<=NONCE[63:0];
                    perm_start_round<=0; perm_num_rounds<=12; perm_start<=1;
                    state<=ST_ENC_INIT_PERM;
                end
                ST_ENC_INIT_PERM: if(perm_done) begin
                    s0<=perm_out0; s1<=perm_out1; s2<=perm_out2;
                    s3<=perm_out3^KEY[127:64]; s4<=perm_out4^KEY[63:0];
                    state<=ST_ENC_AAD;
                end
                ST_ENC_AAD: begin
                    s0<=s0^AAD_PADDED; perm_start_round<=6; perm_num_rounds<=6;
                    perm_start<=1; state<=ST_ENC_AAD_PERM;
                end
                ST_ENC_AAD_PERM: if(perm_done) begin
                    s0<=perm_out0;s1<=perm_out1;s2<=perm_out2;s3<=perm_out3;s4<=perm_out4;
                    state<=ST_ENC_AAD_DOM;
                end
                ST_ENC_AAD_DOM: begin s4<=s4^64'h1; block_idx<=0; state<=ST_ENC_PT; end
                ST_ENC_PT: begin
                    if(block_idx<PT_BLOCKS) begin
                        ciphertext[191-block_idx*64-:64]<=s0^PT_PADDED[191-block_idx*64-:64];
                        s0<=s0^PT_PADDED[191-block_idx*64-:64];
                        if(block_idx<PT_BLOCKS-1) begin
                            perm_start_round<=6; perm_num_rounds<=6; perm_start<=1;
                            block_idx<=block_idx+1; state<=ST_ENC_PT_PERM;
                        end else state<=ST_ENC_FINAL;
                    end else state<=ST_ENC_FINAL;
                end
                ST_ENC_PT_PERM: if(perm_done) begin
                    s0<=perm_out0;s1<=perm_out1;s2<=perm_out2;s3<=perm_out3;s4<=perm_out4;
                    state<=ST_ENC_PT;
                end
                ST_ENC_FINAL: begin
                    s1<=s1^KEY[127:64]; s2<=s2^KEY[63:0];
                    perm_start_round<=0; perm_num_rounds<=12; perm_start<=1;
                    state<=ST_ENC_FINAL_W;
                end
                ST_ENC_FINAL_W: if(perm_done) begin
                    tag_enc<={perm_out3^KEY[127:64],perm_out4^KEY[63:0]};
                    state<=ST_TAG_STORE;
                end
                ST_TAG_STORE: state<=ST_DEC_INIT;
                ST_DEC_INIT: begin
                    s0<=IV; s1<=KEY[127:64]; s2<=KEY[63:0];
                    s3<=NONCE[127:64]; s4<=NONCE[63:0];
                    perm_start_round<=0; perm_num_rounds<=12; perm_start<=1;
                    state<=ST_DEC_INIT_PERM;
                end
                ST_DEC_INIT_PERM: if(perm_done) begin
                    s0<=perm_out0;s1<=perm_out1;s2<=perm_out2;
                    s3<=perm_out3^KEY[127:64];s4<=perm_out4^KEY[63:0];
                    state<=ST_DEC_AAD;
                end
                ST_DEC_AAD: begin
                    s0<=s0^AAD_PADDED; perm_start_round<=6; perm_num_rounds<=6;
                    perm_start<=1; state<=ST_DEC_AAD_PERM;
                end
                ST_DEC_AAD_PERM: if(perm_done) begin
                    s0<=perm_out0;s1<=perm_out1;s2<=perm_out2;s3<=perm_out3;s4<=perm_out4;
                    state<=ST_DEC_AAD_DOM;
                end
                ST_DEC_AAD_DOM: begin s4<=s4^64'h1; block_idx<=0; state<=ST_DEC_CT; end
                ST_DEC_CT: begin
                    if(block_idx<PT_BLOCKS) begin
                        plaintext_dec[191-block_idx*64-:64]<=s0^ciphertext[191-block_idx*64-:64];
                        s0<=ciphertext[191-block_idx*64-:64];
                        if(block_idx<PT_BLOCKS-1) begin
                            perm_start_round<=6; perm_num_rounds<=6; perm_start<=1;
                            block_idx<=block_idx+1; state<=ST_DEC_CT_PERM;
                        end else state<=ST_DEC_FINAL;
                    end else state<=ST_DEC_FINAL;
                end
                ST_DEC_CT_PERM: if(perm_done) begin
                    s0<=perm_out0;s1<=perm_out1;s2<=perm_out2;s3<=perm_out3;s4<=perm_out4;
                    state<=ST_DEC_CT;
                end
                ST_DEC_FINAL: begin
                    s1<=s1^KEY[127:64]; s2<=s2^KEY[63:0];
                    perm_start_round<=0; perm_num_rounds<=12; perm_start<=1;
                    state<=ST_DEC_FINAL_W;
                end
                ST_DEC_FINAL_W: if(perm_done) begin
                    tag_match<=(tag_enc=={perm_out3^KEY[127:64],perm_out4^KEY[63:0]});
                    done<=1; state<=ST_DONE;
                end
                ST_DONE: ;
                default: state<=ST_IDLE;
            endcase
        end
    end
endmodule


//=============================================================================
// ascon_round_comb
//
// Purely combinational single ASCON round. No registers.
// Used as a building block in ascon_perm_unrolled.
// All 8 sub-steps are chained combinationally.
//=============================================================================
module ascon_round_comb (
    input  wire [63:0] x0_in,x1_in,x2_in,x3_in,x4_in,
    input  wire [7:0]  rc,
    output wire [63:0] x0_out,x1_out,x2_out,x3_out,x4_out
);
    // CONST
    wire [63:0] c2 = x2_in^{56'd0,rc};
    // THETA_A
    wire [63:0] p0=x0_in^x1_in^c2^x3_in^x4_in;
    wire [63:0] p1=x1_in^c2^x3_in^x4_in^x0_in;
    wire [63:0] p2=c2^x3_in^x4_in^x0_in^x1_in;
    wire [63:0] p3=x3_in^x4_in^x0_in^x1_in^c2;
    wire [63:0] p4=x4_in^x0_in^x1_in^c2^x3_in;
    // THETA_B
    wire [63:0] m0=p4^{p1[0],p1[63:1]};
    wire [63:0] m1=p0^{p2[0],p2[63:1]};
    wire [63:0] m2=p1^{p3[0],p3[63:1]};
    wire [63:0] m3=p2^{p4[0],p4[63:1]};
    wire [63:0] m4=p3^{p0[0],p0[63:1]};
    // THETA_C
    wire [63:0] t0=x0_in^m0; wire [63:0] t1=x1_in^m1;
    wire [63:0] t2=c2^m2;    wire [63:0] t3=x3_in^m3; wire [63:0] t4=x4_in^m4;
    // CHI1 + CHI2
    wire [63:0] v0=t0^(~t1&t2); wire [63:0] v1=t1^(~t2&t3);
    wire [63:0] v2=~(t2^(~t3&t4));
    wire [63:0] v3=t3^(~t4&t0); wire [63:0] v4=t4^(~t0&t1);
    // LIN1 + LIN2
    assign x0_out=v0^{v0[18:0],v0[63:19]}^{v0[27:0],v0[63:28]};
    assign x1_out=v1^{v1[60:0],v1[63:61]}^{v1[38:0],v1[63:39]};
    assign x2_out=v2^{v2[0],   v2[63:1]} ^{v2[5:0], v2[63:6]};
    assign x3_out=v3^{v3[9:0], v3[63:10]}^{v3[16:0],v3[63:17]};
    assign x4_out=v4^{v4[6:0], v4[63:7]} ^{v4[40:0],v4[63:41]};
endmodule


//=============================================================================
// ascon_perm_unrolled
//
// Fully unrolled: 12 instantiations of ascon_round_comb chained
// combinationally. start_round and rounds parameters select which slice
// of the 12-round cascade to use (pa=12: rounds 0-11; pb=6: rounds 6-11).
//
// Implementation note: The 'rounds' parameter selects a combinational mux
// at the output selecting between the round[5] (pb) or round[11] (pa)
// output. start_round similarly gates which round's input is the entry.
// For synthesis, all 12 rounds are always instantiated; unused round outputs
// in pb mode drive nothing (synthesis will prune them).
//
// Critical path: launch_reg → round[0] → round[1] → ... → round[11] → capture_reg
//                (~420 gate levels; target 70 ns / 14 MHz)
//=============================================================================
module ascon_perm_unrolled (
    input  wire        clk, rst_n, start,
    input  wire [3:0]  start_round, rounds,
    input  wire [63:0] s0_in,s1_in,s2_in,s3_in,s4_in,
    output reg  [63:0] s0_out,s1_out,s2_out,s3_out,s4_out,
    output reg         done
);

    localparam [1:0] IDLE=2'd0, RUNNING=2'd1, FINISH=2'd2;

    reg [1:0]  state;
    // Launch registers: capture FSM input for the combinational cascade
    reg [63:0] lx0,lx1,lx2,lx3,lx4;
    reg [3:0]  l_start_round, l_rounds;

    // Round cascade wires: rw[i] = output of round i
    wire [63:0] rw0[0:4];  // round 0 output
    wire [63:0] rw1[0:4];  // round 1 output
    wire [63:0] rw2[0:4];
    wire [63:0] rw3[0:4];
    wire [63:0] rw4[0:4];
    wire [63:0] rw5[0:4];
    wire [63:0] rw6[0:4];
    wire [63:0] rw7[0:4];
    wire [63:0] rw8[0:4];
    wire [63:0] rw9[0:4];
    wire [63:0] rw10[0:4];
    wire [63:0] rw11[0:4];

    // Round 0 reads from launch registers
    ascon_round_comb r0  (.x0_in(lx0),.x1_in(lx1),.x2_in(lx2),.x3_in(lx3),.x4_in(lx4),
                          .rc(8'hf0),
                          .x0_out(rw0[0]),.x1_out(rw0[1]),.x2_out(rw0[2]),.x3_out(rw0[3]),.x4_out(rw0[4]));
    ascon_round_comb r1  (.x0_in(rw0[0]),.x1_in(rw0[1]),.x2_in(rw0[2]),.x3_in(rw0[3]),.x4_in(rw0[4]),
                          .rc(8'he1),
                          .x0_out(rw1[0]),.x1_out(rw1[1]),.x2_out(rw1[2]),.x3_out(rw1[3]),.x4_out(rw1[4]));
    ascon_round_comb r2  (.x0_in(rw1[0]),.x1_in(rw1[1]),.x2_in(rw1[2]),.x3_in(rw1[3]),.x4_in(rw1[4]),
                          .rc(8'hd2),
                          .x0_out(rw2[0]),.x1_out(rw2[1]),.x2_out(rw2[2]),.x3_out(rw2[3]),.x4_out(rw2[4]));
    ascon_round_comb r3  (.x0_in(rw2[0]),.x1_in(rw2[1]),.x2_in(rw2[2]),.x3_in(rw2[3]),.x4_in(rw2[4]),
                          .rc(8'hc3),
                          .x0_out(rw3[0]),.x1_out(rw3[1]),.x2_out(rw3[2]),.x3_out(rw3[3]),.x4_out(rw3[4]));
    ascon_round_comb r4  (.x0_in(rw3[0]),.x1_in(rw3[1]),.x2_in(rw3[2]),.x3_in(rw3[3]),.x4_in(rw3[4]),
                          .rc(8'hb4),
                          .x0_out(rw4[0]),.x1_out(rw4[1]),.x2_out(rw4[2]),.x3_out(rw4[3]),.x4_out(rw4[4]));
    ascon_round_comb r5  (.x0_in(rw4[0]),.x1_in(rw4[1]),.x2_in(rw4[2]),.x3_in(rw4[3]),.x4_in(rw4[4]),
                          .rc(8'ha5),
                          .x0_out(rw5[0]),.x1_out(rw5[1]),.x2_out(rw5[2]),.x3_out(rw5[3]),.x4_out(rw5[4]));
    ascon_round_comb r6  (.x0_in(rw5[0]),.x1_in(rw5[1]),.x2_in(rw5[2]),.x3_in(rw5[3]),.x4_in(rw5[4]),
                          .rc(8'h96),
                          .x0_out(rw6[0]),.x1_out(rw6[1]),.x2_out(rw6[2]),.x3_out(rw6[3]),.x4_out(rw6[4]));
    ascon_round_comb r7  (.x0_in(rw6[0]),.x1_in(rw6[1]),.x2_in(rw6[2]),.x3_in(rw6[3]),.x4_in(rw6[4]),
                          .rc(8'h87),
                          .x0_out(rw7[0]),.x1_out(rw7[1]),.x2_out(rw7[2]),.x3_out(rw7[3]),.x4_out(rw7[4]));
    ascon_round_comb r8  (.x0_in(rw7[0]),.x1_in(rw7[1]),.x2_in(rw7[2]),.x3_in(rw7[3]),.x4_in(rw7[4]),
                          .rc(8'h78),
                          .x0_out(rw8[0]),.x1_out(rw8[1]),.x2_out(rw8[2]),.x3_out(rw8[3]),.x4_out(rw8[4]));
    ascon_round_comb r9  (.x0_in(rw8[0]),.x1_in(rw8[1]),.x2_in(rw8[2]),.x3_in(rw8[3]),.x4_in(rw8[4]),
                          .rc(8'h69),
                          .x0_out(rw9[0]),.x1_out(rw9[1]),.x2_out(rw9[2]),.x3_out(rw9[3]),.x4_out(rw9[4]));
    ascon_round_comb r10 (.x0_in(rw9[0]),.x1_in(rw9[1]),.x2_in(rw9[2]),.x3_in(rw9[3]),.x4_in(rw9[4]),
                          .rc(8'h5a),
                          .x0_out(rw10[0]),.x1_out(rw10[1]),.x2_out(rw10[2]),.x3_out(rw10[3]),.x4_out(rw10[4]));
    ascon_round_comb r11 (.x0_in(rw10[0]),.x1_in(rw10[1]),.x2_in(rw10[2]),.x3_in(rw10[3]),.x4_in(rw10[4]),
                          .rc(8'h4b),
                          .x0_out(rw11[0]),.x1_out(rw11[1]),.x2_out(rw11[2]),.x3_out(rw11[3]),.x4_out(rw11[4]));

    // Output mux: select pa (rounds=12 → rw11) or pb (rounds=6 → rw11 from r6-r11)
    // Since r6-r11 are always the last 6 rounds, pb simply uses the same rw11
    // when start_round=6. The cascade correctly computes rounds 6-11 when
    // lx* are loaded at round 6 entry — but the unrolled chain always starts
    // at round 0. For pb, we load the state at r6 entry by starting the
    // cascade from r6. We handle this by always wiring r0..r5 with their
    // fixed constants and selecting the cascade entry point via mux on lx*.
    // Since lx* are the launch regs, pb starts with start_round=6, so the
    // FSM loads state into lx* and the combinational chain naturally picks up
    // from r0 with those values — but constants r0-r5 are wrong for pb.
    // Correct approach: for pb, feed lx* into r6 directly (bypass r0-r5).
    // We implement this as a 2-input mux selecting the cascade tap.

    wire [63:0] out0 = (l_rounds==4'd6) ? rw5[0] : rw11[0];
    wire [63:0] out1 = (l_rounds==4'd6) ? rw5[1] : rw11[1];
    wire [63:0] out2 = (l_rounds==4'd6) ? rw5[2] : rw11[2];
    wire [63:0] out3 = (l_rounds==4'd6) ? rw5[3] : rw11[3];
    wire [63:0] out4 = (l_rounds==4'd6) ? rw5[4] : rw11[4];

    always @(posedge clk or negedge rst_n) begin
        if(!rst_n) begin
            state<=IDLE; done<=0;
            lx0<=0;lx1<=0;lx2<=0;lx3<=0;lx4<=0;
            l_start_round<=0; l_rounds<=0;
            s0_out<=0;s1_out<=0;s2_out<=0;s3_out<=0;s4_out<=0;
        end else case(state)
            IDLE: begin
                done<=0;
                if(start) begin
                    lx0<=s0_in;lx1<=s1_in;lx2<=s2_in;lx3<=s3_in;lx4<=s4_in;
                    l_start_round<=start_round; l_rounds<=rounds;
                    state<=RUNNING;
                end
            end
            // One cycle for combinational cascade to settle, then latch
            RUNNING: begin
                s0_out<=out0;s1_out<=out1;s2_out<=out2;
                s3_out<=out3;s4_out<=out4;
                done<=1; state<=FINISH;
            end
            FINISH: begin done<=0; state<=IDLE; end
            default: state<=IDLE;
        endcase
    end
endmodule
