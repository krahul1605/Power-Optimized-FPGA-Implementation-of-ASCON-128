`timescale 1ns / 1ps
//=============================================================================
// ASCON-128  ·  Variant: halfpipe
//
// Visual treatment : Half-depth pipeline — pairs of ASCON sub-steps are
//                    merged into each registered pipeline stage, yielding
//                    4 stages per round instead of 8:
//
//   Stage 0 : CONST  + THETA_A  — constant XOR, then column parity tree
//   Stage 1 : THETA_B + THETA_C — rotation mix, then theta application
//   Stage 2 : CHI1   + CHI2    — AND-NOT terms, then chi XOR (CRITICAL)
//   Stage 3 : LIN1   + LIN2    — rotation operands, then linear XOR
//
// Clocks per pa=12 call : 12 rounds × 4 sub-stages = 48 + 1 FINISH = 49
// Clocks per pb=6  call :  6 rounds × 4 sub-stages = 24 + 1 FINISH = 25
//
// Trade-offs
//   + Half the pipeline register count of elevated (4 stage regs vs 8)
//   + Half the latency (clocks) vs elevated for same frequency
//   + Well-suited to FPGA where LUT+FF absorbs 2 sub-steps efficiently
//   - Critical path doubles per stage vs elevated (~10 ns / 100 MHz target)
//   - Stage 2 (CHI1+CHI2) is timing bottleneck: AND-NOT + XOR + INV chain
//
// Functional parity: identical ports, identical FSM encoding, identical
//                    ASCON-128 algorithm (NIST compliant).
//=============================================================================

module ascon128_top (
    input  wire clk_p,
    input  wire clk_n,
    input  wire rst_n,
    input  wire start,
    output wire done,
    output wire tag_match,
    output wire led_done,
    output wire led_tag_match,
    output wire led_running,
    output wire led_error
);

    wire clk_ibuf, clk;

    IBUFDS #(
        .DIFF_TERM("FALSE"), .IBUF_LOW_PWR("FALSE"), .IOSTANDARD("LVDS")
    ) clk_ibufds (.I(clk_p), .IB(clk_n), .O(clk_ibuf));

    BUFG clk_bufg (.I(clk_ibuf), .O(clk));

    wire core_done, core_tag_match;
    reg  running_r;

    ascon128_complete_halfpipe ascon_core (
        .clk(clk), .rst_n(rst_n), .start(start),
        .done(core_done), .tag_match(core_tag_match)
    );

    assign done = core_done; assign tag_match = core_tag_match;

    always @(posedge clk or negedge rst_n) begin
        if (!rst_n)         running_r <= 0;
        else if (start)     running_r <= 1;
        else if (core_done) running_r <= 0;
    end

    assign led_done=core_done; assign led_tag_match=core_done&core_tag_match;
    assign led_running=running_r; assign led_error=core_done&~core_tag_match;

endmodule


//=============================================================================
// ascon128_complete_halfpipe  — FSM (identical to all variants)
//=============================================================================
module ascon128_complete_halfpipe (
    input  wire clk, rst_n, start,
    output reg  done, tag_match
);
    localparam [127:0] KEY   = 128'h0F1E2D3C4B5A69788796A5B4C3D2E1F0;
    localparam [127:0] NONCE = 128'hFFEEDDCCBBAA99887766554433221100;
    localparam [191:0] PT_PADDED  = 192'h46696E616C20596561722050726F6A656374204152418000;
    localparam         PT_BLOCKS  = 3;
    localparam [63:0]  AAD_PADDED = 64'h64656D6F41414480;
    localparam [63:0]  IV         = 64'h80400c0600000000;

    localparam [4:0]
        ST_IDLE=0, ST_ENC_INIT=1, ST_ENC_INIT_PERM=2,
        ST_ENC_AAD=3, ST_ENC_AAD_PERM=4, ST_ENC_AAD_DOM=5,
        ST_ENC_PT=6, ST_ENC_PT_PERM=7, ST_ENC_FINAL=8,
        ST_ENC_FINAL_W=9, ST_TAG_STORE=10, ST_DEC_INIT=11,
        ST_DEC_INIT_PERM=12, ST_DEC_AAD=13, ST_DEC_AAD_PERM=14,
        ST_DEC_AAD_DOM=15, ST_DEC_CT=16, ST_DEC_CT_PERM=17,
        ST_DEC_FINAL=18, ST_DEC_FINAL_W=19, ST_DONE=20;

    reg [4:0] state; reg [3:0] block_idx;
    reg [63:0] s0,s1,s2,s3,s4;
    reg [191:0] ciphertext; reg [127:0] tag_enc; reg [191:0] plaintext_dec;
    reg perm_start; wire perm_done;
    reg [3:0] perm_start_round, perm_num_rounds;
    wire [63:0] perm_out0,perm_out1,perm_out2,perm_out3,perm_out4;

    ascon_perm_halfpipe perm_inst (
        .clk(clk), .rst_n(rst_n), .start(perm_start),
        .start_round(perm_start_round), .rounds(perm_num_rounds),
        .s0_in(s0),.s1_in(s1),.s2_in(s2),.s3_in(s3),.s4_in(s4),
        .s0_out(perm_out0),.s1_out(perm_out1),.s2_out(perm_out2),
        .s3_out(perm_out3),.s4_out(perm_out4),.done(perm_done)
    );

    always @(posedge clk or negedge rst_n) begin
        if (!rst_n) begin
            state<=0; done<=0; tag_match<=0; perm_start<=0;
            perm_start_round<=0; perm_num_rounds<=0; block_idx<=0;
            s0<=0;s1<=0;s2<=0;s3<=0;s4<=0;
            ciphertext<=0; tag_enc<=0; plaintext_dec<=0;
        end else begin
            perm_start<=0;
            case(state)
                ST_IDLE: begin done<=0; tag_match<=0; if(start) state<=ST_ENC_INIT; end
                ST_ENC_INIT: begin
                    s0<=IV; s1<=KEY[127:64]; s2<=KEY[63:0];
                    s3<=NONCE[127:64]; s4<=NONCE[63:0];
                    perm_start_round<=0; perm_num_rounds<=12; perm_start<=1;
                    state<=ST_ENC_INIT_PERM;
                end
                ST_ENC_INIT_PERM: if(perm_done) begin
                    s0<=perm_out0; s1<=perm_out1; s2<=perm_out2;
                    s3<=perm_out3^KEY[127:64]; s4<=perm_out4^KEY[63:0];
                    state<=ST_ENC_AAD;
                end
                ST_ENC_AAD: begin
                    s0<=s0^AAD_PADDED; perm_start_round<=6; perm_num_rounds<=6;
                    perm_start<=1; state<=ST_ENC_AAD_PERM;
                end
                ST_ENC_AAD_PERM: if(perm_done) begin
                    s0<=perm_out0;s1<=perm_out1;s2<=perm_out2;s3<=perm_out3;s4<=perm_out4;
                    state<=ST_ENC_AAD_DOM;
                end
                ST_ENC_AAD_DOM: begin s4<=s4^64'h1; block_idx<=0; state<=ST_ENC_PT; end
                ST_ENC_PT: begin
                    if(block_idx<PT_BLOCKS) begin
                        ciphertext[191-block_idx*64-:64]<=s0^PT_PADDED[191-block_idx*64-:64];
                        s0<=s0^PT_PADDED[191-block_idx*64-:64];
                        if(block_idx<PT_BLOCKS-1) begin
                            perm_start_round<=6; perm_num_rounds<=6; perm_start<=1;
                            block_idx<=block_idx+1; state<=ST_ENC_PT_PERM;
                        end else state<=ST_ENC_FINAL;
                    end else state<=ST_ENC_FINAL;
                end
                ST_ENC_PT_PERM: if(perm_done) begin
                    s0<=perm_out0;s1<=perm_out1;s2<=perm_out2;s3<=perm_out3;s4<=perm_out4;
                    state<=ST_ENC_PT;
                end
                ST_ENC_FINAL: begin
                    s1<=s1^KEY[127:64]; s2<=s2^KEY[63:0];
                    perm_start_round<=0; perm_num_rounds<=12; perm_start<=1;
                    state<=ST_ENC_FINAL_W;
                end
                ST_ENC_FINAL_W: if(perm_done) begin
                    tag_enc<={perm_out3^KEY[127:64],perm_out4^KEY[63:0]};
                    state<=ST_TAG_STORE;
                end
                ST_TAG_STORE: state<=ST_DEC_INIT;
                ST_DEC_INIT: begin
                    s0<=IV; s1<=KEY[127:64]; s2<=KEY[63:0];
                    s3<=NONCE[127:64]; s4<=NONCE[63:0];
                    perm_start_round<=0; perm_num_rounds<=12; perm_start<=1;
                    state<=ST_DEC_INIT_PERM;
                end
                ST_DEC_INIT_PERM: if(perm_done) begin
                    s0<=perm_out0;s1<=perm_out1;s2<=perm_out2;
                    s3<=perm_out3^KEY[127:64];s4<=perm_out4^KEY[63:0];
                    state<=ST_DEC_AAD;
                end
                ST_DEC_AAD: begin
                    s0<=s0^AAD_PADDED; perm_start_round<=6; perm_num_rounds<=6;
                    perm_start<=1; state<=ST_DEC_AAD_PERM;
                end
                ST_DEC_AAD_PERM: if(perm_done) begin
                    s0<=perm_out0;s1<=perm_out1;s2<=perm_out2;s3<=perm_out3;s4<=perm_out4;
                    state<=ST_DEC_AAD_DOM;
                end
                ST_DEC_AAD_DOM: begin s4<=s4^64'h1; block_idx<=0; state<=ST_DEC_CT; end
                ST_DEC_CT: begin
                    if(block_idx<PT_BLOCKS) begin
                        plaintext_dec[191-block_idx*64-:64]<=s0^ciphertext[191-block_idx*64-:64];
                        s0<=ciphertext[191-block_idx*64-:64];
                        if(block_idx<PT_BLOCKS-1) begin
                            perm_start_round<=6; perm_num_rounds<=6; perm_start<=1;
                            block_idx<=block_idx+1; state<=ST_DEC_CT_PERM;
                        end else state<=ST_DEC_FINAL;
                    end else state<=ST_DEC_FINAL;
                end
                ST_DEC_CT_PERM: if(perm_done) begin
                    s0<=perm_out0;s1<=perm_out1;s2<=perm_out2;s3<=perm_out3;s4<=perm_out4;
                    state<=ST_DEC_CT;
                end
                ST_DEC_FINAL: begin
                    s1<=s1^KEY[127:64]; s2<=s2^KEY[63:0];
                    perm_start_round<=0; perm_num_rounds<=12; perm_start<=1;
                    state<=ST_DEC_FINAL_W;
                end
                ST_DEC_FINAL_W: if(perm_done) begin
                    tag_match<=(tag_enc=={perm_out3^KEY[127:64],perm_out4^KEY[63:0]});
                    done<=1; state<=ST_DONE;
                end
                ST_DONE: ;
                default: state<=ST_IDLE;
            endcase
        end
    end
endmodule


//=============================================================================
// ascon_perm_halfpipe
//
// 4-stage registered pipeline per round. Two sub-steps are fused into each
// stage's combinational cone, with a register barrier between every pair.
//
//   Stage 0 (S0) : CONST + THETA_A
//     x2 ^= rc; compute parities p0..p4 -> register p*
//   Stage 1 (S1) : THETA_B + THETA_C
//     rotation-mix m* from p*; apply theta t = x + m -> register t*
//   Stage 2 (S2) : CHI1 + CHI2      ← CRITICAL PATH
//     AND-NOT u*; chi XOR, x2 invert -> register x* (updated)
//   Stage 3 (S3) : LIN1 + LIN2
//     rotation operands ra*/rb*; final XOR -> register x* (final)
//
// State encoding: 2-bit stage counter (st_stage), 4-bit round counter.
// Critical path: t*_reg → AND-NOT → XOR → INV → x*_reg  (~10 ns / 100 MHz)
//=============================================================================
module ascon_perm_halfpipe (
    input  wire        clk, rst_n, start,
    input  wire [3:0]  start_round, rounds,
    input  wire [63:0] s0_in,s1_in,s2_in,s3_in,s4_in,
    output reg  [63:0] s0_out,s1_out,s2_out,s3_out,s4_out,
    output reg         done
);

    localparam [2:0] IDLE=3'd0, S0=3'd1, S1=3'd2, S2=3'd3, S3=3'd4, FINISH=3'd5;

    reg [2:0]  state;
    reg [3:0]  round_cnt, round_end;

    // Stage registers
    reg [63:0] x0,x1,x2,x3,x4;    // working state (input to S0, output of S2/S3)
    reg [63:0] p0,p1,p2,p3,p4;    // S0 output: parities
    reg [63:0] t0,t1,t2,t3,t4;    // S1 output: theta result

    // Round constant decode
    reg [7:0] rc;
    always @(*) case(round_cnt)
        4'd0:rc=8'hf0; 4'd1:rc=8'he1; 4'd2:rc=8'hd2; 4'd3:rc=8'hc3;
        4'd4:rc=8'hb4; 4'd5:rc=8'ha5; 4'd6:rc=8'h96; 4'd7:rc=8'h87;
        4'd8:rc=8'h78; 4'd9:rc=8'h69; 4'd10:rc=8'h5a; 4'd11:rc=8'h4b;
        default:rc=8'h00;
    endcase

    always @(posedge clk or negedge rst_n) begin
        if(!rst_n) begin
            state<=IDLE; done<=0; round_cnt<=0; round_end<=0;
            x0<=0;x1<=0;x2<=0;x3<=0;x4<=0;
            p0<=0;p1<=0;p2<=0;p3<=0;p4<=0;
            t0<=0;t1<=0;t2<=0;t3<=0;t4<=0;
            s0_out<=0;s1_out<=0;s2_out<=0;s3_out<=0;s4_out<=0;
        end else case(state)
            IDLE: begin
                done<=0;
                if(start) begin
                    x0<=s0_in;x1<=s1_in;x2<=s2_in;x3<=s3_in;x4<=s4_in;
                    round_cnt<=start_round; round_end<=start_round+rounds;
                    state<=S0;
                end
            end
            // Stage 0: CONST + THETA_A (fused)
            S0: begin
                // CONST: XOR round constant into x2, then immediately
                // THETA_A: column parities of post-constant state
                p0<= x0^x1^(x2^{56'd0,rc})^x3^x4;
                p1<= x1^(x2^{56'd0,rc})^x3^x4^x0;
                p2<= (x2^{56'd0,rc})^x3^x4^x0^x1;
                p3<= x3^x4^x0^x1^(x2^{56'd0,rc});
                p4<= x4^x0^x1^(x2^{56'd0,rc})^x3;
                // Carry x* through for THETA_C use in S1
                // We still need original x* after const for theta_c; save into t as temp
                t0<=x0; t1<=x1; t2<=x2^{56'd0,rc}; t3<=x3; t4<=x4;
                state<=S1;
            end
            // Stage 1: THETA_B + THETA_C (fused)
            S1: begin
                // THETA_B: rotation-mixed parities (m*)
                // THETA_C: t_final = x_const XOR m  (combinational merge)
                t0<= t0^(p4^{p1[0],p1[63:1]});
                t1<= t1^(p0^{p2[0],p2[63:1]});
                t2<= t2^(p1^{p3[0],p3[63:1]});
                t3<= t3^(p2^{p4[0],p4[63:1]});
                t4<= t4^(p3^{p0[0],p0[63:1]});
                state<=S2;
            end
            // Stage 2: CHI1 + CHI2 (fused) — CRITICAL PATH
            S2: begin
                // CHI1: AND-NOT; CHI2: XOR, x2 inverted
                x0<= t0^(~t1&t2);
                x1<= t1^(~t2&t3);
                x2<= ~(t2^(~t3&t4));
                x3<= t3^(~t4&t0);
                x4<= t4^(~t0&t1);
                state<=S3;
            end
            // Stage 3: LIN1 + LIN2 (fused) — final linear layer
            S3: begin
                x0<= x0^{x0[18:0],x0[63:19]}^{x0[27:0],x0[63:28]};
                x1<= x1^{x1[60:0],x1[63:61]}^{x1[38:0],x1[63:39]};
                x2<= x2^{x2[0],   x2[63:1]} ^{x2[5:0], x2[63:6]};
                x3<= x3^{x3[9:0], x3[63:10]}^{x3[16:0],x3[63:17]};
                x4<= x4^{x4[6:0], x4[63:7]} ^{x4[40:0],x4[63:41]};
                if(round_cnt < round_end-1) begin
                    round_cnt<=round_cnt+1; state<=S0;
                end else state<=FINISH;
            end
            FINISH: begin
                s0_out<=x0;s1_out<=x1;s2_out<=x2;
                s3_out<=x3;s4_out<=x4; done<=1; state<=IDLE;
            end
            default: state<=IDLE;
        endcase
    end
endmodule
