#==============================================================================
# ASCON-128  ·  Variant: halfpipe
# SDC for Cadence Genus Synthesis
#
# Permutation architecture: 4-stage registered pipeline per round.
#   Two ASCON sub-steps are merged into each pipeline stage:
#     Stage 0 : CONST  + THETA_A  — constant XOR and column parity
#     Stage 1 : THETA_B + THETA_C — rotation mix and theta application
#     Stage 2 : CHI1   + CHI2    — AND-NOT terms and chi XOR
#     Stage 3 : LIN1   + LIN2    — rotation operands and final linear XOR
#
# Architecture trade-offs:
#   + Balanced midpoint: half the pipeline registers of the elevated variant.
#   + Half the latency (clocks per round) vs elevated, double vs baseline.
#   + Well-suited to FPGAs where LUT+FF pairs absorb two sub-steps cheaply.
#   - Critical path doubles per stage relative to elevated (2 sub-steps merged).
#   - Stage 2 (CHI1+CHI2) is the timing bottleneck: AND-NOT + XOR + INV chain.
#
# Timing impact vs elevated:
#   - Critical path per cycle: 2 merged sub-steps (~6-8 LUT/gate levels).
#   - Clock period target: 10.000 ns (100 MHz) — 2× relaxed vs elevated.
#   - Input/output delays: 2.0/0.5 ns standard board interface.
#   - Multicycle paths: NOT needed — each merged stage is exactly 1 cycle.
#
# Clocks per pa=12 call : 12 rounds × 4 sub-stages = 48 + 1 FINISH = 49
# Clocks per pb=6  call :  6 rounds × 4 sub-stages = 24 + 1 FINISH = 25
#
# Synthesis guidance for Genus:
#   Timing closure effort should focus on Stage 2 (CHI path). Use high-effort
#   mapping on the AND-NOT + chi XOR merge. Stage 1 (rotation mix) benefits
#   from barrel-shifter inference if the library supports it.
#==============================================================================

#------------------------------------------------------------------------------
# 1. CLOCK DEFINITION
#    100 MHz / 10 ns — halfpipe 4-stage architecture
#------------------------------------------------------------------------------
create_clock -period 10.000 \
             -name sys_clk \
             -waveform {0.000 5.000} \
             [get_ports clk_p]

#------------------------------------------------------------------------------
# 2. CLOCK UNCERTAINTY
#    Moderate jitter budget for 100 MHz on-chip PLL-driven clock.
#------------------------------------------------------------------------------
set_clock_uncertainty -setup 0.200 [get_clocks sys_clk]
set_clock_uncertainty -hold  0.150 [get_clocks sys_clk]

#------------------------------------------------------------------------------
# 3. CLOCK TRANSITION
#    Fast edge rate; typically driven by PLL output buffer.
#------------------------------------------------------------------------------
set_clock_transition -rise 0.080 [get_clocks sys_clk]
set_clock_transition -fall 0.080 [get_clocks sys_clk]

#------------------------------------------------------------------------------
# 4. INPUT DELAYS
#    At 10 ns period, 2.0 ns max input delay leaves 7.72 ns internal budget.
#------------------------------------------------------------------------------
set_input_delay -clock sys_clk -max 2.000 [get_ports rst_n]
set_input_delay -clock sys_clk -min 0.500 [get_ports rst_n]
set_input_delay -clock sys_clk -max 2.000 [get_ports start]
set_input_delay -clock sys_clk -min 0.500 [get_ports start]

#------------------------------------------------------------------------------
# 5. OUTPUT DELAYS
#------------------------------------------------------------------------------
set_output_delay -clock sys_clk -max 2.000 [get_ports done]
set_output_delay -clock sys_clk -min 0.500 [get_ports done]
set_output_delay -clock sys_clk -max 2.000 [get_ports tag_match]
set_output_delay -clock sys_clk -min 0.500 [get_ports tag_match]
set_output_delay -clock sys_clk -max 2.000 [get_ports led_done]
set_output_delay -clock sys_clk -min 0.500 [get_ports led_done]
set_output_delay -clock sys_clk -max 2.000 [get_ports led_tag_match]
set_output_delay -clock sys_clk -min 0.500 [get_ports led_tag_match]
set_output_delay -clock sys_clk -max 2.000 [get_ports led_running]
set_output_delay -clock sys_clk -min 0.500 [get_ports led_running]
set_output_delay -clock sys_clk -max 2.000 [get_ports led_error]
set_output_delay -clock sys_clk -min 0.500 [get_ports led_error]

#------------------------------------------------------------------------------
# 6. ASYNCHRONOUS RESET - FALSE PATH
#------------------------------------------------------------------------------
set_false_path -from [get_ports rst_n]

#------------------------------------------------------------------------------
# 7. PIPELINE STAGE PATH BUDGET — HALFPIPE
#    Each stage merges two sub-steps into a single combinational cone.
#    Budget: 10.000 - 0.200 (unc) - 0.080 (transition) = 9.720 ns available.
#
#    Per-stage breakdown (estimated):
#      Stage 0 (CONST+THETA_A)  : ~4.0 ns  — XOR tree for 5 parities
#      Stage 1 (THETA_B+THETA_C): ~4.5 ns  — rotate + XOR application
#      Stage 2 (CHI1+CHI2)      : ~5.5 ns  — AND-NOT + XOR + INV  ← CRITICAL
#      Stage 3 (LIN1+LIN2)      : ~4.2 ns  — rotate + XOR merge
#
#    Constrain the critical CHI merged stage explicitly:
#------------------------------------------------------------------------------
# set_max_delay 9.720 -from [get_cells {t*_reg*}] -to [get_cells {x*_reg*}]

#------------------------------------------------------------------------------
# 8. RETIMING ENABLE
#    Retiming across Stage 2/3 boundary may rebalance CHI vs LIN path lengths.
#    Uncomment for 120 MHz+ targets.
#------------------------------------------------------------------------------
# set_attribute retime true [get_db designs ascon_perm_halfpipe]

#------------------------------------------------------------------------------
# 9. DRIVING CELL / OUTPUT LOAD
#------------------------------------------------------------------------------
set_driving_cell -no_design_rule [get_ports {start rst_n}]
set_load 5.0 [get_ports {done tag_match led_done led_tag_match led_running led_error}]

#------------------------------------------------------------------------------
# 10. OPERATING CONDITIONS
#      High-performance condition recommended for 100 MHz target closure.
#      Uncomment and set library condition as appropriate.
#------------------------------------------------------------------------------
# set_operating_conditions -library <lib> FAST

#==============================================================================
# END - ascon128_halfpipe.sdc
#==============================================================================
