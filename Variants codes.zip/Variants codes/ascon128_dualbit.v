`timescale 1ns / 1ps
module ascon128_top (
    input  wire clk_p,clk_n,rst_n,start,
    output wire done,tag_match,led_done,led_tag_match,led_running,led_error
);
    wire clk_ibuf,clk; reg rr;
    IBUFDS #(.DIFF_TERM("FALSE"),.IBUF_LOW_PWR("FALSE"),.IOSTANDARD("LVDS"))
        u(.I(clk_p),.IB(clk_n),.O(clk_ibuf));
    BUFG b(.I(clk_ibuf),.O(clk));
    wire cd,ct;
    ascon128_complete_dualbit ac(.clk(clk),.rst_n(rst_n),.start(start),.done(cd),.tag_match(ct));
    assign done=cd; assign tag_match=ct;
    always @(posedge clk or negedge rst_n) if(!rst_n) rr<=0; else if(start) rr<=1; else if(cd) rr<=0;
    assign led_done=cd; assign led_tag_match=cd&ct; assign led_running=rr; assign led_error=cd&~ct;
endmodule

module ascon128_complete_dualbit(input wire clk,rst_n,start,output reg done,tag_match);
    localparam [127:0] KEY=128'h0F1E2D3C4B5A69788796A5B4C3D2E1F0,NONCE=128'hFFEEDDCCBBAA99887766554433221100;
    localparam [191:0] PT_PADDED=192'h46696E616C20596561722050726F6A656374204152418000;
    localparam PT_BLOCKS=3; localparam [63:0] AAD_PADDED=64'h64656D6F41414480,IV=64'h80400c0600000000;
    localparam [4:0] ST_IDLE=0,ST_EI=1,ST_EIP=2,ST_EA=3,ST_EAP=4,ST_EAD=5,
        ST_EP=6,ST_EPP=7,ST_EF=8,ST_EFW=9,ST_TS=10,ST_DI=11,ST_DIP=12,
        ST_DA=13,ST_DAP=14,ST_DAD=15,ST_DC=16,ST_DCP=17,ST_DF=18,ST_DFW=19,ST_DONE=20;
    reg [4:0] state; reg [3:0] bi;
    reg [63:0] s0,s1,s2,s3,s4;
    reg [191:0] ct_r; reg [127:0] tag_enc; reg [191:0] pt_dec;
    reg ps; wire pd; reg [3:0] psr,pnr;
    wire [63:0] po0,po1,po2,po3,po4;
    ascon_perm_dualbit pi(.clk(clk),.rst_n(rst_n),.start(ps),.start_round(psr),.rounds(pnr),
        .s0_in(s0),.s1_in(s1),.s2_in(s2),.s3_in(s3),.s4_in(s4),
        .s0_out(po0),.s1_out(po1),.s2_out(po2),.s3_out(po3),.s4_out(po4),.done(pd));
    always @(posedge clk or negedge rst_n) begin
        if(!rst_n) begin state<=0;done<=0;tag_match<=0;ps<=0;psr<=0;pnr<=0;bi<=0;
            s0<=0;s1<=0;s2<=0;s3<=0;s4<=0;ct_r<=0;tag_enc<=0;pt_dec<=0;
        end else begin ps<=0;
            case(state)
                ST_IDLE:begin done<=0;tag_match<=0;if(start) state<=ST_EI;end
                ST_EI:begin s0<=IV;s1<=KEY[127:64];s2<=KEY[63:0];s3<=NONCE[127:64];s4<=NONCE[63:0];
                    psr<=0;pnr<=12;ps<=1;state<=ST_EIP;end
                ST_EIP:if(pd)begin s0<=po0;s1<=po1;s2<=po2;s3<=po3^KEY[127:64];s4<=po4^KEY[63:0];state<=ST_EA;end
                ST_EA:begin s0<=s0^AAD_PADDED;psr<=6;pnr<=6;ps<=1;state<=ST_EAP;end
                ST_EAP:if(pd)begin s0<=po0;s1<=po1;s2<=po2;s3<=po3;s4<=po4;state<=ST_EAD;end
                ST_EAD:begin s4<=s4^64'h1;bi<=0;state<=ST_EP;end
                ST_EP:begin
                    if(bi<PT_BLOCKS)begin ct_r[191-bi*64-:64]<=s0^PT_PADDED[191-bi*64-:64];
                        s0<=s0^PT_PADDED[191-bi*64-:64];
                        if(bi<PT_BLOCKS-1)begin psr<=6;pnr<=6;ps<=1;bi<=bi+1;state<=ST_EPP;end else state<=ST_EF;
                    end else state<=ST_EF;end
                ST_EPP:if(pd)begin s0<=po0;s1<=po1;s2<=po2;s3<=po3;s4<=po4;state<=ST_EP;end
                ST_EF:begin s1<=s1^KEY[127:64];s2<=s2^KEY[63:0];psr<=0;pnr<=12;ps<=1;state<=ST_EFW;end
                ST_EFW:if(pd)begin tag_enc<={po3^KEY[127:64],po4^KEY[63:0]};state<=ST_TS;end
                ST_TS:state<=ST_DI;
                ST_DI:begin s0<=IV;s1<=KEY[127:64];s2<=KEY[63:0];s3<=NONCE[127:64];s4<=NONCE[63:0];
                    psr<=0;pnr<=12;ps<=1;state<=ST_DIP;end
                ST_DIP:if(pd)begin s0<=po0;s1<=po1;s2<=po2;s3<=po3^KEY[127:64];s4<=po4^KEY[63:0];state<=ST_DA;end
                ST_DA:begin s0<=s0^AAD_PADDED;psr<=6;pnr<=6;ps<=1;state<=ST_DAP;end
                ST_DAP:if(pd)begin s0<=po0;s1<=po1;s2<=po2;s3<=po3;s4<=po4;state<=ST_DAD;end
                ST_DAD:begin s4<=s4^64'h1;bi<=0;state<=ST_DC;end
                ST_DC:begin
                    if(bi<PT_BLOCKS)begin pt_dec[191-bi*64-:64]<=s0^ct_r[191-bi*64-:64];
                        s0<=ct_r[191-bi*64-:64];
                        if(bi<PT_BLOCKS-1)begin psr<=6;pnr<=6;ps<=1;bi<=bi+1;state<=ST_DCP;end else state<=ST_DF;
                    end else state<=ST_DF;end
                ST_DCP:if(pd)begin s0<=po0;s1<=po1;s2<=po2;s3<=po3;s4<=po4;state<=ST_DC;end
                ST_DF:begin s1<=s1^KEY[127:64];s2<=s2^KEY[63:0];psr<=0;pnr<=12;ps<=1;state<=ST_DFW;end
                ST_DFW:if(pd)begin tag_match<=(tag_enc=={po3^KEY[127:64],po4^KEY[63:0]});done<=1;state<=ST_DONE;end
                ST_DONE:; default:state<=ST_IDLE;
            endcase end end
endmodule
//=============================================================================
// ascon_perm_dualbit
// 2-bit dual-serial Chi — Chi processes 2 bits at a time over 32 cycles.
// Positioned between nibbled(4-bit/16 cyc) and serialized(1-bit/64 cyc).
// A 5-input, 2-bit-wide S-box processes 2 ASCON S-box instances per cycle.
// Phases: CONST(1) + THETA(1) + CHI×32(32) + LIN(1) = 35 phases/round
// Clocks pa=12:421  pb=6:211  Fmax:150 MHz/7 ns
//=============================================================================
module ascon_perm_dualbit (
    input  wire        clk,rst_n,start,
    input  wire [3:0]  start_round,rounds,
    input  wire [63:0] s0_in,s1_in,s2_in,s3_in,s4_in,
    output reg  [63:0] s0_out,s1_out,s2_out,s3_out,s4_out,
    output reg         done
);
    localparam [1:0] IDLE=2'd0,RUN=2'd1,FINISH=2'd2;
    localparam [5:0] PH_CONST=6'd0, PH_THETA=6'd1, PH_LIN=6'd34;

    reg [1:0] state;
    reg [5:0] db_phase;    // 0=CONST,1=THETA,2..33=CHI bit-pair 0..31,34=LIN
    reg [3:0] round_cnt,round_end;
    reg [63:0] x0,x1,x2,x3,x4;

    reg [7:0] rc;
    always @(*) case(round_cnt)
        4'd0:rc=8'hf0;4'd1:rc=8'he1;4'd2:rc=8'hd2;4'd3:rc=8'hc3;
        4'd4:rc=8'hb4;4'd5:rc=8'ha5;4'd6:rc=8'h96;4'd7:rc=8'h87;
        4'd8:rc=8'h78;4'd9:rc=8'h69;4'd10:rc=8'h5a;4'd11:rc=8'h4b;
        default:rc=8'h00;
    endcase

    // Theta cone
    wire [63:0] tp0=x0^x1^x2^x3^x4,tp1=x1^x2^x3^x4^x0,tp2=x2^x3^x4^x0^x1,tp3=x3^x4^x0^x1^x2,tp4=x4^x0^x1^x2^x3;
    wire [63:0] tm0=tp4^{tp1[0],tp1[63:1]},tm1=tp0^{tp2[0],tp2[63:1]},tm2=tp1^{tp3[0],tp3[63:1]};
    wire [63:0] tm3=tp2^{tp4[0],tp4[63:1]},tm4=tp3^{tp0[0],tp0[63:1]};
    wire [63:0] tt0=x0^tm0,tt1=x1^tm1,tt2=x2^tm2,tt3=x3^tm3,tt4=x4^tm4;

    // 2-bit S-box: bit-pair index = db_phase - 2 (0..31), covers bits [2k+1:2k]
    wire [4:0] pair_idx = db_phase - 6'd2;
    wire [5:0] pbase    = {pair_idx, 1'b0};  // bit offset = pair_idx * 2
    wire [1:0] db0 = x0[pbase+:2];
    wire [1:0] db1 = x1[pbase+:2];
    wire [1:0] db2 = x2[pbase+:2];
    wire [1:0] db3 = x3[pbase+:2];
    wire [1:0] db4 = x4[pbase+:2];
    wire [1:0] dy0 = db0^(~db1&db2);
    wire [1:0] dy1 = db1^(~db2&db3);
    wire [1:0] dy2 = ~(db2^(~db3&db4));
    wire [1:0] dy3 = db3^(~db4&db0);
    wire [1:0] dy4 = db4^(~db0&db1);
    wire [63:0] pmask = 64'h3 << pbase;
    wire [63:0] nx0 = (x0&~pmask)|({62'd0,dy0}<<pbase);
    wire [63:0] nx1 = (x1&~pmask)|({62'd0,dy1}<<pbase);
    wire [63:0] nx2 = (x2&~pmask)|({62'd0,dy2}<<pbase);
    wire [63:0] nx3 = (x3&~pmask)|({62'd0,dy3}<<pbase);
    wire [63:0] nx4 = (x4&~pmask)|({62'd0,dy4}<<pbase);

    // Linear
    wire [63:0] ln0=x0^{x0[18:0],x0[63:19]}^{x0[27:0],x0[63:28]};
    wire [63:0] ln1=x1^{x1[60:0],x1[63:61]}^{x1[38:0],x1[63:39]};
    wire [63:0] ln2=x2^{x2[0],x2[63:1]}^{x2[5:0],x2[63:6]};
    wire [63:0] ln3=x3^{x3[9:0],x3[63:10]}^{x3[16:0],x3[63:17]};
    wire [63:0] ln4=x4^{x4[6:0],x4[63:7]}^{x4[40:0],x4[63:41]};

    always @(posedge clk or negedge rst_n) begin
        if(!rst_n) begin state<=IDLE;done<=0;db_phase<=0;round_cnt<=0;round_end<=0;
            x0<=0;x1<=0;x2<=0;x3<=0;x4<=0;s0_out<=0;s1_out<=0;s2_out<=0;s3_out<=0;s4_out<=0;
        end else case(state)
            IDLE: begin done<=0; if(start) begin x0<=s0_in;x1<=s1_in;x2<=s2_in;x3<=s3_in;x4<=s4_in;
                    round_cnt<=start_round;round_end<=start_round+rounds;db_phase<=PH_CONST;state<=RUN; end end
            RUN: begin
                case(db_phase)
                    PH_CONST: begin x2<=x2^{56'd0,rc};             db_phase<=PH_THETA; end
                    PH_THETA: begin x0<=tt0;x1<=tt1;x2<=tt2;x3<=tt3;x4<=tt4; db_phase<=6'd2; end
                    PH_LIN:   begin x0<=ln0;x1<=ln1;x2<=ln2;x3<=ln3;x4<=ln4; db_phase<=PH_CONST;
                        if(round_cnt<round_end-1) round_cnt<=round_cnt+1; else state<=FINISH; end
                    default:  begin x0<=nx0;x1<=nx1;x2<=nx2;x3<=nx3;x4<=nx4;
                        db_phase<=(db_phase==6'd33)?PH_LIN:db_phase+6'd1; end
                endcase end
            FINISH: begin s0_out<=x0;s1_out<=x1;s2_out<=x2;s3_out<=x3;s4_out<=x4;done<=1;state<=IDLE; end
            default: state<=IDLE;
        endcase end
endmodule
