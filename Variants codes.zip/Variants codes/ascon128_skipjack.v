`timescale 1ns / 1ps
module ascon128_top (
    input  wire clk_p,clk_n,rst_n,start,
    output wire done,tag_match,led_done,led_tag_match,led_running,led_error
);
    wire clk_ibuf,clk; reg rr;
    IBUFDS #(.DIFF_TERM("FALSE"),.IBUF_LOW_PWR("FALSE"),.IOSTANDARD("LVDS"))
        u(.I(clk_p),.IB(clk_n),.O(clk_ibuf));
    BUFG b(.I(clk_ibuf),.O(clk));
    wire cd,ct;
    ascon128_complete_skipjack ac(.clk(clk),.rst_n(rst_n),.start(start),.done(cd),.tag_match(ct));
    assign done=cd; assign tag_match=ct;
    always @(posedge clk or negedge rst_n) if(!rst_n) rr<=0; else if(start) rr<=1; else if(cd) rr<=0;
    assign led_done=cd; assign led_tag_match=cd&ct; assign led_running=rr; assign led_error=cd&~ct;
endmodule

module ascon128_complete_skipjack(input wire clk,rst_n,start,output reg done,tag_match);
    localparam [127:0] KEY=128'h0F1E2D3C4B5A69788796A5B4C3D2E1F0,NONCE=128'hFFEEDDCCBBAA99887766554433221100;
    localparam [191:0] PT_PADDED=192'h46696E616C20596561722050726F6A656374204152418000;
    localparam PT_BLOCKS=3; localparam [63:0] AAD_PADDED=64'h64656D6F41414480,IV=64'h80400c0600000000;
    localparam [4:0] ST_IDLE=0,ST_EI=1,ST_EIP=2,ST_EA=3,ST_EAP=4,ST_EAD=5,
        ST_EP=6,ST_EPP=7,ST_EF=8,ST_EFW=9,ST_TS=10,ST_DI=11,ST_DIP=12,
        ST_DA=13,ST_DAP=14,ST_DAD=15,ST_DC=16,ST_DCP=17,ST_DF=18,ST_DFW=19,ST_DONE=20;
    reg [4:0] state; reg [3:0] bi;
    reg [63:0] s0,s1,s2,s3,s4;
    reg [191:0] ct_r; reg [127:0] tag_enc; reg [191:0] pt_dec;
    reg ps; wire pd; reg [3:0] psr,pnr;
    wire [63:0] po0,po1,po2,po3,po4;
    ascon_perm_skipjack pi(.clk(clk),.rst_n(rst_n),.start(ps),.start_round(psr),.rounds(pnr),
        .s0_in(s0),.s1_in(s1),.s2_in(s2),.s3_in(s3),.s4_in(s4),
        .s0_out(po0),.s1_out(po1),.s2_out(po2),.s3_out(po3),.s4_out(po4),.done(pd));
    always @(posedge clk or negedge rst_n) begin
        if(!rst_n) begin state<=0;done<=0;tag_match<=0;ps<=0;psr<=0;pnr<=0;bi<=0;
            s0<=0;s1<=0;s2<=0;s3<=0;s4<=0;ct_r<=0;tag_enc<=0;pt_dec<=0;
        end else begin ps<=0;
            case(state)
                ST_IDLE:begin done<=0;tag_match<=0;if(start) state<=ST_EI;end
                ST_EI:begin s0<=IV;s1<=KEY[127:64];s2<=KEY[63:0];s3<=NONCE[127:64];s4<=NONCE[63:0];
                    psr<=0;pnr<=12;ps<=1;state<=ST_EIP;end
                ST_EIP:if(pd)begin s0<=po0;s1<=po1;s2<=po2;s3<=po3^KEY[127:64];s4<=po4^KEY[63:0];state<=ST_EA;end
                ST_EA:begin s0<=s0^AAD_PADDED;psr<=6;pnr<=6;ps<=1;state<=ST_EAP;end
                ST_EAP:if(pd)begin s0<=po0;s1<=po1;s2<=po2;s3<=po3;s4<=po4;state<=ST_EAD;end
                ST_EAD:begin s4<=s4^64'h1;bi<=0;state<=ST_EP;end
                ST_EP:begin
                    if(bi<PT_BLOCKS)begin ct_r[191-bi*64-:64]<=s0^PT_PADDED[191-bi*64-:64];
                        s0<=s0^PT_PADDED[191-bi*64-:64];
                        if(bi<PT_BLOCKS-1)begin psr<=6;pnr<=6;ps<=1;bi<=bi+1;state<=ST_EPP;end else state<=ST_EF;
                    end else state<=ST_EF;end
                ST_EPP:if(pd)begin s0<=po0;s1<=po1;s2<=po2;s3<=po3;s4<=po4;state<=ST_EP;end
                ST_EF:begin s1<=s1^KEY[127:64];s2<=s2^KEY[63:0];psr<=0;pnr<=12;ps<=1;state<=ST_EFW;end
                ST_EFW:if(pd)begin tag_enc<={po3^KEY[127:64],po4^KEY[63:0]};state<=ST_TS;end
                ST_TS:state<=ST_DI;
                ST_DI:begin s0<=IV;s1<=KEY[127:64];s2<=KEY[63:0];s3<=NONCE[127:64];s4<=NONCE[63:0];
                    psr<=0;pnr<=12;ps<=1;state<=ST_DIP;end
                ST_DIP:if(pd)begin s0<=po0;s1<=po1;s2<=po2;s3<=po3^KEY[127:64];s4<=po4^KEY[63:0];state<=ST_DA;end
                ST_DA:begin s0<=s0^AAD_PADDED;psr<=6;pnr<=6;ps<=1;state<=ST_DAP;end
                ST_DAP:if(pd)begin s0<=po0;s1<=po1;s2<=po2;s3<=po3;s4<=po4;state<=ST_DAD;end
                ST_DAD:begin s4<=s4^64'h1;bi<=0;state<=ST_DC;end
                ST_DC:begin
                    if(bi<PT_BLOCKS)begin pt_dec[191-bi*64-:64]<=s0^ct_r[191-bi*64-:64];
                        s0<=ct_r[191-bi*64-:64];
                        if(bi<PT_BLOCKS-1)begin psr<=6;pnr<=6;ps<=1;bi<=bi+1;state<=ST_DCP;end else state<=ST_DF;
                    end else state<=ST_DF;end
                ST_DCP:if(pd)begin s0<=po0;s1<=po1;s2<=po2;s3<=po3;s4<=po4;state<=ST_DC;end
                ST_DF:begin s1<=s1^KEY[127:64];s2<=s2^KEY[63:0];psr<=0;pnr<=12;ps<=1;state<=ST_DFW;end
                ST_DFW:if(pd)begin tag_match<=(tag_enc=={po3^KEY[127:64],po4^KEY[63:0]});done<=1;state<=ST_DONE;end
                ST_DONE:; default:state<=ST_IDLE;
            endcase end end
endmodule
//=============================================================================
// ascon_perm_skipjack
//
// Alternating fast/slow rounds — even-indexed rounds (0,2,4,...) use the
// 1-cycle baseline engine; odd-indexed rounds (1,3,5,...) use a 4-cycle
// engine (Const | Theta | Chi | Lin separately registered). This creates
// a strictly alternating rhythm: fast, slow, fast, slow...
//
// The two engines share x0..x4 registers. A single bit alt_mode selects
// which engine is active. alt_mode flips at the end of each round.
//
// Total cycles:
//   pa=12: 6 fast rounds (×1) + 6 slow rounds (×4) = 6+24 = 30+1 = 31
//   pb=6:  3 fast rounds (×1) + 3 slow rounds (×4) = 3+12 = 15+1 = 16
//
// Fmax: 25 MHz / 40 ns (fast/odd round = full baseline cone)
//=============================================================================
module ascon_perm_skipjack (
    input  wire        clk,rst_n,start,
    input  wire [3:0]  start_round,rounds,
    input  wire [63:0] s0_in,s1_in,s2_in,s3_in,s4_in,
    output reg  [63:0] s0_out,s1_out,s2_out,s3_out,s4_out,
    output reg         done
);
    localparam [1:0] IDLE=2'd0,RUN=2'd1,FINISH=2'd2;
    localparam [1:0] SL_CONST=2'd0,SL_THETA=2'd1,SL_CHI=2'd2,SL_LIN=2'd3;

    reg [1:0] state,sl_sub;
    reg [3:0] round_cnt,round_end;
    reg       alt_mode;   // 0=fast(baseline), 1=slow(4-stage)
    reg [63:0] x0,x1,x2,x3,x4;
    (* keep="true" *) reg [63:0] th0,th1,th2,th3,th4;
    (* keep="true" *) reg [63:0] ch0,ch1,ch2,ch3,ch4;

    reg [7:0] rc;
    always @(*) case(round_cnt)
        4'd0:rc=8'hf0;4'd1:rc=8'he1;4'd2:rc=8'hd2;4'd3:rc=8'hc3;
        4'd4:rc=8'hb4;4'd5:rc=8'ha5;4'd6:rc=8'h96;4'd7:rc=8'h87;
        4'd8:rc=8'h78;4'd9:rc=8'h69;4'd10:rc=8'h5a;4'd11:rc=8'h4b;
        default:rc=8'h00;
    endcase

    // Fast (baseline) round cone
    wire [63:0] fc2=x2^{56'd0,rc};
    wire [63:0] fp0=x0^x1^fc2^x3^x4,fp1=x1^fc2^x3^x4^x0,fp2=fc2^x3^x4^x0^x1,fp3=x3^x4^x0^x1^fc2,fp4=x4^x0^x1^fc2^x3;
    wire [63:0] fm0=fp4^{fp1[0],fp1[63:1]},fm1=fp0^{fp2[0],fp2[63:1]},fm2=fp1^{fp3[0],fp3[63:1]};
    wire [63:0] fm3=fp2^{fp4[0],fp4[63:1]},fm4=fp3^{fp0[0],fp0[63:1]};
    wire [63:0] ft0=x0^fm0,ft1=x1^fm1,ft2=fc2^fm2,ft3=x3^fm3,ft4=x4^fm4;
    wire [63:0] fu0=~ft1&ft2,fu1=~ft2&ft3,fu2=~ft3&ft4,fu3=~ft4&ft0,fu4=~ft0&ft1;
    wire [63:0] fv0=ft0^fu0,fv1=ft1^fu1,fv2=~(ft2^fu2),fv3=ft3^fu3,fv4=ft4^fu4;
    wire [63:0] fn0=fv0^{fv0[18:0],fv0[63:19]}^{fv0[27:0],fv0[63:28]};
    wire [63:0] fn1=fv1^{fv1[60:0],fv1[63:61]}^{fv1[38:0],fv1[63:39]};
    wire [63:0] fn2=fv2^{fv2[0],fv2[63:1]}^{fv2[5:0],fv2[63:6]};
    wire [63:0] fn3=fv3^{fv3[9:0],fv3[63:10]}^{fv3[16:0],fv3[63:17]};
    wire [63:0] fn4=fv4^{fv4[6:0],fv4[63:7]}^{fv4[40:0],fv4[63:41]};
    // Slow theta cone
    wire [63:0] sp0=x0^x1^x2^x3^x4,sp1=x1^x2^x3^x4^x0,sp2=x2^x3^x4^x0^x1,sp3=x3^x4^x0^x1^x2,sp4=x4^x0^x1^x2^x3;
    wire [63:0] sm0=sp4^{sp1[0],sp1[63:1]},sm1=sp0^{sp2[0],sp2[63:1]},sm2=sp1^{sp3[0],sp3[63:1]};
    wire [63:0] sm3=sp2^{sp4[0],sp4[63:1]},sm4=sp3^{sp0[0],sp0[63:1]};
    wire [63:0] st0=x0^sm0,st1=x1^sm1,st2=x2^sm2,st3=x3^sm3,st4=x4^sm4;
    // Slow chi cone (from th*)
    wire [63:0] sc0=th0^(~th1&th2),sc1=th1^(~th2&th3),sc2=~(th2^(~th3&th4)),sc3=th3^(~th4&th0),sc4=th4^(~th0&th1);
    // Slow lin cone (from ch*)
    wire [63:0] sl0=ch0^{ch0[18:0],ch0[63:19]}^{ch0[27:0],ch0[63:28]};
    wire [63:0] sl1=ch1^{ch1[60:0],ch1[63:61]}^{ch1[38:0],ch1[63:39]};
    wire [63:0] sl2=ch2^{ch2[0],ch2[63:1]}^{ch2[5:0],ch2[63:6]};
    wire [63:0] sl3=ch3^{ch3[9:0],ch3[63:10]}^{ch3[16:0],ch3[63:17]};
    wire [63:0] sl4=ch4^{ch4[6:0],ch4[63:7]}^{ch4[40:0],ch4[63:41]};

    task finish_round; begin
        alt_mode<=~alt_mode; sl_sub<=SL_CONST;
        if(round_cnt<round_end-1) round_cnt<=round_cnt+1; else state<=FINISH;
    end endtask

    always @(posedge clk or negedge rst_n) begin
        if(!rst_n) begin state<=IDLE;done<=0;alt_mode<=0;sl_sub<=0;round_cnt<=0;round_end<=0;
            x0<=0;x1<=0;x2<=0;x3<=0;x4<=0;th0<=0;th1<=0;th2<=0;th3<=0;th4<=0;ch0<=0;ch1<=0;ch2<=0;ch3<=0;ch4<=0;
            s0_out<=0;s1_out<=0;s2_out<=0;s3_out<=0;s4_out<=0;
        end else case(state)
            IDLE:begin done<=0;
                if(start)begin x0<=s0_in;x1<=s1_in;x2<=s2_in;x3<=s3_in;x4<=s4_in;
                    round_cnt<=start_round;round_end<=start_round+rounds;
                    alt_mode<= start_round[0]; sl_sub<=SL_CONST;state<=RUN;end end
            RUN:begin
                if(!alt_mode) begin // FAST: baseline in 1 cycle
                    x0<=fn0;x1<=fn1;x2<=fn2;x3<=fn3;x4<=fn4;
                    finish_round;
                end else begin // SLOW: 4-stage
                    case(sl_sub)
                        SL_CONST:begin x2<=x2^{56'd0,rc};sl_sub<=SL_THETA;end
                        SL_THETA:begin th0<=st0;th1<=st1;th2<=st2;th3<=st3;th4<=st4;sl_sub<=SL_CHI;end
                        SL_CHI:  begin ch0<=sc0;ch1<=sc1;ch2<=sc2;ch3<=sc3;ch4<=sc4;sl_sub<=SL_LIN;end
                        SL_LIN:  begin x0<=sl0;x1<=sl1;x2<=sl2;x3<=sl3;x4<=sl4;finish_round;end
                        default:sl_sub<=SL_CONST;
                    endcase end end
            FINISH:begin s0_out<=x0;s1_out<=x1;s2_out<=x2;s3_out<=x3;s4_out<=x4;done<=1;state<=IDLE;end
            default:state<=IDLE;
        endcase end
endmodule
