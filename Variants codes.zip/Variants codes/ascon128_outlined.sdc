#==============================================================================
# ASCON-128  ·  Variant: s-box-outlined
# SDC for Cadence Genus Synthesis
#
# Permutation architecture: fully unrolled — 12 ascon_round_stage instances
#   chained in sequence.  Each stage is a registered pipeline with a full
#   combinational round (Const + Theta + Chi + Linear) in one cycle.
#
# Key characteristics:
#   - Fixed, known latency: 12 cycles always (pa=12 and pb=6 both take 12
#     cycles; for pb=6 the first 6 stages are structural bypasses).
#   - No round-counter FSM → simple timing analysis, no multicycle paths.
#   - Critical path identical per stage (same gate depth in every round stage).
#   - Compile-time round constants → no MUX on critical path.
#
# Timing target: 40 MHz / 25 ns (matches baseline)
#   One full ASCON round (Const+Theta+Chi+Linear) per cycle.
#   This is the same per-round combinational depth as the s-box-minimal
#   variant but with registered boundaries between every round.
#
# DFT note: the unrolled structure forms a natural scan chain — each
#   ascon_round_stage maps to a clearly outlined floorplan region.
#   Uncomment set_scan_* directives if scan insertion is required.
#==============================================================================

#------------------------------------------------------------------------------
# 1. CLOCK DEFINITION
#    25 MHz / 40 ns — same reference as baseline
#    (Full-round combo path is the budget: ~15-18 gate levels of XOR+AND)
#    If synthesis reveals shorter critical path, tighten to 20 ns / 50 MHz.
#------------------------------------------------------------------------------
create_clock -period 40.000 \
             -name sys_clk \
             -waveform {0.000 20.000} \
             [get_ports clk_p]

#------------------------------------------------------------------------------
# 2. CLOCK UNCERTAINTY
#------------------------------------------------------------------------------
set_clock_uncertainty -setup 0.500 [get_clocks sys_clk]
set_clock_uncertainty -hold  0.200 [get_clocks sys_clk]

#------------------------------------------------------------------------------
# 3. CLOCK TRANSITION
#------------------------------------------------------------------------------
set_clock_transition -rise 0.100 [get_clocks sys_clk]
set_clock_transition -fall 0.100 [get_clocks sys_clk]

#------------------------------------------------------------------------------
# 4. INPUT DELAYS
#------------------------------------------------------------------------------
set_input_delay -clock sys_clk -max 2.000 [get_ports rst_n]
set_input_delay -clock sys_clk -min 0.500 [get_ports rst_n]
set_input_delay -clock sys_clk -max 2.000 [get_ports start]
set_input_delay -clock sys_clk -min 0.500 [get_ports start]

#------------------------------------------------------------------------------
# 5. OUTPUT DELAYS
#------------------------------------------------------------------------------
set_output_delay -clock sys_clk -max 2.000 [get_ports done]
set_output_delay -clock sys_clk -min 0.500 [get_ports done]
set_output_delay -clock sys_clk -max 2.000 [get_ports tag_match]
set_output_delay -clock sys_clk -min 0.500 [get_ports tag_match]
set_output_delay -clock sys_clk -max 2.000 [get_ports led_done]
set_output_delay -clock sys_clk -min 0.500 [get_ports led_done]
set_output_delay -clock sys_clk -max 2.000 [get_ports led_tag_match]
set_output_delay -clock sys_clk -min 0.500 [get_ports led_tag_match]
set_output_delay -clock sys_clk -max 2.000 [get_ports led_running]
set_output_delay -clock sys_clk -min 0.500 [get_ports led_running]
set_output_delay -clock sys_clk -max 2.000 [get_ports led_error]
set_output_delay -clock sys_clk -min 0.500 [get_ports led_error]

#------------------------------------------------------------------------------
# 6. ASYNCHRONOUS RESET - FALSE PATH
#------------------------------------------------------------------------------
set_false_path -from [get_ports rst_n]

#------------------------------------------------------------------------------
# 7. INTER-STAGE PATHS
#    All 12 register boundaries (round_stage[0].out → round_stage[1].in,
#    ..., round_stage[11].out → output latch) are single-cycle paths.
#    No multicycle path exceptions are required.
#
#    To help Genus identify the outlined structure for reporting:
#    (Uncomment if using hierarchical synthesis with keep_hierarchy)
#------------------------------------------------------------------------------
# set_attribute keep_hierarchy true [get_db modules ascon_round_stage]

#------------------------------------------------------------------------------
# 8. CONSTANT-PROPAGATION HINT
#    The ROUND_CONST parameter is compile-time fixed per instance.
#    Genus can constant-propagate through the XOR tree for each stage,
#    reducing gate count.  Ensure elaboration preserves parameters:
#------------------------------------------------------------------------------
# set_attribute ungroup false [get_db instances ROUND_CHAIN*]

#------------------------------------------------------------------------------
# 9. VALID SHIFT-REGISTER FALSE PATHS
#    The vld[] shift register is purely control logic.
#    It has a simple fan-out of 1 and no hold violation risk.
#    Annotate as non-critical:
#------------------------------------------------------------------------------
# set_false_path -through [get_nets {ROUND_CHAIN[*].stage_i.vld_out}]

#------------------------------------------------------------------------------
# 10. DRIVING CELL / OUTPUT LOAD
#------------------------------------------------------------------------------
set_driving_cell -no_design_rule [get_ports {start rst_n}]
set_load 5.0 [get_ports {done tag_match led_done led_tag_match led_running led_error}]

#------------------------------------------------------------------------------
# 11. DFT SCAN INSERTION HOOKS
#    Uncomment for scan-based test flow. Each round_stage is a natural
#    scan segment boundary.
#------------------------------------------------------------------------------
# set_scan_configuration -chain_count 4
# set_scan_configuration -add_lockup_latch false

#==============================================================================
# END - ascon128_outlined.sdc
#==============================================================================
