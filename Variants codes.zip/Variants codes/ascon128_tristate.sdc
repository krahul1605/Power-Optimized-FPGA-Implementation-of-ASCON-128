#==============================================================================
# ASCON-128  ·  Variant: tristate
# SDC for Cadence Genus Synthesis
#
# Permutation architecture: Tri-phase rotating bus — three dedicated
#   combinational cones (Theta, Chi, Linear) are permanently live and
#   driven from shared state registers x0..x4. A register-controlled
#   2-bit phase counter (phase_r) gates a 3-way output mux that selects
#   which cone's result writes back to x0..x4 each cycle.
#
#   Phase-0 (PHASE_THETA): Const + full Theta — critical path bottleneck
#     Path: x*_reg -> XOR (const) -> XOR tree (parities, 3 levels) ->
#           rotate XOR (mix) -> XOR (apply) -> 3-way mux -> x*_reg
#     Estimated: ~10-12 gate levels
#
#   Phase-1 (PHASE_CHI): full Chi substitution (AND-NOT + XOR + INV)
#     Path: x*_reg -> AND-NOT -> XOR -> INV -> 3-way mux -> x*_reg
#     Estimated: ~5-6 gate levels
#
#   Phase-2 (PHASE_LIN): full Linear diffusion (two rotations + XOR)
#     Path: x*_reg -> rotate -> XOR -> XOR -> 3-way mux -> x*_reg
#     Estimated: ~4-5 gate levels
#
# Timing: All three phases share the same clock period. Period is
#   constrained by the slowest phase (PHASE_THETA). Target: 100 MHz / 10 ns.
#   Significant slack will exist on PHASE_CHI and PHASE_LIN cycles.
#
# Clocks per pa=12 call : 12 rounds × 3 phases = 36 + 1 FINISH = 37
# Clocks per pb=6  call :  6 rounds × 3 phases = 18 + 1 FINISH = 19
#
# Synthesis notes:
#   The three cones are always-live; synthesis may attempt to share logic
#   between them. Use keep_hierarchy or dont_merge attributes on the cone
#   boundary wires (th*, ch*, ln*) if physical separation is desired.
#   The 3-way mux on a 320-bit bus adds 1 LUT level; Genus will absorb
#   this into the cone output FF setup path.
#==============================================================================

#------------------------------------------------------------------------------
# 1. CLOCK DEFINITION
#    100 MHz / 10 ns — tri-phase rotating bus (Theta-bottlenecked)
#------------------------------------------------------------------------------
create_clock -period 10.000 \
             -name sys_clk \
             -waveform {0.000 5.000} \
             [get_ports clk_p]

#------------------------------------------------------------------------------
# 2. CLOCK UNCERTAINTY
#    Moderate jitter for 100 MHz board clock on ZCU104 LVDS input.
#------------------------------------------------------------------------------
set_clock_uncertainty -setup 0.200 [get_clocks sys_clk]
set_clock_uncertainty -hold  0.100 [get_clocks sys_clk]

#------------------------------------------------------------------------------
# 3. CLOCK TRANSITION
#    Sharp LVDS-driven clock edge.
#------------------------------------------------------------------------------
set_clock_transition -rise 0.100 [get_clocks sys_clk]
set_clock_transition -fall 0.100 [get_clocks sys_clk]

#------------------------------------------------------------------------------
# 4. INPUT DELAYS
#    2.0 ns max, 0.5 ns min — board interface budget.
#------------------------------------------------------------------------------
set_input_delay -clock sys_clk -max 2.000 [get_ports rst_n]
set_input_delay -clock sys_clk -min 0.500 [get_ports rst_n]
set_input_delay -clock sys_clk -max 2.000 [get_ports start]
set_input_delay -clock sys_clk -min 0.500 [get_ports start]

#------------------------------------------------------------------------------
# 5. OUTPUT DELAYS
#------------------------------------------------------------------------------
set_output_delay -clock sys_clk -max 2.000 [get_ports done]
set_output_delay -clock sys_clk -min 0.500 [get_ports done]
set_output_delay -clock sys_clk -max 2.000 [get_ports tag_match]
set_output_delay -clock sys_clk -min 0.500 [get_ports tag_match]
set_output_delay -clock sys_clk -max 2.000 [get_ports led_done]
set_output_delay -clock sys_clk -min 0.500 [get_ports led_done]
set_output_delay -clock sys_clk -max 2.000 [get_ports led_tag_match]
set_output_delay -clock sys_clk -min 0.500 [get_ports led_tag_match]
set_output_delay -clock sys_clk -max 2.000 [get_ports led_running]
set_output_delay -clock sys_clk -min 0.500 [get_ports led_running]
set_output_delay -clock sys_clk -max 2.000 [get_ports led_error]
set_output_delay -clock sys_clk -min 0.500 [get_ports led_error]

#------------------------------------------------------------------------------
# 6. ASYNCHRONOUS RESET - FALSE PATH
#------------------------------------------------------------------------------
set_false_path -from [get_ports rst_n]

#------------------------------------------------------------------------------
# 7. MULTICYCLE PATH RELAXATION FOR CHI AND LINEAR PHASES
#    The three phases run in sequence under the same clock. When phase_r==1
#    (CHI) or phase_r==2 (LIN), the combinational cone is much shorter than
#    the Theta cone that sizes the clock period.
#
#    Since all phases share one clock, no explicit multicycle constraints are
#    needed for functional correctness. However, the synthesis tool can be
#    informed of the phase-dependent path bounds to improve optimization:
#
#    Theta path budget : 10.000 - 0.200 (unc) - 0.100 (trans) = 9.700 ns
#    Chi path budget   : ~5-6 gate levels → ~3-4 ns (large positive slack)
#    Linear path budget: ~4-5 gate levels → ~2-3 ns (large positive slack)
#
#    Optional: set_multicycle_path relaxation on non-critical phases
#    (uncomment only if tool supports phase-aware multicycle inference)
#------------------------------------------------------------------------------
# set_multicycle_path -setup 1 -from [get_cells {x*_reg*}] -to [get_cells {x*_reg*}]

#------------------------------------------------------------------------------
# 8. CONE ISOLATION — PREVENT CROSS-CONE LOGIC MERGING
#    The three cones (th*, ch*, ln*) should remain structurally distinct
#    for power analysis and placement studies. The keep directives below
#    instruct Genus not to collapse the intermediate cone boundary wires.
#    Uncomment if separate cone characterization is required.
#------------------------------------------------------------------------------
# set_dont_touch [get_nets {th0 th1 th2 th3 th4}]
# set_dont_touch [get_nets {ch0 ch1 ch2 ch3 ch4}]
# set_dont_touch [get_nets {ln0 ln1 ln2 ln3 ln4}]

#------------------------------------------------------------------------------
# 9. DRIVING CELL / OUTPUT LOAD
#------------------------------------------------------------------------------
set_driving_cell -lib_cell INVX1 -no_design_rule [get_ports {start rst_n}]
set_load 5.0 [get_ports {done tag_match led_done led_tag_match led_running led_error}]

#------------------------------------------------------------------------------
# 10. OPERATING CONDITIONS (uncomment and set for target library)
#------------------------------------------------------------------------------
# set_operating_conditions -library <lib> TYPICAL

#==============================================================================
# END - ascon128_tristate.sdc
#==============================================================================
