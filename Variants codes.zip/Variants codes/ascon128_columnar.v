`timescale 1ns / 1ps
//=============================================================================
// ASCON-128  ·  Variant: columnar
//
// Visual treatment : Column-major S-box array — the ASCON state is treated
//                    as a 5-row × 64-column bit matrix. Each 5-bit column
//                    is an independent ASCON S-box instance. This variant
//                    instantiates an 8-column-wide S-box array (8 parallel
//                    5-bit S-boxes) and strides across all 64 columns in
//                    8 groups of 8 columns each (8 cycles for Chi).
//
//                    Column k consists of bits: x0[k], x1[k], x2[k], x3[k], x4[k]
//                    The S-box output for column k:
//                      y0[k] = x0[k] ^ (~x1[k] & x2[k])
//                      y1[k] = x1[k] ^ (~x2[k] & x3[k])
//                      y2[k] = ~(x2[k] ^ (~x3[k] & x4[k]))   [inverted per spec]
//                      y3[k] = x3[k] ^ (~x4[k] & x0[k])
//                      y4[k] = x4[k] ^ (~x0[k] & x1[k])
//
//                    Per-round execution:
//
//     CM_CONST   (1 cycle): Apply round constant to x2.
//
//     CM_THETA   (1 cycle): Full Theta (Const+Theta fused). Standard 64-bit.
//
//     CM_CHI_x   (8 cycles, col_grp = 0..7):
//                    Each cycle processes 8 consecutive columns.
//                    The 8-wide S-box array computes 8 S-boxes in parallel.
//                    Results are written back to the corresponding 8 bit
//                    positions of x0..x4 via a byte-masked write.
//                    col_grp selects which 8-column group: bits [8k+7:8k].
//
//     CM_LIN     (1 cycle): Full Linear diffusion.
//
//                    Total stages per round: 1+1+8+1 = 11 stages.
//
//                    The structural novelty vs. bytelane:
//                      - bytelane: all 8 byte lanes active SIMULTANEOUSLY,
//                        complete in 1 cycle (parallel, no counter)
//                      - columnar: 8 lanes active per cycle, SEQUENCED over
//                        8 cycles via a 3-bit col_grp counter
//                      - The columnar structure uses a single 8-wide S-box
//                        array (one physical instance, reused 8 times via
//                        the col_grp counter) rather than 8 parallel instances
//                      - col_grp addresses the state via bit-indexed reads,
//                        not byte-boundary slicing — allowing non-byte-aligned
//                        column groupings if desired
//
// Clocks per pa=12 call : 12 × 11 = 132 + 1 FINISH = 133
// Clocks per pb=6  call :  6 × 11 =  66 + 1 FINISH =  67
//
// Trade-offs
//   + Minimal Chi logic: single 8-wide S-box array (40 AND-NOT + 40 XOR gates)
//   + Lowest gate count for the S-box computation of any variant
//   + col_grp counter drives a simple 3-bit sequential scan
//   + Linear + Theta remain full 64-bit (same as baseline cones)
//   - Highest cycle count of all variants (133 for pa=12)
//   - col_grp write-back uses 8-bit masked update (OR/AND assembly)
//   - Fmax constrained by Theta (CM_THETA, ~8-10 levels) not the S-box
//
// Functional parity: identical ports and FSM encoding to all variants.
//                    NIST-compliant ASCON-128 algorithm.
//=============================================================================

module ascon128_top (
    input  wire clk_p, clk_n, rst_n, start,
    output wire done, tag_match,
    output wire led_done, led_tag_match, led_running, led_error
);
    wire clk_ibuf, clk;
    IBUFDS #(.DIFF_TERM("FALSE"),.IBUF_LOW_PWR("FALSE"),.IOSTANDARD("LVDS"))
        clk_ibufds(.I(clk_p),.IB(clk_n),.O(clk_ibuf));
    BUFG clk_bufg(.I(clk_ibuf),.O(clk));
    wire core_done, core_tag_match;
    reg  running_r;
    ascon128_complete_columnar ascon_core(.clk(clk),.rst_n(rst_n),.start(start),
        .done(core_done),.tag_match(core_tag_match));
    assign done=core_done; assign tag_match=core_tag_match;
    always @(posedge clk or negedge rst_n)
        if(!rst_n) running_r<=0;
        else if(start) running_r<=1;
        else if(core_done) running_r<=0;
    assign led_done=core_done; assign led_tag_match=core_done&core_tag_match;
    assign led_running=running_r; assign led_error=core_done&~core_tag_match;
endmodule

module ascon128_complete_columnar (
    input  wire clk, rst_n, start,
    output reg  done, tag_match
);
    localparam [127:0] KEY   = 128'h0F1E2D3C4B5A69788796A5B4C3D2E1F0;
    localparam [127:0] NONCE = 128'hFFEEDDCCBBAA99887766554433221100;
    localparam [191:0] PT_PADDED  = 192'h46696E616C20596561722050726F6A656374204152418000;
    localparam         PT_BLOCKS  = 3;
    localparam [63:0]  AAD_PADDED = 64'h64656D6F41414480;
    localparam [63:0]  IV         = 64'h80400c0600000000;
    localparam [4:0]
        ST_IDLE=0,ST_ENC_INIT=1,ST_ENC_INIT_PERM=2,ST_ENC_AAD=3,ST_ENC_AAD_PERM=4,
        ST_ENC_AAD_DOM=5,ST_ENC_PT=6,ST_ENC_PT_PERM=7,ST_ENC_FINAL=8,ST_ENC_FINAL_W=9,
        ST_TAG_STORE=10,ST_DEC_INIT=11,ST_DEC_INIT_PERM=12,ST_DEC_AAD=13,
        ST_DEC_AAD_PERM=14,ST_DEC_AAD_DOM=15,ST_DEC_CT=16,ST_DEC_CT_PERM=17,
        ST_DEC_FINAL=18,ST_DEC_FINAL_W=19,ST_DONE=20;
    reg [4:0] state; reg [3:0] block_idx;
    reg [63:0] s0,s1,s2,s3,s4;
    reg [191:0] ciphertext; reg [127:0] tag_enc; reg [191:0] plaintext_dec;
    reg perm_start; wire perm_done;
    reg [3:0] perm_start_round, perm_num_rounds;
    wire [63:0] perm_out0,perm_out1,perm_out2,perm_out3,perm_out4;
    ascon_perm_columnar perm_inst(
        .clk(clk),.rst_n(rst_n),.start(perm_start),
        .start_round(perm_start_round),.rounds(perm_num_rounds),
        .s0_in(s0),.s1_in(s1),.s2_in(s2),.s3_in(s3),.s4_in(s4),
        .s0_out(perm_out0),.s1_out(perm_out1),.s2_out(perm_out2),
        .s3_out(perm_out3),.s4_out(perm_out4),.done(perm_done));
    always @(posedge clk or negedge rst_n) begin
        if(!rst_n) begin
            state<=0;done<=0;tag_match<=0;perm_start<=0;
            perm_start_round<=0;perm_num_rounds<=0;block_idx<=0;
            s0<=0;s1<=0;s2<=0;s3<=0;s4<=0;ciphertext<=0;tag_enc<=0;plaintext_dec<=0;
        end else begin
            perm_start<=0;
            case(state)
                ST_IDLE: begin done<=0;tag_match<=0;if(start) state<=ST_ENC_INIT; end
                ST_ENC_INIT: begin s0<=IV;s1<=KEY[127:64];s2<=KEY[63:0];s3<=NONCE[127:64];s4<=NONCE[63:0];
                    perm_start_round<=0;perm_num_rounds<=12;perm_start<=1;state<=ST_ENC_INIT_PERM; end
                ST_ENC_INIT_PERM: if(perm_done) begin s0<=perm_out0;s1<=perm_out1;s2<=perm_out2;
                    s3<=perm_out3^KEY[127:64];s4<=perm_out4^KEY[63:0];state<=ST_ENC_AAD; end
                ST_ENC_AAD: begin s0<=s0^AAD_PADDED;perm_start_round<=6;perm_num_rounds<=6;
                    perm_start<=1;state<=ST_ENC_AAD_PERM; end
                ST_ENC_AAD_PERM: if(perm_done) begin s0<=perm_out0;s1<=perm_out1;s2<=perm_out2;
                    s3<=perm_out3;s4<=perm_out4;state<=ST_ENC_AAD_DOM; end
                ST_ENC_AAD_DOM: begin s4<=s4^64'h1;block_idx<=0;state<=ST_ENC_PT; end
                ST_ENC_PT: begin
                    if(block_idx<PT_BLOCKS) begin
                        ciphertext[191-block_idx*64-:64]<=s0^PT_PADDED[191-block_idx*64-:64];
                        s0<=s0^PT_PADDED[191-block_idx*64-:64];
                        if(block_idx<PT_BLOCKS-1) begin perm_start_round<=6;perm_num_rounds<=6;
                            perm_start<=1;block_idx<=block_idx+1;state<=ST_ENC_PT_PERM;
                        end else state<=ST_ENC_FINAL;
                    end else state<=ST_ENC_FINAL; end
                ST_ENC_PT_PERM: if(perm_done) begin s0<=perm_out0;s1<=perm_out1;s2<=perm_out2;
                    s3<=perm_out3;s4<=perm_out4;state<=ST_ENC_PT; end
                ST_ENC_FINAL: begin s1<=s1^KEY[127:64];s2<=s2^KEY[63:0];
                    perm_start_round<=0;perm_num_rounds<=12;perm_start<=1;state<=ST_ENC_FINAL_W; end
                ST_ENC_FINAL_W: if(perm_done) begin tag_enc<={perm_out3^KEY[127:64],perm_out4^KEY[63:0]};
                    state<=ST_TAG_STORE; end
                ST_TAG_STORE: state<=ST_DEC_INIT;
                ST_DEC_INIT: begin s0<=IV;s1<=KEY[127:64];s2<=KEY[63:0];s3<=NONCE[127:64];s4<=NONCE[63:0];
                    perm_start_round<=0;perm_num_rounds<=12;perm_start<=1;state<=ST_DEC_INIT_PERM; end
                ST_DEC_INIT_PERM: if(perm_done) begin s0<=perm_out0;s1<=perm_out1;s2<=perm_out2;
                    s3<=perm_out3^KEY[127:64];s4<=perm_out4^KEY[63:0];state<=ST_DEC_AAD; end
                ST_DEC_AAD: begin s0<=s0^AAD_PADDED;perm_start_round<=6;perm_num_rounds<=6;
                    perm_start<=1;state<=ST_DEC_AAD_PERM; end
                ST_DEC_AAD_PERM: if(perm_done) begin s0<=perm_out0;s1<=perm_out1;s2<=perm_out2;
                    s3<=perm_out3;s4<=perm_out4;state<=ST_DEC_AAD_DOM; end
                ST_DEC_AAD_DOM: begin s4<=s4^64'h1;block_idx<=0;state<=ST_DEC_CT; end
                ST_DEC_CT: begin
                    if(block_idx<PT_BLOCKS) begin
                        plaintext_dec[191-block_idx*64-:64]<=s0^ciphertext[191-block_idx*64-:64];
                        s0<=ciphertext[191-block_idx*64-:64];
                        if(block_idx<PT_BLOCKS-1) begin perm_start_round<=6;perm_num_rounds<=6;
                            perm_start<=1;block_idx<=block_idx+1;state<=ST_DEC_CT_PERM;
                        end else state<=ST_DEC_FINAL;
                    end else state<=ST_DEC_FINAL; end
                ST_DEC_CT_PERM: if(perm_done) begin s0<=perm_out0;s1<=perm_out1;s2<=perm_out2;
                    s3<=perm_out3;s4<=perm_out4;state<=ST_DEC_CT; end
                ST_DEC_FINAL: begin s1<=s1^KEY[127:64];s2<=s2^KEY[63:0];
                    perm_start_round<=0;perm_num_rounds<=12;perm_start<=1;state<=ST_DEC_FINAL_W; end
                ST_DEC_FINAL_W: if(perm_done) begin
                    tag_match<=(tag_enc=={perm_out3^KEY[127:64],perm_out4^KEY[63:0]});
                    done<=1;state<=ST_DONE; end
                ST_DONE: ;
                default: state<=ST_IDLE;
            endcase
        end
    end
endmodule

//=============================================================================
// ascon_perm_columnar
//
// Phase encoding:
//   CM_CONST (4'd0) : x2 ^= rc
//   CM_THETA (4'd1) : full Theta (parity+rotation+apply)
//   CM_CHI   (4'd2..4'd9) : col_grp 0..7, each processes 8 columns
//   CM_LIN   (4'd10): full Linear
//
// Stage counter cm_phase advances 0->1->2->3->...->10->0 (11 phases/round)
// During CM_CHI phases, col_grp = cm_phase - 2 (0..7) selects bit group.
//
// 8-column S-box array: for col_grp g, processes bits [8g+7:8g] of each word.
//   b0k = x0[8g+k], b1k = x1[8g+k], ..., b4k = x4[8g+k]  for k=0..7
//   y0k = b0k ^ (~b1k & b2k)
//   y1k = b1k ^ (~b2k & b3k)
//   y2k = ~(b2k ^ (~b3k & b4k))
//   y3k = b3k ^ (~b4k & b0k)
//   y4k = b4k ^ (~b0k & b1k)
// Written back to x0..x4 at bits [8g+7:8g] using AND-mask clear + OR insert.
//=============================================================================
module ascon_perm_columnar (
    input  wire        clk, rst_n, start,
    input  wire [3:0]  start_round, rounds,
    input  wire [63:0] s0_in,s1_in,s2_in,s3_in,s4_in,
    output reg  [63:0] s0_out,s1_out,s2_out,s3_out,s4_out,
    output reg         done
);
    localparam [1:0] IDLE=2'd0, RUN=2'd1, FINISH=2'd2;
    localparam [3:0] CM_CONST=4'd0, CM_THETA=4'd1, CM_LIN=4'd10;

    reg [1:0]  state;
    reg [3:0]  cm_phase;       // 0..10 (11 phases per round)
    reg [3:0]  round_cnt, round_end;
    reg [63:0] x0,x1,x2,x3,x4;

    reg [7:0] rc;
    always @(*) case(round_cnt)
        4'd0:rc=8'hf0; 4'd1:rc=8'he1; 4'd2:rc=8'hd2; 4'd3:rc=8'hc3;
        4'd4:rc=8'hb4; 4'd5:rc=8'ha5; 4'd6:rc=8'h96; 4'd7:rc=8'h87;
        4'd8:rc=8'h78; 4'd9:rc=8'h69; 4'd10:rc=8'h5a; 4'd11:rc=8'h4b;
        default:rc=8'h00;
    endcase

    // -------------------------------------------------------------------------
    // Theta combinational cone
    // -------------------------------------------------------------------------
    wire [63:0] tp0=x0^x1^x2^x3^x4, tp1=x1^x2^x3^x4^x0;
    wire [63:0] tp2=x2^x3^x4^x0^x1, tp3=x3^x4^x0^x1^x2, tp4=x4^x0^x1^x2^x3;
    wire [63:0] tm0=tp4^{tp1[0],tp1[63:1]}, tm1=tp0^{tp2[0],tp2[63:1]};
    wire [63:0] tm2=tp1^{tp3[0],tp3[63:1]}, tm3=tp2^{tp4[0],tp4[63:1]};
    wire [63:0] tm4=tp3^{tp0[0],tp0[63:1]};
    wire [63:0] tt0=x0^tm0, tt1=x1^tm1, tt2=x2^tm2, tt3=x3^tm3, tt4=x4^tm4;

    // -------------------------------------------------------------------------
    // 8-column S-box array: col_grp selects which byte of each word to process
    // col_grp = cm_phase - 2  (valid when cm_phase in [2..9])
    // -------------------------------------------------------------------------
    wire [2:0] col_grp = cm_phase[2:0] - 3'd2;  // 0..7 when cm_phase=2..9
    wire [7:0] cg_base = {col_grp, 3'b000};      // bit offset = col_grp * 8

    // Extract 8-bit slices for current col_grp
    wire [7:0] sb0 = x0[8*col_grp+7:8*col_grp];
    wire [7:0] sb1 = x1[8*col_grp+7:8*col_grp];
    wire [7:0] sb2 = x2[8*col_grp+7:8*col_grp];
    wire [7:0] sb3 = x3[8*col_grp+7:8*col_grp];
    wire [7:0] sb4 = x4[8*col_grp+7:8*col_grp];

    // 8-parallel S-box outputs
    wire [7:0] sy0 = sb0 ^ (~sb1 & sb2);
    wire [7:0] sy1 = sb1 ^ (~sb2 & sb3);
    wire [7:0] sy2 = ~(sb2 ^ (~sb3 & sb4));
    wire [7:0] sy3 = sb3 ^ (~sb4 & sb0);
    wire [7:0] sy4 = sb4 ^ (~sb0 & sb1);

    // 8-bit byte mask for write-back (clears target byte, ORs in new value)
    wire [63:0] byte_mask = 64'hFF << cg_base;
    wire [63:0] nx0 = (x0 & ~byte_mask) | ({56'd0, sy0} << cg_base);
    wire [63:0] nx1 = (x1 & ~byte_mask) | ({56'd0, sy1} << cg_base);
    wire [63:0] nx2 = (x2 & ~byte_mask) | ({56'd0, sy2} << cg_base);
    wire [63:0] nx3 = (x3 & ~byte_mask) | ({56'd0, sy3} << cg_base);
    wire [63:0] nx4 = (x4 & ~byte_mask) | ({56'd0, sy4} << cg_base);

    // -------------------------------------------------------------------------
    // Linear combinational cone
    // -------------------------------------------------------------------------
    wire [63:0] ln0=x0^{x0[18:0],x0[63:19]}^{x0[27:0],x0[63:28]};
    wire [63:0] ln1=x1^{x1[60:0],x1[63:61]}^{x1[38:0],x1[63:39]};
    wire [63:0] ln2=x2^{x2[0],   x2[63:1]} ^{x2[5:0], x2[63:6]};
    wire [63:0] ln3=x3^{x3[9:0], x3[63:10]}^{x3[16:0],x3[63:17]};
    wire [63:0] ln4=x4^{x4[6:0], x4[63:7]} ^{x4[40:0],x4[63:41]};

    always @(posedge clk or negedge rst_n) begin
        if(!rst_n) begin
            state<=IDLE;done<=0;cm_phase<=0;round_cnt<=0;round_end<=0;
            x0<=0;x1<=0;x2<=0;x3<=0;x4<=0;
            s0_out<=0;s1_out<=0;s2_out<=0;s3_out<=0;s4_out<=0;
        end else case(state)
            IDLE: begin
                done<=0;
                if(start) begin
                    x0<=s0_in;x1<=s1_in;x2<=s2_in;x3<=s3_in;x4<=s4_in;
                    round_cnt<=start_round;round_end<=start_round+rounds;
                    cm_phase<=CM_CONST;state<=RUN;
                end
            end
            RUN: begin
                case(cm_phase)
                    CM_CONST: begin x2<=x2^{56'd0,rc}; cm_phase<=CM_THETA; end
                    CM_THETA: begin x0<=tt0;x1<=tt1;x2<=tt2;x3<=tt3;x4<=tt4; cm_phase<=4'd2; end
                    // CM_CHI phases 2..9: process column groups 0..7
                    4'd2,4'd3,4'd4,4'd5,4'd6,4'd7,4'd8,4'd9: begin
                        x0<=nx0;x1<=nx1;x2<=nx2;x3<=nx3;x4<=nx4;
                        cm_phase <= (cm_phase==4'd9) ? CM_LIN : cm_phase+4'd1;
                    end
                    CM_LIN: begin
                        x0<=ln0;x1<=ln1;x2<=ln2;x3<=ln3;x4<=ln4;
                        cm_phase<=CM_CONST;
                        if(round_cnt<round_end-1) round_cnt<=round_cnt+1;
                        else state<=FINISH;
                    end
                    default: cm_phase<=CM_CONST;
                endcase
            end
            FINISH: begin s0_out<=x0;s1_out<=x1;s2_out<=x2;s3_out<=x3;s4_out<=x4;done<=1;state<=IDLE; end
            default: state<=IDLE;
        endcase
    end
endmodule
