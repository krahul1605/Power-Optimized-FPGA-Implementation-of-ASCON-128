#==============================================================================
# ASCON-128  ·  Variant: baseline
# SDC for Cadence Genus Synthesis
#
# Permutation architecture: Single-cycle, fully combinational per round.
#   All 8 ASCON sub-steps (CONST, THETA_A, THETA_B, THETA_C,
#   CHI1, CHI2, LIN1, LIN2) execute in a single combinational cone between
#   two registers. No intermediate pipeline registers — one round per cycle
#   with the longest possible combinational path.
#
# Timing impact vs elevated:
#   - Critical path per cycle: full permutation round (~35-45 XOR/AND levels).
#   - Clock period target: 40.000 ns (25 MHz) — conservative single-cycle target.
#   - Input/output delays kept at 2.0/0.5 ns for board interface compatibility.
#   - Multicycle paths: NOT needed — design is single-cycle per round by intent.
#
# Clocks per pa=12 call : 12 rounds × 1 cycle = 12 + 1 FINISH = 13
# Clocks per pb=6  call :  6 rounds × 1 cycle =  6 + 1 FINISH =  7
#
# Synthesis guidance for Genus:
#   Synthesis effort should be MEDIUM; the critical path is long but
#   structurally regular (XOR trees + AND-NOT chain). Allow Genus to retime
#   if this file is used as a starting point for pipelined variants.
#==============================================================================

#------------------------------------------------------------------------------
# 1. CLOCK DEFINITION
#    25 MHz / 40 ns — baseline single-cycle combinational permutation
#------------------------------------------------------------------------------
create_clock -period 40.000 \
             -name sys_clk \
             -waveform {0.000 20.000} \
             [get_ports clk_p]

#------------------------------------------------------------------------------
# 2. CLOCK UNCERTAINTY
#    Relaxed jitter budget appropriate for 25 MHz board-speed clock.
#------------------------------------------------------------------------------
set_clock_uncertainty -setup 0.500 [get_clocks sys_clk]
set_clock_uncertainty -hold  0.300 [get_clocks sys_clk]

#------------------------------------------------------------------------------
# 3. CLOCK TRANSITION
#    Relaxed edge rate for low-frequency clock; board-driven.
#------------------------------------------------------------------------------
set_clock_transition -rise 0.200 [get_clocks sys_clk]
set_clock_transition -fall 0.200 [get_clocks sys_clk]

#------------------------------------------------------------------------------
# 4. INPUT DELAYS
#    Conservative budget: 2.0 ns setup leaves 37.5 ns internal at 40 ns period.
#------------------------------------------------------------------------------
set_input_delay -clock sys_clk -max 2.000 [get_ports rst_n]
set_input_delay -clock sys_clk -min 0.500 [get_ports rst_n]
set_input_delay -clock sys_clk -max 2.000 [get_ports start]
set_input_delay -clock sys_clk -min 0.500 [get_ports start]

#------------------------------------------------------------------------------
# 5. OUTPUT DELAYS
#------------------------------------------------------------------------------
set_output_delay -clock sys_clk -max 2.000 [get_ports done]
set_output_delay -clock sys_clk -min 0.500 [get_ports done]
set_output_delay -clock sys_clk -max 2.000 [get_ports tag_match]
set_output_delay -clock sys_clk -min 0.500 [get_ports tag_match]
set_output_delay -clock sys_clk -max 2.000 [get_ports led_done]
set_output_delay -clock sys_clk -min 0.500 [get_ports led_done]
set_output_delay -clock sys_clk -max 2.000 [get_ports led_tag_match]
set_output_delay -clock sys_clk -min 0.500 [get_ports led_tag_match]
set_output_delay -clock sys_clk -max 2.000 [get_ports led_running]
set_output_delay -clock sys_clk -min 0.500 [get_ports led_running]
set_output_delay -clock sys_clk -max 2.000 [get_ports led_error]
set_output_delay -clock sys_clk -min 0.500 [get_ports led_error]

#------------------------------------------------------------------------------
# 6. ASYNCHRONOUS RESET - FALSE PATH
#------------------------------------------------------------------------------
set_false_path -from [get_ports rst_n]

#------------------------------------------------------------------------------
# 7. CRITICAL PATH BUDGET
#    Single combinational cone covers all 8 sub-steps per round.
#    Budget: 40.000 - 0.500 (unc) - 0.200 (transition) = 39.300 ns available.
#    Heaviest path: THETA_A parity XOR → THETA_B rotate → CHI1 AND-NOT chain.
#    Genus will map this to a deep LUT chain; no multicycle relaxation needed.
#
#    To explicitly cap the round combinational cone for max-effort optimization:
#------------------------------------------------------------------------------
# set_max_delay 39.300 -from [get_cells {x*_reg*}] -to [get_cells {x*_reg*}]

#------------------------------------------------------------------------------
# 8. RETIMING (disabled for baseline — retiming would create the pipeline)
#    Uncomment only if intentionally auto-pipelining from this baseline.
#------------------------------------------------------------------------------
# set_attribute retime true [get_db designs ascon_perm_baseline]

#------------------------------------------------------------------------------
# 9. DRIVING CELL / OUTPUT LOAD
#------------------------------------------------------------------------------
set_driving_cell -no_design_rule [get_ports {start rst_n}]
set_load 5.0 [get_ports {done tag_match led_done led_tag_match led_running led_error}]

#------------------------------------------------------------------------------
# 10. OPERATING CONDITIONS
#      Typical-corner synthesis for baseline area/frequency trade-off study.
#      Uncomment and set library condition as appropriate.
#------------------------------------------------------------------------------
# set_operating_conditions -library <lib> TYPICAL

#==============================================================================
# END - ascon128_baseline.sdc
#==============================================================================
