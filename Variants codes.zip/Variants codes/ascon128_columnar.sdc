#==============================================================================
# ASCON-128  ·  Variant: columnar
# SDC for Cadence Genus Synthesis
#
# Permutation architecture: Column-major 8-column-wide S-box array.
#   S-box processes 8 of 64 columns per cycle. 11 phases per round:
#   CM_CONST(1) + CM_THETA(1) + CM_CHI(8 cycles, col_grp 0..7) + CM_LIN(1)
#
#   Critical path: CM_THETA (~8-10 gate levels, 64-bit parity)
#   CM_CHI phases: 8-bit S-box + byte mask + shift + OR  (~4-6 gate levels)
#   CM_LIN: standard Linear (~4-5 gate levels)
#   Fmax target: 100 MHz / 10 ns (CM_THETA bottleneck)
#
#   Note: The byte_mask shift ({56'd0,sy} << cg_base) where cg_base is a
#   registered 6-bit value (from col_grp) creates a barrel-shift path.
#   On FPGA this maps to a shift-mux; on ASIC a decoder. This is in the
#   CM_CHI path which is not the critical path (budget ~9.7 ns, actual ~5 ns).
#
# Clocks pa=12: 12 × 11 + 1 = 133   Clocks pb=6: 6 × 11 + 1 = 67
#==============================================================================
create_clock -period 10.000 -name sys_clk -waveform {0.000 5.000} [get_ports clk_p]
set_clock_uncertainty -setup 0.200 [get_clocks sys_clk]
set_clock_uncertainty -hold  0.100 [get_clocks sys_clk]
set_clock_transition -rise 0.100 [get_clocks sys_clk]
set_clock_transition -fall 0.100 [get_clocks sys_clk]
set_input_delay -clock sys_clk -max 2.000 [get_ports rst_n]
set_input_delay -clock sys_clk -min 0.500 [get_ports rst_n]
set_input_delay -clock sys_clk -max 2.000 [get_ports start]
set_input_delay -clock sys_clk -min 0.500 [get_ports start]
set_output_delay -clock sys_clk -max 2.000 [get_ports done]
set_output_delay -clock sys_clk -min 0.500 [get_ports done]
set_output_delay -clock sys_clk -max 2.000 [get_ports tag_match]
set_output_delay -clock sys_clk -min 0.500 [get_ports tag_match]
set_output_delay -clock sys_clk -max 2.000 [get_ports led_done]
set_output_delay -clock sys_clk -min 0.500 [get_ports led_done]
set_output_delay -clock sys_clk -max 2.000 [get_ports led_tag_match]
set_output_delay -clock sys_clk -min 0.500 [get_ports led_tag_match]
set_output_delay -clock sys_clk -max 2.000 [get_ports led_running]
set_output_delay -clock sys_clk -min 0.500 [get_ports led_running]
set_output_delay -clock sys_clk -max 2.000 [get_ports led_error]
set_output_delay -clock sys_clk -min 0.500 [get_ports led_error]
set_false_path -from [get_ports rst_n]
set_driving_cell -lib_cell INVX1 -no_design_rule [get_ports {start rst_n}]
set_load 5.0 [get_ports {done tag_match led_done led_tag_match led_running led_error}]
# set_operating_conditions -library <lib> TYPICAL
#==============================================================================
# END - ascon128_columnar.sdc
#==============================================================================
