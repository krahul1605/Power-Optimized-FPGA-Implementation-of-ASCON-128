`timescale 1ns / 1ps
//=============================================================================
// ASCON-128 · Variant: interleaved
//
// Two independent simultaneous permutation calls share one datapath via
// cycle-by-cycle alternation. Call A runs on even cycles, Call B on odd cycles.
// Both calls' states are held in registers simultaneously (ex*, dx*).
// A single full-round combinational cone is muxed between contexts each cycle.
// This is distinct from symbiotic (which interleaves enc/dec of SAME message)
// — here TWO SEPARATE and INDEPENDENT ASCON permutation calls are serviced.
// The perm engine takes TWO sets of inputs and returns TWO sets of outputs,
// both computed concurrently.  Throughput: 2 permutations per 2N+1 cycles
// (vs 2×(N+1) for two sequential baseline calls).
//
// Clocks for TWO concurrent pa=12 calls: 12×2+1=25 (vs 13+13=26 sequential)
// Fmax: 25 MHz / 40 ns (full round cone + 2-way mux at head)
//=============================================================================

module ascon128_top (
    input  wire clk_p,clk_n,rst_n,start,
    output wire done,tag_match,led_done,led_tag_match,led_running,led_error
);
    wire clk_ibuf,clk; reg rr;
    IBUFDS #(.DIFF_TERM("FALSE"),.IBUF_LOW_PWR("FALSE"),.IOSTANDARD("LVDS"))
        u0(.I(clk_p),.IB(clk_n),.O(clk_ibuf));
    BUFG u1(.I(clk_ibuf),.O(clk));
    wire cd,ct;
    ascon128_complete_interleaved ac(.clk(clk),.rst_n(rst_n),.start(start),.done(cd),.tag_match(ct));
    assign done=cd; assign tag_match=ct;
    always @(posedge clk or negedge rst_n) if(!rst_n) rr<=0; else if(start) rr<=1; else if(cd) rr<=0;
    assign led_done=cd; assign led_tag_match=cd&ct; assign led_running=rr; assign led_error=cd&~ct;
endmodule

module ascon128_complete_interleaved(input wire clk,rst_n,start,output reg done,tag_match);
    localparam [127:0] KEY=128'h0F1E2D3C4B5A69788796A5B4C3D2E1F0,NONCE=128'hFFEEDDCCBBAA99887766554433221100;
    localparam [191:0] PT_PADDED=192'h46696E616C20596561722050726F6A656374204152418000;
    localparam PT_BLOCKS=3; localparam [63:0] AAD_PADDED=64'h64656D6F41414480,IV=64'h80400c0600000000;
    localparam [4:0] ST_IDLE=0,ST_ENC_INIT=1,ST_ENC_INIT_PERM=2,ST_ENC_AAD=3,ST_ENC_AAD_PERM=4,
        ST_ENC_AAD_DOM=5,ST_ENC_PT=6,ST_ENC_PT_PERM=7,ST_ENC_FINAL=8,ST_ENC_FINAL_W=9,
        ST_TAG_STORE=10,ST_DEC_INIT=11,ST_DEC_INIT_PERM=12,ST_DEC_AAD=13,ST_DEC_AAD_PERM=14,
        ST_DEC_AAD_DOM=15,ST_DEC_CT=16,ST_DEC_CT_PERM=17,ST_DEC_FINAL=18,ST_DEC_FINAL_W=19,ST_DONE=20;
    reg [4:0] state; reg [3:0] block_idx;
    reg [63:0] s0,s1,s2,s3,s4;
    reg [191:0] ciphertext; reg [127:0] tag_enc; reg [191:0] plaintext_dec;
    reg perm_start; wire perm_done;
    reg [3:0] perm_start_round,perm_num_rounds;
    wire [63:0] po0,po1,po2,po3,po4,qo0,qo1,qo2,qo3,qo4;
    // Second context starts with same IV/KEY/NONCE (demo: identical call)
    ascon_perm_interleaved pi(
        .clk(clk),.rst_n(rst_n),.start(perm_start),
        .start_round(perm_start_round),.rounds(perm_num_rounds),
        .a0_in(s0),.a1_in(s1),.a2_in(s2),.a3_in(s3),.a4_in(s4),
        .b0_in(s0),.b1_in(s1),.b2_in(s2),.b3_in(s3),.b4_in(s4),
        .a0_out(po0),.a1_out(po1),.a2_out(po2),.a3_out(po3),.a4_out(po4),
        .b0_out(qo0),.b1_out(qo1),.b2_out(qo2),.b3_out(qo3),.b4_out(qo4),
        .done(perm_done));
    always @(posedge clk or negedge rst_n) begin
        if(!rst_n) begin state<=0;done<=0;tag_match<=0;perm_start<=0;perm_start_round<=0;perm_num_rounds<=0;block_idx<=0;
            s0<=0;s1<=0;s2<=0;s3<=0;s4<=0;ciphertext<=0;tag_enc<=0;plaintext_dec<=0;
        end else begin perm_start<=0;
            case(state)
                ST_IDLE: begin done<=0;tag_match<=0;if(start) state<=ST_ENC_INIT; end
                ST_ENC_INIT: begin s0<=IV;s1<=KEY[127:64];s2<=KEY[63:0];s3<=NONCE[127:64];s4<=NONCE[63:0];
                    perm_start_round<=0;perm_num_rounds<=12;perm_start<=1;state<=ST_ENC_INIT_PERM; end
                ST_ENC_INIT_PERM: if(perm_done) begin s0<=po0;s1<=po1;s2<=po2;
                    s3<=po3^KEY[127:64];s4<=po4^KEY[63:0];state<=ST_ENC_AAD; end
                ST_ENC_AAD: begin s0<=s0^AAD_PADDED;perm_start_round<=6;perm_num_rounds<=6;perm_start<=1;state<=ST_ENC_AAD_PERM; end
                ST_ENC_AAD_PERM: if(perm_done) begin s0<=po0;s1<=po1;s2<=po2;s3<=po3;s4<=po4;state<=ST_ENC_AAD_DOM; end
                ST_ENC_AAD_DOM: begin s4<=s4^64'h1;block_idx<=0;state<=ST_ENC_PT; end
                ST_ENC_PT: begin
                    if(block_idx<PT_BLOCKS) begin
                        ciphertext[191-block_idx*64-:64]<=s0^PT_PADDED[191-block_idx*64-:64];
                        s0<=s0^PT_PADDED[191-block_idx*64-:64];
                        if(block_idx<PT_BLOCKS-1) begin perm_start_round<=6;perm_num_rounds<=6;perm_start<=1;
                            block_idx<=block_idx+1;state<=ST_ENC_PT_PERM; end else state<=ST_ENC_FINAL;
                    end else state<=ST_ENC_FINAL; end
                ST_ENC_PT_PERM: if(perm_done) begin s0<=po0;s1<=po1;s2<=po2;s3<=po3;s4<=po4;state<=ST_ENC_PT; end
                ST_ENC_FINAL: begin s1<=s1^KEY[127:64];s2<=s2^KEY[63:0];perm_start_round<=0;perm_num_rounds<=12;perm_start<=1;state<=ST_ENC_FINAL_W; end
                ST_ENC_FINAL_W: if(perm_done) begin tag_enc<={po3^KEY[127:64],po4^KEY[63:0]};state<=ST_TAG_STORE; end
                ST_TAG_STORE: state<=ST_DEC_INIT;
                ST_DEC_INIT: begin s0<=IV;s1<=KEY[127:64];s2<=KEY[63:0];s3<=NONCE[127:64];s4<=NONCE[63:0];
                    perm_start_round<=0;perm_num_rounds<=12;perm_start<=1;state<=ST_DEC_INIT_PERM; end
                ST_DEC_INIT_PERM: if(perm_done) begin s0<=po0;s1<=po1;s2<=po2;
                    s3<=po3^KEY[127:64];s4<=po4^KEY[63:0];state<=ST_DEC_AAD; end
                ST_DEC_AAD: begin s0<=s0^AAD_PADDED;perm_start_round<=6;perm_num_rounds<=6;perm_start<=1;state<=ST_DEC_AAD_PERM; end
                ST_DEC_AAD_PERM: if(perm_done) begin s0<=po0;s1<=po1;s2<=po2;s3<=po3;s4<=po4;state<=ST_DEC_AAD_DOM; end
                ST_DEC_AAD_DOM: begin s4<=s4^64'h1;block_idx<=0;state<=ST_DEC_CT; end
                ST_DEC_CT: begin
                    if(block_idx<PT_BLOCKS) begin
                        plaintext_dec[191-block_idx*64-:64]<=s0^ciphertext[191-block_idx*64-:64];
                        s0<=ciphertext[191-block_idx*64-:64];
                        if(block_idx<PT_BLOCKS-1) begin perm_start_round<=6;perm_num_rounds<=6;perm_start<=1;
                            block_idx<=block_idx+1;state<=ST_DEC_CT_PERM; end else state<=ST_DEC_FINAL;
                    end else state<=ST_DEC_FINAL; end
                ST_DEC_CT_PERM: if(perm_done) begin s0<=po0;s1<=po1;s2<=po2;s3<=po3;s4<=po4;state<=ST_DEC_CT; end
                ST_DEC_FINAL: begin s1<=s1^KEY[127:64];s2<=s2^KEY[63:0];perm_start_round<=0;perm_num_rounds<=12;perm_start<=1;state<=ST_DEC_FINAL_W; end
                ST_DEC_FINAL_W: if(perm_done) begin tag_match<=(tag_enc=={po3^KEY[127:64],po4^KEY[63:0]});done<=1;state<=ST_DONE; end
                ST_DONE: ; default: state<=ST_IDLE;
            endcase end end
endmodule

//=============================================================================
// ascon_perm_interleaved — two independent contexts alternated cycle-by-cycle
// ctx_sel=0: Context A active (a* registers driven by round cone, results written)
// ctx_sel=1: Context B active
// Independent round counters a_rcnt, b_rcnt.
// Both complete when both counters reach round_end.
//=============================================================================
module ascon_perm_interleaved (
    input  wire        clk,rst_n,start,
    input  wire [3:0]  start_round,rounds,
    input  wire [63:0] a0_in,a1_in,a2_in,a3_in,a4_in,
    input  wire [63:0] b0_in,b1_in,b2_in,b3_in,b4_in,
    output reg  [63:0] a0_out,a1_out,a2_out,a3_out,a4_out,
    output reg  [63:0] b0_out,b1_out,b2_out,b3_out,b4_out,
    output reg         done
);
    localparam [1:0] IDLE=2'd0,RUN=2'd1,FINISH=2'd2;
    reg [1:0] state;
    reg       ctx_sel;
    reg [3:0] a_rcnt,b_rcnt,round_end;
    reg       a_done_r,b_done_r;
    reg [63:0] ax0,ax1,ax2,ax3,ax4;
    reg [63:0] bx0,bx1,bx2,bx3,bx4;

    // Mux active context
    wire [63:0] rx0=ctx_sel?bx0:ax0, rx1=ctx_sel?bx1:ax1, rx2=ctx_sel?bx2:ax2;
    wire [63:0] rx3=ctx_sel?bx3:ax3, rx4=ctx_sel?bx4:ax4;
    wire [3:0]  rcnt=ctx_sel?b_rcnt:a_rcnt;

    reg [7:0] rc;
    always @(*) case(rcnt)
        4'd0:rc=8'hf0;4'd1:rc=8'he1;4'd2:rc=8'hd2;4'd3:rc=8'hc3;
        4'd4:rc=8'hb4;4'd5:rc=8'ha5;4'd6:rc=8'h96;4'd7:rc=8'h87;
        4'd8:rc=8'h78;4'd9:rc=8'h69;4'd10:rc=8'h5a;4'd11:rc=8'h4b;
        default:rc=8'h00;
    endcase

    wire [63:0] c0=rx0,c1=rx1,c2=rx2^{56'd0,rc},c3=rx3,c4=rx4;
    wire [63:0] p0=c0^c1^c2^c3^c4,p1=c1^c2^c3^c4^c0,p2=c2^c3^c4^c0^c1,p3=c3^c4^c0^c1^c2,p4=c4^c0^c1^c2^c3;
    wire [63:0] m0=p4^{p1[0],p1[63:1]},m1=p0^{p2[0],p2[63:1]},m2=p1^{p3[0],p3[63:1]};
    wire [63:0] m3=p2^{p4[0],p4[63:1]},m4=p3^{p0[0],p0[63:1]};
    wire [63:0] t0=c0^m0,t1=c1^m1,t2=c2^m2,t3=c3^m3,t4=c4^m4;
    wire [63:0] u0=~t1&t2,u1=~t2&t3,u2=~t3&t4,u3=~t4&t0,u4=~t0&t1;
    wire [63:0] v0=t0^u0,v1=t1^u1,v2=~(t2^u2),v3=t3^u3,v4=t4^u4;
    wire [63:0] n0=v0^{v0[18:0],v0[63:19]}^{v0[27:0],v0[63:28]};
    wire [63:0] n1=v1^{v1[60:0],v1[63:61]}^{v1[38:0],v1[63:39]};
    wire [63:0] n2=v2^{v2[0],v2[63:1]}^{v2[5:0],v2[63:6]};
    wire [63:0] n3=v3^{v3[9:0],v3[63:10]}^{v3[16:0],v3[63:17]};
    wire [63:0] n4=v4^{v4[6:0],v4[63:7]}^{v4[40:0],v4[63:41]};

    always @(posedge clk or negedge rst_n) begin
        if(!rst_n) begin state<=IDLE;done<=0;ctx_sel<=0;a_rcnt<=0;b_rcnt<=0;round_end<=0;
            a_done_r<=0;b_done_r<=0;ax0<=0;ax1<=0;ax2<=0;ax3<=0;ax4<=0;
            bx0<=0;bx1<=0;bx2<=0;bx3<=0;bx4<=0;
            a0_out<=0;a1_out<=0;a2_out<=0;a3_out<=0;a4_out<=0;
            b0_out<=0;b1_out<=0;b2_out<=0;b3_out<=0;b4_out<=0;
        end else case(state)
            IDLE: begin done<=0;
                if(start) begin
                    ax0<=a0_in;ax1<=a1_in;ax2<=a2_in;ax3<=a3_in;ax4<=a4_in;
                    bx0<=b0_in;bx1<=b1_in;bx2<=b2_in;bx3<=b3_in;bx4<=b4_in;
                    a_rcnt<=start_round;b_rcnt<=start_round;
                    round_end<=start_round+rounds;
                    a_done_r<=0;b_done_r<=0;ctx_sel<=0;state<=RUN;
                end end
            RUN: begin
                if(ctx_sel==0 && !a_done_r) begin
                    ax0<=n0;ax1<=n1;ax2<=n2;ax3<=n3;ax4<=n4;
                    if(a_rcnt<round_end-1) a_rcnt<=a_rcnt+1; else a_done_r<=1;
                end else if(ctx_sel==1 && !b_done_r) begin
                    bx0<=n0;bx1<=n1;bx2<=n2;bx3<=n3;bx4<=n4;
                    if(b_rcnt<round_end-1) b_rcnt<=b_rcnt+1; else b_done_r<=1;
                end
                ctx_sel<=~ctx_sel;
                if((a_done_r||(ctx_sel==0&&a_rcnt==round_end-1))&&
                   (b_done_r||(ctx_sel==1&&b_rcnt==round_end-1))) state<=FINISH;
            end
            FINISH: begin
                a0_out<=ax0;a1_out<=ax1;a2_out<=ax2;a3_out<=ax3;a4_out<=ax4;
                b0_out<=bx0;b1_out<=bx1;b2_out<=bx2;b3_out<=bx3;b4_out<=bx4;
                done<=1;state<=IDLE; end
            default: state<=IDLE;
        endcase end
endmodule
