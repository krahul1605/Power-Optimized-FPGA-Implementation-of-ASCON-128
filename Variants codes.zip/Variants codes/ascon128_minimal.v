`timescale 1ns / 1ps
//=============================================================================
// ASCON-128  ·  Variant: s-box-minimal
//
// Visual treatment : Minimal register depth — the ASCON permutation round
//                    (Constant, Theta, Chi, Linear) is collapsed into a
//                    single combinational super-stage.  Only the mandatory
//                    round-count register is kept; all intermediate pipeline
//                    registers from the baseline are removed.
//
// Trade-offs
//   + Lowest register count (~320 FFs saved per permutation call vs baseline)
//   + Smallest area
//   - Longest combinational path -> lower Fmax (~25 MHz target preserved)
//   - Higher switching activity on combinational clouds per cycle
//
// Functional parity: identical ports, identical FSM state encoding, identical
//                    ASCON-128 algorithm (NIST compliant).
//=============================================================================

module ascon128_top (
    input  wire clk_p,
    input  wire clk_n,
    input  wire rst_n,
    input  wire start,
    output wire done,
    output wire tag_match,
    output wire led_done,
    output wire led_tag_match,
    output wire led_running,
    output wire led_error
);

    wire clk_ibuf, clk;

    IBUFDS #(
        .DIFF_TERM   ("FALSE"),
        .IBUF_LOW_PWR("FALSE"),
        .IOSTANDARD  ("LVDS")
    ) clk_ibufds (
        .I  (clk_p),
        .IB (clk_n),
        .O  (clk_ibuf)
    );

    BUFG clk_bufg (.I(clk_ibuf), .O(clk));

    wire core_done, core_tag_match;
    reg  running_r;

    ascon128_complete_minimal ascon_core (
        .clk      (clk),
        .rst_n    (rst_n),
        .start    (start),
        .done     (core_done),
        .tag_match(core_tag_match)
    );

    assign done      = core_done;
    assign tag_match = core_tag_match;

    always @(posedge clk or negedge rst_n) begin
        if (!rst_n)         running_r <= 1'b0;
        else if (start)     running_r <= 1'b1;
        else if (core_done) running_r <= 1'b0;
    end

    assign led_done      = core_done;
    assign led_tag_match = core_done &  core_tag_match;
    assign led_running   = running_r;
    assign led_error     = core_done & ~core_tag_match;

endmodule


//=============================================================================
// ascon128_complete_minimal  —  top-level FSM (identical to baseline)
//=============================================================================
module ascon128_complete_minimal (
    input  wire clk,
    input  wire rst_n,
    input  wire start,
    output reg  done,
    output reg  tag_match
);

    localparam [127:0] KEY   = 128'h0F1E2D3C4B5A69788796A5B4C3D2E1F0;
    localparam [127:0] NONCE = 128'hFFEEDDCCBBAA99887766554433221100;
    localparam [191:0] PT_PADDED = 192'h46696E616C20596561722050726F6A656374204152418000;
    localparam         PT_BLOCKS = 3;
    localparam         PT_BYTES  = 22;
    localparam [63:0]  AAD_PADDED = 64'h64656D6F41414480;
    localparam [63:0]  IV         = 64'h80400c0600000000;

    localparam [4:0]
        ST_IDLE          = 5'd0,  ST_ENC_INIT      = 5'd1,
        ST_ENC_INIT_PERM = 5'd2,  ST_ENC_AAD       = 5'd3,
        ST_ENC_AAD_PERM  = 5'd4,  ST_ENC_AAD_DOM   = 5'd5,
        ST_ENC_PT        = 5'd6,  ST_ENC_PT_PERM   = 5'd7,
        ST_ENC_FINAL     = 5'd8,  ST_ENC_FINAL_W   = 5'd9,
        ST_TAG_STORE     = 5'd10, ST_DEC_INIT      = 5'd11,
        ST_DEC_INIT_PERM = 5'd12, ST_DEC_AAD       = 5'd13,
        ST_DEC_AAD_PERM  = 5'd14, ST_DEC_AAD_DOM   = 5'd15,
        ST_DEC_CT        = 5'd16, ST_DEC_CT_PERM   = 5'd17,
        ST_DEC_FINAL     = 5'd18, ST_DEC_FINAL_W   = 5'd19,
        ST_DONE          = 5'd20;

    reg [4:0]  state;
    reg [63:0] s0, s1, s2, s3, s4;
    reg [191:0] ciphertext;
    reg [127:0] tag_enc;
    reg [191:0] plaintext_dec;
    reg         perm_start;
    wire        perm_done;
    reg  [3:0]  perm_start_round;
    reg  [3:0]  perm_num_rounds;
    wire [63:0] perm_out0, perm_out1, perm_out2, perm_out3, perm_out4;
    reg  [3:0]  block_idx;

    // Minimal variant: single-cycle-per-round permutation
    ascon_perm_minimal perm_inst (
        .clk        (clk),
        .rst_n      (rst_n),
        .start      (perm_start),
        .start_round(perm_start_round),
        .rounds     (perm_num_rounds),
        .s0_in      (s0), .s1_in(s1), .s2_in(s2), .s3_in(s3), .s4_in(s4),
        .s0_out     (perm_out0), .s1_out(perm_out1), .s2_out(perm_out2),
        .s3_out     (perm_out3), .s4_out(perm_out4),
        .done       (perm_done)
    );

    always @(posedge clk or negedge rst_n) begin
        if (!rst_n) begin
            state <= ST_IDLE; done <= 0; tag_match <= 0;
            perm_start <= 0; perm_start_round <= 0; perm_num_rounds <= 0;
            block_idx <= 0;
            s0<=0; s1<=0; s2<=0; s3<=0; s4<=0;
            ciphertext<=0; tag_enc<=0; plaintext_dec<=0;
        end else begin
            perm_start <= 1'b0;
            case (state)
                ST_IDLE: begin
                    done <= 0; tag_match <= 0;
                    if (start) state <= ST_ENC_INIT;
                end
                ST_ENC_INIT: begin
                    s0<=IV; s1<=KEY[127:64]; s2<=KEY[63:0];
                    s3<=NONCE[127:64]; s4<=NONCE[63:0];
                    perm_start_round<=4'd0; perm_num_rounds<=4'd12;
                    perm_start<=1; state<=ST_ENC_INIT_PERM;
                end
                ST_ENC_INIT_PERM: begin
                    if (perm_done) begin
                        s0<=perm_out0; s1<=perm_out1; s2<=perm_out2;
                        s3<=perm_out3^KEY[127:64]; s4<=perm_out4^KEY[63:0];
                        state<=ST_ENC_AAD;
                    end
                end
                ST_ENC_AAD: begin
                    s0<=s0^AAD_PADDED;
                    perm_start_round<=4'd6; perm_num_rounds<=4'd6;
                    perm_start<=1; state<=ST_ENC_AAD_PERM;
                end
                ST_ENC_AAD_PERM: begin
                    if (perm_done) begin
                        s0<=perm_out0; s1<=perm_out1; s2<=perm_out2;
                        s3<=perm_out3; s4<=perm_out4;
                        state<=ST_ENC_AAD_DOM;
                    end
                end
                ST_ENC_AAD_DOM: begin
                    s4<=s4^64'h1; block_idx<=0; state<=ST_ENC_PT;
                end
                ST_ENC_PT: begin
                    if (block_idx < PT_BLOCKS) begin
                        ciphertext[191-block_idx*64-:64] <= s0^PT_PADDED[191-block_idx*64-:64];
                        s0 <= s0^PT_PADDED[191-block_idx*64-:64];
                        if (block_idx < PT_BLOCKS-1) begin
                            perm_start_round<=4'd6; perm_num_rounds<=4'd6;
                            perm_start<=1; block_idx<=block_idx+1;
                            state<=ST_ENC_PT_PERM;
                        end else state<=ST_ENC_FINAL;
                    end else state<=ST_ENC_FINAL;
                end
                ST_ENC_PT_PERM: begin
                    if (perm_done) begin
                        s0<=perm_out0; s1<=perm_out1; s2<=perm_out2;
                        s3<=perm_out3; s4<=perm_out4; state<=ST_ENC_PT;
                    end
                end
                ST_ENC_FINAL: begin
                    s1<=s1^KEY[127:64]; s2<=s2^KEY[63:0];
                    perm_start_round<=4'd0; perm_num_rounds<=4'd12;
                    perm_start<=1; state<=ST_ENC_FINAL_W;
                end
                ST_ENC_FINAL_W: begin
                    if (perm_done) begin
                        tag_enc<={perm_out3^KEY[127:64], perm_out4^KEY[63:0]};
                        state<=ST_TAG_STORE;
                    end
                end
                ST_TAG_STORE: state<=ST_DEC_INIT;
                ST_DEC_INIT: begin
                    s0<=IV; s1<=KEY[127:64]; s2<=KEY[63:0];
                    s3<=NONCE[127:64]; s4<=NONCE[63:0];
                    perm_start_round<=4'd0; perm_num_rounds<=4'd12;
                    perm_start<=1; state<=ST_DEC_INIT_PERM;
                end
                ST_DEC_INIT_PERM: begin
                    if (perm_done) begin
                        s0<=perm_out0; s1<=perm_out1; s2<=perm_out2;
                        s3<=perm_out3^KEY[127:64]; s4<=perm_out4^KEY[63:0];
                        state<=ST_DEC_AAD;
                    end
                end
                ST_DEC_AAD: begin
                    s0<=s0^AAD_PADDED;
                    perm_start_round<=4'd6; perm_num_rounds<=4'd6;
                    perm_start<=1; state<=ST_DEC_AAD_PERM;
                end
                ST_DEC_AAD_PERM: begin
                    if (perm_done) begin
                        s0<=perm_out0; s1<=perm_out1; s2<=perm_out2;
                        s3<=perm_out3; s4<=perm_out4; state<=ST_DEC_AAD_DOM;
                    end
                end
                ST_DEC_AAD_DOM: begin
                    s4<=s4^64'h1; block_idx<=0; state<=ST_DEC_CT;
                end
                ST_DEC_CT: begin
                    if (block_idx < PT_BLOCKS) begin
                        plaintext_dec[191-block_idx*64-:64] <= s0^ciphertext[191-block_idx*64-:64];
                        s0 <= ciphertext[191-block_idx*64-:64];
                        if (block_idx < PT_BLOCKS-1) begin
                            perm_start_round<=4'd6; perm_num_rounds<=4'd6;
                            perm_start<=1; block_idx<=block_idx+1;
                            state<=ST_DEC_CT_PERM;
                        end else state<=ST_DEC_FINAL;
                    end else state<=ST_DEC_FINAL;
                end
                ST_DEC_CT_PERM: begin
                    if (perm_done) begin
                        s0<=perm_out0; s1<=perm_out1; s2<=perm_out2;
                        s3<=perm_out3; s4<=perm_out4; state<=ST_DEC_CT;
                    end
                end
                ST_DEC_FINAL: begin
                    s1<=s1^KEY[127:64]; s2<=s2^KEY[63:0];
                    perm_start_round<=4'd0; perm_num_rounds<=4'd12;
                    perm_start<=1; state<=ST_DEC_FINAL_W;
                end
                ST_DEC_FINAL_W: begin
                    if (perm_done) begin
                        tag_match <= (tag_enc == {perm_out3^KEY[127:64], perm_out4^KEY[63:0]});
                        done <= 1; state <= ST_DONE;
                    end
                end
                ST_DONE: ; // hold
                default: state<=ST_IDLE;
            endcase
        end
    end
endmodule


//=============================================================================
// ascon_perm_minimal
// Variant styling: ONE cycle per full ASCON round (Constant+Theta+Chi+Linear
// all computed combinationally in a single always block, registered once per
// round).  This is the minimal-register "flat" treatment.
//
// Clocks per pa=12 call : 12
// Clocks per pb=6  call :  6
// FFs added vs baseline : -(p0..p4, m0..m4, t0..t4, u0..u4, ra*/rb*) = -2560 FFs
//=============================================================================
module ascon_perm_minimal (
    input  wire        clk,
    input  wire        rst_n,
    input  wire        start,
    input  wire [3:0]  start_round,
    input  wire [3:0]  rounds,
    input  wire [63:0] s0_in, s1_in, s2_in, s3_in, s4_in,
    output reg  [63:0] s0_out, s1_out, s2_out, s3_out, s4_out,
    output reg         done
);

    localparam [3:0] IDLE = 0, ROUND = 1, FINISH = 2;

    reg [3:0] state, round_cnt, round_end;
    reg [63:0] x0, x1, x2, x3, x4;

    // Round constant lookup (combinational)
    function [7:0] get_rc;
        input [3:0] r;
        case (r)
            4'd0:  get_rc = 8'hf0; 4'd1:  get_rc = 8'he1;
            4'd2:  get_rc = 8'hd2; 4'd3:  get_rc = 8'hc3;
            4'd4:  get_rc = 8'hb4; 4'd5:  get_rc = 8'ha5;
            4'd6:  get_rc = 8'h96; 4'd7:  get_rc = 8'h87;
            4'd8:  get_rc = 8'h78; 4'd9:  get_rc = 8'h69;
            4'd10: get_rc = 8'h5a; 4'd11: get_rc = 8'h4b;
            default: get_rc = 8'h00;
        endcase
    endfunction

    // Full combinational round (Constant → Theta → Chi → Linear)
    task automatic do_round;
        input  [63:0] i0, i1, i2, i3, i4;
        input  [3:0]  rc_idx;
        output [63:0] o0, o1, o2, o3, o4;
        reg [63:0] a0,a1,a2,a3,a4;
        reg [63:0] p0,p1,p2,p3,p4;
        reg [63:0] m0,m1,m2,m3,m4;
        reg [63:0] t0,t1,t2,t3,t4;
        reg [63:0] u0,u1,u2,u3,u4;
        begin
            // Constant addition
            a0=i0; a1=i1; a2=i2^{56'd0,get_rc(rc_idx)}; a3=i3; a4=i4;
            // Theta: column parities
            p0=a0^a1^a2^a3^a4; p1=a1^a2^a3^a4^a0;
            p2=a2^a3^a4^a0^a1; p3=a3^a4^a0^a1^a2; p4=a4^a0^a1^a2^a3;
            // Theta: rotation mix
            m0=p4^{p1[0],p1[63:1]}; m1=p0^{p2[0],p2[63:1]};
            m2=p1^{p3[0],p3[63:1]}; m3=p2^{p4[0],p4[63:1]};
            m4=p3^{p0[0],p0[63:1]};
            // Theta: apply
            t0=a0^m0; t1=a1^m1; t2=a2^m2; t3=a3^m3; t4=a4^m4;
            // Chi: AND-NOT then XOR (x2 inverted per spec)
            u0=~t1&t2; u1=~t2&t3; u2=~t3&t4; u3=~t4&t0; u4=~t0&t1;
            a0=t0^u0; a1=t1^u1; a2=~(t2^u2); a3=t3^u3; a4=t4^u4;
            // Linear: rotation pairs XOR'd in one step
            o0=a0^{a0[18:0],a0[63:19]}^{a0[27:0],a0[63:28]};
            o1=a1^{a1[60:0],a1[63:61]}^{a1[38:0],a1[63:39]};
            o2=a2^{a2[0],   a2[63:1]} ^{a2[5:0], a2[63:6]};
            o3=a3^{a3[9:0], a3[63:10]}^{a3[16:0],a3[63:17]};
            o4=a4^{a4[6:0], a4[63:7]} ^{a4[40:0],a4[63:41]};
        end
    endtask

    always @(posedge clk or negedge rst_n) begin
        if (!rst_n) begin
            state<=IDLE; done<=0; round_cnt<=0; round_end<=0;
            x0<=0; x1<=0; x2<=0; x3<=0; x4<=0;
            s0_out<=0; s1_out<=0; s2_out<=0; s3_out<=0; s4_out<=0;
        end else begin
            case (state)
                IDLE: begin
                    done<=0;
                    if (start) begin
                        x0<=s0_in; x1<=s1_in; x2<=s2_in; x3<=s3_in; x4<=s4_in;
                        round_cnt<=start_round; round_end<=start_round+rounds;
                        state<=ROUND;
                    end
                end
                ROUND: begin
                    // Entire round in one cycle (deep combinational path)
                    do_round(x0,x1,x2,x3,x4, round_cnt, x0,x1,x2,x3,x4);
                    if (round_cnt < round_end-1) begin
                        round_cnt<=round_cnt+1; state<=ROUND;
                    end else state<=FINISH;
                end
                FINISH: begin
                    s0_out<=x0; s1_out<=x1; s2_out<=x2;
                    s3_out<=x3; s4_out<=x4; done<=1; state<=IDLE;
                end
                default: state<=IDLE;
            endcase
        end
    end
endmodule
