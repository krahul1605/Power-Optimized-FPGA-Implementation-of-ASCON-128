#==============================================================================
# ASCON-128  ·  Variant: lookahead
# SDC for Cadence Genus Synthesis
#
# Permutation architecture: Speculative 2-round lookahead pipeline.
#   Two full-round combinational cones (A and B) are chained in series:
#   Cone A: x*_reg -> full round -> an* (committed result)
#   Cone B: an* (combinational) -> full round -> bn* (speculative next round)
#   Both chained combinationally — no intermediate register between A and B.
#
#   Critical path: x*_reg -> ConeA (35-45 levels) -> ConeB (35-45 levels)
#                  -> sx*_reg
#   Total: ~70-90 gate levels  (~2× baseline)
#   Fmax target: 12 MHz / 80 ns
#
#   The shadow register sx* stores the speculative result but in this
#   single-token implementation it is computed and stored but the committed
#   path uses only Cone A's output (an*). The sx* shadows are structural
#   intermediates kept for analysis and potential multi-token extension.
#
# Clocks pa=12: 12 + 1 = 13   Clocks pb=6: 6 + 1 = 7
# (Same latency as baseline despite 2× combinational depth per cycle)
#==============================================================================
create_clock -period 80.000 -name sys_clk -waveform {0.000 40.000} [get_ports clk_p]
set_clock_uncertainty -setup 1.000 [get_clocks sys_clk]
set_clock_uncertainty -hold  0.500 [get_clocks sys_clk]
set_clock_transition -rise 0.400 [get_clocks sys_clk]
set_clock_transition -fall 0.400 [get_clocks sys_clk]
set_input_delay -clock sys_clk -max 2.000 [get_ports rst_n]
set_input_delay -clock sys_clk -min 0.500 [get_ports rst_n]
set_input_delay -clock sys_clk -max 2.000 [get_ports start]
set_input_delay -clock sys_clk -min 0.500 [get_ports start]
set_output_delay -clock sys_clk -max 2.000 [get_ports done]
set_output_delay -clock sys_clk -min 0.500 [get_ports done]
set_output_delay -clock sys_clk -max 2.000 [get_ports tag_match]
set_output_delay -clock sys_clk -min 0.500 [get_ports tag_match]
set_output_delay -clock sys_clk -max 2.000 [get_ports led_done]
set_output_delay -clock sys_clk -min 0.500 [get_ports led_done]
set_output_delay -clock sys_clk -max 2.000 [get_ports led_tag_match]
set_output_delay -clock sys_clk -min 0.500 [get_ports led_tag_match]
set_output_delay -clock sys_clk -max 2.000 [get_ports led_running]
set_output_delay -clock sys_clk -min 0.500 [get_ports led_running]
set_output_delay -clock sys_clk -max 2.000 [get_ports led_error]
set_output_delay -clock sys_clk -min 0.500 [get_ports led_error]
set_false_path -from [get_ports rst_n]
# Preserve the shadow register sx* to prevent synthesis from eliminating
# the speculative cone B (which has no architectural effect in single-token mode)
# set_dont_touch [get_cells {sx*_reg*}]
# Explicitly budget the 2-cone chained path:
# set_max_delay 78.000 -from [get_cells {x*_reg*}] -to [get_cells {x*_reg* sx*_reg*}]
set_driving_cell -lib_cell INVX1 -no_design_rule [get_ports {start rst_n}]
set_load 5.0 [get_ports {done tag_match led_done led_tag_match led_running led_error}]
# set_operating_conditions -library <lib> TYPICAL
#==============================================================================
# END - ascon128_lookahead.sdc
#==============================================================================
