#==============================================================================
# ASCON-128  ·  Variant: quarterpipe
# SDC for Cadence Genus Synthesis
#
# Permutation architecture: 2-stage registered pipeline per round.
#   Four ASCON sub-steps are merged into each of two pipeline stages:
#     Stage 0 : CONST + THETA_A + THETA_B + THETA_C
#               — constant injection, parity computation, rotation mix,
#                 and theta application all in one combinational cone.
#     Stage 1 : CHI1 + CHI2 + LIN1 + LIN2
#               — AND-NOT, chi XOR, rotation operands, and linear XOR merge.
#
# Architecture trade-offs:
#   + Only 2 register barriers per round — lowest pipeline overhead.
#   + Register count: 2 stages × 5×64b = 640 FFs (plus inter-stage regs).
#   + Simple FSM: only 2 state transitions per round iteration.
#   - Long combinational paths per stage (~10-14 gate levels in Stage 1).
#   - Stage 1 dominates timing: AND-NOT + XOR + 2× rotate + XOR chain.
#   - Sensitive to library cell drive strength; buffer insertion likely needed.
#
# Timing impact vs elevated:
#   - Critical path per cycle: 4 merged sub-steps (~12-16 gate/LUT levels).
#   - Clock period target: 15.000 ns (67 MHz) — midpoint between folded/halfpipe.
#   - Input/output delays: 2.0/0.5 ns standard board interface.
#   - Multicycle paths: NOT needed — each merged group is exactly 1 cycle.
#
# Clocks per pa=12 call : 12 rounds × 2 sub-stages = 24 + 1 FINISH = 25
# Clocks per pb=6  call :  6 rounds × 2 sub-stages = 12 + 1 FINISH = 13
#
# Synthesis guidance for Genus:
#   Stage 1 (CHI+LIN) is the critical path. Genus should apply maximum
#   fanout control on the AND-NOT outputs feeding the rotation network.
#   Consider set_max_fanout 8 on Stage 1 outputs to prevent drive contention.
#   Buffer tree insertion after chi is recommended for this path depth.
#==============================================================================

#------------------------------------------------------------------------------
# 1. CLOCK DEFINITION
#    67 MHz / 15 ns — quarterpipe 2-stage per-round architecture
#------------------------------------------------------------------------------
create_clock -period 15.000 \
             -name sys_clk \
             -waveform {0.000 7.500} \
             [get_ports clk_p]

#------------------------------------------------------------------------------
# 2. CLOCK UNCERTAINTY
#    Moderate jitter budget for 67 MHz operation.
#------------------------------------------------------------------------------
set_clock_uncertainty -setup 0.400 [get_clocks sys_clk]
set_clock_uncertainty -hold  0.250 [get_clocks sys_clk]

#------------------------------------------------------------------------------
# 3. CLOCK TRANSITION
#    Moderate edge rate for 67 MHz clock distribution.
#------------------------------------------------------------------------------
set_clock_transition -rise 0.120 [get_clocks sys_clk]
set_clock_transition -fall 0.120 [get_clocks sys_clk]

#------------------------------------------------------------------------------
# 4. INPUT DELAYS
#    At 15 ns period, 2.0 ns max input delay leaves 12.48 ns internal budget.
#------------------------------------------------------------------------------
set_input_delay -clock sys_clk -max 2.000 [get_ports rst_n]
set_input_delay -clock sys_clk -min 0.500 [get_ports rst_n]
set_input_delay -clock sys_clk -max 2.000 [get_ports start]
set_input_delay -clock sys_clk -min 0.500 [get_ports start]

#------------------------------------------------------------------------------
# 5. OUTPUT DELAYS
#------------------------------------------------------------------------------
set_output_delay -clock sys_clk -max 2.000 [get_ports done]
set_output_delay -clock sys_clk -min 0.500 [get_ports done]
set_output_delay -clock sys_clk -max 2.000 [get_ports tag_match]
set_output_delay -clock sys_clk -min 0.500 [get_ports tag_match]
set_output_delay -clock sys_clk -max 2.000 [get_ports led_done]
set_output_delay -clock sys_clk -min 0.500 [get_ports led_done]
set_output_delay -clock sys_clk -max 2.000 [get_ports led_tag_match]
set_output_delay -clock sys_clk -min 0.500 [get_ports led_tag_match]
set_output_delay -clock sys_clk -max 2.000 [get_ports led_running]
set_output_delay -clock sys_clk -min 0.500 [get_ports led_running]
set_output_delay -clock sys_clk -max 2.000 [get_ports led_error]
set_output_delay -clock sys_clk -min 0.500 [get_ports led_error]

#------------------------------------------------------------------------------
# 6. ASYNCHRONOUS RESET - FALSE PATH
#------------------------------------------------------------------------------
set_false_path -from [get_ports rst_n]

#------------------------------------------------------------------------------
# 7. PIPELINE STAGE PATH BUDGET — QUARTERPIPE
#    Budget: 15.000 - 0.400 (unc) - 0.120 (transition) = 14.480 ns available.
#
#    Per-stage breakdown (estimated):
#      Stage 0 (CONST+THETA_A+THETA_B+THETA_C): ~7.5 ns — XOR cascade chain
#      Stage 1 (CHI1+CHI2+LIN1+LIN2)          : ~9.8 ns — AND+XOR+rotate ← CRITICAL
#
#    Stage 1 exceeds a naive estimate — Genus must aggressively buffer the
#    AND-NOT output fanout (x5 × 64b bits) into the dual-rotation network.
#
#    Explicitly constrain Stage 1 register-to-register path:
#------------------------------------------------------------------------------
# set_max_delay 14.480 -from [get_cells {t*_reg*}] -to [get_cells {x*_reg*}]
# set_max_fanout 8 [get_nets {u*}]

#------------------------------------------------------------------------------
# 8. RETIMING ENABLE
#    Retiming between Stage 0/1 may move some THETA_C work into Stage 1's
#    register boundary, rebalancing the path. Use with caution — stage
#    semantics are coupled to the round counter FSM.
#------------------------------------------------------------------------------
# set_attribute retime true [get_db designs ascon_perm_quarterpipe]

#------------------------------------------------------------------------------
# 9. DRIVING CELL / OUTPUT LOAD
#------------------------------------------------------------------------------
set_driving_cell -no_design_rule [get_ports {start rst_n}]
set_load 5.0 [get_ports {done tag_match led_done led_tag_match led_running led_error}]

#------------------------------------------------------------------------------
# 10. OPERATING CONDITIONS
#      Typical corner acceptable; fast corner for 75 MHz+ closure.
#      Uncomment and set library condition as appropriate.
#------------------------------------------------------------------------------
# set_operating_conditions -library <lib> FAST

#==============================================================================
# END - ascon128_quarterpipe.sdc
#==============================================================================
