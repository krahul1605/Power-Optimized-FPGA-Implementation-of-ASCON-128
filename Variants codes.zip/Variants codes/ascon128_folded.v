`timescale 1ns / 1ps
//=============================================================================
// ASCON-128  ·  Variant: folded
//
// Visual treatment : Folded datapath — a single registered compute unit
//                    serves ALL 8 ASCON sub-steps via an 8-way mux.
//                    A 3-bit sub-step counter selects which sub-step the
//                    shared ALU computes each cycle. The 5×64-bit working
//                    state registers are written back every cycle through
//                    the shared mux output.
//
// Clocks per pa=12 call : 12 rounds × 8 sub-steps = 96 + 1 FINISH = 97
// Clocks per pb=6  call :  6 rounds × 8 sub-steps = 48 + 1 FINISH = 49
//
// Trade-offs
//   + Minimum logic area — one shared ALU serves all sub-steps
//   + Only ONE set of 5×64b working registers (320 FFs + mux overhead)
//   - Mux-dominated critical path limits Fmax (target 50 MHz / 20 ns)
//   - Mux tree adds 1-2 LUT levels on top of the heaviest sub-step (CHI1)
//   - Same latency as elevated (97/49 clocks) but worse frequency
//
// Functional parity: identical ports, identical FSM encoding, identical
//                    ASCON-128 algorithm (NIST compliant).
//=============================================================================

module ascon128_top (
    input  wire clk_p,
    input  wire clk_n,
    input  wire rst_n,
    input  wire start,
    output wire done,
    output wire tag_match,
    output wire led_done,
    output wire led_tag_match,
    output wire led_running,
    output wire led_error
);

    wire clk_ibuf, clk;

    IBUFDS #(
        .DIFF_TERM("FALSE"), .IBUF_LOW_PWR("FALSE"), .IOSTANDARD("LVDS")
    ) clk_ibufds (.I(clk_p), .IB(clk_n), .O(clk_ibuf));

    BUFG clk_bufg (.I(clk_ibuf), .O(clk));

    wire core_done, core_tag_match;
    reg  running_r;

    ascon128_complete_folded ascon_core (
        .clk(clk), .rst_n(rst_n), .start(start),
        .done(core_done), .tag_match(core_tag_match)
    );

    assign done = core_done; assign tag_match = core_tag_match;

    always @(posedge clk or negedge rst_n) begin
        if (!rst_n)         running_r <= 0;
        else if (start)     running_r <= 1;
        else if (core_done) running_r <= 0;
    end

    assign led_done=core_done; assign led_tag_match=core_done&core_tag_match;
    assign led_running=running_r; assign led_error=core_done&~core_tag_match;

endmodule


//=============================================================================
// ascon128_complete_folded  — FSM (identical to all variants)
//=============================================================================
module ascon128_complete_folded (
    input  wire clk, rst_n, start,
    output reg  done, tag_match
);
    localparam [127:0] KEY   = 128'h0F1E2D3C4B5A69788796A5B4C3D2E1F0;
    localparam [127:0] NONCE = 128'hFFEEDDCCBBAA99887766554433221100;
    localparam [191:0] PT_PADDED  = 192'h46696E616C20596561722050726F6A656374204152418000;
    localparam         PT_BLOCKS  = 3;
    localparam [63:0]  AAD_PADDED = 64'h64656D6F41414480;
    localparam [63:0]  IV         = 64'h80400c0600000000;

    localparam [4:0]
        ST_IDLE=0, ST_ENC_INIT=1, ST_ENC_INIT_PERM=2,
        ST_ENC_AAD=3, ST_ENC_AAD_PERM=4, ST_ENC_AAD_DOM=5,
        ST_ENC_PT=6, ST_ENC_PT_PERM=7, ST_ENC_FINAL=8,
        ST_ENC_FINAL_W=9, ST_TAG_STORE=10, ST_DEC_INIT=11,
        ST_DEC_INIT_PERM=12, ST_DEC_AAD=13, ST_DEC_AAD_PERM=14,
        ST_DEC_AAD_DOM=15, ST_DEC_CT=16, ST_DEC_CT_PERM=17,
        ST_DEC_FINAL=18, ST_DEC_FINAL_W=19, ST_DONE=20;

    reg [4:0] state; reg [3:0] block_idx;
    reg [63:0] s0,s1,s2,s3,s4;
    reg [191:0] ciphertext; reg [127:0] tag_enc; reg [191:0] plaintext_dec;
    reg perm_start; wire perm_done;
    reg [3:0] perm_start_round, perm_num_rounds;
    wire [63:0] perm_out0,perm_out1,perm_out2,perm_out3,perm_out4;

    ascon_perm_folded perm_inst (
        .clk(clk), .rst_n(rst_n), .start(perm_start),
        .start_round(perm_start_round), .rounds(perm_num_rounds),
        .s0_in(s0),.s1_in(s1),.s2_in(s2),.s3_in(s3),.s4_in(s4),
        .s0_out(perm_out0),.s1_out(perm_out1),.s2_out(perm_out2),
        .s3_out(perm_out3),.s4_out(perm_out4),.done(perm_done)
    );

    always @(posedge clk or negedge rst_n) begin
        if (!rst_n) begin
            state<=0; done<=0; tag_match<=0; perm_start<=0;
            perm_start_round<=0; perm_num_rounds<=0; block_idx<=0;
            s0<=0;s1<=0;s2<=0;s3<=0;s4<=0;
            ciphertext<=0; tag_enc<=0; plaintext_dec<=0;
        end else begin
            perm_start<=0;
            case(state)
                ST_IDLE: begin done<=0; tag_match<=0; if(start) state<=ST_ENC_INIT; end
                ST_ENC_INIT: begin
                    s0<=IV; s1<=KEY[127:64]; s2<=KEY[63:0];
                    s3<=NONCE[127:64]; s4<=NONCE[63:0];
                    perm_start_round<=0; perm_num_rounds<=12; perm_start<=1;
                    state<=ST_ENC_INIT_PERM;
                end
                ST_ENC_INIT_PERM: if(perm_done) begin
                    s0<=perm_out0; s1<=perm_out1; s2<=perm_out2;
                    s3<=perm_out3^KEY[127:64]; s4<=perm_out4^KEY[63:0];
                    state<=ST_ENC_AAD;
                end
                ST_ENC_AAD: begin
                    s0<=s0^AAD_PADDED; perm_start_round<=6; perm_num_rounds<=6;
                    perm_start<=1; state<=ST_ENC_AAD_PERM;
                end
                ST_ENC_AAD_PERM: if(perm_done) begin
                    s0<=perm_out0;s1<=perm_out1;s2<=perm_out2;s3<=perm_out3;s4<=perm_out4;
                    state<=ST_ENC_AAD_DOM;
                end
                ST_ENC_AAD_DOM: begin s4<=s4^64'h1; block_idx<=0; state<=ST_ENC_PT; end
                ST_ENC_PT: begin
                    if(block_idx<PT_BLOCKS) begin
                        ciphertext[191-block_idx*64-:64]<=s0^PT_PADDED[191-block_idx*64-:64];
                        s0<=s0^PT_PADDED[191-block_idx*64-:64];
                        if(block_idx<PT_BLOCKS-1) begin
                            perm_start_round<=6; perm_num_rounds<=6; perm_start<=1;
                            block_idx<=block_idx+1; state<=ST_ENC_PT_PERM;
                        end else state<=ST_ENC_FINAL;
                    end else state<=ST_ENC_FINAL;
                end
                ST_ENC_PT_PERM: if(perm_done) begin
                    s0<=perm_out0;s1<=perm_out1;s2<=perm_out2;s3<=perm_out3;s4<=perm_out4;
                    state<=ST_ENC_PT;
                end
                ST_ENC_FINAL: begin
                    s1<=s1^KEY[127:64]; s2<=s2^KEY[63:0];
                    perm_start_round<=0; perm_num_rounds<=12; perm_start<=1;
                    state<=ST_ENC_FINAL_W;
                end
                ST_ENC_FINAL_W: if(perm_done) begin
                    tag_enc<={perm_out3^KEY[127:64],perm_out4^KEY[63:0]};
                    state<=ST_TAG_STORE;
                end
                ST_TAG_STORE: state<=ST_DEC_INIT;
                ST_DEC_INIT: begin
                    s0<=IV; s1<=KEY[127:64]; s2<=KEY[63:0];
                    s3<=NONCE[127:64]; s4<=NONCE[63:0];
                    perm_start_round<=0; perm_num_rounds<=12; perm_start<=1;
                    state<=ST_DEC_INIT_PERM;
                end
                ST_DEC_INIT_PERM: if(perm_done) begin
                    s0<=perm_out0;s1<=perm_out1;s2<=perm_out2;
                    s3<=perm_out3^KEY[127:64];s4<=perm_out4^KEY[63:0];
                    state<=ST_DEC_AAD;
                end
                ST_DEC_AAD: begin
                    s0<=s0^AAD_PADDED; perm_start_round<=6; perm_num_rounds<=6;
                    perm_start<=1; state<=ST_DEC_AAD_PERM;
                end
                ST_DEC_AAD_PERM: if(perm_done) begin
                    s0<=perm_out0;s1<=perm_out1;s2<=perm_out2;s3<=perm_out3;s4<=perm_out4;
                    state<=ST_DEC_AAD_DOM;
                end
                ST_DEC_AAD_DOM: begin s4<=s4^64'h1; block_idx<=0; state<=ST_DEC_CT; end
                ST_DEC_CT: begin
                    if(block_idx<PT_BLOCKS) begin
                        plaintext_dec[191-block_idx*64-:64]<=s0^ciphertext[191-block_idx*64-:64];
                        s0<=ciphertext[191-block_idx*64-:64];
                        if(block_idx<PT_BLOCKS-1) begin
                            perm_start_round<=6; perm_num_rounds<=6; perm_start<=1;
                            block_idx<=block_idx+1; state<=ST_DEC_CT_PERM;
                        end else state<=ST_DEC_FINAL;
                    end else state<=ST_DEC_FINAL;
                end
                ST_DEC_CT_PERM: if(perm_done) begin
                    s0<=perm_out0;s1<=perm_out1;s2<=perm_out2;s3<=perm_out3;s4<=perm_out4;
                    state<=ST_DEC_CT;
                end
                ST_DEC_FINAL: begin
                    s1<=s1^KEY[127:64]; s2<=s2^KEY[63:0];
                    perm_start_round<=0; perm_num_rounds<=12; perm_start<=1;
                    state<=ST_DEC_FINAL_W;
                end
                ST_DEC_FINAL_W: if(perm_done) begin
                    tag_match<=(tag_enc=={perm_out3^KEY[127:64],perm_out4^KEY[63:0]});
                    done<=1; state<=ST_DONE;
                end
                ST_DONE: ;
                default: state<=ST_IDLE;
            endcase
        end
    end
endmodule


//=============================================================================
// ascon_perm_folded
//
// Folded datapath: one shared compute unit serves all 8 sub-steps via a
// 3-bit sub-step counter (sub_step). The single set of state registers
// x0..x4 is written back through the mux output every cycle.
//
// Sub-step encoding (sub_step[2:0]):
//   3'd0 : CONST   — XOR round constant into x2
//   3'd1 : THETA_A — compute column parities p0..p4 into x0..x4
//   3'd2 : THETA_B — rotation mix, m0..m4 into x0..x4 (needs saved parities)
//   3'd3 : THETA_C — apply theta: t = x + m, store into x0..x4
//   3'd4 : CHI1    — AND-NOT terms u0..u4 into p-regs (repurposed)
//   3'd5 : CHI2    — chi XOR, x2 inverted, into x0..x4
//   3'd6 : LIN1    — rotation operands ra*/rb* into p-regs (repurposed)
//   3'd7 : LIN2    — final XOR into x0..x4; advance round or FINISH
//
// Intermediate values (parities, rotations) are stored in a second set of
// p0..p4 registers shared/repurposed across sub-steps to avoid extra FFs.
//
// Critical path: sub_step_reg → 8-way mux → ALU → x*_reg  (~20 ns / 50 MHz)
//=============================================================================
module ascon_perm_folded (
    input  wire        clk, rst_n, start,
    input  wire [3:0]  start_round, rounds,
    input  wire [63:0] s0_in,s1_in,s2_in,s3_in,s4_in,
    output reg  [63:0] s0_out,s1_out,s2_out,s3_out,s4_out,
    output reg         done
);

    localparam [1:0] IDLE=2'd0, RUN=2'd1, FINISH=2'd2;

    reg [1:0]  state;
    reg [2:0]  sub_step;
    reg [3:0]  round_cnt, round_end;
    reg [63:0] x0,x1,x2,x3,x4;   // working state
    reg [63:0] p0,p1,p2,p3,p4;   // intermediate: parities, then rotations

    // Round constant decode
    reg [7:0] rc;
    always @(*) case(round_cnt)
        4'd0:rc=8'hf0; 4'd1:rc=8'he1; 4'd2:rc=8'hd2; 4'd3:rc=8'hc3;
        4'd4:rc=8'hb4; 4'd5:rc=8'ha5; 4'd6:rc=8'h96; 4'd7:rc=8'h87;
        4'd8:rc=8'h78; 4'd9:rc=8'h69; 4'd10:rc=8'h5a; 4'd11:rc=8'h4b;
        default:rc=8'h00;
    endcase

    always @(posedge clk or negedge rst_n) begin
        if(!rst_n) begin
            state<=IDLE; done<=0; sub_step<=0; round_cnt<=0; round_end<=0;
            x0<=0;x1<=0;x2<=0;x3<=0;x4<=0;
            p0<=0;p1<=0;p2<=0;p3<=0;p4<=0;
            s0_out<=0;s1_out<=0;s2_out<=0;s3_out<=0;s4_out<=0;
        end else case(state)
            IDLE: begin
                done<=0;
                if(start) begin
                    x0<=s0_in;x1<=s1_in;x2<=s2_in;x3<=s3_in;x4<=s4_in;
                    round_cnt<=start_round; round_end<=start_round+rounds;
                    sub_step<=0; state<=RUN;
                end
            end
            RUN: begin
                case(sub_step)
                    // CONST: XOR round constant into x2
                    3'd0: begin x2<=x2^{56'd0,rc}; sub_step<=1; end
                    // THETA_A: column parities stored into p-regs
                    3'd1: begin
                        p0<=x0^x1^x2^x3^x4; p1<=x1^x2^x3^x4^x0;
                        p2<=x2^x3^x4^x0^x1; p3<=x3^x4^x0^x1^x2;
                        p4<=x4^x0^x1^x2^x3; sub_step<=2;
                    end
                    // THETA_B: rotation-mixed parities, stored back into p-regs
                    3'd2: begin
                        p0<=p4^{p1[0],p1[63:1]};
                        p1<=p0^{p2[0],p2[63:1]};
                        p2<=p1^{p3[0],p3[63:1]};
                        p3<=p2^{p4[0],p4[63:1]};
                        p4<=p3^{p0[0],p0[63:1]};
                        sub_step<=3;
                    end
                    // THETA_C: apply theta (x = x XOR m)
                    3'd3: begin
                        x0<=x0^p0; x1<=x1^p1; x2<=x2^p2;
                        x3<=x3^p3; x4<=x4^p4; sub_step<=4;
                    end
                    // CHI1: AND-NOT, repurpose p-regs for u terms
                    3'd4: begin
                        p0<=~x1&x2; p1<=~x2&x3; p2<=~x3&x4;
                        p3<=~x4&x0; p4<=~x0&x1; sub_step<=5;
                    end
                    // CHI2: chi XOR, x2 inverted per ASCON spec
                    3'd5: begin
                        x0<=x0^p0; x1<=x1^p1; x2<=~(x2^p2);
                        x3<=x3^p3; x4<=x4^p4; sub_step<=6;
                    end
                    // LIN1: rotation operands — pack ra into p, rb into separate
                    // Store ra XOR rb directly to avoid extra registers:
                    // new_xi = xi ^ (xi rotated rA) ^ (xi rotated rB)
                    // We compute xi^ra first into p, then XOR rb in LIN2.
                    3'd6: begin
                        p0<=x0^{x0[18:0],x0[63:19]};
                        p1<=x1^{x1[60:0],x1[63:61]};
                        p2<=x2^{x2[0],   x2[63:1]};
                        p3<=x3^{x3[9:0], x3[63:10]};
                        p4<=x4^{x4[6:0], x4[63:7]};
                        sub_step<=7;
                    end
                    // LIN2: XOR second rotation (rb) to complete linear layer
                    3'd7: begin
                        x0<=p0^{x0[27:0],x0[63:28]};
                        x1<=p1^{x1[38:0],x1[63:39]};
                        x2<=p2^{x2[5:0], x2[63:6]};
                        x3<=p3^{x3[16:0],x3[63:17]};
                        x4<=p4^{x4[40:0],x4[63:41]};
                        sub_step<=0;
                        if(round_cnt < round_end-1) round_cnt<=round_cnt+1;
                        else state<=FINISH;
                    end
                    default: sub_step<=0;
                endcase
            end
            FINISH: begin
                s0_out<=x0;s1_out<=x1;s2_out<=x2;
                s3_out<=x3;s4_out<=x4; done<=1; state<=IDLE;
            end
            default: state<=IDLE;
        endcase
    end
endmodule
