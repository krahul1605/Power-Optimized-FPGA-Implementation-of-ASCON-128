#==============================================================================
# ASCON-128  ·  Variant: tapped
# SDC for Cadence Genus Synthesis
#
# Permutation architecture: Shift-register chain with rotating pointer.
#   Five state words stored in chain[0..4]. A 3-bit rot_ptr maps logical
#   word i to chain[(i+rot_ptr)%5] via a mod-5 decode. rot_ptr advances
#   by 1 mod 5 each round, rotating physical-to-logical assignment.
#
#   Four phases per round: SH_CONST(1), SH_THETA(1), SH_CHI(1), SH_LIN(1)
#   Critical path: SH_THETA — chain[*] -> 5-way indexed read -> XOR parity
#                  tree -> rotate -> apply -> chain[*]  (~10-12 gate levels)
#   Fmax target: 100 MHz / 10 ns
#
# Clocks per pa=12 : 12 × 4 + 1 = 49   Clocks per pb=6 : 6 × 4 + 1 = 25
#==============================================================================
create_clock -period 10.000 -name sys_clk -waveform {0.000 5.000} [get_ports clk_p]
set_clock_uncertainty -setup 0.200 [get_clocks sys_clk]
set_clock_uncertainty -hold  0.100 [get_clocks sys_clk]
set_clock_transition -rise 0.100 [get_clocks sys_clk]
set_clock_transition -fall 0.100 [get_clocks sys_clk]
set_input_delay -clock sys_clk -max 2.000 [get_ports rst_n]
set_input_delay -clock sys_clk -min 0.500 [get_ports rst_n]
set_input_delay -clock sys_clk -max 2.000 [get_ports start]
set_input_delay -clock sys_clk -min 0.500 [get_ports start]
set_output_delay -clock sys_clk -max 2.000 [get_ports done]
set_output_delay -clock sys_clk -min 0.500 [get_ports done]
set_output_delay -clock sys_clk -max 2.000 [get_ports tag_match]
set_output_delay -clock sys_clk -min 0.500 [get_ports tag_match]
set_output_delay -clock sys_clk -max 2.000 [get_ports led_done]
set_output_delay -clock sys_clk -min 0.500 [get_ports led_done]
set_output_delay -clock sys_clk -max 2.000 [get_ports led_tag_match]
set_output_delay -clock sys_clk -min 0.500 [get_ports led_tag_match]
set_output_delay -clock sys_clk -max 2.000 [get_ports led_running]
set_output_delay -clock sys_clk -min 0.500 [get_ports led_running]
set_output_delay -clock sys_clk -max 2.000 [get_ports led_error]
set_output_delay -clock sys_clk -min 0.500 [get_ports led_error]
set_false_path -from [get_ports rst_n]
#
# The 5-way indexed read mux (chain[tp(rot_ptr,i)]) adds ~1-2 LUT levels
# to the start of each phase's combinational path. At 100 MHz (10 ns period)
# this is well within budget (budget = 10.0 - 0.2 - 0.1 = 9.7 ns).
# The mod-5 decode for tp() is a small combinational block (~5 LUTs); Genus
# will typically absorb this into the read mux path.
#
set_driving_cell -lib_cell INVX1 -no_design_rule [get_ports {start rst_n}]
set_load 5.0 [get_ports {done tag_match led_done led_tag_match led_running led_error}]
# set_operating_conditions -library <lib> TYPICAL
#==============================================================================
# END - ascon128_tapped.sdc
#==============================================================================
