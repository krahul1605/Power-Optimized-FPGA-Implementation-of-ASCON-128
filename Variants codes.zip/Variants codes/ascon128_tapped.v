`timescale 1ns / 1ps
//=============================================================================
// ASCON-128  ·  Variant: tapped
//
// Visual treatment : Shift-register chain state storage — the five ASCON
//                    state words are stored in a 5-stage circular shift
//                    register. Each pipeline stage of the round computation
//                    "taps" a different position in the chain rather than
//                    reading from a fixed, centrally-addressed register file.
//
//                    State storage layout (shift chain, 5 positions):
//                      pos[0] = always the "current working" word
//                      pos[1..4] = the remaining four words in circular order
//
//                    Per-round execution (5 shift phases):
//
//     SH_CONST (1 cyc): XOR round constant into pos[2] (which holds x2 in
//                       the initial orientation). Shift chain advances: the
//                       word at pos[0] moves to pos[4], pos[1]->pos[0], etc.
//                       Actually, the chain is a barrel: rather than physically
//                       shifting all words, a 3-bit rotation pointer (rot_ptr)
//                       indexes which chain entry maps to which logical word.
//                       Constant is XORed into the entry pointed to by (rot_ptr+2)%5.
//
//     SH_THETA (1 cyc): Theta computed over all five chain entries using the
//                       rotation pointer to address them. Result replaces chain.
//
//     SH_CHI   (1 cyc): Chi computed. The chain entry at (rot_ptr+2)%5 is
//                       additionally inverted (ASCON spec for x2).
//
//     SH_LIN   (1 cyc): Linear diffusion applied per chain entry.
//                       After this phase, rot_ptr advances by 1 (rotating
//                       the logical-to-physical mapping for the next round).
//
//                    The structural novelty: state is NOT addressed by a fixed
//                    name (x0..x4) but by a rotating pointer into a chain
//                    array (chain[0..4]). The logical word "x_i" maps to
//                    chain[(i + rot_ptr) % 5]. This rotation changes every
//                    round, creating a different physical register assignment
//                    for the same logical word in each round — which has
//                    implications for power analysis (switching patterns
//                    spread across all 5 chain entries evenly over 5 rounds).
//
// Clocks per pa=12 call : 12 × 4 phases = 48 + 1 FINISH = 49
// Clocks per pb=6  call :  6 × 4 phases = 24 + 1 FINISH = 25
//
// Trade-offs
//   + Physical switching pattern rotates across chain entries — uniform power
//   + rot_ptr mod-5 counter is the only control overhead (3 bits)
//   + No mux wider than 5-way on 64b (for the constant and inversion taps)
//   + 4 cycles/round, same Fmax region as wavefront/retimed (~100 MHz)
//   - Logical-to-physical indexing requires modular addressing (5-way mux)
//   - Slightly more complex constant injection (rot_ptr offset computation)
//
// Functional parity: identical ports and FSM encoding to all variants.
//                    NIST-compliant ASCON-128 algorithm.
//=============================================================================

module ascon128_top (
    input  wire clk_p, clk_n, rst_n, start,
    output wire done, tag_match,
    output wire led_done, led_tag_match, led_running, led_error
);
    wire clk_ibuf, clk;
    IBUFDS #(.DIFF_TERM("FALSE"),.IBUF_LOW_PWR("FALSE"),.IOSTANDARD("LVDS"))
        clk_ibufds(.I(clk_p),.IB(clk_n),.O(clk_ibuf));
    BUFG clk_bufg(.I(clk_ibuf),.O(clk));
    wire core_done, core_tag_match;
    reg  running_r;
    ascon128_complete_tapped ascon_core(.clk(clk),.rst_n(rst_n),.start(start),
        .done(core_done),.tag_match(core_tag_match));
    assign done=core_done; assign tag_match=core_tag_match;
    always @(posedge clk or negedge rst_n)
        if(!rst_n) running_r<=0;
        else if(start) running_r<=1;
        else if(core_done) running_r<=0;
    assign led_done=core_done; assign led_tag_match=core_done&core_tag_match;
    assign led_running=running_r; assign led_error=core_done&~core_tag_match;
endmodule

module ascon128_complete_tapped (
    input  wire clk, rst_n, start,
    output reg  done, tag_match
);
    localparam [127:0] KEY   = 128'h0F1E2D3C4B5A69788796A5B4C3D2E1F0;
    localparam [127:0] NONCE = 128'hFFEEDDCCBBAA99887766554433221100;
    localparam [191:0] PT_PADDED  = 192'h46696E616C20596561722050726F6A656374204152418000;
    localparam         PT_BLOCKS  = 3;
    localparam [63:0]  AAD_PADDED = 64'h64656D6F41414480;
    localparam [63:0]  IV         = 64'h80400c0600000000;
    localparam [4:0]
        ST_IDLE=0,ST_ENC_INIT=1,ST_ENC_INIT_PERM=2,ST_ENC_AAD=3,ST_ENC_AAD_PERM=4,
        ST_ENC_AAD_DOM=5,ST_ENC_PT=6,ST_ENC_PT_PERM=7,ST_ENC_FINAL=8,ST_ENC_FINAL_W=9,
        ST_TAG_STORE=10,ST_DEC_INIT=11,ST_DEC_INIT_PERM=12,ST_DEC_AAD=13,
        ST_DEC_AAD_PERM=14,ST_DEC_AAD_DOM=15,ST_DEC_CT=16,ST_DEC_CT_PERM=17,
        ST_DEC_FINAL=18,ST_DEC_FINAL_W=19,ST_DONE=20;
    reg [4:0] state; reg [3:0] block_idx;
    reg [63:0] s0,s1,s2,s3,s4;
    reg [191:0] ciphertext; reg [127:0] tag_enc; reg [191:0] plaintext_dec;
    reg perm_start; wire perm_done;
    reg [3:0] perm_start_round, perm_num_rounds;
    wire [63:0] perm_out0,perm_out1,perm_out2,perm_out3,perm_out4;
    ascon_perm_tapped perm_inst(
        .clk(clk),.rst_n(rst_n),.start(perm_start),
        .start_round(perm_start_round),.rounds(perm_num_rounds),
        .s0_in(s0),.s1_in(s1),.s2_in(s2),.s3_in(s3),.s4_in(s4),
        .s0_out(perm_out0),.s1_out(perm_out1),.s2_out(perm_out2),
        .s3_out(perm_out3),.s4_out(perm_out4),.done(perm_done));
    always @(posedge clk or negedge rst_n) begin
        if(!rst_n) begin
            state<=0;done<=0;tag_match<=0;perm_start<=0;
            perm_start_round<=0;perm_num_rounds<=0;block_idx<=0;
            s0<=0;s1<=0;s2<=0;s3<=0;s4<=0;ciphertext<=0;tag_enc<=0;plaintext_dec<=0;
        end else begin
            perm_start<=0;
            case(state)
                ST_IDLE: begin done<=0;tag_match<=0;if(start) state<=ST_ENC_INIT; end
                ST_ENC_INIT: begin s0<=IV;s1<=KEY[127:64];s2<=KEY[63:0];s3<=NONCE[127:64];s4<=NONCE[63:0];
                    perm_start_round<=0;perm_num_rounds<=12;perm_start<=1;state<=ST_ENC_INIT_PERM; end
                ST_ENC_INIT_PERM: if(perm_done) begin s0<=perm_out0;s1<=perm_out1;s2<=perm_out2;
                    s3<=perm_out3^KEY[127:64];s4<=perm_out4^KEY[63:0];state<=ST_ENC_AAD; end
                ST_ENC_AAD: begin s0<=s0^AAD_PADDED;perm_start_round<=6;perm_num_rounds<=6;
                    perm_start<=1;state<=ST_ENC_AAD_PERM; end
                ST_ENC_AAD_PERM: if(perm_done) begin s0<=perm_out0;s1<=perm_out1;s2<=perm_out2;
                    s3<=perm_out3;s4<=perm_out4;state<=ST_ENC_AAD_DOM; end
                ST_ENC_AAD_DOM: begin s4<=s4^64'h1;block_idx<=0;state<=ST_ENC_PT; end
                ST_ENC_PT: begin
                    if(block_idx<PT_BLOCKS) begin
                        ciphertext[191-block_idx*64-:64]<=s0^PT_PADDED[191-block_idx*64-:64];
                        s0<=s0^PT_PADDED[191-block_idx*64-:64];
                        if(block_idx<PT_BLOCKS-1) begin perm_start_round<=6;perm_num_rounds<=6;
                            perm_start<=1;block_idx<=block_idx+1;state<=ST_ENC_PT_PERM;
                        end else state<=ST_ENC_FINAL;
                    end else state<=ST_ENC_FINAL; end
                ST_ENC_PT_PERM: if(perm_done) begin s0<=perm_out0;s1<=perm_out1;s2<=perm_out2;
                    s3<=perm_out3;s4<=perm_out4;state<=ST_ENC_PT; end
                ST_ENC_FINAL: begin s1<=s1^KEY[127:64];s2<=s2^KEY[63:0];
                    perm_start_round<=0;perm_num_rounds<=12;perm_start<=1;state<=ST_ENC_FINAL_W; end
                ST_ENC_FINAL_W: if(perm_done) begin tag_enc<={perm_out3^KEY[127:64],perm_out4^KEY[63:0]};
                    state<=ST_TAG_STORE; end
                ST_TAG_STORE: state<=ST_DEC_INIT;
                ST_DEC_INIT: begin s0<=IV;s1<=KEY[127:64];s2<=KEY[63:0];s3<=NONCE[127:64];s4<=NONCE[63:0];
                    perm_start_round<=0;perm_num_rounds<=12;perm_start<=1;state<=ST_DEC_INIT_PERM; end
                ST_DEC_INIT_PERM: if(perm_done) begin s0<=perm_out0;s1<=perm_out1;s2<=perm_out2;
                    s3<=perm_out3^KEY[127:64];s4<=perm_out4^KEY[63:0];state<=ST_DEC_AAD; end
                ST_DEC_AAD: begin s0<=s0^AAD_PADDED;perm_start_round<=6;perm_num_rounds<=6;
                    perm_start<=1;state<=ST_DEC_AAD_PERM; end
                ST_DEC_AAD_PERM: if(perm_done) begin s0<=perm_out0;s1<=perm_out1;s2<=perm_out2;
                    s3<=perm_out3;s4<=perm_out4;state<=ST_DEC_AAD_DOM; end
                ST_DEC_AAD_DOM: begin s4<=s4^64'h1;block_idx<=0;state<=ST_DEC_CT; end
                ST_DEC_CT: begin
                    if(block_idx<PT_BLOCKS) begin
                        plaintext_dec[191-block_idx*64-:64]<=s0^ciphertext[191-block_idx*64-:64];
                        s0<=ciphertext[191-block_idx*64-:64];
                        if(block_idx<PT_BLOCKS-1) begin perm_start_round<=6;perm_num_rounds<=6;
                            perm_start<=1;block_idx<=block_idx+1;state<=ST_DEC_CT_PERM;
                        end else state<=ST_DEC_FINAL;
                    end else state<=ST_DEC_FINAL; end
                ST_DEC_CT_PERM: if(perm_done) begin s0<=perm_out0;s1<=perm_out1;s2<=perm_out2;
                    s3<=perm_out3;s4<=perm_out4;state<=ST_DEC_CT; end
                ST_DEC_FINAL: begin s1<=s1^KEY[127:64];s2<=s2^KEY[63:0];
                    perm_start_round<=0;perm_num_rounds<=12;perm_start<=1;state<=ST_DEC_FINAL_W; end
                ST_DEC_FINAL_W: if(perm_done) begin
                    tag_match<=(tag_enc=={perm_out3^KEY[127:64],perm_out4^KEY[63:0]});
                    done<=1;state<=ST_DONE; end
                ST_DONE: ;
                default: state<=ST_IDLE;
            endcase
        end
    end
endmodule

//=============================================================================
// ascon_perm_tapped
//
// Shift-register chain with rotating pointer for physical word assignment.
//
// State storage: chain[0..4] — five 64-bit registers forming a circular chain.
// Rotation pointer: rot_ptr[2:0] — maps logical word i to chain[(i+rot_ptr)%5].
//
// Logical-to-physical mapping:
//   logical x_i  ->  chain[(i + rot_ptr) % 5]
//
// Helper function tp(i): returns physical chain index for logical word i.
//   tp(0) = rot_ptr % 5
//   tp(1) = (rot_ptr+1) % 5
//   tp(2) = (rot_ptr+2) % 5
//   tp(3) = (rot_ptr+3) % 5
//   tp(4) = (rot_ptr+4) % 5
//
// Since rot_ptr is 0..4 and increments by 1 each round (mod 5),
// we implement the 5-way modular address as a direct comparison decode.
//
// Phases per round (4):
//   SH_CONST: chain[tp(2)] ^= {56'd0, rc}      (tap position 2)
//   SH_THETA: full Theta over chain[], addressed by tp()
//   SH_CHI  : full Chi; chain[tp(2)] also inverted
//   SH_LIN  : full Linear; then rot_ptr = (rot_ptr+1)%5
//
// Round constant decode uses round_cnt (unchanged from all variants).
// Fmax target: 100 MHz / 10 ns (Theta phase bottleneck)
//=============================================================================
module ascon_perm_tapped (
    input  wire        clk, rst_n, start,
    input  wire [3:0]  start_round, rounds,
    input  wire [63:0] s0_in,s1_in,s2_in,s3_in,s4_in,
    output reg  [63:0] s0_out,s1_out,s2_out,s3_out,s4_out,
    output reg         done
);
    localparam [1:0] IDLE=2'd0, RUN=2'd1, FINISH=2'd2;
    localparam [1:0] SH_CONST=2'd0, SH_THETA=2'd1, SH_CHI=2'd2, SH_LIN=2'd3;

    reg [1:0] state, sh_phase;
    reg [2:0] rot_ptr;           // rotation pointer: 0..4
    reg [3:0] round_cnt, round_end;

    // Chain storage — five 64-bit registers
    reg [63:0] chain[0:4];

    // Round constant
    reg [7:0] rc;
    always @(*) case(round_cnt)
        4'd0:rc=8'hf0; 4'd1:rc=8'he1; 4'd2:rc=8'hd2; 4'd3:rc=8'hc3;
        4'd4:rc=8'hb4; 4'd5:rc=8'ha5; 4'd6:rc=8'h96; 4'd7:rc=8'h87;
        4'd8:rc=8'h78; 4'd9:rc=8'h69; 4'd10:rc=8'h5a; 4'd11:rc=8'h4b;
        default:rc=8'h00;
    endcase

    // -------------------------------------------------------------------------
    // Physical index computation via mod-5 decode
    // tp(offset) = (rot_ptr + offset) mod 5
    // -------------------------------------------------------------------------
    function [2:0] tp;
        input [2:0] base;
        input [2:0] offset;
        reg [3:0] sum;
        begin
            sum = base + offset;
            if(sum >= 5) tp = sum - 3'd5;
            else         tp = sum[2:0];
        end
    endfunction

    // -------------------------------------------------------------------------
    // Read helpers — logical word i = chain[tp(rot_ptr, i)]
    // -------------------------------------------------------------------------
    wire [63:0] lx0 = chain[tp(rot_ptr, 3'd0)];
    wire [63:0] lx1 = chain[tp(rot_ptr, 3'd1)];
    wire [63:0] lx2 = chain[tp(rot_ptr, 3'd2)];
    wire [63:0] lx3 = chain[tp(rot_ptr, 3'd3)];
    wire [63:0] lx4 = chain[tp(rot_ptr, 3'd4)];

    // -------------------------------------------------------------------------
    // Theta combinational cone (driven from lx*)
    // -------------------------------------------------------------------------
    wire [63:0] tp0_w=lx0^lx1^lx2^lx3^lx4;
    wire [63:0] tp1_w=lx1^lx2^lx3^lx4^lx0;
    wire [63:0] tp2_w=lx2^lx3^lx4^lx0^lx1;
    wire [63:0] tp3_w=lx3^lx4^lx0^lx1^lx2;
    wire [63:0] tp4_w=lx4^lx0^lx1^lx2^lx3;
    wire [63:0] tm0_w=tp4_w^{tp1_w[0],tp1_w[63:1]};
    wire [63:0] tm1_w=tp0_w^{tp2_w[0],tp2_w[63:1]};
    wire [63:0] tm2_w=tp1_w^{tp3_w[0],tp3_w[63:1]};
    wire [63:0] tm3_w=tp2_w^{tp4_w[0],tp4_w[63:1]};
    wire [63:0] tm4_w=tp3_w^{tp0_w[0],tp0_w[63:1]};
    wire [63:0] tt0_w=lx0^tm0_w, tt1_w=lx1^tm1_w, tt2_w=lx2^tm2_w;
    wire [63:0] tt3_w=lx3^tm3_w, tt4_w=lx4^tm4_w;

    // -------------------------------------------------------------------------
    // Chi combinational cone (driven from lx*, post-theta)
    // -------------------------------------------------------------------------
    wire [63:0] tc0_w=lx0^(~lx1&lx2);
    wire [63:0] tc1_w=lx1^(~lx2&lx3);
    wire [63:0] tc2_w=~(lx2^(~lx3&lx4));
    wire [63:0] tc3_w=lx3^(~lx4&lx0);
    wire [63:0] tc4_w=lx4^(~lx0&lx1);

    // -------------------------------------------------------------------------
    // Linear combinational cone (driven from lx*, post-chi)
    // -------------------------------------------------------------------------
    wire [63:0] tl0_w=lx0^{lx0[18:0],lx0[63:19]}^{lx0[27:0],lx0[63:28]};
    wire [63:0] tl1_w=lx1^{lx1[60:0],lx1[63:61]}^{lx1[38:0],lx1[63:39]};
    wire [63:0] tl2_w=lx2^{lx2[0],   lx2[63:1]} ^{lx2[5:0], lx2[63:6]};
    wire [63:0] tl3_w=lx3^{lx3[9:0], lx3[63:10]}^{lx3[16:0],lx3[63:17]};
    wire [63:0] tl4_w=lx4^{lx4[6:0], lx4[63:7]} ^{lx4[40:0],lx4[63:41]};

    integer i;
    always @(posedge clk or negedge rst_n) begin
        if(!rst_n) begin
            state<=IDLE; done<=0; sh_phase<=SH_CONST; rot_ptr<=0;
            round_cnt<=0; round_end<=0;
            for(i=0;i<5;i=i+1) chain[i]<=0;
            s0_out<=0;s1_out<=0;s2_out<=0;s3_out<=0;s4_out<=0;
        end else case(state)
            IDLE: begin
                done<=0;
                if(start) begin
                    // Load input into chain starting at rot_ptr=0 (chain[i] = s_i)
                    chain[0]<=s0_in; chain[1]<=s1_in; chain[2]<=s2_in;
                    chain[3]<=s3_in; chain[4]<=s4_in;
                    rot_ptr<=3'd0;
                    round_cnt<=start_round; round_end<=start_round+rounds;
                    sh_phase<=SH_CONST; state<=RUN;
                end
            end
            RUN: begin
                case(sh_phase)
                    // Apply round constant to the chain entry holding logical x2
                    SH_CONST: begin
                        chain[tp(rot_ptr,3'd2)] <= chain[tp(rot_ptr,3'd2)] ^ {56'd0,rc};
                        sh_phase <= SH_THETA;
                    end
                    // Theta: write results back to all five chain positions
                    SH_THETA: begin
                        chain[tp(rot_ptr,3'd0)] <= tt0_w;
                        chain[tp(rot_ptr,3'd1)] <= tt1_w;
                        chain[tp(rot_ptr,3'd2)] <= tt2_w;
                        chain[tp(rot_ptr,3'd3)] <= tt3_w;
                        chain[tp(rot_ptr,3'd4)] <= tt4_w;
                        sh_phase <= SH_CHI;
                    end
                    // Chi: write results back; lx2 result already inverted in tc2_w
                    SH_CHI: begin
                        chain[tp(rot_ptr,3'd0)] <= tc0_w;
                        chain[tp(rot_ptr,3'd1)] <= tc1_w;
                        chain[tp(rot_ptr,3'd2)] <= tc2_w;
                        chain[tp(rot_ptr,3'd3)] <= tc3_w;
                        chain[tp(rot_ptr,3'd4)] <= tc4_w;
                        sh_phase <= SH_LIN;
                    end
                    // Linear: write results; advance rot_ptr by 1 mod 5
                    SH_LIN: begin
                        chain[tp(rot_ptr,3'd0)] <= tl0_w;
                        chain[tp(rot_ptr,3'd1)] <= tl1_w;
                        chain[tp(rot_ptr,3'd2)] <= tl2_w;
                        chain[tp(rot_ptr,3'd3)] <= tl3_w;
                        chain[tp(rot_ptr,3'd4)] <= tl4_w;
                        // Advance rotation pointer mod 5
                        rot_ptr <= (rot_ptr == 3'd4) ? 3'd0 : rot_ptr + 3'd1;
                        sh_phase <= SH_CONST;
                        if(round_cnt < round_end-1) round_cnt <= round_cnt+1;
                        else state <= FINISH;
                    end
                    default: sh_phase <= SH_CONST;
                endcase
            end
            FINISH: begin
                // Output logical words via current rot_ptr mapping
                s0_out<=chain[tp(rot_ptr,3'd0)];
                s1_out<=chain[tp(rot_ptr,3'd1)];
                s2_out<=chain[tp(rot_ptr,3'd2)];
                s3_out<=chain[tp(rot_ptr,3'd3)];
                s4_out<=chain[tp(rot_ptr,3'd4)];
                done<=1; state<=IDLE;
            end
            default: state<=IDLE;
        endcase
    end
endmodule
