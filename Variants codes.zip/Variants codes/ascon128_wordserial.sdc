#==============================================================================
# SDC Constraints — ascon128_wordserial
# Target : Cadence Genus / Innovus
# Period : 10 ns  →  100 MHz
#
# Rationale
# ---------
# The wordserial variant processes one 64-bit Chi column per clock cycle.
# The critical path per cycle is:
#
#   s*_reg (5 × 64 bits read) → rc mux (word 2 only) → Chi column mux
#     → chi_buf write OR lin* → s*_reg
#
# Stages:
#   s* → chi_result mux [~2 levels] → chi_buf_N register : ~2 levels total
#   chi_buf → linear [~5 levels] → s*_reg                : ~5 levels total
#   (worst case at wi=4 when Linear is applied)
#
# At wi=4: s* reads + chi4 computation + lin4 application = ~7-9 gate levels
# At ~0.65 ns/level: ~5.5 ns, leaving 4.5 ns margin → conservative 10 ns period
#
# The 5-word read bus (320 bits) fans out to all 5 Chi units simultaneously.
# Fanout on s* outputs is the primary constraint — each drives 5 Chi AND gates.
#==============================================================================

#-- Primary clock
create_clock -name clk -period 10.000 [get_ports clk_p]
set_clock_uncertainty 0.15 [get_clocks clk]

#-- Input/output timing
set_input_delay  -clock clk -max 0.5 [get_ports {rst_n start}]
set_output_delay -clock clk -max 1.0 [get_ports {done tag_match led_*}]

#-- Fanout control on state read bus
# Each of s0..s4 (64 bits each) drives up to 5 Chi AND/XOR units = 320 loads
# This is the main timing risk — synthesis must buffer these nets.
set_max_fanout 20 [get_nets {s0[*] s1[*] s2[*] s3[*] s4[*]}]

#-- Fanout on round constant select (round_start + round_cnt → rc mux)
set_max_fanout 8  [get_nets {round_cnt[*] round_start[*]}]

#-- Fanout on word_idx counter (drives 5-way Chi result mux)
set_max_fanout 8  [get_nets {word_idx[*]}]

#-- Multicycle path: chi_buf registers are written at wi=0..3 and read
# at wi=4 (one round later, same round_cnt) — this is a same-clock-domain
# single-cycle path, no multicycle annotation needed.
# However: chi_buf4 is written and read in the SAME cycle (wi=4):
#   chi_buf4 <= chi_result   (reg write)
#   lin4 uses chi_result directly (combinational bypass)
# Genus must see chi_buf4 as a registered output only; lin4 uses chi_result.
# If synthesis inserts chi_buf4 into the lin4 path, flag it:
set_dont_retime [get_cells {chi_buf4_reg}] false
# (Allow retiming of chi_buf4 — it will not introduce a cycle since linear
#  uses chi_result wire, not chi_buf4 register output, at wi=4.)

#-- Load/drive
set_load  5.0 [get_ports {done tag_match led_done led_tag_match led_running led_error}]
set_drive 1.0 [get_ports {clk_p clk_n rst_n start}]

#-- False paths
set_false_path -from [get_ports rst_n]
set_false_path -to   [get_ports led_*]

#-- Operating conditions
set_operating_conditions -max_library slow -max slow
