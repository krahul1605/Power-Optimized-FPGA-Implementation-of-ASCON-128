`timescale 1ns / 1ps
//=============================================================================
// ASCON-128  ·  Variant: rotary
//
// Visual treatment : Rotary word-order permutation — the five ASCON state
//                    words are stored in a register file that is logically
//                    rotated by one position after every complete round.
//                    Instead of fixed registers x0..x4, the state is stored
//                    in a 5-entry register file (rf[0..4]), and a 3-bit
//                    word-rotation counter (wrot) maps logical positions to
//                    physical entries. After each round, wrot increments
//                    mod-5, shifting the entire word order by one position.
//
//                    Logical-to-physical mapping:
//                      Logical x_i  =>  rf[(i + wrot) % 5]
//
//                    The rotation means that after round R:
//                      - wrot = R mod 5
//                      - The physical register rf[0] holds logical word (5-R)%5
//                      - Each round starts with a different word "at the front"
//
//                    The ASCON round function itself is WORD-ORDER INVARIANT
//                    in the following sense: permuting which register holds
//                    which word does NOT change the mathematical result as
//                    long as we consistently address all words by their
//                    LOGICAL index (i) rather than physical index. The rotary
//                    variant simply changes the physical-to-logical mapping
//                    each round — the mathematics are identical to all other
//                    variants.
//
//                    The combinational round logic always reads logical x_i
//                    from rf[(i+wrot)%5] and writes logical result back to
//                    rf[(i+wrot)%5]. The round constant is always applied to
//                    logical x2, which lives at rf[(2+wrot)%5].
//
//                    Structural novelty vs. tapped:
//                      - tapped: 4 phases/round (CONST, THETA, CHI, LIN)
//                        with rot_ptr advancing inside the permutation
//                      - rotary: 1 cycle/round (full round per cycle, like
//                        baseline), but the WORD ROTATION changes which
//                        physical register maps to which logical word.
//                        The rotation happens BETWEEN rounds, not within.
//
// Clocks per pa=12 call : 12 rounds × 1 cycle = 12 + 1 FINISH = 13
// Clocks per pb=6  call :  6 rounds × 1 cycle =  6 + 1 FINISH =  7
//
// Trade-offs
//   + Same 1-cycle-per-round latency as baseline (13/7 clocks)
//   + Physical register utilization spreads across all 5 rf entries evenly
//   + wrot adds 5-way indexed reads (1-2 LUT levels) vs. fixed names
//   - Critical path: full round cone + 5-way indexed read/write (~36-47 levels)
//   - mod-5 rotation logic for wrot adds ~5 LUTs (small overhead)
//   - Fmax slightly lower than baseline due to 5-way mux on read path
//     Target: 22 MHz / 45 ns
//=============================================================================

module ascon128_top (
    input  wire clk_p, clk_n, rst_n, start,
    output wire done, tag_match,
    output wire led_done, led_tag_match, led_running, led_error
);
    wire clk_ibuf, clk;
    IBUFDS #(.DIFF_TERM("FALSE"),.IBUF_LOW_PWR("FALSE"),.IOSTANDARD("LVDS"))
        clk_ibufds(.I(clk_p),.IB(clk_n),.O(clk_ibuf));
    BUFG clk_bufg(.I(clk_ibuf),.O(clk));
    wire core_done, core_tag_match;
    reg  running_r;
    ascon128_complete_rotary ascon_core(.clk(clk),.rst_n(rst_n),.start(start),
        .done(core_done),.tag_match(core_tag_match));
    assign done=core_done; assign tag_match=core_tag_match;
    always @(posedge clk or negedge rst_n)
        if(!rst_n) running_r<=0;
        else if(start) running_r<=1;
        else if(core_done) running_r<=0;
    assign led_done=core_done; assign led_tag_match=core_done&core_tag_match;
    assign led_running=running_r; assign led_error=core_done&~core_tag_match;
endmodule

module ascon128_complete_rotary (
    input  wire clk, rst_n, start,
    output reg  done, tag_match
);
    localparam [127:0] KEY   = 128'h0F1E2D3C4B5A69788796A5B4C3D2E1F0;
    localparam [127:0] NONCE = 128'hFFEEDDCCBBAA99887766554433221100;
    localparam [191:0] PT_PADDED  = 192'h46696E616C20596561722050726F6A656374204152418000;
    localparam         PT_BLOCKS  = 3;
    localparam [63:0]  AAD_PADDED = 64'h64656D6F41414480;
    localparam [63:0]  IV         = 64'h80400c0600000000;
    localparam [4:0]
        ST_IDLE=0,ST_ENC_INIT=1,ST_ENC_INIT_PERM=2,ST_ENC_AAD=3,ST_ENC_AAD_PERM=4,
        ST_ENC_AAD_DOM=5,ST_ENC_PT=6,ST_ENC_PT_PERM=7,ST_ENC_FINAL=8,ST_ENC_FINAL_W=9,
        ST_TAG_STORE=10,ST_DEC_INIT=11,ST_DEC_INIT_PERM=12,ST_DEC_AAD=13,
        ST_DEC_AAD_PERM=14,ST_DEC_AAD_DOM=15,ST_DEC_CT=16,ST_DEC_CT_PERM=17,
        ST_DEC_FINAL=18,ST_DEC_FINAL_W=19,ST_DONE=20;
    reg [4:0] state; reg [3:0] block_idx;
    reg [63:0] s0,s1,s2,s3,s4;
    reg [191:0] ciphertext; reg [127:0] tag_enc; reg [191:0] plaintext_dec;
    reg perm_start; wire perm_done;
    reg [3:0] perm_start_round, perm_num_rounds;
    wire [63:0] perm_out0,perm_out1,perm_out2,perm_out3,perm_out4;
    ascon_perm_rotary perm_inst(
        .clk(clk),.rst_n(rst_n),.start(perm_start),
        .start_round(perm_start_round),.rounds(perm_num_rounds),
        .s0_in(s0),.s1_in(s1),.s2_in(s2),.s3_in(s3),.s4_in(s4),
        .s0_out(perm_out0),.s1_out(perm_out1),.s2_out(perm_out2),
        .s3_out(perm_out3),.s4_out(perm_out4),.done(perm_done));
    always @(posedge clk or negedge rst_n) begin
        if(!rst_n) begin
            state<=0;done<=0;tag_match<=0;perm_start<=0;
            perm_start_round<=0;perm_num_rounds<=0;block_idx<=0;
            s0<=0;s1<=0;s2<=0;s3<=0;s4<=0;ciphertext<=0;tag_enc<=0;plaintext_dec<=0;
        end else begin
            perm_start<=0;
            case(state)
                ST_IDLE: begin done<=0;tag_match<=0;if(start) state<=ST_ENC_INIT; end
                ST_ENC_INIT: begin s0<=IV;s1<=KEY[127:64];s2<=KEY[63:0];s3<=NONCE[127:64];s4<=NONCE[63:0];
                    perm_start_round<=0;perm_num_rounds<=12;perm_start<=1;state<=ST_ENC_INIT_PERM; end
                ST_ENC_INIT_PERM: if(perm_done) begin s0<=perm_out0;s1<=perm_out1;s2<=perm_out2;
                    s3<=perm_out3^KEY[127:64];s4<=perm_out4^KEY[63:0];state<=ST_ENC_AAD; end
                ST_ENC_AAD: begin s0<=s0^AAD_PADDED;perm_start_round<=6;perm_num_rounds<=6;
                    perm_start<=1;state<=ST_ENC_AAD_PERM; end
                ST_ENC_AAD_PERM: if(perm_done) begin s0<=perm_out0;s1<=perm_out1;s2<=perm_out2;
                    s3<=perm_out3;s4<=perm_out4;state<=ST_ENC_AAD_DOM; end
                ST_ENC_AAD_DOM: begin s4<=s4^64'h1;block_idx<=0;state<=ST_ENC_PT; end
                ST_ENC_PT: begin
                    if(block_idx<PT_BLOCKS) begin
                        ciphertext[191-block_idx*64-:64]<=s0^PT_PADDED[191-block_idx*64-:64];
                        s0<=s0^PT_PADDED[191-block_idx*64-:64];
                        if(block_idx<PT_BLOCKS-1) begin perm_start_round<=6;perm_num_rounds<=6;
                            perm_start<=1;block_idx<=block_idx+1;state<=ST_ENC_PT_PERM;
                        end else state<=ST_ENC_FINAL;
                    end else state<=ST_ENC_FINAL; end
                ST_ENC_PT_PERM: if(perm_done) begin s0<=perm_out0;s1<=perm_out1;s2<=perm_out2;
                    s3<=perm_out3;s4<=perm_out4;state<=ST_ENC_PT; end
                ST_ENC_FINAL: begin s1<=s1^KEY[127:64];s2<=s2^KEY[63:0];
                    perm_start_round<=0;perm_num_rounds<=12;perm_start<=1;state<=ST_ENC_FINAL_W; end
                ST_ENC_FINAL_W: if(perm_done) begin tag_enc<={perm_out3^KEY[127:64],perm_out4^KEY[63:0]};
                    state<=ST_TAG_STORE; end
                ST_TAG_STORE: state<=ST_DEC_INIT;
                ST_DEC_INIT: begin s0<=IV;s1<=KEY[127:64];s2<=KEY[63:0];s3<=NONCE[127:64];s4<=NONCE[63:0];
                    perm_start_round<=0;perm_num_rounds<=12;perm_start<=1;state<=ST_DEC_INIT_PERM; end
                ST_DEC_INIT_PERM: if(perm_done) begin s0<=perm_out0;s1<=perm_out1;s2<=perm_out2;
                    s3<=perm_out3^KEY[127:64];s4<=perm_out4^KEY[63:0];state<=ST_DEC_AAD; end
                ST_DEC_AAD: begin s0<=s0^AAD_PADDED;perm_start_round<=6;perm_num_rounds<=6;
                    perm_start<=1;state<=ST_DEC_AAD_PERM; end
                ST_DEC_AAD_PERM: if(perm_done) begin s0<=perm_out0;s1<=perm_out1;s2<=perm_out2;
                    s3<=perm_out3;s4<=perm_out4;state<=ST_DEC_AAD_DOM; end
                ST_DEC_AAD_DOM: begin s4<=s4^64'h1;block_idx<=0;state<=ST_DEC_CT; end
                ST_DEC_CT: begin
                    if(block_idx<PT_BLOCKS) begin
                        plaintext_dec[191-block_idx*64-:64]<=s0^ciphertext[191-block_idx*64-:64];
                        s0<=ciphertext[191-block_idx*64-:64];
                        if(block_idx<PT_BLOCKS-1) begin perm_start_round<=6;perm_num_rounds<=6;
                            perm_start<=1;block_idx<=block_idx+1;state<=ST_DEC_CT_PERM;
                        end else state<=ST_DEC_FINAL;
                    end else state<=ST_DEC_FINAL; end
                ST_DEC_CT_PERM: if(perm_done) begin s0<=perm_out0;s1<=perm_out1;s2<=perm_out2;
                    s3<=perm_out3;s4<=perm_out4;state<=ST_DEC_CT; end
                ST_DEC_FINAL: begin s1<=s1^KEY[127:64];s2<=s2^KEY[63:0];
                    perm_start_round<=0;perm_num_rounds<=12;perm_start<=1;state<=ST_DEC_FINAL_W; end
                ST_DEC_FINAL_W: if(perm_done) begin
                    tag_match<=(tag_enc=={perm_out3^KEY[127:64],perm_out4^KEY[63:0]});
                    done<=1;state<=ST_DONE; end
                ST_DONE: ;
                default: state<=ST_IDLE;
            endcase
        end
    end
endmodule

//=============================================================================
// ascon_perm_rotary
//
// 5-entry register file (rf[0..4]) + 3-bit word-rotation counter (wrot).
// Logical word i  →  physical rf[(i + wrot) % 5].
//
// After each round, wrot = (wrot + 1) % 5.
// This rotates the logical-to-physical mapping by one position each round,
// so over 5 rounds every logical word has been in every physical slot.
//
// Round logic: identical to baseline, but all reads/writes go through
// the wrot-indexed 5-way mux.
//
// wrot mod-5 helper: implemented as a combinational comparator chain.
// The 5-way indexed read is the only structural difference vs. baseline.
//=============================================================================
module ascon_perm_rotary (
    input  wire        clk, rst_n, start,
    input  wire [3:0]  start_round, rounds,
    input  wire [63:0] s0_in,s1_in,s2_in,s3_in,s4_in,
    output reg  [63:0] s0_out,s1_out,s2_out,s3_out,s4_out,
    output reg         done
);
    localparam [1:0] IDLE=2'd0, RUN=2'd1, FINISH=2'd2;

    reg [1:0] state;
    reg [2:0] wrot;           // 0..4
    reg [3:0] round_cnt, round_end;

    // Physical register file
    reg [63:0] rf[0:4];

    reg [7:0] rc;
    always @(*) case(round_cnt)
        4'd0:rc=8'hf0; 4'd1:rc=8'he1; 4'd2:rc=8'hd2; 4'd3:rc=8'hc3;
        4'd4:rc=8'hb4; 4'd5:rc=8'ha5; 4'd6:rc=8'h96; 4'd7:rc=8'h87;
        4'd8:rc=8'h78; 4'd9:rc=8'h69; 4'd10:rc=8'h5a; 4'd11:rc=8'h4b;
        default:rc=8'h00;
    endcase

    // mod-5 address function: returns (base + offset) % 5
    function [2:0] m5;
        input [2:0] base;
        input [2:0] off;
        reg [3:0] s;
        begin s = base + off; if(s >= 5) m5 = s - 3'd5; else m5 = s[2:0]; end
    endfunction

    // Logical word reads via wrot-indexed mux
    wire [63:0] lx0 = rf[m5(wrot,3'd0)];
    wire [63:0] lx1 = rf[m5(wrot,3'd1)];
    wire [63:0] lx2 = rf[m5(wrot,3'd2)];
    wire [63:0] lx3 = rf[m5(wrot,3'd3)];
    wire [63:0] lx4 = rf[m5(wrot,3'd4)];

    // Full round cone on logical words
    wire [63:0] c0=lx0,c1=lx1,c2=lx2^{56'd0,rc},c3=lx3,c4=lx4;
    wire [63:0] p0=c0^c1^c2^c3^c4,p1=c1^c2^c3^c4^c0;
    wire [63:0] p2=c2^c3^c4^c0^c1,p3=c3^c4^c0^c1^c2,p4=c4^c0^c1^c2^c3;
    wire [63:0] m0=p4^{p1[0],p1[63:1]},m1=p0^{p2[0],p2[63:1]};
    wire [63:0] m2=p1^{p3[0],p3[63:1]},m3=p2^{p4[0],p4[63:1]};
    wire [63:0] m4=p3^{p0[0],p0[63:1]};
    wire [63:0] t0=c0^m0,t1=c1^m1,t2=c2^m2,t3=c3^m3,t4=c4^m4;
    wire [63:0] u0=~t1&t2,u1=~t2&t3,u2=~t3&t4,u3=~t4&t0,u4=~t0&t1;
    wire [63:0] v0=t0^u0,v1=t1^u1,v2=~(t2^u2),v3=t3^u3,v4=t4^u4;
    wire [63:0] ra0={v0[18:0],v0[63:19]},rb0={v0[27:0],v0[63:28]};
    wire [63:0] ra1={v1[60:0],v1[63:61]},rb1={v1[38:0],v1[63:39]};
    wire [63:0] ra2={v2[0],   v2[63:1]}, rb2={v2[5:0], v2[63:6]};
    wire [63:0] ra3={v3[9:0], v3[63:10]},rb3={v3[16:0],v3[63:17]};
    wire [63:0] ra4={v4[6:0], v4[63:7]}, rb4={v4[40:0],v4[63:41]};
    wire [63:0] n0=v0^ra0^rb0,n1=v1^ra1^rb1,n2=v2^ra2^rb2;
    wire [63:0] n3=v3^ra3^rb3,n4=v4^ra4^rb4;

    integer i;
    always @(posedge clk or negedge rst_n) begin
        if(!rst_n) begin
            state<=IDLE;done<=0;wrot<=0;round_cnt<=0;round_end<=0;
            for(i=0;i<5;i=i+1) rf[i]<=0;
            s0_out<=0;s1_out<=0;s2_out<=0;s3_out<=0;s4_out<=0;
        end else case(state)
            IDLE: begin
                done<=0;
                if(start) begin
                    // Load input: logical x_i goes to rf[(i+0)%5] when wrot=0
                    rf[0]<=s0_in;rf[1]<=s1_in;rf[2]<=s2_in;rf[3]<=s3_in;rf[4]<=s4_in;
                    wrot<=3'd0;
                    round_cnt<=start_round;round_end<=start_round+rounds;
                    state<=RUN;
                end
            end
            RUN: begin
                // Write round results back through wrot-indexed addresses
                rf[m5(wrot,3'd0)]<=n0;
                rf[m5(wrot,3'd1)]<=n1;
                rf[m5(wrot,3'd2)]<=n2;
                rf[m5(wrot,3'd3)]<=n3;
                rf[m5(wrot,3'd4)]<=n4;
                // Advance word rotation (mod 5)
                wrot <= (wrot==3'd4) ? 3'd0 : wrot+3'd1;
                if(round_cnt<round_end-1) round_cnt<=round_cnt+1;
                else state<=FINISH;
            end
            FINISH: begin
                // Output logical words through current wrot mapping
                s0_out<=rf[m5(wrot,3'd0)];
                s1_out<=rf[m5(wrot,3'd1)];
                s2_out<=rf[m5(wrot,3'd2)];
                s3_out<=rf[m5(wrot,3'd3)];
                s4_out<=rf[m5(wrot,3'd4)];
                done<=1;state<=IDLE;
            end
            default: state<=IDLE;
        endcase
    end
endmodule
