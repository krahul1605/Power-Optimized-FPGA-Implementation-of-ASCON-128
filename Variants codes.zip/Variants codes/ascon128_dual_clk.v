`timescale 1ns / 1ps
module ascon128_top (
    input  wire clk_p,clk_n,rst_n,start,
    output wire done,tag_match,led_done,led_tag_match,led_running,led_error
);
    wire clk_ibuf,clk; reg rr;
    IBUFDS #(.DIFF_TERM("FALSE"),.IBUF_LOW_PWR("FALSE"),.IOSTANDARD("LVDS"))
        u(.I(clk_p),.IB(clk_n),.O(clk_ibuf));
    BUFG b(.I(clk_ibuf),.O(clk));
    wire cd,ct;
    ascon128_complete_dual_clk ac(.clk(clk),.rst_n(rst_n),.start(start),.done(cd),.tag_match(ct));
    assign done=cd; assign tag_match=ct;
    always @(posedge clk or negedge rst_n) if(!rst_n) rr<=0; else if(start) rr<=1; else if(cd) rr<=0;
    assign led_done=cd; assign led_tag_match=cd&ct; assign led_running=rr; assign led_error=cd&~ct;
endmodule

module ascon128_complete_dual_clk(input wire clk,rst_n,start,output reg done,tag_match);
    localparam [127:0] KEY=128'h0F1E2D3C4B5A69788796A5B4C3D2E1F0,NONCE=128'hFFEEDDCCBBAA99887766554433221100;
    localparam [191:0] PT_PADDED=192'h46696E616C20596561722050726F6A656374204152418000;
    localparam PT_BLOCKS=3; localparam [63:0] AAD_PADDED=64'h64656D6F41414480,IV=64'h80400c0600000000;
    localparam [4:0] ST_IDLE=0,ST_EI=1,ST_EIP=2,ST_EA=3,ST_EAP=4,ST_EAD=5,
        ST_EP=6,ST_EPP=7,ST_EF=8,ST_EFW=9,ST_TS=10,ST_DI=11,ST_DIP=12,
        ST_DA=13,ST_DAP=14,ST_DAD=15,ST_DC=16,ST_DCP=17,ST_DF=18,ST_DFW=19,ST_DONE=20;
    reg [4:0] state; reg [3:0] bi;
    reg [63:0] s0,s1,s2,s3,s4;
    reg [191:0] ct_r; reg [127:0] tag_enc; reg [191:0] pt_dec;
    reg ps; wire pd; reg [3:0] psr,pnr;
    wire [63:0] po0,po1,po2,po3,po4;
    ascon_perm_dual_clk pi(.clk(clk),.rst_n(rst_n),.start(ps),.start_round(psr),.rounds(pnr),
        .s0_in(s0),.s1_in(s1),.s2_in(s2),.s3_in(s3),.s4_in(s4),
        .s0_out(po0),.s1_out(po1),.s2_out(po2),.s3_out(po3),.s4_out(po4),.done(pd));
    always @(posedge clk or negedge rst_n) begin
        if(!rst_n) begin state<=0;done<=0;tag_match<=0;ps<=0;psr<=0;pnr<=0;bi<=0;
            s0<=0;s1<=0;s2<=0;s3<=0;s4<=0;ct_r<=0;tag_enc<=0;pt_dec<=0;
        end else begin ps<=0;
            case(state)
                ST_IDLE:begin done<=0;tag_match<=0;if(start) state<=ST_EI;end
                ST_EI:begin s0<=IV;s1<=KEY[127:64];s2<=KEY[63:0];s3<=NONCE[127:64];s4<=NONCE[63:0];
                    psr<=0;pnr<=12;ps<=1;state<=ST_EIP;end
                ST_EIP:if(pd)begin s0<=po0;s1<=po1;s2<=po2;s3<=po3^KEY[127:64];s4<=po4^KEY[63:0];state<=ST_EA;end
                ST_EA:begin s0<=s0^AAD_PADDED;psr<=6;pnr<=6;ps<=1;state<=ST_EAP;end
                ST_EAP:if(pd)begin s0<=po0;s1<=po1;s2<=po2;s3<=po3;s4<=po4;state<=ST_EAD;end
                ST_EAD:begin s4<=s4^64'h1;bi<=0;state<=ST_EP;end
                ST_EP:begin
                    if(bi<PT_BLOCKS)begin ct_r[191-bi*64-:64]<=s0^PT_PADDED[191-bi*64-:64];
                        s0<=s0^PT_PADDED[191-bi*64-:64];
                        if(bi<PT_BLOCKS-1)begin psr<=6;pnr<=6;ps<=1;bi<=bi+1;state<=ST_EPP;end else state<=ST_EF;
                    end else state<=ST_EF;end
                ST_EPP:if(pd)begin s0<=po0;s1<=po1;s2<=po2;s3<=po3;s4<=po4;state<=ST_EP;end
                ST_EF:begin s1<=s1^KEY[127:64];s2<=s2^KEY[63:0];psr<=0;pnr<=12;ps<=1;state<=ST_EFW;end
                ST_EFW:if(pd)begin tag_enc<={po3^KEY[127:64],po4^KEY[63:0]};state<=ST_TS;end
                ST_TS:state<=ST_DI;
                ST_DI:begin s0<=IV;s1<=KEY[127:64];s2<=KEY[63:0];s3<=NONCE[127:64];s4<=NONCE[63:0];
                    psr<=0;pnr<=12;ps<=1;state<=ST_DIP;end
                ST_DIP:if(pd)begin s0<=po0;s1<=po1;s2<=po2;s3<=po3^KEY[127:64];s4<=po4^KEY[63:0];state<=ST_DA;end
                ST_DA:begin s0<=s0^AAD_PADDED;psr<=6;pnr<=6;ps<=1;state<=ST_DAP;end
                ST_DAP:if(pd)begin s0<=po0;s1<=po1;s2<=po2;s3<=po3;s4<=po4;state<=ST_DAD;end
                ST_DAD:begin s4<=s4^64'h1;bi<=0;state<=ST_DC;end
                ST_DC:begin
                    if(bi<PT_BLOCKS)begin pt_dec[191-bi*64-:64]<=s0^ct_r[191-bi*64-:64];
                        s0<=ct_r[191-bi*64-:64];
                        if(bi<PT_BLOCKS-1)begin psr<=6;pnr<=6;ps<=1;bi<=bi+1;state<=ST_DCP;end else state<=ST_DF;
                    end else state<=ST_DF;end
                ST_DCP:if(pd)begin s0<=po0;s1<=po1;s2<=po2;s3<=po3;s4<=po4;state<=ST_DC;end
                ST_DF:begin s1<=s1^KEY[127:64];s2<=s2^KEY[63:0];psr<=0;pnr<=12;ps<=1;state<=ST_DFW;end
                ST_DFW:if(pd)begin tag_match<=(tag_enc=={po3^KEY[127:64],po4^KEY[63:0]});done<=1;state<=ST_DONE;end
                ST_DONE:; default:state<=ST_IDLE;
            endcase end end
endmodule
//=============================================================================
// ascon_perm_dual_clk
//
// Dual-speed pipeline — Theta operates on a 2-cycle "slow path" (its result
// is computed over 2 registered half-steps), while Chi and Linear operate
// on the full-speed 1-cycle path. This creates asymmetric stage depths
// within a single round:
//
//   DC_THETA_A (1 cyc): Compute column parities and rotation-mix only.
//                        Register parity intermediates: pa*, rm* (320 FFs).
//   DC_THETA_B (1 cyc): Apply theta (xi ^= mix_i). This is the "decimated"
//                        second half-step — its critical path is just XOR
//                        (~1-2 gate levels), far shallower than the parity tree.
//   DC_CHI     (1 cyc): Full Chi (AND-NOT + XOR + INV).
//   DC_LIN     (1 cyc): Full Linear (two rotations + XOR).
//
// 4 cycles/round. The Theta critical path is split across 2 cycles:
//   DC_THETA_A: x* → parity XOR tree (~3-4 levels) + rotation-mix XOR (~1) → pa*, rm*
//   DC_THETA_B: pa*, rm* → apply XOR (~1) → x*
//   Both stages are ~4-5 gate levels — much shallower than the unified
//   Theta cone (~8-10 levels) used in most other variants.
//
// Fmax target: 200 MHz / 5 ns (DC_THETA_A or DC_THETA_B are now the bottleneck,
//              each at ~4-5 levels vs. the ~8-10 of single-stage theta)
// Clocks pa=12: 49  Clocks pb=6: 25
//=============================================================================
module ascon_perm_dual_clk (
    input  wire        clk,rst_n,start,
    input  wire [3:0]  start_round,rounds,
    input  wire [63:0] s0_in,s1_in,s2_in,s3_in,s4_in,
    output reg  [63:0] s0_out,s1_out,s2_out,s3_out,s4_out,
    output reg         done
);
    localparam [1:0] IDLE=2'd0,RUN=2'd1,FINISH=2'd2;
    localparam [1:0] DC_THETA_A=2'd0,DC_THETA_B=2'd1,DC_CHI=2'd2,DC_LIN=2'd3;

    reg [1:0] state,dc_phase;
    reg [3:0] round_cnt,round_end;
    reg [63:0] x0,x1,x2,x3,x4;
    // Theta half-step intermediates: parity result per word (m_i = mix_i)
    (* keep="true" *) reg [63:0] m0,m1,m2,m3,m4;
    // Chi intermediate
    (* keep="true" *) reg [63:0] ch0,ch1,ch2,ch3,ch4;

    reg [7:0] rc;
    always @(*) case(round_cnt)
        4'd0:rc=8'hf0;4'd1:rc=8'he1;4'd2:rc=8'hd2;4'd3:rc=8'hc3;
        4'd4:rc=8'hb4;4'd5:rc=8'ha5;4'd6:rc=8'h96;4'd7:rc=8'h87;
        4'd8:rc=8'h78;4'd9:rc=8'h69;4'd10:rc=8'h5a;4'd11:rc=8'h4b;
        default:rc=8'h00;
    endcase

    // DC_THETA_A: parity tree + rotation-mix only (no apply yet)
    // Include const in this half: x2 is used with rc applied
    wire [63:0] ax2=x2^{56'd0,rc};
    wire [63:0] p0=x0^x1^ax2^x3^x4, p1=x1^ax2^x3^x4^x0;
    wire [63:0] p2=ax2^x3^x4^x0^x1, p3=x3^x4^x0^x1^ax2, p4=x4^x0^x1^ax2^x3;
    wire [63:0] rm0=p4^{p1[0],p1[63:1]}, rm1=p0^{p2[0],p2[63:1]};
    wire [63:0] rm2=p1^{p3[0],p3[63:1]}, rm3=p2^{p4[0],p4[63:1]};
    wire [63:0] rm4=p3^{p0[0],p0[63:1]};
    // (rm* registered as m* in DC_THETA_A cycle; ax2 stored as x2)

    // DC_THETA_B: apply theta correction (xi ^= m_i) — 1-level XOR per word
    wire [63:0] ta0=x0^m0, ta1=x1^m1, ta2=x2^m2, ta3=x3^m3, ta4=x4^m4;

    // DC_CHI: full chi on x*
    wire [63:0] tc0=x0^(~x1&x2), tc1=x1^(~x2&x3), tc2=~(x2^(~x3&x4)), tc3=x3^(~x4&x0), tc4=x4^(~x0&x1);

    // DC_LIN: linear on ch*
    wire [63:0] tl0=ch0^{ch0[18:0],ch0[63:19]}^{ch0[27:0],ch0[63:28]};
    wire [63:0] tl1=ch1^{ch1[60:0],ch1[63:61]}^{ch1[38:0],ch1[63:39]};
    wire [63:0] tl2=ch2^{ch2[0],ch2[63:1]}^{ch2[5:0],ch2[63:6]};
    wire [63:0] tl3=ch3^{ch3[9:0],ch3[63:10]}^{ch3[16:0],ch3[63:17]};
    wire [63:0] tl4=ch4^{ch4[6:0],ch4[63:7]}^{ch4[40:0],ch4[63:41]};

    always @(posedge clk or negedge rst_n) begin
        if(!rst_n) begin state<=IDLE;done<=0;dc_phase<=DC_THETA_A;round_cnt<=0;round_end<=0;
            x0<=0;x1<=0;x2<=0;x3<=0;x4<=0;m0<=0;m1<=0;m2<=0;m3<=0;m4<=0;ch0<=0;ch1<=0;ch2<=0;ch3<=0;ch4<=0;
            s0_out<=0;s1_out<=0;s2_out<=0;s3_out<=0;s4_out<=0;
        end else case(state)
            IDLE:begin done<=0;
                if(start)begin x0<=s0_in;x1<=s1_in;x2<=s2_in;x3<=s3_in;x4<=s4_in;
                    round_cnt<=start_round;round_end<=start_round+rounds;dc_phase<=DC_THETA_A;state<=RUN;end end
            RUN:begin
                case(dc_phase)
                    DC_THETA_A:begin
                        // Store const-applied x2 and rotation-mix results
                        x2<=ax2;  // register post-constant x2
                        m0<=rm0;m1<=rm1;m2<=rm2;m3<=rm3;m4<=rm4;  // register mix values
                        dc_phase<=DC_THETA_B;
                    end
                    DC_THETA_B:begin  // Apply theta: 1-level XOR only
                        x0<=ta0;x1<=ta1;x2<=ta2;x3<=ta3;x4<=ta4;
                        dc_phase<=DC_CHI;
                    end
                    DC_CHI:begin
                        ch0<=tc0;ch1<=tc1;ch2<=tc2;ch3<=tc3;ch4<=tc4;
                        dc_phase<=DC_LIN;
                    end
                    DC_LIN:begin
                        x0<=tl0;x1<=tl1;x2<=tl2;x3<=tl3;x4<=tl4;
                        dc_phase<=DC_THETA_A;
                        if(round_cnt<round_end-1) round_cnt<=round_cnt+1; else state<=FINISH;
                    end
                    default:dc_phase<=DC_THETA_A;
                endcase end
            FINISH:begin s0_out<=x0;s1_out<=x1;s2_out<=x2;s3_out<=x3;s4_out<=x4;done<=1;state<=IDLE;end
            default:state<=IDLE;
        endcase end
endmodule
