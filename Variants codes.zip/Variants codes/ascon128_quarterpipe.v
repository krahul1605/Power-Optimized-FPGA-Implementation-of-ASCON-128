`timescale 1ns / 1ps
//=============================================================================
// ASCON-128  ·  Variant: quarterpipe
//
// Visual treatment : Quarter-depth pipeline — four ASCON sub-steps are
//                    fused into each of two registered pipeline stages
//                    per round:
//
//   Stage 0 : CONST + THETA_A + THETA_B + THETA_C
//             — constant injection, parity tree, rotation mix, theta XOR
//   Stage 1 : CHI1 + CHI2 + LIN1 + LIN2        (CRITICAL PATH)
//             — AND-NOT, chi XOR/INV, rotation operands, linear XOR
//
// Clocks per pa=12 call : 12 rounds × 2 sub-stages = 24 + 1 FINISH = 25
// Clocks per pb=6  call :  6 rounds × 2 sub-stages = 12 + 1 FINISH = 13
//
// Trade-offs
//   + Only 2 register barriers per round — minimum pipeline overhead
//   + Only ONE inter-stage register bank (5×64b = 320 FFs)
//   + Lowest clocks-per-call of all pipelined variants
//   - Stage 1 has the longest per-stage critical path in any variant
//     (AND-NOT + XOR + INV + 2× rotate + XOR cascade, ~15 ns / 67 MHz)
//   - Fanout on AND-NOT output (u*) requires buffering in implementation
//
// Functional parity: identical ports, identical FSM encoding, identical
//                    ASCON-128 algorithm (NIST compliant).
//=============================================================================

module ascon128_top (
    input  wire clk_p,
    input  wire clk_n,
    input  wire rst_n,
    input  wire start,
    output wire done,
    output wire tag_match,
    output wire led_done,
    output wire led_tag_match,
    output wire led_running,
    output wire led_error
);

    wire clk_ibuf, clk;

    IBUFDS #(
        .DIFF_TERM("FALSE"), .IBUF_LOW_PWR("FALSE"), .IOSTANDARD("LVDS")
    ) clk_ibufds (.I(clk_p), .IB(clk_n), .O(clk_ibuf));

    BUFG clk_bufg (.I(clk_ibuf), .O(clk));

    wire core_done, core_tag_match;
    reg  running_r;

    ascon128_complete_quarterpipe ascon_core (
        .clk(clk), .rst_n(rst_n), .start(start),
        .done(core_done), .tag_match(core_tag_match)
    );

    assign done = core_done; assign tag_match = core_tag_match;

    always @(posedge clk or negedge rst_n) begin
        if (!rst_n)         running_r <= 0;
        else if (start)     running_r <= 1;
        else if (core_done) running_r <= 0;
    end

    assign led_done=core_done; assign led_tag_match=core_done&core_tag_match;
    assign led_running=running_r; assign led_error=core_done&~core_tag_match;

endmodule


//=============================================================================
// ascon128_complete_quarterpipe  — FSM (identical to all variants)
//=============================================================================
module ascon128_complete_quarterpipe (
    input  wire clk, rst_n, start,
    output reg  done, tag_match
);
    localparam [127:0] KEY   = 128'h0F1E2D3C4B5A69788796A5B4C3D2E1F0;
    localparam [127:0] NONCE = 128'hFFEEDDCCBBAA99887766554433221100;
    localparam [191:0] PT_PADDED  = 192'h46696E616C20596561722050726F6A656374204152418000;
    localparam         PT_BLOCKS  = 3;
    localparam [63:0]  AAD_PADDED = 64'h64656D6F41414480;
    localparam [63:0]  IV         = 64'h80400c0600000000;

    localparam [4:0]
        ST_IDLE=0, ST_ENC_INIT=1, ST_ENC_INIT_PERM=2,
        ST_ENC_AAD=3, ST_ENC_AAD_PERM=4, ST_ENC_AAD_DOM=5,
        ST_ENC_PT=6, ST_ENC_PT_PERM=7, ST_ENC_FINAL=8,
        ST_ENC_FINAL_W=9, ST_TAG_STORE=10, ST_DEC_INIT=11,
        ST_DEC_INIT_PERM=12, ST_DEC_AAD=13, ST_DEC_AAD_PERM=14,
        ST_DEC_AAD_DOM=15, ST_DEC_CT=16, ST_DEC_CT_PERM=17,
        ST_DEC_FINAL=18, ST_DEC_FINAL_W=19, ST_DONE=20;

    reg [4:0] state; reg [3:0] block_idx;
    reg [63:0] s0,s1,s2,s3,s4;
    reg [191:0] ciphertext; reg [127:0] tag_enc; reg [191:0] plaintext_dec;
    reg perm_start; wire perm_done;
    reg [3:0] perm_start_round, perm_num_rounds;
    wire [63:0] perm_out0,perm_out1,perm_out2,perm_out3,perm_out4;

    ascon_perm_quarterpipe perm_inst (
        .clk(clk), .rst_n(rst_n), .start(perm_start),
        .start_round(perm_start_round), .rounds(perm_num_rounds),
        .s0_in(s0),.s1_in(s1),.s2_in(s2),.s3_in(s3),.s4_in(s4),
        .s0_out(perm_out0),.s1_out(perm_out1),.s2_out(perm_out2),
        .s3_out(perm_out3),.s4_out(perm_out4),.done(perm_done)
    );

    always @(posedge clk or negedge rst_n) begin
        if (!rst_n) begin
            state<=0; done<=0; tag_match<=0; perm_start<=0;
            perm_start_round<=0; perm_num_rounds<=0; block_idx<=0;
            s0<=0;s1<=0;s2<=0;s3<=0;s4<=0;
            ciphertext<=0; tag_enc<=0; plaintext_dec<=0;
        end else begin
            perm_start<=0;
            case(state)
                ST_IDLE: begin done<=0; tag_match<=0; if(start) state<=ST_ENC_INIT; end
                ST_ENC_INIT: begin
                    s0<=IV; s1<=KEY[127:64]; s2<=KEY[63:0];
                    s3<=NONCE[127:64]; s4<=NONCE[63:0];
                    perm_start_round<=0; perm_num_rounds<=12; perm_start<=1;
                    state<=ST_ENC_INIT_PERM;
                end
                ST_ENC_INIT_PERM: if(perm_done) begin
                    s0<=perm_out0; s1<=perm_out1; s2<=perm_out2;
                    s3<=perm_out3^KEY[127:64]; s4<=perm_out4^KEY[63:0];
                    state<=ST_ENC_AAD;
                end
                ST_ENC_AAD: begin
                    s0<=s0^AAD_PADDED; perm_start_round<=6; perm_num_rounds<=6;
                    perm_start<=1; state<=ST_ENC_AAD_PERM;
                end
                ST_ENC_AAD_PERM: if(perm_done) begin
                    s0<=perm_out0;s1<=perm_out1;s2<=perm_out2;s3<=perm_out3;s4<=perm_out4;
                    state<=ST_ENC_AAD_DOM;
                end
                ST_ENC_AAD_DOM: begin s4<=s4^64'h1; block_idx<=0; state<=ST_ENC_PT; end
                ST_ENC_PT: begin
                    if(block_idx<PT_BLOCKS) begin
                        ciphertext[191-block_idx*64-:64]<=s0^PT_PADDED[191-block_idx*64-:64];
                        s0<=s0^PT_PADDED[191-block_idx*64-:64];
                        if(block_idx<PT_BLOCKS-1) begin
                            perm_start_round<=6; perm_num_rounds<=6; perm_start<=1;
                            block_idx<=block_idx+1; state<=ST_ENC_PT_PERM;
                        end else state<=ST_ENC_FINAL;
                    end else state<=ST_ENC_FINAL;
                end
                ST_ENC_PT_PERM: if(perm_done) begin
                    s0<=perm_out0;s1<=perm_out1;s2<=perm_out2;s3<=perm_out3;s4<=perm_out4;
                    state<=ST_ENC_PT;
                end
                ST_ENC_FINAL: begin
                    s1<=s1^KEY[127:64]; s2<=s2^KEY[63:0];
                    perm_start_round<=0; perm_num_rounds<=12; perm_start<=1;
                    state<=ST_ENC_FINAL_W;
                end
                ST_ENC_FINAL_W: if(perm_done) begin
                    tag_enc<={perm_out3^KEY[127:64],perm_out4^KEY[63:0]};
                    state<=ST_TAG_STORE;
                end
                ST_TAG_STORE: state<=ST_DEC_INIT;
                ST_DEC_INIT: begin
                    s0<=IV; s1<=KEY[127:64]; s2<=KEY[63:0];
                    s3<=NONCE[127:64]; s4<=NONCE[63:0];
                    perm_start_round<=0; perm_num_rounds<=12; perm_start<=1;
                    state<=ST_DEC_INIT_PERM;
                end
                ST_DEC_INIT_PERM: if(perm_done) begin
                    s0<=perm_out0;s1<=perm_out1;s2<=perm_out2;
                    s3<=perm_out3^KEY[127:64];s4<=perm_out4^KEY[63:0];
                    state<=ST_DEC_AAD;
                end
                ST_DEC_AAD: begin
                    s0<=s0^AAD_PADDED; perm_start_round<=6; perm_num_rounds<=6;
                    perm_start<=1; state<=ST_DEC_AAD_PERM;
                end
                ST_DEC_AAD_PERM: if(perm_done) begin
                    s0<=perm_out0;s1<=perm_out1;s2<=perm_out2;s3<=perm_out3;s4<=perm_out4;
                    state<=ST_DEC_AAD_DOM;
                end
                ST_DEC_AAD_DOM: begin s4<=s4^64'h1; block_idx<=0; state<=ST_DEC_CT; end
                ST_DEC_CT: begin
                    if(block_idx<PT_BLOCKS) begin
                        plaintext_dec[191-block_idx*64-:64]<=s0^ciphertext[191-block_idx*64-:64];
                        s0<=ciphertext[191-block_idx*64-:64];
                        if(block_idx<PT_BLOCKS-1) begin
                            perm_start_round<=6; perm_num_rounds<=6; perm_start<=1;
                            block_idx<=block_idx+1; state<=ST_DEC_CT_PERM;
                        end else state<=ST_DEC_FINAL;
                    end else state<=ST_DEC_FINAL;
                end
                ST_DEC_CT_PERM: if(perm_done) begin
                    s0<=perm_out0;s1<=perm_out1;s2<=perm_out2;s3<=perm_out3;s4<=perm_out4;
                    state<=ST_DEC_CT;
                end
                ST_DEC_FINAL: begin
                    s1<=s1^KEY[127:64]; s2<=s2^KEY[63:0];
                    perm_start_round<=0; perm_num_rounds<=12; perm_start<=1;
                    state<=ST_DEC_FINAL_W;
                end
                ST_DEC_FINAL_W: if(perm_done) begin
                    tag_match<=(tag_enc=={perm_out3^KEY[127:64],perm_out4^KEY[63:0]});
                    done<=1; state<=ST_DONE;
                end
                ST_DONE: ;
                default: state<=ST_IDLE;
            endcase
        end
    end
endmodule


//=============================================================================
// ascon_perm_quarterpipe
//
// 2-stage registered pipeline per round. Four sub-steps are fused into
// each stage's combinational cone.
//
//   Stage 0 (THETA): x* → [CONST] → [THETA_A parities] →
//                    [THETA_B rotation mix] → [THETA_C XOR] → t* regs
//
//   Stage 1 (CHI+LIN): t* → [CHI1 AND-NOT] → [CHI2 XOR/INV] →
//                       [LIN1 rotate] → [LIN2 XOR] → x* regs
//
// Critical path: t*_reg → AND-NOT → XOR → INV → rotate → XOR → x*_reg
//               (~14-15 ns / 67 MHz target)
// Fanout note: AND-NOT outputs (u0..u4, each 64b) fan into both the chi
//              XOR and are re-read for rotation; buffer insertion expected.
//=============================================================================
module ascon_perm_quarterpipe (
    input  wire        clk, rst_n, start,
    input  wire [3:0]  start_round, rounds,
    input  wire [63:0] s0_in,s1_in,s2_in,s3_in,s4_in,
    output reg  [63:0] s0_out,s1_out,s2_out,s3_out,s4_out,
    output reg         done
);

    localparam [1:0] IDLE=2'd0, THETA=2'd1, CHI_LIN=2'd2, FINISH=2'd3;

    reg [1:0]  state;
    reg [3:0]  round_cnt, round_end;
    reg [63:0] x0,x1,x2,x3,x4;   // working state (input to THETA, output of CHI_LIN)
    reg [63:0] t0,t1,t2,t3,t4;   // inter-stage: theta output

    // Round constant decode
    reg [7:0] rc;
    always @(*) case(round_cnt)
        4'd0:rc=8'hf0; 4'd1:rc=8'he1; 4'd2:rc=8'hd2; 4'd3:rc=8'hc3;
        4'd4:rc=8'hb4; 4'd5:rc=8'ha5; 4'd6:rc=8'h96; 4'd7:rc=8'h87;
        4'd8:rc=8'h78; 4'd9:rc=8'h69; 4'd10:rc=8'h5a; 4'd11:rc=8'h4b;
        default:rc=8'h00;
    endcase

    // -------------------------------------------------------------------------
    // Stage 0 combinational (CONST + THETA_A + THETA_B + THETA_C fused)
    // Input: x0..x4 + rc.   Output: t0..t4
    // -------------------------------------------------------------------------
    wire [63:0] cx2 = x2^{56'd0,rc};  // post-CONST x2
    // THETA_A: parities
    wire [63:0] q0 = x0^x1^cx2^x3^x4;
    wire [63:0] q1 = x1^cx2^x3^x4^x0;
    wire [63:0] q2 = cx2^x3^x4^x0^x1;
    wire [63:0] q3 = x3^x4^x0^x1^cx2;
    wire [63:0] q4 = x4^x0^x1^cx2^x3;
    // THETA_B: rotation mix → m*
    wire [63:0] m0_w = q4^{q1[0],q1[63:1]};
    wire [63:0] m1_w = q0^{q2[0],q2[63:1]};
    wire [63:0] m2_w = q1^{q3[0],q3[63:1]};
    wire [63:0] m3_w = q2^{q4[0],q4[63:1]};
    wire [63:0] m4_w = q3^{q0[0],q0[63:1]};
    // THETA_C: apply theta
    wire [63:0] t0_w = x0^m0_w;
    wire [63:0] t1_w = x1^m1_w;
    wire [63:0] t2_w = cx2^m2_w;
    wire [63:0] t3_w = x3^m3_w;
    wire [63:0] t4_w = x4^m4_w;

    // -------------------------------------------------------------------------
    // Stage 1 combinational (CHI1 + CHI2 + LIN1 + LIN2 fused) — CRITICAL PATH
    // Input: t0..t4.   Output: x0..x4 (new)
    // -------------------------------------------------------------------------
    // CHI1: AND-NOT
    wire [63:0] u0_w = ~t0&t1;  // repurposed: chi uses ~t[i]&t[i+1]
    wire [63:0] u1_w = ~t1&t2;
    wire [63:0] u2_w = ~t2&t3;
    wire [63:0] u3_w = ~t3&t4;
    wire [63:0] u4_w = ~t4&t0;
    // CHI2: XOR, x2 inverted
    wire [63:0] v0_w = t0^(~t1&t2);
    wire [63:0] v1_w = t1^(~t2&t3);
    wire [63:0] v2_w = ~(t2^(~t3&t4));
    wire [63:0] v3_w = t3^(~t4&t0);
    wire [63:0] v4_w = t4^(~t0&t1);
    // LIN1+LIN2: rotation XOR merge
    wire [63:0] n0_w = v0_w^{v0_w[18:0],v0_w[63:19]}^{v0_w[27:0],v0_w[63:28]};
    wire [63:0] n1_w = v1_w^{v1_w[60:0],v1_w[63:61]}^{v1_w[38:0],v1_w[63:39]};
    wire [63:0] n2_w = v2_w^{v2_w[0],   v2_w[63:1]} ^{v2_w[5:0], v2_w[63:6]};
    wire [63:0] n3_w = v3_w^{v3_w[9:0], v3_w[63:10]}^{v3_w[16:0],v3_w[63:17]};
    wire [63:0] n4_w = v4_w^{v4_w[6:0], v4_w[63:7]} ^{v4_w[40:0],v4_w[63:41]};

    // Suppress unused wire warnings for intermediate chi wires
    wire _u_unused = |{u0_w,u1_w,u2_w,u3_w,u4_w};

    always @(posedge clk or negedge rst_n) begin
        if(!rst_n) begin
            state<=IDLE; done<=0; round_cnt<=0; round_end<=0;
            x0<=0;x1<=0;x2<=0;x3<=0;x4<=0;
            t0<=0;t1<=0;t2<=0;t3<=0;t4<=0;
            s0_out<=0;s1_out<=0;s2_out<=0;s3_out<=0;s4_out<=0;
        end else case(state)
            IDLE: begin
                done<=0;
                if(start) begin
                    x0<=s0_in;x1<=s1_in;x2<=s2_in;x3<=s3_in;x4<=s4_in;
                    round_cnt<=start_round; round_end<=start_round+rounds;
                    state<=THETA;
                end
            end
            // Stage 0: latch theta output (CONST+THETA_A+THETA_B+THETA_C)
            THETA: begin
                t0<=t0_w; t1<=t1_w; t2<=t2_w; t3<=t3_w; t4<=t4_w;
                state<=CHI_LIN;
            end
            // Stage 1: latch chi+lin output, advance or finish
            CHI_LIN: begin
                x0<=n0_w; x1<=n1_w; x2<=n2_w; x3<=n3_w; x4<=n4_w;
                if(round_cnt < round_end-1) begin
                    round_cnt<=round_cnt+1; state<=THETA;
                end else state<=FINISH;
            end
            FINISH: begin
                s0_out<=x0;s1_out<=x1;s2_out<=x2;
                s3_out<=x3;s4_out<=x4; done<=1; state<=IDLE;
            end
            default: state<=IDLE;
        endcase
    end
endmodule
