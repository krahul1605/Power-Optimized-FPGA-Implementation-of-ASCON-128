#==============================================================================
# ASCON-128  ·  Variant: gated
# SDC for Cadence Genus Synthesis
#
# Permutation architecture: Clock-enable per sub-step register layer.
#   Four register layers (x, ct, ca, cv), each with explicit CE signal.
#   Only the active layer's FFs update each cycle.
#
#   5 phases per round:
#     GD_CONST   (ce_x):     x2 ^= rc                    ~1-2 gate levels
#     GD_THETA   (ce_ct):    Theta(x*) -> ct*             ~8-10 gate levels (critical)
#     GD_CHI_AND (ce_ca):    AND-NOT(ct*) -> ca*          ~2 gate levels
#     GD_CHI_XOR (ce_cv):    ct* ^ ca* -> cv*; ~cv2      ~2-3 gate levels
#     GD_LIN     (ce_x):     Linear(cv*) -> x*            ~4-5 gate levels
#
#   Fmax target: 100 MHz / 10 ns (GD_THETA bottleneck)
#   Clocks pa=12: 12 × 5 + 1 = 61   Clocks pb=6: 6 × 5 + 1 = 31
#
# Power note: On ZCU104 UltraScale+, synthesis should map the conditional
#   register updates (if(ce_x) ... if(ce_ct) ...) to FF CE pins, NOT to
#   data-path muxes. Use set_attribute use_clock_enable true or equivalent
#   to encourage FF CE mapping. This minimises dynamic power since ~4×320 = 1280
#   FFs exist but only 320 toggle per cycle.
#==============================================================================
create_clock -period 10.000 -name sys_clk -waveform {0.000 5.000} [get_ports clk_p]
set_clock_uncertainty -setup 0.200 [get_clocks sys_clk]
set_clock_uncertainty -hold  0.100 [get_clocks sys_clk]
set_clock_transition -rise 0.100 [get_clocks sys_clk]
set_clock_transition -fall 0.100 [get_clocks sys_clk]
set_input_delay -clock sys_clk -max 2.000 [get_ports rst_n]
set_input_delay -clock sys_clk -min 0.500 [get_ports rst_n]
set_input_delay -clock sys_clk -max 2.000 [get_ports start]
set_input_delay -clock sys_clk -min 0.500 [get_ports start]
set_output_delay -clock sys_clk -max 2.000 [get_ports done]
set_output_delay -clock sys_clk -min 0.500 [get_ports done]
set_output_delay -clock sys_clk -max 2.000 [get_ports tag_match]
set_output_delay -clock sys_clk -min 0.500 [get_ports tag_match]
set_output_delay -clock sys_clk -max 2.000 [get_ports led_done]
set_output_delay -clock sys_clk -min 0.500 [get_ports led_done]
set_output_delay -clock sys_clk -max 2.000 [get_ports led_tag_match]
set_output_delay -clock sys_clk -min 0.500 [get_ports led_tag_match]
set_output_delay -clock sys_clk -max 2.000 [get_ports led_running]
set_output_delay -clock sys_clk -min 0.500 [get_ports led_running]
set_output_delay -clock sys_clk -max 2.000 [get_ports led_error]
set_output_delay -clock sys_clk -min 0.500 [get_ports led_error]
set_false_path -from [get_ports rst_n]
# Preserve register layer boundaries — prevent merging of ct*, ca*, cv* into x*
# set_dont_touch [get_cells {ct*_reg* ca*_reg* cv*_reg*}]
set_driving_cell -lib_cell INVX1 -no_design_rule [get_ports {start rst_n}]
set_load 5.0 [get_ports {done tag_match led_done led_tag_match led_running led_error}]
# set_operating_conditions -library <lib> TYPICAL
#==============================================================================
# END - ascon128_gated.sdc
#==============================================================================
