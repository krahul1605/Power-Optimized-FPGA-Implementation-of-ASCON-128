#==============================================================================
# ASCON-128  ·  Variant: unrolled
# SDC for Cadence Genus Synthesis
#
# Permutation architecture: Fully unrolled combinational permutation.
#   All 12 rounds (pa) or 6 rounds (pb) are instantiated as a purely
#   combinational pipeline with NO intermediate registered barriers between
#   rounds. A single registered capture stage latches the final permutation
#   output after the entire combinational cascade settles.
#
#   Internal structure per round (combinational, no FFs):
#     CONST → THETA_A → THETA_B → THETA_C → CHI1 → CHI2 → LIN1 → LIN2
#   12 such stages are chained in silicon, wire-connected round-to-round.
#
# Architecture trade-offs:
#   + Absolute minimum latency: 1 clock cycle per full permutation call (pa/pb).
#   + Zero pipeline stall; back-to-back start-to-done in 2 cycles (latch+capture).
#   - Extremely long combinational path: 12 rounds × ~35 gate levels = ~420 levels.
#   - Very high area: 12× replicated logic for each round.
#   - Synthesis runtime is high; expect hours of compile time for pa=12 unroll.
#   - Practical Fmax is low (~15 MHz) due to path depth.
#
# Timing impact vs elevated:
#   - Critical path: full 12-round combinational cascade (~65-80 ns typical).
#   - Clock period target: 70.000 ns (~14 MHz) — covers worst-case path depth.
#   - Input/output delays: 2.0/0.5 ns standard.
#   - Multicycle paths: NOT used — by construction only 1 cycle per call.
#
# Clocks per pa=12 call : 1 (full combinational) + 1 FINISH = 2
# Clocks per pb=6  call : 1 (full combinational) + 1 FINISH = 2
#
# Synthesis guidance for Genus:
#   Disable structuring to prevent re-sharing of round logic (defeats unrolling).
#   Use max_area=0 to prioritize timing over area in this throughput-first design.
#   Expect large netlist; set compile timeout conservatively (8+ hours for pa=12).
#==============================================================================

#------------------------------------------------------------------------------
# 1. CLOCK DEFINITION
#    14 MHz / 70 ns — fully unrolled 12-round combinational permutation
#------------------------------------------------------------------------------
create_clock -period 70.000 \
             -name sys_clk \
             -waveform {0.000 35.000} \
             [get_ports clk_p]

#------------------------------------------------------------------------------
# 2. CLOCK UNCERTAINTY
#    Very relaxed jitter budget; period is dominated by logic path, not clock.
#------------------------------------------------------------------------------
set_clock_uncertainty -setup 0.800 [get_clocks sys_clk]
set_clock_uncertainty -hold  0.500 [get_clocks sys_clk]

#------------------------------------------------------------------------------
# 3. CLOCK TRANSITION
#    Relaxed edge rate; board-speed clock for unrolled capture register.
#------------------------------------------------------------------------------
set_clock_transition -rise 0.300 [get_clocks sys_clk]
set_clock_transition -fall 0.300 [get_clocks sys_clk]

#------------------------------------------------------------------------------
# 4. INPUT DELAYS
#    At 70 ns period, 2.0 ns max input delay leaves ~66.9 ns internal budget.
#------------------------------------------------------------------------------
set_input_delay -clock sys_clk -max 2.000 [get_ports rst_n]
set_input_delay -clock sys_clk -min 0.500 [get_ports rst_n]
set_input_delay -clock sys_clk -max 2.000 [get_ports start]
set_input_delay -clock sys_clk -min 0.500 [get_ports start]

#------------------------------------------------------------------------------
# 5. OUTPUT DELAYS
#------------------------------------------------------------------------------
set_output_delay -clock sys_clk -max 2.000 [get_ports done]
set_output_delay -clock sys_clk -min 0.500 [get_ports done]
set_output_delay -clock sys_clk -max 2.000 [get_ports tag_match]
set_output_delay -clock sys_clk -min 0.500 [get_ports tag_match]
set_output_delay -clock sys_clk -max 2.000 [get_ports led_done]
set_output_delay -clock sys_clk -min 0.500 [get_ports led_done]
set_output_delay -clock sys_clk -max 2.000 [get_ports led_tag_match]
set_output_delay -clock sys_clk -min 0.500 [get_ports led_tag_match]
set_output_delay -clock sys_clk -max 2.000 [get_ports led_running]
set_output_delay -clock sys_clk -min 0.500 [get_ports led_running]
set_output_delay -clock sys_clk -max 2.000 [get_ports led_error]
set_output_delay -clock sys_clk -min 0.500 [get_ports led_error]

#------------------------------------------------------------------------------
# 6. ASYNCHRONOUS RESET - FALSE PATH
#------------------------------------------------------------------------------
set_false_path -from [get_ports rst_n]

#------------------------------------------------------------------------------
# 7. CRITICAL PATH BUDGET — FULL 12-ROUND COMBINATIONAL CASCADE
#    Budget: 70.000 - 0.800 (unc) - 0.300 (transition) = 68.900 ns available.
#    Path traverses: round[0].CONST → ... → round[11].LIN2 → capture_reg.
#    The wire-delay between round replicas is significant at scale; ensure
#    Genus floorplanning places replicated round logic in contiguous cells.
#
#    Constrain input registers (s*_launch) to output capture registers:
#------------------------------------------------------------------------------
# set_max_delay 68.900 -from [get_cells {s*_launch_reg*}] -to [get_cells {s*_capture_reg*}]

#------------------------------------------------------------------------------
# 8. SYNTHESIS DIRECTIVES — UNROLLED-SPECIFIC
#    Prevent logic sharing across round boundaries (defeats unrolling intent):
#------------------------------------------------------------------------------
# set_attribute compile_no_new_cells false [get_db designs ascon_perm_unrolled]
# set_attribute ungroup true [get_db modules {round_*}]

#------------------------------------------------------------------------------
# 9. DRIVING CELL / OUTPUT LOAD
#------------------------------------------------------------------------------
set_driving_cell -no_design_rule [get_ports {start rst_n}]
set_load 5.0 [get_ports {done tag_match led_done led_tag_match led_running led_error}]

#------------------------------------------------------------------------------
# 10. OPERATING CONDITIONS
#      Worst-case slow corner to bound the long combinational path.
#      Uncomment and set library condition as appropriate.
#------------------------------------------------------------------------------
# set_operating_conditions -library <lib> SLOW

#==============================================================================
# END - ascon128_unrolled.sdc
#==============================================================================
