`timescale 1ns / 1ps
//=============================================================================
// ASCON-128  ·  Variant: wavefront
//
// Visual treatment : Systolic word-parallel PE array — each of the five
//                    ASCON 64-bit state words (x0..x4) is assigned its own
//                    dedicated Processing Element (PE_0..PE_4). Each PE
//                    contains local state storage and local combinational
//                    logic for the sub-steps it can compute independently.
//                    Inter-word dependencies (Theta parity mixing, Chi
//                    AND-NOT neighbours) are propagated through registered
//                    cross-word buses, creating a wavefront of data flowing
//                    between PEs rather than a single centralized computation.
//
//                    Per-round execution sequence (4 phases):
//
//     Phase WF_CONST  (1 cycle): Each PE independently XORs round constant
//                                into its own word (only PE_2 is affected;
//                                others pass through. No inter-PE dependency.)
//
//     Phase WF_THETA  (1 cycle): Each PE computes its OWN parity contribution
//                                (just its local word), then the cross-word
//                                XOR bus is used to combine all 5 parities.
//                                Rotation-mixed parities are computed and
//                                theta is applied — all fused with registered
//                                parity bus outputs.
//                                NOTE: requires parity bus from previous cycle.
//
//     Phase WF_CHI    (1 cycle): Each PE reads its left-neighbour's word from
//                                a registered neighbour bus to compute
//                                AND-NOT. PE_i computes ~x[i+1] & x[i+2]
//                                using registered copies of the neighbour.
//
//     Phase WF_LINEAR (1 cycle): Each PE independently applies its own
//                                rotation constants (no inter-PE dependency).
//                                Linear layer is fully local per PE.
//
//                    The registered parity bus and neighbour bus are the
//                    structural distinguishing feature — data flows in a
//                    wavefront pattern between PEs, not through a central mux.
//
// Clocks per pa=12 call : 12 rounds × 4 phases = 48 + 1 FINISH = 49
// Clocks per pb=6  call :  6 rounds × 4 phases = 24 + 1 FINISH = 25
//
// Trade-offs
//   + Five parallel PEs reduce mux depth — each PE's logic is minimal
//   + Cross-PE buses are narrow (64b parity + 64b neighbour per PE)
//   + Linear phase is embarrassingly parallel (zero cross-PE traffic)
//   + Maps well to FPGA column-slice placement (one column per PE)
//   - Parity bus adds one registered pipeline stage vs. pure combinational
//   - Neighbour bus requires registered copies of adjacent state words
//   - Slight overhead in registered cross-bus FFs (~320 extra FFs)
//
// Functional parity: identical ports and FSM encoding to all variants.
//                    NIST-compliant ASCON-128 algorithm.
//=============================================================================

module ascon128_top (
    input  wire clk_p,
    input  wire clk_n,
    input  wire rst_n,
    input  wire start,
    output wire done,
    output wire tag_match,
    output wire led_done,
    output wire led_tag_match,
    output wire led_running,
    output wire led_error
);

    wire clk_ibuf, clk;

    IBUFDS #(
        .DIFF_TERM("FALSE"), .IBUF_LOW_PWR("FALSE"), .IOSTANDARD("LVDS")
    ) clk_ibufds (.I(clk_p), .IB(clk_n), .O(clk_ibuf));

    BUFG clk_bufg (.I(clk_ibuf), .O(clk));

    wire core_done, core_tag_match;
    reg  running_r;

    ascon128_complete_wavefront ascon_core (
        .clk(clk), .rst_n(rst_n), .start(start),
        .done(core_done), .tag_match(core_tag_match)
    );

    assign done = core_done; assign tag_match = core_tag_match;

    always @(posedge clk or negedge rst_n) begin
        if (!rst_n)         running_r <= 0;
        else if (start)     running_r <= 1;
        else if (core_done) running_r <= 0;
    end

    assign led_done=core_done; assign led_tag_match=core_done&core_tag_match;
    assign led_running=running_r; assign led_error=core_done&~core_tag_match;

endmodule


//=============================================================================
// ascon128_complete_wavefront  — FSM (identical structure to all variants)
//=============================================================================
module ascon128_complete_wavefront (
    input  wire clk, rst_n, start,
    output reg  done, tag_match
);
    localparam [127:0] KEY   = 128'h0F1E2D3C4B5A69788796A5B4C3D2E1F0;
    localparam [127:0] NONCE = 128'hFFEEDDCCBBAA99887766554433221100;
    localparam [191:0] PT_PADDED  = 192'h46696E616C20596561722050726F6A656374204152418000;
    localparam         PT_BLOCKS  = 3;
    localparam [63:0]  AAD_PADDED = 64'h64656D6F41414480;
    localparam [63:0]  IV         = 64'h80400c0600000000;

    localparam [4:0]
        ST_IDLE=0, ST_ENC_INIT=1, ST_ENC_INIT_PERM=2,
        ST_ENC_AAD=3, ST_ENC_AAD_PERM=4, ST_ENC_AAD_DOM=5,
        ST_ENC_PT=6, ST_ENC_PT_PERM=7, ST_ENC_FINAL=8,
        ST_ENC_FINAL_W=9, ST_TAG_STORE=10, ST_DEC_INIT=11,
        ST_DEC_INIT_PERM=12, ST_DEC_AAD=13, ST_DEC_AAD_PERM=14,
        ST_DEC_AAD_DOM=15, ST_DEC_CT=16, ST_DEC_CT_PERM=17,
        ST_DEC_FINAL=18, ST_DEC_FINAL_W=19, ST_DONE=20;

    reg [4:0] state; reg [3:0] block_idx;
    reg [63:0] s0,s1,s2,s3,s4;
    reg [191:0] ciphertext; reg [127:0] tag_enc; reg [191:0] plaintext_dec;
    reg perm_start; wire perm_done;
    reg [3:0] perm_start_round, perm_num_rounds;
    wire [63:0] perm_out0,perm_out1,perm_out2,perm_out3,perm_out4;

    ascon_perm_wavefront perm_inst (
        .clk(clk), .rst_n(rst_n), .start(perm_start),
        .start_round(perm_start_round), .rounds(perm_num_rounds),
        .s0_in(s0),.s1_in(s1),.s2_in(s2),.s3_in(s3),.s4_in(s4),
        .s0_out(perm_out0),.s1_out(perm_out1),.s2_out(perm_out2),
        .s3_out(perm_out3),.s4_out(perm_out4),.done(perm_done)
    );

    always @(posedge clk or negedge rst_n) begin
        if (!rst_n) begin
            state<=0; done<=0; tag_match<=0; perm_start<=0;
            perm_start_round<=0; perm_num_rounds<=0; block_idx<=0;
            s0<=0;s1<=0;s2<=0;s3<=0;s4<=0;
            ciphertext<=0; tag_enc<=0; plaintext_dec<=0;
        end else begin
            perm_start<=0;
            case(state)
                ST_IDLE: begin done<=0; tag_match<=0; if(start) state<=ST_ENC_INIT; end
                ST_ENC_INIT: begin
                    s0<=IV; s1<=KEY[127:64]; s2<=KEY[63:0];
                    s3<=NONCE[127:64]; s4<=NONCE[63:0];
                    perm_start_round<=0; perm_num_rounds<=12; perm_start<=1;
                    state<=ST_ENC_INIT_PERM;
                end
                ST_ENC_INIT_PERM: if(perm_done) begin
                    s0<=perm_out0; s1<=perm_out1; s2<=perm_out2;
                    s3<=perm_out3^KEY[127:64]; s4<=perm_out4^KEY[63:0];
                    state<=ST_ENC_AAD;
                end
                ST_ENC_AAD: begin
                    s0<=s0^AAD_PADDED; perm_start_round<=6; perm_num_rounds<=6;
                    perm_start<=1; state<=ST_ENC_AAD_PERM;
                end
                ST_ENC_AAD_PERM: if(perm_done) begin
                    s0<=perm_out0;s1<=perm_out1;s2<=perm_out2;s3<=perm_out3;s4<=perm_out4;
                    state<=ST_ENC_AAD_DOM;
                end
                ST_ENC_AAD_DOM: begin s4<=s4^64'h1; block_idx<=0; state<=ST_ENC_PT; end
                ST_ENC_PT: begin
                    if(block_idx<PT_BLOCKS) begin
                        ciphertext[191-block_idx*64-:64]<=s0^PT_PADDED[191-block_idx*64-:64];
                        s0<=s0^PT_PADDED[191-block_idx*64-:64];
                        if(block_idx<PT_BLOCKS-1) begin
                            perm_start_round<=6; perm_num_rounds<=6; perm_start<=1;
                            block_idx<=block_idx+1; state<=ST_ENC_PT_PERM;
                        end else state<=ST_ENC_FINAL;
                    end else state<=ST_ENC_FINAL;
                end
                ST_ENC_PT_PERM: if(perm_done) begin
                    s0<=perm_out0;s1<=perm_out1;s2<=perm_out2;s3<=perm_out3;s4<=perm_out4;
                    state<=ST_ENC_PT;
                end
                ST_ENC_FINAL: begin
                    s1<=s1^KEY[127:64]; s2<=s2^KEY[63:0];
                    perm_start_round<=0; perm_num_rounds<=12; perm_start<=1;
                    state<=ST_ENC_FINAL_W;
                end
                ST_ENC_FINAL_W: if(perm_done) begin
                    tag_enc<={perm_out3^KEY[127:64],perm_out4^KEY[63:0]};
                    state<=ST_TAG_STORE;
                end
                ST_TAG_STORE: state<=ST_DEC_INIT;
                ST_DEC_INIT: begin
                    s0<=IV; s1<=KEY[127:64]; s2<=KEY[63:0];
                    s3<=NONCE[127:64]; s4<=NONCE[63:0];
                    perm_start_round<=0; perm_num_rounds<=12; perm_start<=1;
                    state<=ST_DEC_INIT_PERM;
                end
                ST_DEC_INIT_PERM: if(perm_done) begin
                    s0<=perm_out0;s1<=perm_out1;s2<=perm_out2;
                    s3<=perm_out3^KEY[127:64];s4<=perm_out4^KEY[63:0];
                    state<=ST_DEC_AAD;
                end
                ST_DEC_AAD: begin
                    s0<=s0^AAD_PADDED; perm_start_round<=6; perm_num_rounds<=6;
                    perm_start<=1; state<=ST_DEC_AAD_PERM;
                end
                ST_DEC_AAD_PERM: if(perm_done) begin
                    s0<=perm_out0;s1<=perm_out1;s2<=perm_out2;s3<=perm_out3;s4<=perm_out4;
                    state<=ST_DEC_AAD_DOM;
                end
                ST_DEC_AAD_DOM: begin s4<=s4^64'h1; block_idx<=0; state<=ST_DEC_CT; end
                ST_DEC_CT: begin
                    if(block_idx<PT_BLOCKS) begin
                        plaintext_dec[191-block_idx*64-:64]<=s0^ciphertext[191-block_idx*64-:64];
                        s0<=ciphertext[191-block_idx*64-:64];
                        if(block_idx<PT_BLOCKS-1) begin
                            perm_start_round<=6; perm_num_rounds<=6; perm_start<=1;
                            block_idx<=block_idx+1; state<=ST_DEC_CT_PERM;
                        end else state<=ST_DEC_FINAL;
                    end else state<=ST_DEC_FINAL;
                end
                ST_DEC_CT_PERM: if(perm_done) begin
                    s0<=perm_out0;s1<=perm_out1;s2<=perm_out2;s3<=perm_out3;s4<=perm_out4;
                    state<=ST_DEC_CT;
                end
                ST_DEC_FINAL: begin
                    s1<=s1^KEY[127:64]; s2<=s2^KEY[63:0];
                    perm_start_round<=0; perm_num_rounds<=12; perm_start<=1;
                    state<=ST_DEC_FINAL_W;
                end
                ST_DEC_FINAL_W: if(perm_done) begin
                    tag_match<=(tag_enc=={perm_out3^KEY[127:64],perm_out4^KEY[63:0]});
                    done<=1; state<=ST_DONE;
                end
                ST_DONE: ;
                default: state<=ST_IDLE;
            endcase
        end
    end
endmodule


//=============================================================================
// ascon_perm_wavefront
//
// Systolic word-parallel PE array. Five PEs, one per state word.
//
// Phase encoding (2-bit wf_phase register):
//   WF_CONST  (2'd0): Each PE applies its round constant locally.
//                     Only PE_2 is modified; all PEs register the result.
//                     No cross-PE bus traffic.
//
//   WF_THETA  (2'd1): Two sub-cycles fused:
//     Cycle WF_THETA: Each PE XORs ALL five words (read simultaneously
//                     from x0..x4) to compute its own theta result.
//                     All parity contributions, rotation mixing, and
//                     theta application are fused combinationally.
//                     The theta output is registered into x0..x4.
//                     Cross-word reads happen in this single cycle using
//                     the combinational shared bus (not registered between PEs).
//
//   WF_CHI    (2'd2): Each PE reads registered neighbour words via the
//                     nb_bus (registered in WF_THETA). AND-NOT and XOR
//                     are computed locally per PE with the registered
//                     neighbour values. The result is written to x0..x4.
//                     nb_bus is refreshed from x0..x4 at the END of this phase.
//
//   WF_LINEAR (2'd3): Each PE independently applies its rotation constants.
//                     Zero cross-PE traffic in this phase. Result registered.
//                     After this phase, round_cnt increments.
//
// Cross-PE buses:
//   nb_bus[0..4]: Registered copies of x[(i+1)%5] used in WF_CHI.
//                 Loaded at the START of WF_CHI from the post-theta state.
//
// Critical path:
//   WF_THETA: x*_reg -> XOR (const) -> 5-input parity XOR tree (~3 levels)
//             -> rotate -> XOR -> x*_reg  (~8-10 gate levels, ~8 ns)
//   WF_CHI  : x*_reg (neighbour) -> AND-NOT -> XOR -> x*_reg  (~3-4 ns)
//   WF_LINEAR: x*_reg -> rotate -> XOR -> x*_reg  (~3 ns)
//   WF_CONST: x*_reg -> XOR -> x*_reg  (~1-2 ns)
//   Fmax target: 125 MHz / 8 ns (WF_THETA bottleneck)
//
// Clocks per pa=12 call : 12 × 4 = 48 + 1 FINISH = 49
// Clocks per pb=6  call :  6 × 4 = 24 + 1 FINISH = 25
//=============================================================================
module ascon_perm_wavefront (
    input  wire        clk, rst_n, start,
    input  wire [3:0]  start_round, rounds,
    input  wire [63:0] s0_in,s1_in,s2_in,s3_in,s4_in,
    output reg  [63:0] s0_out,s1_out,s2_out,s3_out,s4_out,
    output reg         done
);

    localparam [1:0] IDLE=2'd0, RUN=2'd1, FINISH=2'd2;

    // Wavefront phase counter
    localparam [1:0] WF_CONST=2'd0, WF_THETA=2'd1, WF_CHI=2'd2, WF_LINEAR=2'd3;

    reg [1:0]  state;
    reg [1:0]  wf_phase;        // wavefront phase (per-round 4-phase counter)
    reg [3:0]  round_cnt, round_end;

    // Primary state words — one register per PE
    reg [63:0] x0,x1,x2,x3,x4;

    // Registered neighbour bus — PE_i reads nb[i] = x[(i+1)%5] for Chi
    // Loaded from x* at the start of WF_CHI phase
    reg [63:0] nb0,nb1,nb2,nb3,nb4;

    // -------------------------------------------------------------------------
    // Round constant decode
    // -------------------------------------------------------------------------
    reg [7:0] rc;
    always @(*) case(round_cnt)
        4'd0:rc=8'hf0; 4'd1:rc=8'he1; 4'd2:rc=8'hd2; 4'd3:rc=8'hc3;
        4'd4:rc=8'hb4; 4'd5:rc=8'ha5; 4'd6:rc=8'h96; 4'd7:rc=8'h87;
        4'd8:rc=8'h78; 4'd9:rc=8'h69; 4'd10:rc=8'h5a; 4'd11:rc=8'h4b;
        default:rc=8'h00;
    endcase

    // =========================================================================
    // THETA combinational cone (driven from x* during WF_THETA)
    // Full theta fused: constant already applied in WF_CONST so x* is post-const
    // =========================================================================
    // Column parities (no constant addition needed — already done in WF_CONST)
    wire [63:0] tp0 = x0^x1^x2^x3^x4;
    wire [63:0] tp1 = x1^x2^x3^x4^x0;
    wire [63:0] tp2 = x2^x3^x4^x0^x1;
    wire [63:0] tp3 = x3^x4^x0^x1^x2;
    wire [63:0] tp4 = x4^x0^x1^x2^x3;

    // Rotation-mixed parities
    wire [63:0] tm0 = tp4^{tp1[0],tp1[63:1]};
    wire [63:0] tm1 = tp0^{tp2[0],tp2[63:1]};
    wire [63:0] tm2 = tp1^{tp3[0],tp3[63:1]};
    wire [63:0] tm3 = tp2^{tp4[0],tp4[63:1]};
    wire [63:0] tm4 = tp3^{tp0[0],tp0[63:1]};

    // Theta output per PE (x XOR mixed_parity)
    wire [63:0] tt0 = x0^tm0;
    wire [63:0] tt1 = x1^tm1;
    wire [63:0] tt2 = x2^tm2;
    wire [63:0] tt3 = x3^tm3;
    wire [63:0] tt4 = x4^tm4;

    // =========================================================================
    // CHI combinational cone (driven from x* and nb* during WF_CHI)
    // PE_i: chi_xi = x_i XOR (~x_{i+1} AND x_{i+2})
    // nb[i] holds registered x[(i+1)%5], x[(i+2)%5] must be read from x* directly
    // =========================================================================
    // For Chi: new_xi = xi ^ (~x[i+1] & x[i+2])
    // nb0 = registered x1 (= x[(0+1)%5]), x2 = x[(0+2)%5] — read live from x2
    wire [63:0] ch0_w = x0 ^ (~nb0 & x2);
    wire [63:0] ch1_w = x1 ^ (~nb1 & x3);
    wire [63:0] ch2_w = ~(x2 ^ (~nb2 & x4));   // x2 inverted per ASCON spec
    wire [63:0] ch3_w = x3 ^ (~nb3 & x0);
    wire [63:0] ch4_w = x4 ^ (~nb4 & x1);

    // =========================================================================
    // LINEAR combinational cone (driven from x* during WF_LINEAR)
    // PE_i applies its own rotation constants independently
    // =========================================================================
    wire [63:0] ln0_w = x0^{x0[18:0],x0[63:19]}^{x0[27:0],x0[63:28]};
    wire [63:0] ln1_w = x1^{x1[60:0],x1[63:61]}^{x1[38:0],x1[63:39]};
    wire [63:0] ln2_w = x2^{x2[0],   x2[63:1]} ^{x2[5:0], x2[63:6]};
    wire [63:0] ln3_w = x3^{x3[9:0], x3[63:10]}^{x3[16:0],x3[63:17]};
    wire [63:0] ln4_w = x4^{x4[6:0], x4[63:7]} ^{x4[40:0],x4[63:41]};

    // =========================================================================
    // FSM + wavefront sequencer
    // =========================================================================
    always @(posedge clk or negedge rst_n) begin
        if(!rst_n) begin
            state<=IDLE; done<=0; wf_phase<=0; round_cnt<=0; round_end<=0;
            x0<=0;x1<=0;x2<=0;x3<=0;x4<=0;
            nb0<=0;nb1<=0;nb2<=0;nb3<=0;nb4<=0;
            s0_out<=0;s1_out<=0;s2_out<=0;s3_out<=0;s4_out<=0;
        end else case(state)
            IDLE: begin
                done<=0;
                if(start) begin
                    x0<=s0_in;x1<=s1_in;x2<=s2_in;x3<=s3_in;x4<=s4_in;
                    round_cnt<=start_round; round_end<=start_round+rounds;
                    wf_phase<=WF_CONST; state<=RUN;
                end
            end
            RUN: begin
                case(wf_phase)
                    // ----------------------------------------------------------
                    // WF_CONST: PE_2 XORs round constant. All others pass-through.
                    // No cross-PE bus traffic.
                    // ----------------------------------------------------------
                    WF_CONST: begin
                        x2 <= x2 ^ {56'd0, rc};
                        // x0,x1,x3,x4 unchanged (PEs hold their own words)
                        // Load neighbour bus for upcoming WF_CHI
                        // (loaded here so nb* is ready 2 phases ahead of use)
                        // Actually nb is loaded at WF_THETA exit; load here to
                        // pipeline the read. We load current x* as nb* now:
                        nb0<=x1; nb1<=x2; nb2<=x3; nb3<=x4; nb4<=x0;
                        wf_phase <= WF_THETA;
                    end
                    // ----------------------------------------------------------
                    // WF_THETA: all 5 PEs apply theta simultaneously using
                    // shared combinational reads of x0..x4 (all-to-all XOR tree).
                    // Theta cone outputs tt0..tt4 are registered into x*.
                    // ----------------------------------------------------------
                    WF_THETA: begin
                        x0<=tt0; x1<=tt1; x2<=tt2; x3<=tt3; x4<=tt4;
                        // Refresh nb* with post-theta values for Chi:
                        // nb[i] = x[(i+1)%5] after theta
                        nb0<=tt1; nb1<=tt2; nb2<=tt3; nb3<=tt4; nb4<=tt0;
                        wf_phase <= WF_CHI;
                    end
                    // ----------------------------------------------------------
                    // WF_CHI: each PE reads its own x_i and registered nb[i]
                    // (= post-theta x[i+1]). Second neighbour x[i+2] is read
                    // live from the combinational x* bus.
                    // ----------------------------------------------------------
                    WF_CHI: begin
                        x0<=ch0_w; x1<=ch1_w; x2<=ch2_w; x3<=ch3_w; x4<=ch4_w;
                        wf_phase <= WF_LINEAR;
                    end
                    // ----------------------------------------------------------
                    // WF_LINEAR: each PE independently applies its own rotations.
                    // No cross-PE traffic. After this phase, round ends.
                    // ----------------------------------------------------------
                    WF_LINEAR: begin
                        x0<=ln0_w; x1<=ln1_w; x2<=ln2_w; x3<=ln3_w; x4<=ln4_w;
                        wf_phase <= WF_CONST;
                        if(round_cnt < round_end-1) begin
                            round_cnt <= round_cnt + 1;
                        end else begin
                            state <= FINISH;
                        end
                    end
                    default: wf_phase <= WF_CONST;
                endcase
            end
            FINISH: begin
                s0_out<=x0;s1_out<=x1;s2_out<=x2;
                s3_out<=x3;s4_out<=x4; done<=1; state<=IDLE;
            end
            default: state<=IDLE;
        endcase
    end
endmodule
