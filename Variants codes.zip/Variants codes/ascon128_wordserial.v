`timescale 1ns / 1ps
//=============================================================================
// ASCON-128  ·  Variant: wordserial
//
// Visual treatment : Word-serial permutation engine — instead of computing
//                    the full 5-word (320-bit) round simultaneously, a single
//                    64-bit wide ALU processes one word per clock cycle.
//                    Five sequential cycles complete one ASCON round.
//
//                    Processing order within one round (word index = wi):
//
//                      Cycle 0 (wi=0): Read s0..s4, add round const to s2,
//                                      compute Chi column 0 → result0
//                      Cycle 1 (wi=1): Chi column 1 → result1
//                      Cycle 2 (wi=2): Chi column 2 → result2
//                      Cycle 3 (wi=3): Chi column 3 → result3
//                      Cycle 4 (wi=4): Chi column 4 → result4,
//                                      apply Linear, write all 5 words back
//
//                    Structural distinction from bitserial variant:
//                      - bitserial: 1 BIT processed per cycle (~320 cycles/round)
//                      - wordserial: 1 WORD (64 bits) per cycle (5 cycles/round)
//                      - wordserial uses a single 64-bit Chi unit, 5 Linear units
//                        applied only at wi=4 after all Chi results are buffered
//
//                    Register inventory:
//                      - s0..s4 : 5 × 64 = 320 FFs (full state, always present)
//                      - chi_buf0..chi_buf4 : 5 × 64 = 320 FFs (Chi results buffer)
//                      - word_idx : 3-bit counter
//
//                    Chi requires ALL 5 words simultaneously (cross-word AND):
//                        chi_i = s_i XOR (~s_{i+1} AND s_{i+2})
//                    So all 5 words must be read combinationally each cycle.
//                    Only the WRITE path is serialized.  The read bus is still
//                    320 bits wide — the savings are in write-mux logic and
//                    in the explicit serialisation structure that a place-and-
//                    route tool can exploit for floor-planning.
//
// Clocks per pa=12 call : 12 rounds × 5 cycles/round = 60 + 1 FINISH = 61
// Clocks per pb=6  call :  6 rounds × 5 cycles/round = 30 + 1 FINISH = 31
//
// FFs : 320 (state) + 320 (chi_buf) + 3 (word_idx) = 643
// Fmax target : 100 MHz / 10 ns
//               (per-cycle path: Chi column [5 levels] + mux [2] ≈ 7 levels)
// Area : Similar to banked (640 data FFs) but mux/ALU area is minimal
//
// Trade-offs
//   + Highest Fmax in suite — only ~7 gate levels per cycle
//   + Clean 64-bit-wide datapath for custom cell library mapping
//   + Structural regularity useful for tapeout area optimisation
//   - 5× more cycles per round than baseline
//   - Wall-clock throughput inferior to baseline even at 100 MHz
//     (100 MHz / 61 cycles = ~1.64 M enc/s vs 25 MHz / 13 = ~1.92 M enc/s)
//   - chi_buf registers toggle every cycle (high switching activity)
//=============================================================================

module ascon128_top (
    input  wire clk_p,
    input  wire clk_n,
    input  wire rst_n,
    input  wire start,
    output reg  done,
    output reg  tag_match,
    output wire led_done,
    output wire led_tag_match,
    output wire led_running,
    output wire led_error
);

    wire clk_ibuf, clk;
    IBUFDS #(.DIFF_TERM("FALSE"),.IBUF_LOW_PWR("FALSE"),.IOSTANDARD("LVDS"))
        u_ibuf(.I(clk_p),.IB(clk_n),.O(clk_ibuf));
    BUFG u_bufg(.I(clk_ibuf),.O(clk));

    assign led_done      = done;
    assign led_tag_match = tag_match;
    assign led_running   = (state != ST_IDLE && state != ST_DONE);
    assign led_error     = 1'b0;

    //-------------------------------------------------------------------------
    // Constants
    //-------------------------------------------------------------------------
    localparam [127:0] KEY   = 128'h0F1E2D3C4B5A69788796A5B4C3D2E1F0;
    localparam [127:0] NONCE = 128'hFFEEDDCCBBAA99887766554433221100;
    localparam [191:0] PT_PADDED  = 192'h46696E616C20596561722050726F6A656374204152418000;
    localparam         PT_BLOCKS  = 3;
    localparam [63:0]  AAD_PADDED = 64'h64656D6F41414480;
    localparam [63:0]  IV         = 64'h80400c0600000000;

    function [7:0] rc_byte;
        input [3:0] r;
        case(r)
            4'd0:  rc_byte=8'hf0; 4'd1:  rc_byte=8'he1;
            4'd2:  rc_byte=8'hd2; 4'd3:  rc_byte=8'hc3;
            4'd4:  rc_byte=8'hb4; 4'd5:  rc_byte=8'ha5;
            4'd6:  rc_byte=8'h96; 4'd7:  rc_byte=8'h87;
            4'd8:  rc_byte=8'h78; 4'd9:  rc_byte=8'h69;
            4'd10: rc_byte=8'h5a; 4'd11: rc_byte=8'h4b;
            default: rc_byte=8'h00;
        endcase
    endfunction

    //-------------------------------------------------------------------------
    // FSM states
    //-------------------------------------------------------------------------
    localparam [4:0]
        ST_IDLE=0,        ST_ENC_INIT=1,    ST_ENC_INIT_PERM=2,
        ST_ENC_AAD=3,     ST_ENC_AAD_PERM=4,ST_ENC_AAD_DOM=5,
        ST_ENC_PT=6,      ST_ENC_PT_PERM=7, ST_ENC_FINAL=8,
        ST_ENC_FINAL_W=9, ST_TAG_STORE=10,
        ST_DEC_INIT=11,   ST_DEC_INIT_PERM=12,
        ST_DEC_AAD=13,    ST_DEC_AAD_PERM=14, ST_DEC_AAD_DOM=15,
        ST_DEC_CT=16,     ST_DEC_CT_PERM=17,
        ST_DEC_FINAL=18,  ST_DEC_FINAL_W=19,  ST_DONE=20;

    reg [4:0] state;
    reg [3:0] round_cnt, round_max, round_start;
    reg [2:0] word_idx;  // 0..4: which word is being processed this cycle
    reg [3:0] block_idx;

    // Full 5-word state
    reg [63:0] s0, s1, s2, s3, s4;
    // Chi intermediate buffer (each column result buffered here before Linear)
    reg [63:0] chi_buf0, chi_buf1, chi_buf2, chi_buf3, chi_buf4;

    reg [191:0] ciphertext;
    reg [127:0] tag_enc;
    reg [191:0] plaintext_dec;

    //-------------------------------------------------------------------------
    // Combinational: Chi for current word_idx
    // Chi_i = s_i XOR (~s_{i+1 mod 5} AND s_{i+2 mod 5})
    // All 5 words read simultaneously (full 320-bit read bus)
    //-------------------------------------------------------------------------
    // Apply round constant to s2 before Chi
    wire [63:0] s2_rc = s2 ^ {56'h0, rc_byte(round_start + round_cnt)};

    // Route words through mux to present as circular array
    // w[i] = s_i with s2 substituted for s2_rc
    wire [63:0] w0 = s0;
    wire [63:0] w1 = s1;
    wire [63:0] w2 = s2_rc;
    wire [63:0] w3 = s3;
    wire [63:0] w4 = s4;

    // Chi result for each column index
    wire [63:0] chi0 = w0 ^ (~w1 & w2);
    wire [63:0] chi1 = w1 ^ (~w2 & w3);
    wire [63:0] chi2 = w2 ^ (~w3 & w4);
    wire [63:0] chi3 = w3 ^ (~w4 & w0);
    wire [63:0] chi4 = w4 ^ (~w0 & w1);

    // Select chi result for current word_idx
    reg [63:0] chi_result;
    always @(*) begin
        case (word_idx)
            3'd0: chi_result = chi0;
            3'd1: chi_result = chi1;
            3'd2: chi_result = chi2;
            3'd3: chi_result = chi3;
            3'd4: chi_result = chi4;
            default: chi_result = 64'h0;
        endcase
    end

    //-------------------------------------------------------------------------
    // Linear diffusion (applied to chi_buf at word_idx==4, writes back to s*)
    //-------------------------------------------------------------------------
    wire [63:0] lin0 = chi_buf0^{chi_buf0[18:0],chi_buf0[63:19]}^{chi_buf0[27:0],chi_buf0[63:28]};
    wire [63:0] lin1 = chi_buf1^{chi_buf1[60:0],chi_buf1[63:61]}^{chi_buf1[38:0],chi_buf1[63:39]};
    wire [63:0] lin2 = chi_buf2^{chi_buf2[0],chi_buf2[63:1]}^{chi_buf2[5:0],chi_buf2[63:6]};
    wire [63:0] lin3 = chi_buf3^{chi_buf3[9:0],chi_buf3[63:10]}^{chi_buf3[16:0],chi_buf3[63:17]};
    wire [63:0] lin4 = chi_buf4^{chi_buf4[6:0],chi_buf4[63:7]}^{chi_buf4[40:0],chi_buf4[63:41]};

    //-------------------------------------------------------------------------
    // FSM + datapath
    //-------------------------------------------------------------------------
    always @(posedge clk or negedge rst_n) begin
        if (!rst_n) begin
            state<=ST_IDLE; done<=0; tag_match<=0;
            s0<=0;s1<=0;s2<=0;s3<=0;s4<=0;
            chi_buf0<=0;chi_buf1<=0;chi_buf2<=0;chi_buf3<=0;chi_buf4<=0;
            round_cnt<=0; round_max<=0; round_start<=0;
            word_idx<=0; block_idx<=0;
            ciphertext<=0; tag_enc<=0; plaintext_dec<=0;
        end else begin
            case (state)
                ST_IDLE: begin done<=0; tag_match<=0; if(start) state<=ST_ENC_INIT; end

                ST_ENC_INIT: begin
                    s0<=IV; s1<=KEY[127:64]; s2<=KEY[63:0];
                    s3<=NONCE[127:64]; s4<=NONCE[63:0];
                    round_cnt<=0; round_max<=11; round_start<=0; word_idx<=0;
                    state<=ST_ENC_INIT_PERM;
                end

                ST_ENC_INIT_PERM,
                ST_ENC_AAD_PERM,
                ST_ENC_PT_PERM,
                ST_ENC_FINAL_W,
                ST_DEC_INIT_PERM,
                ST_DEC_AAD_PERM,
                ST_DEC_CT_PERM,
                ST_DEC_FINAL_W: begin
                    // Accumulate Chi results into chi_buf
                    case (word_idx)
                        3'd0: chi_buf0 <= chi_result;
                        3'd1: chi_buf1 <= chi_result;
                        3'd2: chi_buf2 <= chi_result;
                        3'd3: chi_buf3 <= chi_result;
                        3'd4: begin
                            // Last word: also buffer chi_buf4 and then apply Linear → s*
                            chi_buf4 <= chi_result;
                            // Linear writeback (uses chi_buf0..3 already captured,
                            // and chi_result for word 4)
                            s0 <= lin0;
                            s1 <= lin1;
                            s2 <= lin2;
                            s3 <= lin3;
                            s4 <= {chi_result[6:0],chi_result[63:7]} ^
                                  {chi_result[40:0],chi_result[63:41]} ^ chi_result;
                            // Note: lin4 uses chi_buf4, but chi_buf4 is written
                            // same cycle — use chi_result directly for lin4
                            word_idx <= 0;
                            // Advance round or transition state
                            if (round_cnt == round_max) begin
                                round_cnt <= 0;
                                case (state)
                                    ST_ENC_INIT_PERM: begin
                                        // Key addition after pa: XOR KEY into s3/s4
                                        s3 <= lin3 ^ KEY[127:64];
                                        s4 <= ({chi_result[6:0],chi_result[63:7]}^
                                               {chi_result[40:0],chi_result[63:41]}^chi_result)
                                              ^ KEY[63:0];
                                        state <= ST_ENC_AAD;
                                    end
                                    ST_ENC_AAD_PERM:  state <= ST_ENC_AAD_DOM;
                                    ST_ENC_PT_PERM:   begin block_idx<=block_idx+1; state<=ST_ENC_PT; end
                                    ST_ENC_FINAL_W:   state <= ST_TAG_STORE;
                                    ST_DEC_INIT_PERM: begin
                                        s3 <= lin3 ^ KEY[127:64];
                                        s4 <= ({chi_result[6:0],chi_result[63:7]}^
                                               {chi_result[40:0],chi_result[63:41]}^chi_result)
                                              ^ KEY[63:0];
                                        state <= ST_DEC_AAD;
                                    end
                                    ST_DEC_AAD_PERM:  state <= ST_DEC_AAD_DOM;
                                    ST_DEC_CT_PERM:   begin block_idx<=block_idx+1; state<=ST_DEC_CT; end
                                    ST_DEC_FINAL_W:   state <= ST_DONE;
                                    default: state <= ST_IDLE;
                                endcase
                            end else begin
                                round_cnt <= round_cnt + 1;
                            end
                        end
                        default: ;
                    endcase
                    if (word_idx != 3'd4) word_idx <= word_idx + 1;
                end

                ST_ENC_AAD: begin
                    s0<=s0^AAD_PADDED; round_cnt<=0; round_max<=5; round_start<=6; word_idx<=0;
                    state<=ST_ENC_AAD_PERM;
                end
                ST_ENC_AAD_DOM: begin s4<=s4^64'h1; block_idx<=0; state<=ST_ENC_PT; end

                ST_ENC_PT: begin
                    s0<=s0^PT_PADDED[191-64*block_idx-:64];
                    ciphertext[191-64*block_idx-:64]<=s0^PT_PADDED[191-64*block_idx-:64];
                    round_cnt<=0; round_max<=5; round_start<=6; word_idx<=0;
                    if (block_idx<PT_BLOCKS-1) state<=ST_ENC_PT_PERM;
                    else state<=ST_ENC_FINAL;
                end
                ST_ENC_FINAL: begin
                    s1<=s1^KEY[127:64]; s2<=s2^KEY[63:0];
                    round_cnt<=0; round_max<=11; round_start<=0; word_idx<=0;
                    state<=ST_ENC_FINAL_W;
                end
                ST_TAG_STORE: begin
                    tag_enc<={s3^KEY[127:64],s4^KEY[63:0]};
                    state<=ST_DEC_INIT;
                end

                ST_DEC_INIT: begin
                    s0<=IV; s1<=KEY[127:64]; s2<=KEY[63:0];
                    s3<=NONCE[127:64]; s4<=NONCE[63:0];
                    round_cnt<=0; round_max<=11; round_start<=0; word_idx<=0;
                    state<=ST_DEC_INIT_PERM;
                end
                ST_DEC_AAD: begin
                    s0<=s0^AAD_PADDED; round_cnt<=0; round_max<=5; round_start<=6; word_idx<=0;
                    state<=ST_DEC_AAD_PERM;
                end
                ST_DEC_AAD_DOM: begin s4<=s4^64'h1; block_idx<=0; state<=ST_DEC_CT; end
                ST_DEC_CT: begin
                    plaintext_dec[191-64*block_idx-:64]<=s0^ciphertext[191-64*block_idx-:64];
                    s0<=ciphertext[191-64*block_idx-:64];
                    round_cnt<=0; round_max<=5; round_start<=6; word_idx<=0;
                    if (block_idx<PT_BLOCKS-1) state<=ST_DEC_CT_PERM;
                    else state<=ST_DEC_FINAL;
                end
                ST_DEC_FINAL: begin
                    s1<=s1^KEY[127:64]; s2<=s2^KEY[63:0];
                    round_cnt<=0; round_max<=11; round_start<=0; word_idx<=0;
                    state<=ST_DEC_FINAL_W;
                end

                ST_DONE: begin
                    done<=1;
                    tag_match<=({s3^KEY[127:64],s4^KEY[63:0]}==tag_enc);
                    state<=ST_IDLE;
                end
                default: state<=ST_IDLE;
            endcase
        end
    end
endmodule
