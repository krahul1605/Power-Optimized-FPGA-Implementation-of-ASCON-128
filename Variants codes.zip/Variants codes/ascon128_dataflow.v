`timescale 1ns / 1ps
//=============================================================================
// ASCON-128  ·  Variant: dataflow
//
// Visual treatment : Token-passing dataflow pipeline — each of the five
//                    cryptographic sub-operations (Const, Theta, Chi, Linear,
//                    and a Round-Control stage) is implemented as a dedicated
//                    always block acting as an independent dataflow "actor".
//                    Data tokens flow between actors through registered
//                    valid/accept handshake signals and dedicated inter-stage
//                    data registers. No central FSM dispatches sub-steps;
//                    instead each actor fires autonomously when its input
//                    valid strobe is asserted and its output register is free.
//
//                    Actor pipeline (one token per round passes through):
//
//     ACTOR_RC  : Round-Constant actor
//                 Fires when: rc_valid asserted (from upstream)
//                 Action: XOR round constant into x2; pass token to theta
//                 Registers: rc_x{0..4}, rc_valid
//
//     ACTOR_TH  : Theta actor
//                 Fires when: th_valid asserted (from RC actor)
//                 Action: Full Theta (parities + rotation mix + apply)
//                 Registers: th_x{0..4}, th_valid
//
//     ACTOR_CH  : Chi actor
//                 Fires when: ch_valid asserted (from Theta actor)
//                 Action: Full Chi (AND-NOT + XOR, x2 inverted)
//                 Registers: ch_x{0..4}, ch_valid
//
//     ACTOR_LN  : Linear actor
//                 Fires when: ln_valid asserted (from Chi actor)
//                 Action: Full Linear (two rotations + XOR per word)
//                 Registers: ln_x{0..4}, ln_valid
//
//     ACTOR_RND : Round-Control actor
//                 Fires when: ln_valid asserted (reads from Linear output)
//                 Action: Increment round counter; re-inject token into RC
//                         if more rounds remain, else signal FINISH
//                 Registers: round_cnt, done flag
//
//                    The structural novelty is the control topology:
//                      - No sub-step mux (unlike folded)
//                      - No shared state registers (unlike tristate)
//                      - Each actor owns its own dedicated data registers
//                      - Handshake valid strobes, NOT a phase counter,
//                        sequence the pipeline — this decouples the control
//                        plane (valid/accept) from the data plane (x* banks)
//                      - In this single-token implementation the pipeline runs
//                        at one-token-at-a-time throughput (same as folded),
//                        but the structural form maps cleanly to a multi-token
//                        throughput extension
//
// Clocks per pa=12 call : 12 rounds × 4 actor stages = 48 + 1 FINISH = 49
// Clocks per pb=6  call :  6 rounds × 4 actor stages = 24 + 1 FINISH = 25
//
// Trade-offs
//   + No central mux — each actor's combinational path is pure
//   + Valid strobes create a clear structural boundary for power gating
//   + Each actor's data registers are physically independent clusters
//   + Pipeline extends naturally to multi-token (throughput > 1 round/4 clocks)
//   - Five independent register banks (5 × 320 FFs = 1600 FFs total)
//   - Valid strobe logic adds small overhead per actor (~5 FFs)
//   - In single-token mode, latency is identical to wavefront/retimed (49/25)
//
// Functional parity: identical ports and FSM encoding to all variants.
//                    NIST-compliant ASCON-128 algorithm.
//=============================================================================

module ascon128_top (
    input  wire clk_p,
    input  wire clk_n,
    input  wire rst_n,
    input  wire start,
    output wire done,
    output wire tag_match,
    output wire led_done,
    output wire led_tag_match,
    output wire led_running,
    output wire led_error
);

    wire clk_ibuf, clk;

    IBUFDS #(
        .DIFF_TERM("FALSE"), .IBUF_LOW_PWR("FALSE"), .IOSTANDARD("LVDS")
    ) clk_ibufds (.I(clk_p), .IB(clk_n), .O(clk_ibuf));

    BUFG clk_bufg (.I(clk_ibuf), .O(clk));

    wire core_done, core_tag_match;
    reg  running_r;

    ascon128_complete_dataflow ascon_core (
        .clk(clk), .rst_n(rst_n), .start(start),
        .done(core_done), .tag_match(core_tag_match)
    );

    assign done = core_done; assign tag_match = core_tag_match;

    always @(posedge clk or negedge rst_n) begin
        if (!rst_n)         running_r <= 0;
        else if (start)     running_r <= 1;
        else if (core_done) running_r <= 0;
    end

    assign led_done=core_done; assign led_tag_match=core_done&core_tag_match;
    assign led_running=running_r; assign led_error=core_done&~core_tag_match;

endmodule


//=============================================================================
// ascon128_complete_dataflow  — FSM (identical structure to all variants)
//=============================================================================
module ascon128_complete_dataflow (
    input  wire clk, rst_n, start,
    output reg  done, tag_match
);
    localparam [127:0] KEY   = 128'h0F1E2D3C4B5A69788796A5B4C3D2E1F0;
    localparam [127:0] NONCE = 128'hFFEEDDCCBBAA99887766554433221100;
    localparam [191:0] PT_PADDED  = 192'h46696E616C20596561722050726F6A656374204152418000;
    localparam         PT_BLOCKS  = 3;
    localparam [63:0]  AAD_PADDED = 64'h64656D6F41414480;
    localparam [63:0]  IV         = 64'h80400c0600000000;

    localparam [4:0]
        ST_IDLE=0, ST_ENC_INIT=1, ST_ENC_INIT_PERM=2,
        ST_ENC_AAD=3, ST_ENC_AAD_PERM=4, ST_ENC_AAD_DOM=5,
        ST_ENC_PT=6, ST_ENC_PT_PERM=7, ST_ENC_FINAL=8,
        ST_ENC_FINAL_W=9, ST_TAG_STORE=10, ST_DEC_INIT=11,
        ST_DEC_INIT_PERM=12, ST_DEC_AAD=13, ST_DEC_AAD_PERM=14,
        ST_DEC_AAD_DOM=15, ST_DEC_CT=16, ST_DEC_CT_PERM=17,
        ST_DEC_FINAL=18, ST_DEC_FINAL_W=19, ST_DONE=20;

    reg [4:0] state; reg [3:0] block_idx;
    reg [63:0] s0,s1,s2,s3,s4;
    reg [191:0] ciphertext; reg [127:0] tag_enc; reg [191:0] plaintext_dec;
    reg perm_start; wire perm_done;
    reg [3:0] perm_start_round, perm_num_rounds;
    wire [63:0] perm_out0,perm_out1,perm_out2,perm_out3,perm_out4;

    ascon_perm_dataflow perm_inst (
        .clk(clk), .rst_n(rst_n), .start(perm_start),
        .start_round(perm_start_round), .rounds(perm_num_rounds),
        .s0_in(s0),.s1_in(s1),.s2_in(s2),.s3_in(s3),.s4_in(s4),
        .s0_out(perm_out0),.s1_out(perm_out1),.s2_out(perm_out2),
        .s3_out(perm_out3),.s4_out(perm_out4),.done(perm_done)
    );

    always @(posedge clk or negedge rst_n) begin
        if (!rst_n) begin
            state<=0; done<=0; tag_match<=0; perm_start<=0;
            perm_start_round<=0; perm_num_rounds<=0; block_idx<=0;
            s0<=0;s1<=0;s2<=0;s3<=0;s4<=0;
            ciphertext<=0; tag_enc<=0; plaintext_dec<=0;
        end else begin
            perm_start<=0;
            case(state)
                ST_IDLE: begin done<=0; tag_match<=0; if(start) state<=ST_ENC_INIT; end
                ST_ENC_INIT: begin
                    s0<=IV; s1<=KEY[127:64]; s2<=KEY[63:0];
                    s3<=NONCE[127:64]; s4<=NONCE[63:0];
                    perm_start_round<=0; perm_num_rounds<=12; perm_start<=1;
                    state<=ST_ENC_INIT_PERM;
                end
                ST_ENC_INIT_PERM: if(perm_done) begin
                    s0<=perm_out0; s1<=perm_out1; s2<=perm_out2;
                    s3<=perm_out3^KEY[127:64]; s4<=perm_out4^KEY[63:0];
                    state<=ST_ENC_AAD;
                end
                ST_ENC_AAD: begin
                    s0<=s0^AAD_PADDED; perm_start_round<=6; perm_num_rounds<=6;
                    perm_start<=1; state<=ST_ENC_AAD_PERM;
                end
                ST_ENC_AAD_PERM: if(perm_done) begin
                    s0<=perm_out0;s1<=perm_out1;s2<=perm_out2;s3<=perm_out3;s4<=perm_out4;
                    state<=ST_ENC_AAD_DOM;
                end
                ST_ENC_AAD_DOM: begin s4<=s4^64'h1; block_idx<=0; state<=ST_ENC_PT; end
                ST_ENC_PT: begin
                    if(block_idx<PT_BLOCKS) begin
                        ciphertext[191-block_idx*64-:64]<=s0^PT_PADDED[191-block_idx*64-:64];
                        s0<=s0^PT_PADDED[191-block_idx*64-:64];
                        if(block_idx<PT_BLOCKS-1) begin
                            perm_start_round<=6; perm_num_rounds<=6; perm_start<=1;
                            block_idx<=block_idx+1; state<=ST_ENC_PT_PERM;
                        end else state<=ST_ENC_FINAL;
                    end else state<=ST_ENC_FINAL;
                end
                ST_ENC_PT_PERM: if(perm_done) begin
                    s0<=perm_out0;s1<=perm_out1;s2<=perm_out2;s3<=perm_out3;s4<=perm_out4;
                    state<=ST_ENC_PT;
                end
                ST_ENC_FINAL: begin
                    s1<=s1^KEY[127:64]; s2<=s2^KEY[63:0];
                    perm_start_round<=0; perm_num_rounds<=12; perm_start<=1;
                    state<=ST_ENC_FINAL_W;
                end
                ST_ENC_FINAL_W: if(perm_done) begin
                    tag_enc<={perm_out3^KEY[127:64],perm_out4^KEY[63:0]};
                    state<=ST_TAG_STORE;
                end
                ST_TAG_STORE: state<=ST_DEC_INIT;
                ST_DEC_INIT: begin
                    s0<=IV; s1<=KEY[127:64]; s2<=KEY[63:0];
                    s3<=NONCE[127:64]; s4<=NONCE[63:0];
                    perm_start_round<=0; perm_num_rounds<=12; perm_start<=1;
                    state<=ST_DEC_INIT_PERM;
                end
                ST_DEC_INIT_PERM: if(perm_done) begin
                    s0<=perm_out0;s1<=perm_out1;s2<=perm_out2;
                    s3<=perm_out3^KEY[127:64];s4<=perm_out4^KEY[63:0];
                    state<=ST_DEC_AAD;
                end
                ST_DEC_AAD: begin
                    s0<=s0^AAD_PADDED; perm_start_round<=6; perm_num_rounds<=6;
                    perm_start<=1; state<=ST_DEC_AAD_PERM;
                end
                ST_DEC_AAD_PERM: if(perm_done) begin
                    s0<=perm_out0;s1<=perm_out1;s2<=perm_out2;s3<=perm_out3;s4<=perm_out4;
                    state<=ST_DEC_AAD_DOM;
                end
                ST_DEC_AAD_DOM: begin s4<=s4^64'h1; block_idx<=0; state<=ST_DEC_CT; end
                ST_DEC_CT: begin
                    if(block_idx<PT_BLOCKS) begin
                        plaintext_dec[191-block_idx*64-:64]<=s0^ciphertext[191-block_idx*64-:64];
                        s0<=ciphertext[191-block_idx*64-:64];
                        if(block_idx<PT_BLOCKS-1) begin
                            perm_start_round<=6; perm_num_rounds<=6; perm_start<=1;
                            block_idx<=block_idx+1; state<=ST_DEC_CT_PERM;
                        end else state<=ST_DEC_FINAL;
                    end else state<=ST_DEC_FINAL;
                end
                ST_DEC_CT_PERM: if(perm_done) begin
                    s0<=perm_out0;s1<=perm_out1;s2<=perm_out2;s3<=perm_out3;s4<=perm_out4;
                    state<=ST_DEC_CT;
                end
                ST_DEC_FINAL: begin
                    s1<=s1^KEY[127:64]; s2<=s2^KEY[63:0];
                    perm_start_round<=0; perm_num_rounds<=12; perm_start<=1;
                    state<=ST_DEC_FINAL_W;
                end
                ST_DEC_FINAL_W: if(perm_done) begin
                    tag_match<=(tag_enc=={perm_out3^KEY[127:64],perm_out4^KEY[63:0]});
                    done<=1; state<=ST_DONE;
                end
                ST_DONE: ;
                default: state<=ST_IDLE;
            endcase
        end
    end
endmodule


//=============================================================================
// ascon_perm_dataflow
//
// Token-passing dataflow pipeline with five independent actors.
// Each actor owns private data registers and a valid strobe.
// Sequencing is driven entirely by valid propagation — no FSM stage counter.
//
// Actor register banks and valid flags:
//   ACTOR_RC  : rc_x{0..4}  + rc_valid   — holds post-constant token
//   ACTOR_TH  : th_x{0..4}  + th_valid   — holds post-theta token
//   ACTOR_CH  : ch_x{0..4}  + ch_valid   — holds post-chi token
//   ACTOR_LN  : ln_x{0..4}  + ln_valid   — holds post-linear token
//
// Per-round flow:
//   Cycle 1: start strobe injects token into RC actor
//            rc_x* <= input XOR const; rc_valid <= 1
//   Cycle 2: RC valid fires Theta actor
//            th_x* <= theta(rc_x*); th_valid <= 1; rc_valid <= 0
//   Cycle 3: TH valid fires Chi actor
//            ch_x* <= chi(th_x*); ch_valid <= 1; th_valid <= 0
//   Cycle 4: CH valid fires Linear actor + Round-Control actor
//            ln_x* <= linear(ch_x*); ln_valid <= 1; ch_valid <= 0
//            Round-Control: if rounds remain, re-inject token to RC actor
//                           (rc_x* <= ln_x*; rc_valid <= 1; ln_valid <= 0)
//                           else: go to FINISH
//
// Critical path:
//   ACTOR_TH: th_x*_reg -> XOR parity tree -> rotate XOR -> apply XOR
//             -> th_x*_reg  (~8-10 gate levels; bottleneck)
//   ACTOR_CH: th_x*_reg -> AND-NOT -> XOR/INV -> ch_x*_reg  (~3-4 levels)
//   ACTOR_LN: ch_x*_reg -> rotate -> XOR -> ln_x*_reg  (~3-4 levels)
//   ACTOR_RC: input -> XOR -> rc_x*_reg  (~1-2 levels)
//   Fmax target: 100 MHz / 10 ns (ACTOR_TH bottleneck)
//
// Clocks per pa=12 call : 12 × 4 = 48 + 1 FINISH = 49
// Clocks per pb=6  call :  6 × 4 = 24 + 1 FINISH = 25
//=============================================================================
module ascon_perm_dataflow (
    input  wire        clk, rst_n, start,
    input  wire [3:0]  start_round, rounds,
    input  wire [63:0] s0_in,s1_in,s2_in,s3_in,s4_in,
    output reg  [63:0] s0_out,s1_out,s2_out,s3_out,s4_out,
    output reg         done
);

    localparam [1:0] IDLE=2'd0, RUN=2'd1, FINISH=2'd2;

    reg [1:0]  state;
    reg [3:0]  round_cnt, round_end;

    // =========================================================================
    // ACTOR_RC register bank — post round-constant state
    // =========================================================================
    reg [63:0] rc_x0,rc_x1,rc_x2,rc_x3,rc_x4;
    reg        rc_valid;

    // =========================================================================
    // ACTOR_TH register bank — post theta state
    // =========================================================================
    (* keep = "true" *) reg [63:0] th_x0,th_x1,th_x2,th_x3,th_x4;
    reg        th_valid;

    // =========================================================================
    // ACTOR_CH register bank — post chi state
    // =========================================================================
    (* keep = "true" *) reg [63:0] ch_x0,ch_x1,ch_x2,ch_x3,ch_x4;
    reg        ch_valid;

    // =========================================================================
    // ACTOR_LN register bank — post linear state (pipeline output)
    // =========================================================================
    (* keep = "true" *) reg [63:0] ln_x0,ln_x1,ln_x2,ln_x3,ln_x4;
    reg        ln_valid;

    // -------------------------------------------------------------------------
    // Round constant decode — driven from round_cnt
    // -------------------------------------------------------------------------
    reg [7:0] rc;
    always @(*) case(round_cnt)
        4'd0:rc=8'hf0; 4'd1:rc=8'he1; 4'd2:rc=8'hd2; 4'd3:rc=8'hc3;
        4'd4:rc=8'hb4; 4'd5:rc=8'ha5; 4'd6:rc=8'h96; 4'd7:rc=8'h87;
        4'd8:rc=8'h78; 4'd9:rc=8'h69; 4'd10:rc=8'h5a; 4'd11:rc=8'h4b;
        default:rc=8'h00;
    endcase

    // =========================================================================
    // Theta combinational cone — driven from rc_x* actor bank
    // =========================================================================
    // Column parities
    wire [63:0] df_tp0 = rc_x0^rc_x1^rc_x2^rc_x3^rc_x4;
    wire [63:0] df_tp1 = rc_x1^rc_x2^rc_x3^rc_x4^rc_x0;
    wire [63:0] df_tp2 = rc_x2^rc_x3^rc_x4^rc_x0^rc_x1;
    wire [63:0] df_tp3 = rc_x3^rc_x4^rc_x0^rc_x1^rc_x2;
    wire [63:0] df_tp4 = rc_x4^rc_x0^rc_x1^rc_x2^rc_x3;
    // Rotation mix
    wire [63:0] df_tm0 = df_tp4^{df_tp1[0],df_tp1[63:1]};
    wire [63:0] df_tm1 = df_tp0^{df_tp2[0],df_tp2[63:1]};
    wire [63:0] df_tm2 = df_tp1^{df_tp3[0],df_tp3[63:1]};
    wire [63:0] df_tm3 = df_tp2^{df_tp4[0],df_tp4[63:1]};
    wire [63:0] df_tm4 = df_tp3^{df_tp0[0],df_tp0[63:1]};
    // Theta output wires (registered into th_x* when th_valid fires)
    wire [63:0] df_th0 = rc_x0^df_tm0;
    wire [63:0] df_th1 = rc_x1^df_tm1;
    wire [63:0] df_th2 = rc_x2^df_tm2;
    wire [63:0] df_th3 = rc_x3^df_tm3;
    wire [63:0] df_th4 = rc_x4^df_tm4;

    // =========================================================================
    // Chi combinational cone — driven from th_x* actor bank
    // =========================================================================
    wire [63:0] df_ch0 = th_x0^(~th_x1&th_x2);
    wire [63:0] df_ch1 = th_x1^(~th_x2&th_x3);
    wire [63:0] df_ch2 = ~(th_x2^(~th_x3&th_x4));   // x2 inverted per ASCON spec
    wire [63:0] df_ch3 = th_x3^(~th_x4&th_x0);
    wire [63:0] df_ch4 = th_x4^(~th_x0&th_x1);

    // =========================================================================
    // Linear combinational cone — driven from ch_x* actor bank
    // =========================================================================
    wire [63:0] df_ln0 = ch_x0^{ch_x0[18:0],ch_x0[63:19]}^{ch_x0[27:0],ch_x0[63:28]};
    wire [63:0] df_ln1 = ch_x1^{ch_x1[60:0],ch_x1[63:61]}^{ch_x1[38:0],ch_x1[63:39]};
    wire [63:0] df_ln2 = ch_x2^{ch_x2[0],   ch_x2[63:1]} ^{ch_x2[5:0], ch_x2[63:6]};
    wire [63:0] df_ln3 = ch_x3^{ch_x3[9:0], ch_x3[63:10]}^{ch_x3[16:0],ch_x3[63:17]};
    wire [63:0] df_ln4 = ch_x4^{ch_x4[6:0], ch_x4[63:7]} ^{ch_x4[40:0],ch_x4[63:41]};

    // =========================================================================
    // FSM — handles IDLE/RUN/FINISH, injects initial token
    // =========================================================================
    always @(posedge clk or negedge rst_n) begin
        if(!rst_n) begin
            state<=IDLE; done<=0; round_cnt<=0; round_end<=0;
            rc_x0<=0;rc_x1<=0;rc_x2<=0;rc_x3<=0;rc_x4<=0; rc_valid<=0;
            th_x0<=0;th_x1<=0;th_x2<=0;th_x3<=0;th_x4<=0; th_valid<=0;
            ch_x0<=0;ch_x1<=0;ch_x2<=0;ch_x3<=0;ch_x4<=0; ch_valid<=0;
            ln_x0<=0;ln_x1<=0;ln_x2<=0;ln_x3<=0;ln_x4<=0; ln_valid<=0;
            s0_out<=0;s1_out<=0;s2_out<=0;s3_out<=0;s4_out<=0;
        end else begin
            case(state)
                // ==============================================================
                // IDLE: wait for start; inject initial token into ACTOR_RC
                // ==============================================================
                IDLE: begin
                    done<=0;
                    if(start) begin
                        round_cnt   <= start_round;
                        round_end   <= start_round + rounds;
                        // Inject token: apply first round constant immediately
                        rc_x0 <= s0_in;
                        rc_x1 <= s1_in;
                        rc_x2 <= s2_in ^ {56'd0, (
                                    (start_round==4'd0) ? 8'hf0 :
                                    (start_round==4'd6) ? 8'h96 : 8'h00)};
                        rc_x3 <= s3_in;
                        rc_x4 <= s4_in;
                        rc_valid <= 1;
                        state <= RUN;
                    end
                end

                // ==============================================================
                // RUN: token propagation managed by actor blocks below
                // State machine just monitors ln_valid for round completion
                // ==============================================================
                RUN: begin
                    // ---- ACTOR_TH fires when rc_valid is asserted ----
                    if(rc_valid) begin
                        th_x0<=df_th0; th_x1<=df_th1; th_x2<=df_th2;
                        th_x3<=df_th3; th_x4<=df_th4;
                        th_valid<=1;
                        rc_valid<=0;   // consume rc token
                    end

                    // ---- ACTOR_CH fires when th_valid is asserted ----
                    if(th_valid) begin
                        ch_x0<=df_ch0; ch_x1<=df_ch1; ch_x2<=df_ch2;
                        ch_x3<=df_ch3; ch_x4<=df_ch4;
                        ch_valid<=1;
                        th_valid<=0;   // consume th token
                    end

                    // ---- ACTOR_LN fires when ch_valid is asserted ----
                    if(ch_valid) begin
                        ln_x0<=df_ln0; ln_x1<=df_ln1; ln_x2<=df_ln2;
                        ln_x3<=df_ln3; ln_x4<=df_ln4;
                        ln_valid<=1;
                        ch_valid<=0;   // consume ch token
                    end

                    // ---- ACTOR_RND (Round Control) fires when ln_valid ----
                    if(ln_valid) begin
                        ln_valid<=0;  // consume ln token
                        if(round_cnt < round_end-1) begin
                            // More rounds: re-inject token into RC actor
                            // Apply next round's constant to ln output
                            round_cnt <= round_cnt + 1;
                            rc_x0 <= ln_x0;
                            rc_x1 <= ln_x1;
                            rc_x2 <= ln_x2 ^ {56'd0, (
                                        (round_cnt+1==4'd0)  ? 8'hf0 :
                                        (round_cnt+1==4'd1)  ? 8'he1 :
                                        (round_cnt+1==4'd2)  ? 8'hd2 :
                                        (round_cnt+1==4'd3)  ? 8'hc3 :
                                        (round_cnt+1==4'd4)  ? 8'hb4 :
                                        (round_cnt+1==4'd5)  ? 8'ha5 :
                                        (round_cnt+1==4'd6)  ? 8'h96 :
                                        (round_cnt+1==4'd7)  ? 8'h87 :
                                        (round_cnt+1==4'd8)  ? 8'h78 :
                                        (round_cnt+1==4'd9)  ? 8'h69 :
                                        (round_cnt+1==4'd10) ? 8'h5a :
                                        (round_cnt+1==4'd11) ? 8'h4b : 8'h00)};
                            rc_x3 <= ln_x3;
                            rc_x4 <= ln_x4;
                            rc_valid <= 1;
                        end else begin
                            // All rounds complete — move to FINISH
                            state <= FINISH;
                        end
                    end
                end

                // ==============================================================
                // FINISH: drain ln_x* to outputs
                // ==============================================================
                FINISH: begin
                    s0_out<=ln_x0; s1_out<=ln_x1; s2_out<=ln_x2;
                    s3_out<=ln_x3; s4_out<=ln_x4;
                    done<=1; state<=IDLE;
                end

                default: state<=IDLE;
            endcase
        end
    end
endmodule
