#==============================================================================
# ASCON-128  ·  Variant: dataflow
# SDC for Cadence Genus Synthesis
#
# Permutation architecture: Token-passing dataflow pipeline.
#   Five independent actor register banks (RC, TH, CH, LN + round control).
#   No central phase counter or sub-step mux — sequencing is driven entirely
#   by registered valid strobes propagating between actors.
#
#   Actor data registers and their timing paths:
#
#   ACTOR_RC  (rc_x* / rc_valid):
#     Path: s*_in or ln_x*_reg -> XOR(const) -> rc_x*_reg
#     Gate depth: ~1-2 levels. Estimated: ~1-2 ns.
#
#   ACTOR_TH  (th_x* / th_valid) — CRITICAL PATH:
#     Path: rc_x*_reg -> XOR parity tree (3 levels) -> rotate XOR ->
#           apply XOR -> th_x*_reg
#     Gate depth: ~8-10 levels. Estimated: ~8-9 ns.
#     This is the timing bottleneck — sizes the clock period.
#
#   ACTOR_CH  (ch_x* / ch_valid):
#     Path: th_x*_reg -> AND-NOT -> XOR -> [INV for x2] -> ch_x*_reg
#     Gate depth: ~3-4 levels. Estimated: ~3-4 ns.
#
#   ACTOR_LN  (ln_x* / ln_valid):
#     Path: ch_x*_reg -> rotate -> XOR -> ln_x*_reg
#     Gate depth: ~3-4 levels. Estimated: ~3-4 ns.
#
# Valid strobe paths (control plane):
#   rc_valid_reg -> th_valid_reg -> ch_valid_reg -> ln_valid_reg
#   These are single-bit registered signals — negligible timing impact.
#
# Fmax target: 100 MHz / 10 ns (ACTOR_TH bottleneck, conservative budget)
#
# Clocks per pa=12 call : 12 × 4 = 48 + 1 FINISH = 49
# Clocks per pb=6  call :  6 × 4 = 24 + 1 FINISH = 25
#
# Synthesis notes:
#   The (* keep = "true" *) pragmas on th_x*, ch_x*, ln_x* prevent Genus
#   from merging adjacent actor logic cones. This preserves the structural
#   actor boundary, which is important for:
#     - Power analysis (switching per actor can be measured independently)
#     - Physical implementation (one register cluster per actor)
#     - Future multi-token throughput extension (actors become pipeline stages)
#   The valid strobe signals (rc_valid, th_valid, ch_valid, ln_valid) should
#   remain as separate net objects — do not inline them into the data path.
#==============================================================================

#------------------------------------------------------------------------------
# 1. CLOCK DEFINITION
#    100 MHz / 10 ns — token-passing dataflow (ACTOR_TH bottleneck)
#------------------------------------------------------------------------------
create_clock -period 10.000 \
             -name sys_clk \
             -waveform {0.000 5.000} \
             [get_ports clk_p]

#------------------------------------------------------------------------------
# 2. CLOCK UNCERTAINTY
#    Moderate jitter budget for 100 MHz on ZCU104 LVDS input.
#------------------------------------------------------------------------------
set_clock_uncertainty -setup 0.200 [get_clocks sys_clk]
set_clock_uncertainty -hold  0.100 [get_clocks sys_clk]

#------------------------------------------------------------------------------
# 3. CLOCK TRANSITION
#------------------------------------------------------------------------------
set_clock_transition -rise 0.100 [get_clocks sys_clk]
set_clock_transition -fall 0.100 [get_clocks sys_clk]

#------------------------------------------------------------------------------
# 4. INPUT DELAYS
#------------------------------------------------------------------------------
set_input_delay -clock sys_clk -max 2.000 [get_ports rst_n]
set_input_delay -clock sys_clk -min 0.500 [get_ports rst_n]
set_input_delay -clock sys_clk -max 2.000 [get_ports start]
set_input_delay -clock sys_clk -min 0.500 [get_ports start]

#------------------------------------------------------------------------------
# 5. OUTPUT DELAYS
#------------------------------------------------------------------------------
set_output_delay -clock sys_clk -max 2.000 [get_ports done]
set_output_delay -clock sys_clk -min 0.500 [get_ports done]
set_output_delay -clock sys_clk -max 2.000 [get_ports tag_match]
set_output_delay -clock sys_clk -min 0.500 [get_ports tag_match]
set_output_delay -clock sys_clk -max 2.000 [get_ports led_done]
set_output_delay -clock sys_clk -min 0.500 [get_ports led_done]
set_output_delay -clock sys_clk -max 2.000 [get_ports led_tag_match]
set_output_delay -clock sys_clk -min 0.500 [get_ports led_tag_match]
set_output_delay -clock sys_clk -max 2.000 [get_ports led_running]
set_output_delay -clock sys_clk -min 0.500 [get_ports led_running]
set_output_delay -clock sys_clk -max 2.000 [get_ports led_error]
set_output_delay -clock sys_clk -min 0.500 [get_ports led_error]

#------------------------------------------------------------------------------
# 6. ASYNCHRONOUS RESET - FALSE PATH
#------------------------------------------------------------------------------
set_false_path -from [get_ports rst_n]

#------------------------------------------------------------------------------
# 7. ACTOR REGISTER BANK PRESERVATION
#    The th_x*, ch_x*, ln_x* actor register banks carry (* keep = "true" *)
#    in RTL. Reinforce this at the SDC level to prevent merging during
#    logical optimisation:
#------------------------------------------------------------------------------
# set_dont_touch [get_cells {th_x*_reg*}]
# set_dont_touch [get_cells {ch_x*_reg*}]
# set_dont_touch [get_cells {ln_x*_reg*}]

#------------------------------------------------------------------------------
# 8. VALID STROBE TIMING — SHORT PATHS
#    The valid strobe signals (rc_valid, th_valid, ch_valid, ln_valid) are
#    single-bit registered signals with 1-2 gate levels of combinational
#    logic. At 100 MHz they have large positive slack (~8 ns).
#    No multicycle or false path constraints are required.
#
#    Optional: cap the strobe paths to prevent over-retiming:
#------------------------------------------------------------------------------
# set_max_delay 9.700 -from [get_cells {rc_valid_reg}] -to [get_cells {th_valid_reg}]
# set_max_delay 9.700 -from [get_cells {th_valid_reg}] -to [get_cells {ch_valid_reg}]
# set_max_delay 9.700 -from [get_cells {ch_valid_reg}] -to [get_cells {ln_valid_reg}]

#------------------------------------------------------------------------------
# 9. CRITICAL PATH BUDGET
#    ACTOR_TH path: rc_x*_reg -> parity XOR tree -> rotate -> apply -> th_x*_reg
#    Budget: 10.000 - 0.200 (unc) - 0.100 (trans) = 9.700 ns
#    ACTOR_CH, ACTOR_LN, ACTOR_RC will all have ~6-8 ns positive slack.
#------------------------------------------------------------------------------
# set_max_delay 9.700 -from [get_cells {rc_x*_reg*}] -to [get_cells {th_x*_reg*}]

#------------------------------------------------------------------------------
# 10. DRIVING CELL / OUTPUT LOAD
#------------------------------------------------------------------------------
set_driving_cell -lib_cell INVX1 -no_design_rule [get_ports {start rst_n}]
set_load 5.0 [get_ports {done tag_match led_done led_tag_match led_running led_error}]

#------------------------------------------------------------------------------
# 11. OPERATING CONDITIONS (uncomment and set for target library)
#------------------------------------------------------------------------------
# set_operating_conditions -library <lib> TYPICAL

#==============================================================================
# END - ascon128_dataflow.sdc
#==============================================================================
