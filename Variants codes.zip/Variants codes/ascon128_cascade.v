`timescale 1ns / 1ps
//=============================================================================
// ASCON-128  ·  Variant: cascade
//
// Visual treatment : Two-speed cascaded sub-engine — a single permutation
//                    datapath is shared between a FAST sub-engine (3-stage:
//                    Const+Theta, Chi, Linear) and a SLOW sub-engine
//                    (6-stage: each of the 6 atomic ASCON sub-steps is
//                    registered individually: CONST, THA, THB, THC, CHI, LIN).
//                    The two engines alternate: FAST runs for 2 consecutive
//                    rounds, then SLOW runs for 1 round, then FAST again.
//                    The shared datapath (x0..x4) is written by whichever
//                    sub-engine is active. A 2-bit cascade_mode register
//                    selects which engine drives the state update each cycle.
//
//                    Structural novelty: A single state register set (x0..x4)
//                    is updated by two structurally different combinational
//                    cones alternately. The 3-stage fast engine uses fused
//                    Const+Theta, standalone Chi, standalone Linear.
//                    The 6-stage slow engine uses individually registered
//                    CONST, THETA_A, THETA_B, THETA_C, CHI, LINEAR.
//                    The cascade_mode switches the write-back mux every round.
//
// This creates a NON-UNIFORM pipeline where rounds 0,1 of each triplet use
// the fast path (3 cycles each) and round 2 uses the slow path (6 cycles).
// For pa=12: (8 fast rounds × 3 cyc) + (4 slow rounds × 6 cyc) = 24+24=48+1=49
// For pb=6 : (4 fast rounds × 3 cyc) + (2 slow rounds × 6 cyc) = 12+12=24+1=25
//=============================================================================

module ascon128_top (
    input  wire clk_p, clk_n, rst_n, start,
    output wire done, tag_match,
    output wire led_done, led_tag_match, led_running, led_error
);
    wire clk_ibuf, clk;
    IBUFDS #(.DIFF_TERM("FALSE"),.IBUF_LOW_PWR("FALSE"),.IOSTANDARD("LVDS"))
        clk_ibufds(.I(clk_p),.IB(clk_n),.O(clk_ibuf));
    BUFG clk_bufg(.I(clk_ibuf),.O(clk));
    wire core_done, core_tag_match;
    reg  running_r;
    ascon128_complete_cascade ascon_core(.clk(clk),.rst_n(rst_n),.start(start),
        .done(core_done),.tag_match(core_tag_match));
    assign done=core_done; assign tag_match=core_tag_match;
    always @(posedge clk or negedge rst_n)
        if(!rst_n) running_r<=0;
        else if(start) running_r<=1;
        else if(core_done) running_r<=0;
    assign led_done=core_done; assign led_tag_match=core_done&core_tag_match;
    assign led_running=running_r; assign led_error=core_done&~core_tag_match;
endmodule

module ascon128_complete_cascade (
    input  wire clk, rst_n, start,
    output reg  done, tag_match
);
    localparam [127:0] KEY   = 128'h0F1E2D3C4B5A69788796A5B4C3D2E1F0;
    localparam [127:0] NONCE = 128'hFFEEDDCCBBAA99887766554433221100;
    localparam [191:0] PT_PADDED  = 192'h46696E616C20596561722050726F6A656374204152418000;
    localparam         PT_BLOCKS  = 3;
    localparam [63:0]  AAD_PADDED = 64'h64656D6F41414480;
    localparam [63:0]  IV         = 64'h80400c0600000000;
    localparam [4:0]
        ST_IDLE=0,ST_ENC_INIT=1,ST_ENC_INIT_PERM=2,ST_ENC_AAD=3,ST_ENC_AAD_PERM=4,
        ST_ENC_AAD_DOM=5,ST_ENC_PT=6,ST_ENC_PT_PERM=7,ST_ENC_FINAL=8,ST_ENC_FINAL_W=9,
        ST_TAG_STORE=10,ST_DEC_INIT=11,ST_DEC_INIT_PERM=12,ST_DEC_AAD=13,
        ST_DEC_AAD_PERM=14,ST_DEC_AAD_DOM=15,ST_DEC_CT=16,ST_DEC_CT_PERM=17,
        ST_DEC_FINAL=18,ST_DEC_FINAL_W=19,ST_DONE=20;
    reg [4:0] state; reg [3:0] block_idx;
    reg [63:0] s0,s1,s2,s3,s4;
    reg [191:0] ciphertext; reg [127:0] tag_enc; reg [191:0] plaintext_dec;
    reg perm_start; wire perm_done;
    reg [3:0] perm_start_round, perm_num_rounds;
    wire [63:0] perm_out0,perm_out1,perm_out2,perm_out3,perm_out4;
    ascon_perm_cascade perm_inst(
        .clk(clk),.rst_n(rst_n),.start(perm_start),
        .start_round(perm_start_round),.rounds(perm_num_rounds),
        .s0_in(s0),.s1_in(s1),.s2_in(s2),.s3_in(s3),.s4_in(s4),
        .s0_out(perm_out0),.s1_out(perm_out1),.s2_out(perm_out2),
        .s3_out(perm_out3),.s4_out(perm_out4),.done(perm_done));
    always @(posedge clk or negedge rst_n) begin
        if(!rst_n) begin
            state<=0;done<=0;tag_match<=0;perm_start<=0;
            perm_start_round<=0;perm_num_rounds<=0;block_idx<=0;
            s0<=0;s1<=0;s2<=0;s3<=0;s4<=0;ciphertext<=0;tag_enc<=0;plaintext_dec<=0;
        end else begin
            perm_start<=0;
            case(state)
                ST_IDLE: begin done<=0;tag_match<=0;if(start) state<=ST_ENC_INIT; end
                ST_ENC_INIT: begin s0<=IV;s1<=KEY[127:64];s2<=KEY[63:0];s3<=NONCE[127:64];s4<=NONCE[63:0];
                    perm_start_round<=0;perm_num_rounds<=12;perm_start<=1;state<=ST_ENC_INIT_PERM; end
                ST_ENC_INIT_PERM: if(perm_done) begin s0<=perm_out0;s1<=perm_out1;s2<=perm_out2;
                    s3<=perm_out3^KEY[127:64];s4<=perm_out4^KEY[63:0];state<=ST_ENC_AAD; end
                ST_ENC_AAD: begin s0<=s0^AAD_PADDED;perm_start_round<=6;perm_num_rounds<=6;
                    perm_start<=1;state<=ST_ENC_AAD_PERM; end
                ST_ENC_AAD_PERM: if(perm_done) begin s0<=perm_out0;s1<=perm_out1;s2<=perm_out2;
                    s3<=perm_out3;s4<=perm_out4;state<=ST_ENC_AAD_DOM; end
                ST_ENC_AAD_DOM: begin s4<=s4^64'h1;block_idx<=0;state<=ST_ENC_PT; end
                ST_ENC_PT: begin
                    if(block_idx<PT_BLOCKS) begin
                        ciphertext[191-block_idx*64-:64]<=s0^PT_PADDED[191-block_idx*64-:64];
                        s0<=s0^PT_PADDED[191-block_idx*64-:64];
                        if(block_idx<PT_BLOCKS-1) begin perm_start_round<=6;perm_num_rounds<=6;
                            perm_start<=1;block_idx<=block_idx+1;state<=ST_ENC_PT_PERM;
                        end else state<=ST_ENC_FINAL;
                    end else state<=ST_ENC_FINAL; end
                ST_ENC_PT_PERM: if(perm_done) begin s0<=perm_out0;s1<=perm_out1;s2<=perm_out2;
                    s3<=perm_out3;s4<=perm_out4;state<=ST_ENC_PT; end
                ST_ENC_FINAL: begin s1<=s1^KEY[127:64];s2<=s2^KEY[63:0];
                    perm_start_round<=0;perm_num_rounds<=12;perm_start<=1;state<=ST_ENC_FINAL_W; end
                ST_ENC_FINAL_W: if(perm_done) begin tag_enc<={perm_out3^KEY[127:64],perm_out4^KEY[63:0]};
                    state<=ST_TAG_STORE; end
                ST_TAG_STORE: state<=ST_DEC_INIT;
                ST_DEC_INIT: begin s0<=IV;s1<=KEY[127:64];s2<=KEY[63:0];s3<=NONCE[127:64];s4<=NONCE[63:0];
                    perm_start_round<=0;perm_num_rounds<=12;perm_start<=1;state<=ST_DEC_INIT_PERM; end
                ST_DEC_INIT_PERM: if(perm_done) begin s0<=perm_out0;s1<=perm_out1;s2<=perm_out2;
                    s3<=perm_out3^KEY[127:64];s4<=perm_out4^KEY[63:0];state<=ST_DEC_AAD; end
                ST_DEC_AAD: begin s0<=s0^AAD_PADDED;perm_start_round<=6;perm_num_rounds<=6;
                    perm_start<=1;state<=ST_DEC_AAD_PERM; end
                ST_DEC_AAD_PERM: if(perm_done) begin s0<=perm_out0;s1<=perm_out1;s2<=perm_out2;
                    s3<=perm_out3;s4<=perm_out4;state<=ST_DEC_AAD_DOM; end
                ST_DEC_AAD_DOM: begin s4<=s4^64'h1;block_idx<=0;state<=ST_DEC_CT; end
                ST_DEC_CT: begin
                    if(block_idx<PT_BLOCKS) begin
                        plaintext_dec[191-block_idx*64-:64]<=s0^ciphertext[191-block_idx*64-:64];
                        s0<=ciphertext[191-block_idx*64-:64];
                        if(block_idx<PT_BLOCKS-1) begin perm_start_round<=6;perm_num_rounds<=6;
                            perm_start<=1;block_idx<=block_idx+1;state<=ST_DEC_CT_PERM;
                        end else state<=ST_DEC_FINAL;
                    end else state<=ST_DEC_FINAL; end
                ST_DEC_CT_PERM: if(perm_done) begin s0<=perm_out0;s1<=perm_out1;s2<=perm_out2;
                    s3<=perm_out3;s4<=perm_out4;state<=ST_DEC_CT; end
                ST_DEC_FINAL: begin s1<=s1^KEY[127:64];s2<=s2^KEY[63:0];
                    perm_start_round<=0;perm_num_rounds<=12;perm_start<=1;state<=ST_DEC_FINAL_W; end
                ST_DEC_FINAL_W: if(perm_done) begin
                    tag_match<=(tag_enc=={perm_out3^KEY[127:64],perm_out4^KEY[63:0]});
                    done<=1;state<=ST_DONE; end
                ST_DONE: ;
                default: state<=ST_IDLE;
            endcase
        end
    end
endmodule

//=============================================================================
// ascon_perm_cascade
//
// Two alternating sub-engines share x0..x4.
// FAST sub-engine (3 stages per round): used for rounds where round_cnt%3 != 2
//   FC_THETA: Const+Theta fused  -> x*
//   FC_CHI  : Chi                -> x*
//   FC_LIN  : Linear             -> x*
//
// SLOW sub-engine (6 stages per round): used when round_cnt%3 == 2
//   SC_CONST: CONST only         -> x2
//   SC_THA  : THETA_A parities   -> p*
//   SC_THB  : THETA_B rotation   -> p*
//   SC_THC  : THETA_C apply      -> x*
//   SC_CHI  : Chi                -> x*
//   SC_LIN  : Linear             -> x*
//
// A 3-bit stage counter advances through the active sub-engine's stages.
// After each sub-engine completes a round, round_cnt increments and the
// mode switches if needed (round_cnt%3 == 2 selects SLOW).
//
// For pa=12: rounds 0,1,3,4,6,7,9,10 use FAST (8 rounds × 3 = 24 cycles)
//            rounds 2,5,8,11 use SLOW (4 rounds × 6 = 24 cycles) -> total 48+1
// For pb=6 : rounds 6,7,9,10 use FAST (4×3=12); rounds 8,11 use SLOW (2×6=12) -> 24+1
//=============================================================================
module ascon_perm_cascade (
    input  wire        clk, rst_n, start,
    input  wire [3:0]  start_round, rounds,
    input  wire [63:0] s0_in,s1_in,s2_in,s3_in,s4_in,
    output reg  [63:0] s0_out,s1_out,s2_out,s3_out,s4_out,
    output reg         done
);
    localparam [1:0] IDLE=2'd0, RUN=2'd1, FINISH=2'd2;
    // Fast engine stage IDs (3-bit, low values)
    localparam [2:0] FC_THETA=3'd0, FC_CHI=3'd1, FC_LIN=3'd2;
    // Slow engine stage IDs (3-bit, values 3-8 but we use 3-bit: 3,4,5,6,7,0 reused -> use 6 states)
    localparam [2:0] SC_CONST=3'd3, SC_THA=3'd4, SC_THB=3'd5, SC_THC=3'd6, SC_CHI=3'd7;
    // SC_LIN reuses FC_LIN (same operation) = 3'd2, but in slow mode

    reg [1:0] state;
    reg [2:0] ca_stage;
    reg [3:0] round_cnt, round_end;
    reg       slow_mode;     // 1 = slow engine active this round

    reg [63:0] x0,x1,x2,x3,x4;
    // Slow engine intermediates
    reg [63:0] p0,p1,p2,p3,p4;

    reg [7:0] rc;
    always @(*) case(round_cnt)
        4'd0:rc=8'hf0; 4'd1:rc=8'he1; 4'd2:rc=8'hd2; 4'd3:rc=8'hc3;
        4'd4:rc=8'hb4; 4'd5:rc=8'ha5; 4'd6:rc=8'h96; 4'd7:rc=8'h87;
        4'd8:rc=8'h78; 4'd9:rc=8'h69; 4'd10:rc=8'h5a; 4'd11:rc=8'h4b;
        default:rc=8'h00;
    endcase

    // ------- FAST ENGINE cones (same as tristate/soft) -------
    // FC_THETA: full Const+Theta fused
    wire [63:0] cx2f=x2^{56'd0,rc};
    wire [63:0] fp0=x0^x1^cx2f^x3^x4, fp1=x1^cx2f^x3^x4^x0;
    wire [63:0] fp2=cx2f^x3^x4^x0^x1, fp3=x3^x4^x0^x1^cx2f, fp4=x4^x0^x1^cx2f^x3;
    wire [63:0] fm0=fp4^{fp1[0],fp1[63:1]}, fm1=fp0^{fp2[0],fp2[63:1]};
    wire [63:0] fm2=fp1^{fp3[0],fp3[63:1]}, fm3=fp2^{fp4[0],fp4[63:1]};
    wire [63:0] fm4=fp3^{fp0[0],fp0[63:1]};
    wire [63:0] ft0=x0^fm0,ft1=x1^fm1,ft2=cx2f^fm2,ft3=x3^fm3,ft4=x4^fm4;
    // FC_CHI / SC_CHI
    wire [63:0] fc0=x0^(~x1&x2), fc1=x1^(~x2&x3);
    wire [63:0] fc2=~(x2^(~x3&x4)), fc3=x3^(~x4&x0), fc4=x4^(~x0&x1);
    // FC_LIN / SC_LIN
    wire [63:0] fl0=x0^{x0[18:0],x0[63:19]}^{x0[27:0],x0[63:28]};
    wire [63:0] fl1=x1^{x1[60:0],x1[63:61]}^{x1[38:0],x1[63:39]};
    wire [63:0] fl2=x2^{x2[0],   x2[63:1]} ^{x2[5:0], x2[63:6]};
    wire [63:0] fl3=x3^{x3[9:0], x3[63:10]}^{x3[16:0],x3[63:17]};
    wire [63:0] fl4=x4^{x4[6:0], x4[63:7]} ^{x4[40:0],x4[63:41]};

    // Determines whether this round uses slow engine
    wire use_slow = ((round_cnt - start_round) % 3 == 2);

    task advance_round;
        begin
            if(round_cnt < round_end-1) begin
                round_cnt <= round_cnt + 1;
                // Set mode for NEXT round
                slow_mode <= ((round_cnt+1 - start_round) % 3 == 2);
                ca_stage <= FC_THETA;  // fast default; overridden below if slow
            end else begin
                state <= FINISH;
            end
        end
    endtask

    always @(posedge clk or negedge rst_n) begin
        if(!rst_n) begin
            state<=IDLE;done<=0;ca_stage<=FC_THETA;round_cnt<=0;round_end<=0;slow_mode<=0;
            x0<=0;x1<=0;x2<=0;x3<=0;x4<=0;p0<=0;p1<=0;p2<=0;p3<=0;p4<=0;
            s0_out<=0;s1_out<=0;s2_out<=0;s3_out<=0;s4_out<=0;
        end else case(state)
            IDLE: begin
                done<=0;
                if(start) begin
                    x0<=s0_in;x1<=s1_in;x2<=s2_in;x3<=s3_in;x4<=s4_in;
                    round_cnt<=start_round;round_end<=start_round+rounds;
                    // First round mode
                    slow_mode <= (start_round % 3 == 2);
                    ca_stage <= FC_THETA;
                    state<=RUN;
                end
            end
            RUN: begin
                if(!slow_mode) begin
                    // ---- FAST ENGINE (3 stages) ----
                    case(ca_stage)
                        FC_THETA: begin x0<=ft0;x1<=ft1;x2<=ft2;x3<=ft3;x4<=ft4; ca_stage<=FC_CHI; end
                        FC_CHI:   begin x0<=fc0;x1<=fc1;x2<=fc2;x3<=fc3;x4<=fc4; ca_stage<=FC_LIN; end
                        FC_LIN:   begin x0<=fl0;x1<=fl1;x2<=fl2;x3<=fl3;x4<=fl4;
                            if(round_cnt<round_end-1) begin
                                round_cnt<=round_cnt+1;
                                slow_mode<=((round_cnt+1-start_round)%3==2);
                                ca_stage<=FC_THETA;
                            end else state<=FINISH;
                        end
                        default: ca_stage<=FC_THETA;
                    endcase
                end else begin
                    // ---- SLOW ENGINE (6 stages) ----
                    case(ca_stage)
                        FC_THETA: begin x2<=x2^{56'd0,rc}; ca_stage<=SC_THA; end   // CONST (reuse FC_THETA slot)
                        SC_THA: begin
                            p0<=x0^x1^x2^x3^x4; p1<=x1^x2^x3^x4^x0;
                            p2<=x2^x3^x4^x0^x1; p3<=x3^x4^x0^x1^x2; p4<=x4^x0^x1^x2^x3;
                            ca_stage<=SC_THB;
                        end
                        SC_THB: begin
                            p0<=p4^{p1[0],p1[63:1]}; p1<=p0^{p2[0],p2[63:1]};
                            p2<=p1^{p3[0],p3[63:1]}; p3<=p2^{p4[0],p4[63:1]};
                            p4<=p3^{p0[0],p0[63:1]}; ca_stage<=SC_THC;
                        end
                        SC_THC: begin x0<=x0^p0;x1<=x1^p1;x2<=x2^p2;x3<=x3^p3;x4<=x4^p4; ca_stage<=SC_CHI; end
                        SC_CHI: begin x0<=fc0;x1<=fc1;x2<=fc2;x3<=fc3;x4<=fc4; ca_stage<=FC_LIN; end
                        FC_LIN: begin x0<=fl0;x1<=fl1;x2<=fl2;x3<=fl3;x4<=fl4;
                            if(round_cnt<round_end-1) begin
                                round_cnt<=round_cnt+1;
                                slow_mode<=((round_cnt+1-start_round)%3==2);
                                ca_stage<=FC_THETA;
                            end else state<=FINISH;
                        end
                        default: ca_stage<=FC_THETA;
                    endcase
                end
            end
            FINISH: begin s0_out<=x0;s1_out<=x1;s2_out<=x2;s3_out<=x3;s4_out<=x4;done<=1;state<=IDLE; end
            default: state<=IDLE;
        endcase
    end
endmodule
