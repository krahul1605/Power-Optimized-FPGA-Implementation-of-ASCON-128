#==============================================================================
# ASCON-128  ·  Variant: banked
# SDC for Cadence Genus Synthesis
#
# Permutation architecture: Dual-bank ping-pong state memory.
#   Two identical 320-bit register banks (Bank A: a0..a4, Bank B: b0..b4).
#   A registered bank-select bit (bank_sel) alternates every cycle:
#     bank_sel==0: Bank A is read source; Bank B receives round result
#     bank_sel==1: Bank B is read source; Bank A receives round result
#
#   Combinational logic:
#     Read mux (2-way, 320-bit): rx[i] = bank_sel ? b[i] : a[i]
#     Full round (Const+Theta+Chi+Linear): identical to baseline
#       Path: rx* mux -> XOR(const) -> XOR_parity_tree -> rotate_XOR ->
#             chi_AND_NOT -> chi_XOR_INV -> rotate -> XOR -> n*
#     Write: n* registered into idle bank (gated by bank_sel)
#
# Critical path per cycle:
#   a*_reg or b*_reg -> 2-way read mux (1 LUT level) ->
#   Const XOR -> Theta parity tree (~3 levels) -> Theta rotate/apply (~2) ->
#   Chi AND-NOT (~2) -> Chi XOR/INV (~1) -> Lin rotate (~0) -> Lin XOR (~2) ->
#   a*_reg or b*_reg (write via bank-select gated enable)
#   Total: ~35-45 gate levels (1 extra level vs baseline for the read mux)
#   Fmax target: 25 MHz / 40 ns (same class as baseline)
#
# Compared to baseline:
#   - 1 extra LUT level for the 320-bit read mux at the pipeline head
#   - Write-enable gating on each bank reduces switching power on idle FFs
#   - Double the state FFs (640 vs 320) — higher area but enables bank
#     isolation for power/side-channel analysis
#   - Timing budget effectively identical to baseline (40 ns)
#
# Clocks per pa=12 call : 12 + 1 FINISH = 13  (same as baseline)
# Clocks per pb=6  call :  6 + 1 FINISH =  7  (same as baseline)
#
# Synthesis notes:
#   - The (* keep = "true" *) pragmas on a* and b* register banks prevent
#     Genus from merging the two banks into a single register with mux.
#     This is essential to preserve the dual-bank physical topology.
#   - The bank_sel-gated write enables should be mapped to FF clock-enable
#     inputs (CE pin on Xilinx FFs) rather than data muxes, to achieve
#     power gating. Use set_attribute dont_retime on the bank registers if
#     retiming would merge the banks.
#   - The 320-bit read mux adds one LUT level to the combinational path.
#     Genus may absorb it into the first XOR stage of the round logic.
#     If physical bank separation is important, use keep_hierarchy on the
#     read mux logic.
#==============================================================================

#------------------------------------------------------------------------------
# 1. CLOCK DEFINITION
#    25 MHz / 40 ns — dual-bank ping-pong with full combinational round
#    (one extra read-mux level vs baseline; same period target)
#------------------------------------------------------------------------------
create_clock -period 40.000 \
             -name sys_clk \
             -waveform {0.000 20.000} \
             [get_ports clk_p]

#------------------------------------------------------------------------------
# 2. CLOCK UNCERTAINTY
#    Relaxed jitter budget appropriate for 25 MHz board-speed clock.
#------------------------------------------------------------------------------
set_clock_uncertainty -setup 0.500 [get_clocks sys_clk]
set_clock_uncertainty -hold  0.300 [get_clocks sys_clk]

#------------------------------------------------------------------------------
# 3. CLOCK TRANSITION
#    Relaxed edge rate for low-frequency clock.
#------------------------------------------------------------------------------
set_clock_transition -rise 0.200 [get_clocks sys_clk]
set_clock_transition -fall 0.200 [get_clocks sys_clk]

#------------------------------------------------------------------------------
# 4. INPUT DELAYS
#    Conservative budget: 2.0 ns setup leaves 37.5 ns internal at 40 ns period.
#------------------------------------------------------------------------------
set_input_delay -clock sys_clk -max 2.000 [get_ports rst_n]
set_input_delay -clock sys_clk -min 0.500 [get_ports rst_n]
set_input_delay -clock sys_clk -max 2.000 [get_ports start]
set_input_delay -clock sys_clk -min 0.500 [get_ports start]

#------------------------------------------------------------------------------
# 5. OUTPUT DELAYS
#------------------------------------------------------------------------------
set_output_delay -clock sys_clk -max 2.000 [get_ports done]
set_output_delay -clock sys_clk -min 0.500 [get_ports done]
set_output_delay -clock sys_clk -max 2.000 [get_ports tag_match]
set_output_delay -clock sys_clk -min 0.500 [get_ports tag_match]
set_output_delay -clock sys_clk -max 2.000 [get_ports led_done]
set_output_delay -clock sys_clk -min 0.500 [get_ports led_done]
set_output_delay -clock sys_clk -max 2.000 [get_ports led_tag_match]
set_output_delay -clock sys_clk -min 0.500 [get_ports led_tag_match]
set_output_delay -clock sys_clk -max 2.000 [get_ports led_running]
set_output_delay -clock sys_clk -min 0.500 [get_ports led_running]
set_output_delay -clock sys_clk -max 2.000 [get_ports led_error]
set_output_delay -clock sys_clk -min 0.500 [get_ports led_error]

#------------------------------------------------------------------------------
# 6. ASYNCHRONOUS RESET - FALSE PATH
#------------------------------------------------------------------------------
set_false_path -from [get_ports rst_n]

#------------------------------------------------------------------------------
# 7. DUAL-BANK REGISTER PRESERVATION
#    Bank A (a*) and Bank B (b*) must remain physically separate register
#    clusters. Prevent synthesis from merging them into a unified state array:
#------------------------------------------------------------------------------
# set_dont_touch [get_cells {a*_reg*}]
# set_dont_touch [get_cells {b*_reg*}]

#------------------------------------------------------------------------------
# 8. READ MUX PATH ANNOTATION
#    The 320-bit bank-select read mux adds 1 LUT level to the start of
#    the combinational round. This is included in the 40 ns period budget.
#    Total critical path: mux(1) + round(35-45) ≈ 36-46 gate levels.
#    With 40 ns and ~0.9 ns/level, this comfortably fits.
#
#    Optional: explicitly bound the read mux + round path:
#------------------------------------------------------------------------------
# set_max_delay 39.300 -from [get_cells {a*_reg* b*_reg*}] -to [get_cells {a*_reg* b*_reg*}]

#------------------------------------------------------------------------------
# 9. BANK-SELECT WRITE-ENABLE TIMING
#    bank_sel is a registered 1-bit signal that gates write enables.
#    It has a very short combinational path (1-bit invert/pass).
#    At 25 MHz there is >39 ns of positive slack on this path.
#    No special constraint required.
#------------------------------------------------------------------------------

#------------------------------------------------------------------------------
# 10. DRIVING CELL / OUTPUT LOAD
#------------------------------------------------------------------------------
set_driving_cell -lib_cell INVX1 -no_design_rule [get_ports {start rst_n}]
set_load 5.0 [get_ports {done tag_match led_done led_tag_match led_running led_error}]

#------------------------------------------------------------------------------
# 11. OPERATING CONDITIONS (uncomment and set for target library)
#------------------------------------------------------------------------------
# set_operating_conditions -library <lib> TYPICAL

#==============================================================================
# END - ascon128_banked.sdc
#==============================================================================
