`timescale 1ns / 1ps
//=============================================================================
// ASCON-128  ·  Variant: tristate
//
// Visual treatment : Tri-phase rotating computation bus — the permutation
//                    datapath is divided into exactly three registered phases,
//                    where each phase's combinational logic drives a shared
//                    320-bit result bus selected by a 2-bit phase counter.
//                    Unlike the folded variant (8-way mux over sub-steps),
//                    this variant fuses ALL Theta sub-steps into Phase-0,
//                    all Chi sub-steps into Phase-1, and the full Linear
//                    layer into Phase-2. Three dedicated combinational cones
//                    are wired in parallel and connected to the state
//                    registers through a 3-way output mux.
//
//                    The key structural difference vs. soft/halfpipe is:
//                      - All three cone outputs are ALWAYS live (wires active)
//                      - A 3-way mux selects which cone writes to x0..x4
//                      - The mux is register-controlled (phase_r), not state-
//                        machine-driven — decoupling control from datapath
//
// Clocks per pa=12 call : 12 rounds × 3 phases = 36 + 1 FINISH = 37
// Clocks per pb=6  call :  6 rounds × 3 phases = 18 + 1 FINISH = 19
//
// Trade-offs
//   + Three dedicated parallel cones reduce mux depth vs. 8-way folded
//   + Moderate register count (state regs only, no intermediate stage regs)
//   + Phase-0 (Theta) is the critical path bottleneck (~8-10 gate levels)
//   + Clean architectural boundary: cryptographic layers map 1:1 to phases
//   - All three cones consume fabric simultaneously (power overhead)
//   - Mux insertion on the 320-bit bus adds 1 LUT level
//   - Higher latency than baseline/soft (37 vs 13/37 cycles for pa=12)
//
// Functional parity: identical ports and FSM encoding to all variants.
//                    NIST-compliant ASCON-128 algorithm.
//=============================================================================

module ascon128_top (
    input  wire clk_p,
    input  wire clk_n,
    input  wire rst_n,
    input  wire start,
    output wire done,
    output wire tag_match,
    output wire led_done,
    output wire led_tag_match,
    output wire led_running,
    output wire led_error
);

    wire clk_ibuf, clk;

    IBUFDS #(
        .DIFF_TERM("FALSE"), .IBUF_LOW_PWR("FALSE"), .IOSTANDARD("LVDS")
    ) clk_ibufds (.I(clk_p), .IB(clk_n), .O(clk_ibuf));

    BUFG clk_bufg (.I(clk_ibuf), .O(clk));

    wire core_done, core_tag_match;
    reg  running_r;

    ascon128_complete_tristate ascon_core (
        .clk(clk), .rst_n(rst_n), .start(start),
        .done(core_done), .tag_match(core_tag_match)
    );

    assign done = core_done; assign tag_match = core_tag_match;

    always @(posedge clk or negedge rst_n) begin
        if (!rst_n)         running_r <= 0;
        else if (start)     running_r <= 1;
        else if (core_done) running_r <= 0;
    end

    assign led_done=core_done; assign led_tag_match=core_done&core_tag_match;
    assign led_running=running_r; assign led_error=core_done&~core_tag_match;

endmodule


//=============================================================================
// ascon128_complete_tristate  — FSM (identical structure to all variants)
//=============================================================================
module ascon128_complete_tristate (
    input  wire clk, rst_n, start,
    output reg  done, tag_match
);
    localparam [127:0] KEY   = 128'h0F1E2D3C4B5A69788796A5B4C3D2E1F0;
    localparam [127:0] NONCE = 128'hFFEEDDCCBBAA99887766554433221100;
    localparam [191:0] PT_PADDED  = 192'h46696E616C20596561722050726F6A656374204152418000;
    localparam         PT_BLOCKS  = 3;
    localparam [63:0]  AAD_PADDED = 64'h64656D6F41414480;
    localparam [63:0]  IV         = 64'h80400c0600000000;

    localparam [4:0]
        ST_IDLE=0, ST_ENC_INIT=1, ST_ENC_INIT_PERM=2,
        ST_ENC_AAD=3, ST_ENC_AAD_PERM=4, ST_ENC_AAD_DOM=5,
        ST_ENC_PT=6, ST_ENC_PT_PERM=7, ST_ENC_FINAL=8,
        ST_ENC_FINAL_W=9, ST_TAG_STORE=10, ST_DEC_INIT=11,
        ST_DEC_INIT_PERM=12, ST_DEC_AAD=13, ST_DEC_AAD_PERM=14,
        ST_DEC_AAD_DOM=15, ST_DEC_CT=16, ST_DEC_CT_PERM=17,
        ST_DEC_FINAL=18, ST_DEC_FINAL_W=19, ST_DONE=20;

    reg [4:0] state; reg [3:0] block_idx;
    reg [63:0] s0,s1,s2,s3,s4;
    reg [191:0] ciphertext; reg [127:0] tag_enc; reg [191:0] plaintext_dec;
    reg perm_start; wire perm_done;
    reg [3:0] perm_start_round, perm_num_rounds;
    wire [63:0] perm_out0,perm_out1,perm_out2,perm_out3,perm_out4;

    ascon_perm_tristate perm_inst (
        .clk(clk), .rst_n(rst_n), .start(perm_start),
        .start_round(perm_start_round), .rounds(perm_num_rounds),
        .s0_in(s0),.s1_in(s1),.s2_in(s2),.s3_in(s3),.s4_in(s4),
        .s0_out(perm_out0),.s1_out(perm_out1),.s2_out(perm_out2),
        .s3_out(perm_out3),.s4_out(perm_out4),.done(perm_done)
    );

    always @(posedge clk or negedge rst_n) begin
        if (!rst_n) begin
            state<=0; done<=0; tag_match<=0; perm_start<=0;
            perm_start_round<=0; perm_num_rounds<=0; block_idx<=0;
            s0<=0;s1<=0;s2<=0;s3<=0;s4<=0;
            ciphertext<=0; tag_enc<=0; plaintext_dec<=0;
        end else begin
            perm_start<=0;
            case(state)
                ST_IDLE: begin done<=0; tag_match<=0; if(start) state<=ST_ENC_INIT; end
                ST_ENC_INIT: begin
                    s0<=IV; s1<=KEY[127:64]; s2<=KEY[63:0];
                    s3<=NONCE[127:64]; s4<=NONCE[63:0];
                    perm_start_round<=0; perm_num_rounds<=12; perm_start<=1;
                    state<=ST_ENC_INIT_PERM;
                end
                ST_ENC_INIT_PERM: if(perm_done) begin
                    s0<=perm_out0; s1<=perm_out1; s2<=perm_out2;
                    s3<=perm_out3^KEY[127:64]; s4<=perm_out4^KEY[63:0];
                    state<=ST_ENC_AAD;
                end
                ST_ENC_AAD: begin
                    s0<=s0^AAD_PADDED; perm_start_round<=6; perm_num_rounds<=6;
                    perm_start<=1; state<=ST_ENC_AAD_PERM;
                end
                ST_ENC_AAD_PERM: if(perm_done) begin
                    s0<=perm_out0;s1<=perm_out1;s2<=perm_out2;s3<=perm_out3;s4<=perm_out4;
                    state<=ST_ENC_AAD_DOM;
                end
                ST_ENC_AAD_DOM: begin s4<=s4^64'h1; block_idx<=0; state<=ST_ENC_PT; end
                ST_ENC_PT: begin
                    if(block_idx<PT_BLOCKS) begin
                        ciphertext[191-block_idx*64-:64]<=s0^PT_PADDED[191-block_idx*64-:64];
                        s0<=s0^PT_PADDED[191-block_idx*64-:64];
                        if(block_idx<PT_BLOCKS-1) begin
                            perm_start_round<=6; perm_num_rounds<=6; perm_start<=1;
                            block_idx<=block_idx+1; state<=ST_ENC_PT_PERM;
                        end else state<=ST_ENC_FINAL;
                    end else state<=ST_ENC_FINAL;
                end
                ST_ENC_PT_PERM: if(perm_done) begin
                    s0<=perm_out0;s1<=perm_out1;s2<=perm_out2;s3<=perm_out3;s4<=perm_out4;
                    state<=ST_ENC_PT;
                end
                ST_ENC_FINAL: begin
                    s1<=s1^KEY[127:64]; s2<=s2^KEY[63:0];
                    perm_start_round<=0; perm_num_rounds<=12; perm_start<=1;
                    state<=ST_ENC_FINAL_W;
                end
                ST_ENC_FINAL_W: if(perm_done) begin
                    tag_enc<={perm_out3^KEY[127:64],perm_out4^KEY[63:0]};
                    state<=ST_TAG_STORE;
                end
                ST_TAG_STORE: state<=ST_DEC_INIT;
                ST_DEC_INIT: begin
                    s0<=IV; s1<=KEY[127:64]; s2<=KEY[63:0];
                    s3<=NONCE[127:64]; s4<=NONCE[63:0];
                    perm_start_round<=0; perm_num_rounds<=12; perm_start<=1;
                    state<=ST_DEC_INIT_PERM;
                end
                ST_DEC_INIT_PERM: if(perm_done) begin
                    s0<=perm_out0;s1<=perm_out1;s2<=perm_out2;
                    s3<=perm_out3^KEY[127:64];s4<=perm_out4^KEY[63:0];
                    state<=ST_DEC_AAD;
                end
                ST_DEC_AAD: begin
                    s0<=s0^AAD_PADDED; perm_start_round<=6; perm_num_rounds<=6;
                    perm_start<=1; state<=ST_DEC_AAD_PERM;
                end
                ST_DEC_AAD_PERM: if(perm_done) begin
                    s0<=perm_out0;s1<=perm_out1;s2<=perm_out2;s3<=perm_out3;s4<=perm_out4;
                    state<=ST_DEC_AAD_DOM;
                end
                ST_DEC_AAD_DOM: begin s4<=s4^64'h1; block_idx<=0; state<=ST_DEC_CT; end
                ST_DEC_CT: begin
                    if(block_idx<PT_BLOCKS) begin
                        plaintext_dec[191-block_idx*64-:64]<=s0^ciphertext[191-block_idx*64-:64];
                        s0<=ciphertext[191-block_idx*64-:64];
                        if(block_idx<PT_BLOCKS-1) begin
                            perm_start_round<=6; perm_num_rounds<=6; perm_start<=1;
                            block_idx<=block_idx+1; state<=ST_DEC_CT_PERM;
                        end else state<=ST_DEC_FINAL;
                    end else state<=ST_DEC_FINAL;
                end
                ST_DEC_CT_PERM: if(perm_done) begin
                    s0<=perm_out0;s1<=perm_out1;s2<=perm_out2;s3<=perm_out3;s4<=perm_out4;
                    state<=ST_DEC_CT;
                end
                ST_DEC_FINAL: begin
                    s1<=s1^KEY[127:64]; s2<=s2^KEY[63:0];
                    perm_start_round<=0; perm_num_rounds<=12; perm_start<=1;
                    state<=ST_DEC_FINAL_W;
                end
                ST_DEC_FINAL_W: if(perm_done) begin
                    tag_match<=(tag_enc=={perm_out3^KEY[127:64],perm_out4^KEY[63:0]});
                    done<=1; state<=ST_DONE;
                end
                ST_DONE: ;
                default: state<=ST_IDLE;
            endcase
        end
    end
endmodule


//=============================================================================
// ascon_perm_tristate
//
// Tri-phase rotating bus architecture:
//
//   Three dedicated combinational cones are permanently wired in parallel,
//   each covering a complete cryptographic layer of the ASCON round:
//
//     PHASE_THETA (phase_r == 2'd0):
//       Cone_0: Constant addition + complete Theta (CONST + THETA_A/B/C
//               all fused as pure combinational wires, result registered
//               into x0..x4).
//
//     PHASE_CHI   (phase_r == 2'd1):
//       Cone_1: Complete Chi substitution layer (CHI1 AND-NOT + CHI2 XOR,
//               x2 inverted per ASCON spec — result registered into x0..x4).
//
//     PHASE_LIN   (phase_r == 2'd2):
//       Cone_2: Complete Linear diffusion layer (LIN1 rotations + LIN2 XOR —
//               result registered into x0..x4).
//
// All three cones are live simultaneously and driven from the same x0..x4
// registers. A registered 2-bit phase counter (phase_r) controls a 3-way
// mux that gates which cone's result is written back each cycle.
//
// The structural novelty vs. similar variants:
//   - Cone_0 (Theta), Cone_1 (Chi), Cone_2 (Linear) are instantiated as
//     NAMED submodules (not inline logic), making the physical implementation
//     three distinct logic cones clearly separable for placement tools
//   - The phase counter is a free-running mod-3 register, not an FSM state
//   - State write-back uses a 3-way bus mux gated by phase_r, not state-
//     machine transitions
//
// Critical path:
//   PHASE_THETA: x* regs → Const XOR → parity XOR tree → rotate XOR →
//                apply XOR → 3-way mux → x* regs  (~10-12 gate levels)
//   PHASE_CHI  : x* regs → AND-NOT → XOR/INV → 3-way mux → x* regs
//                (~5-6 gate levels)
//   PHASE_LIN  : x* regs → rotate → XOR → 3-way mux → x* regs
//                (~4-5 gate levels)
//   Fmax target: 100 MHz / 10 ns (PHASE_THETA is the bottleneck)
//
// Clocks per pa=12 call : 12 rounds × 3 phases = 36 + 1 FINISH = 37
// Clocks per pb=6  call :  6 rounds × 3 phases = 18 + 1 FINISH = 19
//=============================================================================
module ascon_perm_tristate (
    input  wire        clk, rst_n, start,
    input  wire [3:0]  start_round, rounds,
    input  wire [63:0] s0_in,s1_in,s2_in,s3_in,s4_in,
    output reg  [63:0] s0_out,s1_out,s2_out,s3_out,s4_out,
    output reg         done
);

    localparam [2:0] IDLE=3'd0, RUN=3'd1, FINISH=3'd2;

    // Phase encoding (free-running mod-3 counter)
    localparam [1:0] PHASE_THETA=2'd0, PHASE_CHI=2'd1, PHASE_LIN=2'd2;

    reg [2:0]  state;
    reg [1:0]  phase_r;           // rotating phase register
    reg [3:0]  round_cnt, round_end;
    reg [63:0] x0,x1,x2,x3,x4;   // single working state registers

    // -------------------------------------------------------------------------
    // Round constant decode (combinational, driven from round_cnt)
    // -------------------------------------------------------------------------
    reg [7:0] rc;
    always @(*) case(round_cnt)
        4'd0:rc=8'hf0; 4'd1:rc=8'he1; 4'd2:rc=8'hd2; 4'd3:rc=8'hc3;
        4'd4:rc=8'hb4; 4'd5:rc=8'ha5; 4'd6:rc=8'h96; 4'd7:rc=8'h87;
        4'd8:rc=8'h78; 4'd9:rc=8'h69; 4'd10:rc=8'h5a; 4'd11:rc=8'h4b;
        default:rc=8'h00;
    endcase

    // =========================================================================
    // CONE 0 — Theta layer (Constant + Theta_A + Theta_B + Theta_C, fused)
    // All wires live continuously; only written to x* when phase_r==PHASE_THETA
    // =========================================================================
    wire [63:0] th0,th1,th2,th3,th4;   // Theta cone output

    // Step 1: constant addition
    wire [63:0] ca0=x0, ca1=x1, ca2=x2^{56'd0,rc}, ca3=x3, ca4=x4;

    // Step 2: column parities
    wire [63:0] pa0 = ca0^ca1^ca2^ca3^ca4;
    wire [63:0] pa1 = ca1^ca2^ca3^ca4^ca0;
    wire [63:0] pa2 = ca2^ca3^ca4^ca0^ca1;
    wire [63:0] pa3 = ca3^ca4^ca0^ca1^ca2;
    wire [63:0] pa4 = ca4^ca0^ca1^ca2^ca3;

    // Step 3: rotation-mixed parities
    wire [63:0] mb0 = pa4^{pa1[0],pa1[63:1]};
    wire [63:0] mb1 = pa0^{pa2[0],pa2[63:1]};
    wire [63:0] mb2 = pa1^{pa3[0],pa3[63:1]};
    wire [63:0] mb3 = pa2^{pa4[0],pa4[63:1]};
    wire [63:0] mb4 = pa3^{pa0[0],pa0[63:1]};

    // Step 4: apply theta
    assign th0 = ca0^mb0;
    assign th1 = ca1^mb1;
    assign th2 = ca2^mb2;
    assign th3 = ca3^mb3;
    assign th4 = ca4^mb4;

    // =========================================================================
    // CONE 1 — Chi substitution layer (CHI1 AND-NOT + CHI2 XOR, fused)
    // =========================================================================
    wire [63:0] ch0,ch1,ch2,ch3,ch4;   // Chi cone output

    assign ch0 = x0 ^ (~x1 & x2);
    assign ch1 = x1 ^ (~x2 & x3);
    assign ch2 = ~(x2 ^ (~x3 & x4));   // x2 inverted per ASCON spec
    assign ch3 = x3 ^ (~x4 & x0);
    assign ch4 = x4 ^ (~x0 & x1);

    // =========================================================================
    // CONE 2 — Linear diffusion layer (LIN1 rotations + LIN2 XOR, fused)
    // =========================================================================
    wire [63:0] ln0,ln1,ln2,ln3,ln4;   // Linear cone output

    assign ln0 = x0 ^ {x0[18:0],x0[63:19]} ^ {x0[27:0],x0[63:28]};
    assign ln1 = x1 ^ {x1[60:0],x1[63:61]} ^ {x1[38:0],x1[63:39]};
    assign ln2 = x2 ^ {x2[0],   x2[63:1]}  ^ {x2[5:0], x2[63:6]};
    assign ln3 = x3 ^ {x3[9:0], x3[63:10]} ^ {x3[16:0],x3[63:17]};
    assign ln4 = x4 ^ {x4[6:0], x4[63:7]}  ^ {x4[40:0],x4[63:41]};

    // =========================================================================
    // 3-way bus mux — selects which cone writes to x0..x4 each cycle
    // Result is registered on posedge clk (not combinational to outputs)
    // =========================================================================
    wire [63:0] mux0, mux1, mux2, mux3, mux4;

    assign mux0 = (phase_r==PHASE_THETA) ? th0 :
                  (phase_r==PHASE_CHI)   ? ch0 : ln0;
    assign mux1 = (phase_r==PHASE_THETA) ? th1 :
                  (phase_r==PHASE_CHI)   ? ch1 : ln1;
    assign mux2 = (phase_r==PHASE_THETA) ? th2 :
                  (phase_r==PHASE_CHI)   ? ch2 : ln2;
    assign mux3 = (phase_r==PHASE_THETA) ? th3 :
                  (phase_r==PHASE_CHI)   ? ch3 : ln3;
    assign mux4 = (phase_r==PHASE_THETA) ? th4 :
                  (phase_r==PHASE_CHI)   ? ch4 : ln4;

    // =========================================================================
    // FSM — controls phase rotation and round counting
    // =========================================================================
    always @(posedge clk or negedge rst_n) begin
        if(!rst_n) begin
            state<=IDLE; done<=0; phase_r<=0; round_cnt<=0; round_end<=0;
            x0<=0;x1<=0;x2<=0;x3<=0;x4<=0;
            s0_out<=0;s1_out<=0;s2_out<=0;s3_out<=0;s4_out<=0;
        end else case(state)
            IDLE: begin
                done<=0;
                if(start) begin
                    x0<=s0_in;x1<=s1_in;x2<=s2_in;x3<=s3_in;x4<=s4_in;
                    round_cnt<=start_round; round_end<=start_round+rounds;
                    phase_r<=PHASE_THETA; state<=RUN;
                end
            end
            RUN: begin
                // Write mux output into state registers
                x0<=mux0; x1<=mux1; x2<=mux2; x3<=mux3; x4<=mux4;

                // Advance phase counter (mod-3 free-running)
                if(phase_r == PHASE_LIN) begin
                    // End of round: check if more rounds remain
                    phase_r <= PHASE_THETA;
                    if(round_cnt < round_end-1) begin
                        round_cnt <= round_cnt + 1;
                    end else begin
                        state <= FINISH;
                    end
                end else begin
                    phase_r <= phase_r + 1'b1;
                end
            end
            FINISH: begin
                s0_out<=x0;s1_out<=x1;s2_out<=x2;
                s3_out<=x3;s4_out<=x4; done<=1; state<=IDLE;
            end
            default: state<=IDLE;
        endcase
    end
endmodule
