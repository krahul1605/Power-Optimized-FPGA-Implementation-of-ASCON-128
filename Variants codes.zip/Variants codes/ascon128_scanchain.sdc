#==============================================================================
# SDC Constraints — ascon128_scanchain
# Target : Cadence Genus / Innovus + Cadence Encounter Test (ET) / Modus
# Functional Period  : 40 ns  →  25 MHz
# Scan Shift Period  : 50 ns  →  20 MHz  (relaxed — scan path is non-critical)
#
# Rationale
# ---------
# The scanchain variant has TWO distinct operating modes, each with different
# timing requirements:
#
# 1. FUNCTIONAL MODE (scan_en=0):
#    Identical combinational depth to baseline (~35-45 gate levels).
#    The scan mux adds 1 gate level to every s* D-input path.
#    Impact: ~0.65 ns additional → target remains 40 ns with margin.
#
# 2. SCAN SHIFT MODE (scan_en=1):
#    Critical path: scan_chain_in[N] (from s*[N+1]) → mux → s*[N]
#    This is a single mux + wire path — ~2-3 gate levels.
#    Scan shift can run at 20 MHz (50 ns) conservatively; actual capability
#    could be 100+ MHz (only 2-3 levels), but 20 MHz is sufficient for ATPG.
#
# Additional DFT timing rules:
#    - scan_en must be stable for the entire clock cycle (no glitch)
#    - scan_in setup/hold relative to clk during shift mode
#    - scan_out propagation delay from last FF (s4[0]) to output port
#==============================================================================

#-- Functional clock (both modes use the same physical clock)
create_clock -name clk -period 40.000 [get_ports clk_p]
set_clock_uncertainty 0.3 [get_clocks clk]

#-- Scan shift clock (same source, relaxed period for ATPG)
# In Encounter Test, a separate scan_clk can be defined for ATPG use.
# For SDC, declare as a generated clock at the same source:
create_generated_clock -name scan_clk -source [get_pins u_bufg/O] \
    -divide_by 1 [get_pins u_bufg/O] -add -master_clock clk
set_clock_uncertainty 0.5 [get_clocks scan_clk]
# Note: Encounter Test will use scan_clk for ATPG timing checks.

#-- Input/output timing — FUNCTIONAL mode
set_input_delay  -clock clk -max 1.0 [get_ports {rst_n start}]
set_output_delay -clock clk -max 2.0 [get_ports {done tag_match led_*}]

#-- Scan port timing — SHIFT mode
# scan_in must be stable before clk rising edge (standard cell setup ~0.3 ns)
set_input_delay  -clock clk -max 2.0 [get_ports scan_in]
set_input_delay  -clock clk -max 1.0 [get_ports scan_en]
set_output_delay -clock clk -max 2.0 [get_ports scan_out]

#-- Scan mux on functional path: scan_en=0 → mux selects functional D
# The mux adds 1 gate level.  No multicycle path needed — 40 ns accommodates.
# Document the additional delay for awareness:
# Functional path: s*_reg → [scan_mux_0, 1 level] → [round_logic, 35-45] → s*_reg
# Total: ~36-46 levels ≈ 23-30 ns — fits within 40 ns.

#-- Scan chain path: during scan_en=1
# scan_in → [scan_mux, 1-2 levels] → s0[63] → scan_chain_wire → s0[62] ...
# Each hop is 1 mux level: 2 gate levels × 0.65 ns = 1.3 ns → 50 ns is generous.
# ATPG tool will use these constraints for shift-mode timing verification.

#-- scan_en setup constraint
# scan_en is a control signal that selects between functional and scan D-inputs.
# It must be stable BEFORE the setup window of any FF D-input it controls.
# set_clock_gating_check is not applicable here (scan_en is not a clock gate).
# Instead, constrain as a normal input with tight arrival:
set_input_delay -clock clk -max 1.5 -min 0.3 [get_ports scan_en]

#-- False paths for scan infrastructure
# Scan path (scan_in → scan_out through all 320 FFs) is a shift-mode path.
# In functional mode (scan_en=0), scan_in has no timing impact on circuit outputs.
set_false_path -from [get_ports scan_in] -through [get_nets scan_chain_in*] \
               -to   [get_ports {done tag_match}]
# (scan_in → functional outputs is false in functional mode)

#-- Fanout on scan_en (drives 320 mux selects — one per state FF)
set_max_fanout 32 [get_nets scan_en]

#-- Fanout on scan_chain_in bus (each bit fans out to 1 FF — trivial)
# No fanout constraint needed.

#-- DFT exemptions
# The scan chain itself must not be retimed (would break shift-mode ordering)
set_dont_retime [get_cells {s0_reg s1_reg s2_reg s3_reg s4_reg}] true

#-- ATPG directives (Cadence Encounter Test / Modus DFT style comments)
# These are documentation; ET reads them from a separate test protocol file.
# Shift clock     : clk
# Capture clock   : clk
# Scan chain name : sc_main
# Chain length    : 320
# Scan in port    : scan_in
# Scan out port   : scan_out
# Scan enable     : scan_en (active HIGH = shift)
# Test coverage target: >95% stuck-at

#-- Load/drive
set_load  5.0 [get_ports {done tag_match led_done led_tag_match led_running led_error scan_out}]
set_drive 1.0 [get_ports {clk_p clk_n rst_n start scan_in scan_en}]

#-- False paths
set_false_path -from [get_ports rst_n]
set_false_path -to   [get_ports led_*]

#-- Operating conditions
set_operating_conditions -max_library slow -max slow
