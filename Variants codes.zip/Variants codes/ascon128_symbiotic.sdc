#==============================================================================
# ASCON-128  ·  Variant: symbiotic
# SDC for Cadence Genus Synthesis
#
# Permutation architecture: Dual-context time-multiplexed engine.
#   Two register sets (ex*, dx* for enc/dec). ctx_sel mux selects which
#   context feeds the single full-round combinational cone each cycle.
#
#   Critical path: ax*_reg -> ctx_sel mux (1 level) -> full round cone
#                  (~35-45 gate levels) -> ex*_reg or dx*_reg
#   The ctx_sel mux adds ~1 LUT level vs. baseline.
#   Fmax target: 25 MHz / 40 ns (same class as baseline)
#
#   Combined enc+dec pa=12 permutation: 24 + 1 = 25 cycles
#   (vs 13+13=26 cycles for two sequential baseline calls)
#==============================================================================
create_clock -period 40.000 -name sys_clk -waveform {0.000 20.000} [get_ports clk_p]
set_clock_uncertainty -setup 0.500 [get_clocks sys_clk]
set_clock_uncertainty -hold  0.300 [get_clocks sys_clk]
set_clock_transition -rise 0.200 [get_clocks sys_clk]
set_clock_transition -fall 0.200 [get_clocks sys_clk]
set_input_delay -clock sys_clk -max 2.000 [get_ports rst_n]
set_input_delay -clock sys_clk -min 0.500 [get_ports rst_n]
set_input_delay -clock sys_clk -max 2.000 [get_ports start]
set_input_delay -clock sys_clk -min 0.500 [get_ports start]
set_output_delay -clock sys_clk -max 2.000 [get_ports done]
set_output_delay -clock sys_clk -min 0.500 [get_ports done]
set_output_delay -clock sys_clk -max 2.000 [get_ports tag_match]
set_output_delay -clock sys_clk -min 0.500 [get_ports tag_match]
set_output_delay -clock sys_clk -max 2.000 [get_ports led_done]
set_output_delay -clock sys_clk -min 0.500 [get_ports led_done]
set_output_delay -clock sys_clk -max 2.000 [get_ports led_tag_match]
set_output_delay -clock sys_clk -min 0.500 [get_ports led_tag_match]
set_output_delay -clock sys_clk -max 2.000 [get_ports led_running]
set_output_delay -clock sys_clk -min 0.500 [get_ports led_running]
set_output_delay -clock sys_clk -max 2.000 [get_ports led_error]
set_output_delay -clock sys_clk -min 0.500 [get_ports led_error]
set_false_path -from [get_ports rst_n]
set_driving_cell -lib_cell INVX1 -no_design_rule [get_ports {start rst_n}]
set_load 5.0 [get_ports {done tag_match led_done led_tag_match led_running led_error}]
# set_operating_conditions -library <lib> TYPICAL
#==============================================================================
# END - ascon128_symbiotic.sdc
#==============================================================================
