`timescale 1ns / 1ps
//=============================================================================
// ASCON-128  ·  Variant: baseline
//
// Architecture : Pipelined permutation core (ascon_perm_fast) instantiated
//                by the top-level FSM (ascon128_baseline).
//
//                The permutation is split into 4 registered pipeline stages
//                per round (CONST -> SBOX -> CHI -> LINEAR), allowing each
//                stage to meet timing at 100 MHz / 10 ns independently.
//
//                Clocks per round : 4 (one per pipeline stage)
//                Clocks per pa=12 : 4 x 12 + 2 (IDLE + FINISH) = 50 cycles
//                Clocks per pb=6  : 4 x  6 + 2                  = 26 cycles
//
// Interface    : Fully runtime-configurable — key, nonce, AAD, plaintext,
//                and length are all supplied as input ports.  Supports both
//                encrypt-then-verify (default) and decrypt-only
//                (dec_tag_override=1) flows.  Variable-length plaintext up
//                to N_MAX_BLOCKS x 8 bytes (default 64 bytes / 8 blocks).
//
// FFs          : 320 (state) + permutation pipeline regs + FSM + data latches
// Fmax target  : 100 MHz / 10 ns
//
// Trade-offs
//   + Runtime-configurable key/nonce/plaintext (most flexible in suite)
//   + Variable-length plaintext via pt_len_bytes
//   + Encrypt and decrypt in a single session (or decrypt-only override)
//   - Highest latency per permutation call (4 cycles/round vs. 1 cycle/round
//     in the single-cycle variants) due to pipeline staging
//   - Larger FF count from permutation pipeline registers (t0..t4, x0..x4)
//=============================================================================

//=============================================================================
// ASCON Permutation — pipelined, 4 stages per round, 100 MHz target
//
// Stage 1 (CONST) : XOR round constant into x2
// Stage 2 (SBOX)  : Compute theta (pre-Chi) mixing terms t0..t4
// Stage 3 (CHI)   : Apply non-linear Chi layer to t0..t4 -> x0..x4
// Stage 4 (LINEAR): Apply linear diffusion rotations to x0..x4
//
// Round constants (ASCON v1.2 — indexed by absolute round number):
//   Round  0: 0xf0    Round  6: 0x96
//   Round  1: 0xe1    Round  7: 0x87
//   Round  2: 0xd2    Round  8: 0x78
//   Round  3: 0xc3    Round  9: 0x69
//   Round  4: 0xb4    Round 10: 0x5a
//   Round  5: 0xa5    Round 11: 0x4b
//
// pa=12: start_round=0,  rounds=12  (constants 0xf0..0x4b)
// pb=6 : start_round=6,  rounds=6   (constants 0x96..0x4b)
//=============================================================================
module ascon_perm_fast (
    input  wire        clk,
    input  wire        rst_n,
    input  wire        start,
    input  wire [3:0]  start_round,   // 0 for pa=12, 6 for pb=6
    input  wire [3:0]  rounds,        // number of rounds to execute
    input  wire [63:0] s0_in,
    input  wire [63:0] s1_in,
    input  wire [63:0] s2_in,
    input  wire [63:0] s3_in,
    input  wire [63:0] s4_in,
    output reg  [63:0] s0_out,
    output reg  [63:0] s1_out,
    output reg  [63:0] s2_out,
    output reg  [63:0] s3_out,
    output reg  [63:0] s4_out,
    output reg         done
);

    localparam [2:0]
        IDLE   = 3'd0,
        CONST  = 3'd1,
        SBOX   = 3'd2,
        CHI    = 3'd3,
        LINEAR = 3'd4,
        FINISH = 3'd5;

    reg [2:0] state;
    reg [3:0] round_cnt;     // current absolute round index
    reg [3:0] round_end;     // start_round + rounds (exclusive upper bound)
    reg [3:0] target_rounds;

    reg [63:0] x0, x1, x2, x3, x4;  // working state registers
    reg [63:0] t0, t1, t2, t3, t4;  // theta intermediate registers

    // Round constant — combinational lookup on current round_cnt
    reg [7:0] rc;
    always @(*) begin
        case (round_cnt)
            4'd0:  rc = 8'hf0;
            4'd1:  rc = 8'he1;
            4'd2:  rc = 8'hd2;
            4'd3:  rc = 8'hc3;
            4'd4:  rc = 8'hb4;
            4'd5:  rc = 8'ha5;
            4'd6:  rc = 8'h96;
            4'd7:  rc = 8'h87;
            4'd8:  rc = 8'h78;
            4'd9:  rc = 8'h69;
            4'd10: rc = 8'h5a;
            4'd11: rc = 8'h4b;
            default: rc = 8'h00;
        endcase
    end

    always @(posedge clk or negedge rst_n) begin
        if (!rst_n) begin
            state         <= IDLE;
            done          <= 1'b0;
            round_cnt     <= 4'd0;
            round_end     <= 4'd0;
            target_rounds <= 4'd0;
            x0 <= 64'd0; x1 <= 64'd0; x2 <= 64'd0; x3 <= 64'd0; x4 <= 64'd0;
            t0 <= 64'd0; t1 <= 64'd0; t2 <= 64'd0; t3 <= 64'd0; t4 <= 64'd0;
            s0_out <= 64'd0; s1_out <= 64'd0; s2_out <= 64'd0;
            s3_out <= 64'd0; s4_out <= 64'd0;
        end else begin
            case (state)

                IDLE: begin
                    done <= 1'b0;
                    if (start) begin
                        x0            <= s0_in;
                        x1            <= s1_in;
                        x2            <= s2_in;
                        x3            <= s3_in;
                        x4            <= s4_in;
                        round_cnt     <= start_round;
                        round_end     <= start_round + rounds;
                        target_rounds <= rounds;
                        state         <= CONST;
                    end
                end

                // Stage 1: XOR round constant into x2
                CONST: begin
                    x2    <= x2 ^ {56'd0, rc};
                    state <= SBOX;
                end

                // Stage 2: Theta (pre-Chi) mixing — compute t0..t4
                // t0 = x0^x4,  t1 = x1,  t2 = x2^x1,  t3 = x3,  t4 = x4^x3
                SBOX: begin
                    t0    <= x0 ^ x4;
                    t1    <= x1;
                    t2    <= x2 ^ x1;
                    t3    <= x3;
                    t4    <= x4 ^ x3;
                    state <= CHI;
                end

                // Stage 3: Chi (non-linear) layer
                // Si = ti ^ (~t(i+1) & t(i+2));  x2 output is inverted
                CHI: begin
                    x0    <=  t0 ^ (~t1 & t2);
                    x1    <=  t1 ^ (~t2 & t3);
                    x2    <= ~(t2 ^ (~t3 & t4));
                    x3    <=  t3 ^ (~t4 & t0);
                    x4    <=  t4 ^ (~t0 & t1);
                    state <= LINEAR;
                end

                // Stage 4: Linear diffusion layer (ASCON v1.2 rotation constants)
                //   x0: x ^ (x >>> 19) ^ (x >>> 28)
                //   x1: x ^ (x >>> 61) ^ (x >>> 39)
                //   x2: x ^ (x >>>  1) ^ (x >>>  6)
                //   x3: x ^ (x >>> 10) ^ (x >>> 17)
                //   x4: x ^ (x >>>  7) ^ (x >>> 41)
                LINEAR: begin
                    x0 <= x0 ^ {x0[18:0], x0[63:19]} ^ {x0[27:0], x0[63:28]};
                    x1 <= x1 ^ {x1[60:0], x1[63:61]} ^ {x1[38:0], x1[63:39]};
                    x2 <= x2 ^ {x2[0],    x2[63:1]}  ^ {x2[5:0],  x2[63:6]};
                    x3 <= x3 ^ {x3[9:0],  x3[63:10]} ^ {x3[16:0], x3[63:17]};
                    x4 <= x4 ^ {x4[6:0],  x4[63:7]}  ^ {x4[40:0], x4[63:41]};

                    if (round_cnt < round_end - 1) begin
                        round_cnt <= round_cnt + 4'd1;
                        state     <= CONST;
                    end else begin
                        state <= FINISH;
                    end
                end

                // Output registered results and assert done for one cycle
                FINISH: begin
                    s0_out <= x0;
                    s1_out <= x1;
                    s2_out <= x2;
                    s3_out <= x3;
                    s4_out <= x4;
                    done   <= 1'b1;
                    state  <= IDLE;
                end

                default: state <= IDLE;
            endcase
        end
    end
endmodule

//=============================================================================
// ASCON-128 Top — baseline
//
// Instantiates ascon_perm_fast and drives it via a 21-state FSM implementing
// the full ASCON-128 authenticated encryption and decryption sequence.
//
// Supported flows:
//   Encrypt + verify : dec_tag_override=0 — runs encrypt, stores tag,
//                      then runs decrypt and verifies tag_match.
//   Decrypt only     : dec_tag_override=1 — skips encrypt, runs decrypt
//                      against dec_tag_in directly.
//=============================================================================
module ascon128_baseline #(
    parameter N_MAX_BLOCKS = 8   // max 64-bit rate blocks = max 64 bytes PT
)(
    input  wire         clk,
    input  wire         rst_n,
    input  wire         start,

    input  wire [127:0] key,
    input  wire [127:0] nonce,
    input  wire [63:0]  aad_padded,
    input  wire [N_MAX_BLOCKS*64-1:0] pt_padded,
    input  wire [6:0]   pt_len_bytes,     // actual byte count (before padding)

    input  wire         dec_tag_override, // 1 = skip encrypt, go straight to decrypt
    input  wire [127:0] dec_tag_in,       // expected tag when dec_tag_override=1

    output wire [N_MAX_BLOCKS*64-1:0] ciphertext,    // registered, reassembled from ct_blk[]
    output reg  [127:0] tag_out,
    output wire [N_MAX_BLOCKS*64-1:0] plaintext_dec, // registered, reassembled from ptd_blk[]
    output reg          done,
    output reg          tag_match,
    output reg          session_done
);

    localparam [63:0] IV = 64'h80400c0600000000;

    localparam [4:0]
        ST_IDLE          = 5'd0,  ST_ENC_INIT      = 5'd1,  ST_ENC_INIT_PERM = 5'd2,
        ST_ENC_AAD       = 5'd3,  ST_ENC_AAD_PERM  = 5'd4,  ST_ENC_AAD_DOM   = 5'd5,
        ST_ENC_PT        = 5'd6,  ST_ENC_PT_PERM   = 5'd7,  ST_ENC_FINAL     = 5'd8,
        ST_ENC_FINAL_W   = 5'd9,  ST_TAG_STORE     = 5'd10, ST_DEC_INIT      = 5'd11,
        ST_DEC_INIT_PERM = 5'd12, ST_DEC_AAD       = 5'd13, ST_DEC_AAD_PERM  = 5'd14,
        ST_DEC_AAD_DOM   = 5'd15, ST_DEC_CT        = 5'd16, ST_DEC_CT_PERM   = 5'd17,
        ST_DEC_FINAL     = 5'd18, ST_DEC_FINAL_W   = 5'd19, ST_DONE          = 5'd20;

    reg [4:0]   state;
    reg [63:0]  s0, s1, s2, s3, s4;
    reg [127:0] tag_enc;
    reg [3:0]   block_idx;
    reg [3:0]   num_blocks_lat;

    reg [127:0] key_lat, nonce_lat;
    reg [63:0]  aad_lat;
    reg [N_MAX_BLOCKS*64-1:0] pt_lat;
    reg         dec_override_lat;
    reg [127:0] dec_tag_lat;

    //=========================================================================
    // Block arrays
    // pt_blk[] : combinationally unpacked from pt_lat (constant indices)
    // ct_blk[] : written by FSM, packed to ciphertext output wire
    // ptd_blk[]: written by FSM, packed to plaintext_dec output wire
    //=========================================================================
    wire [63:0] pt_blk  [0:N_MAX_BLOCKS-1];
    reg  [63:0] ct_blk  [0:N_MAX_BLOCKS-1];
    reg  [63:0] ptd_blk [0:N_MAX_BLOCKS-1];

    genvar gi;
    generate
        for (gi = 0; gi < N_MAX_BLOCKS; gi = gi + 1) begin : gen_pt_unpack
            assign pt_blk[gi] = pt_lat[(N_MAX_BLOCKS-1-gi)*64 +: 64];
        end
    endgenerate

    generate
        for (gi = 0; gi < N_MAX_BLOCKS; gi = gi + 1) begin : gen_ct_pack
            assign ciphertext[(N_MAX_BLOCKS-1-gi)*64 +: 64] = ct_blk[gi];
        end
    endgenerate

    generate
        for (gi = 0; gi < N_MAX_BLOCKS; gi = gi + 1) begin : gen_ptd_pack
            assign plaintext_dec[(N_MAX_BLOCKS-1-gi)*64 +: 64] = ptd_blk[gi];
        end
    endgenerate

    //=========================================================================
    // ceil(n/8) — computes number of 64-bit blocks from byte length
    //=========================================================================
    function [3:0] ceil_div8;
        input [6:0] n;
        reg [7:0] t;
        begin
            if (n == 7'd0) begin
                ceil_div8 = 4'd1;
            end else begin
                t = {1'b0, n} + 8'd7;
                ceil_div8 = t[6:3];
                if (ceil_div8 > N_MAX_BLOCKS[3:0])
                    ceil_div8 = N_MAX_BLOCKS[3:0];
            end
        end
    endfunction

    //=========================================================================
    // Permutation interface
    //=========================================================================
    reg         perm_start;
    wire        perm_done;
    reg  [3:0]  perm_start_round;
    reg  [3:0]  perm_num_rounds;
    wire [63:0] perm_out0, perm_out1, perm_out2, perm_out3, perm_out4;

    ascon_perm_fast perm_inst (
        .clk(clk), .rst_n(rst_n), .start(perm_start),
        .start_round(perm_start_round), .rounds(perm_num_rounds),
        .s0_in(s0), .s1_in(s1), .s2_in(s2), .s3_in(s3), .s4_in(s4),
        .s0_out(perm_out0), .s1_out(perm_out1), .s2_out(perm_out2),
        .s3_out(perm_out3), .s4_out(perm_out4), .done(perm_done)
    );

    //=========================================================================
    // Main FSM
    //=========================================================================
    integer ri;

    always @(posedge clk or negedge rst_n) begin
        if (!rst_n) begin
            state            <= ST_IDLE;
            done             <= 1'b0;
            tag_match        <= 1'b0;
            session_done     <= 1'b0;
            perm_start       <= 1'b0;
            perm_start_round <= 4'd0;
            perm_num_rounds  <= 4'd0;
            block_idx        <= 4'd0;
            num_blocks_lat   <= 4'd1;
            s0 <= 64'd0; s1 <= 64'd0; s2 <= 64'd0; s3 <= 64'd0; s4 <= 64'd0;
            tag_enc          <= 128'd0;
            tag_out          <= 128'd0;
            key_lat          <= 128'd0;
            nonce_lat        <= 128'd0;
            aad_lat          <= 64'd0;
            pt_lat           <= {N_MAX_BLOCKS*64{1'b0}};
            dec_override_lat <= 1'b0;
            dec_tag_lat      <= 128'd0;
            for (ri = 0; ri < N_MAX_BLOCKS; ri = ri + 1) begin
                ct_blk[ri]  <= 64'd0;
                ptd_blk[ri] <= 64'd0;
            end
        end else begin
            perm_start   <= 1'b0;
            session_done <= 1'b0;

            case (state)

                ST_IDLE: begin
                    done      <= 1'b0;
                    tag_match <= 1'b0;
                    if (start) begin
                        key_lat          <= key;
                        nonce_lat        <= nonce;
                        aad_lat          <= aad_padded;
                        pt_lat           <= pt_padded;
                        dec_override_lat <= dec_tag_override;
                        dec_tag_lat      <= dec_tag_in;
                        num_blocks_lat   <= ceil_div8(pt_len_bytes);
                        state <= dec_tag_override ? ST_DEC_INIT : ST_ENC_INIT;
                    end
                end

                // ── ENCRYPT ──────────────────────────────────────────────────
                ST_ENC_INIT: begin
                    s0 <= IV;
                    s1 <= key_lat[127:64];
                    s2 <= key_lat[63:0];
                    s3 <= nonce_lat[127:64];
                    s4 <= nonce_lat[63:0];
                    perm_start_round <= 4'd0;
                    perm_num_rounds  <= 4'd12;
                    perm_start <= 1'b1;
                    state      <= ST_ENC_INIT_PERM;
                end

                ST_ENC_INIT_PERM: begin
                    if (perm_done) begin
                        s0    <= perm_out0;
                        s1    <= perm_out1;
                        s2    <= perm_out2;
                        s3    <= perm_out3 ^ key_lat[127:64];
                        s4    <= perm_out4 ^ key_lat[63:0];
                        state <= ST_ENC_AAD;
                    end
                end

                ST_ENC_AAD: begin
                    s0 <= s0 ^ aad_lat;
                    perm_start_round <= 4'd6;
                    perm_num_rounds  <= 4'd6;
                    perm_start <= 1'b1;
                    state      <= ST_ENC_AAD_PERM;
                end

                ST_ENC_AAD_PERM: begin
                    if (perm_done) begin
                        s0 <= perm_out0; s1 <= perm_out1; s2 <= perm_out2;
                        s3 <= perm_out3; s4 <= perm_out4;
                        state <= ST_ENC_AAD_DOM;
                    end
                end

                ST_ENC_AAD_DOM: begin
                    s4        <= s4 ^ 64'h0000000000000001;
                    block_idx <= 4'd0;
                    state     <= ST_ENC_PT;
                end

                ST_ENC_PT: begin
                    if (block_idx < num_blocks_lat) begin
                        ct_blk[block_idx] <= s0 ^ pt_blk[block_idx];
                        s0                <= s0 ^ pt_blk[block_idx];
                        if (block_idx < num_blocks_lat - 4'd1) begin
                            perm_start_round <= 4'd6;
                            perm_num_rounds  <= 4'd6;
                            perm_start       <= 1'b1;
                            block_idx        <= block_idx + 4'd1;
                            state            <= ST_ENC_PT_PERM;
                        end else begin
                            state <= ST_ENC_FINAL;
                        end
                    end else begin
                        state <= ST_ENC_FINAL;
                    end
                end

                ST_ENC_PT_PERM: begin
                    if (perm_done) begin
                        s0 <= perm_out0; s1 <= perm_out1; s2 <= perm_out2;
                        s3 <= perm_out3; s4 <= perm_out4;
                        state <= ST_ENC_PT;
                    end
                end

                ST_ENC_FINAL: begin
                    s1 <= s1 ^ key_lat[127:64];
                    s2 <= s2 ^ key_lat[63:0];
                    perm_start_round <= 4'd0;
                    perm_num_rounds  <= 4'd12;
                    perm_start <= 1'b1;
                    state      <= ST_ENC_FINAL_W;
                end

                ST_ENC_FINAL_W: begin
                    if (perm_done) begin
                        tag_enc <= {perm_out3 ^ key_lat[127:64],
                                    perm_out4 ^ key_lat[63:0]};
                        tag_out <= {perm_out3 ^ key_lat[127:64],
                                    perm_out4 ^ key_lat[63:0]};
                        state   <= ST_TAG_STORE;
                    end
                end

                // Route: encrypt-only -> ST_DONE; encrypt+decrypt -> ST_DEC_INIT
                ST_TAG_STORE: state <= dec_override_lat ? ST_DEC_INIT : ST_DONE;

                // ── DECRYPT ──────────────────────────────────────────────────
                ST_DEC_INIT: begin
                    s0 <= IV;
                    s1 <= key_lat[127:64];
                    s2 <= key_lat[63:0];
                    s3 <= nonce_lat[127:64];
                    s4 <= nonce_lat[63:0];
                    perm_start_round <= 4'd0;
                    perm_num_rounds  <= 4'd12;
                    perm_start <= 1'b1;
                    state      <= ST_DEC_INIT_PERM;
                end

                ST_DEC_INIT_PERM: begin
                    if (perm_done) begin
                        s0    <= perm_out0;
                        s1    <= perm_out1;
                        s2    <= perm_out2;
                        s3    <= perm_out3 ^ key_lat[127:64];
                        s4    <= perm_out4 ^ key_lat[63:0];
                        state <= ST_DEC_AAD;
                    end
                end

                ST_DEC_AAD: begin
                    s0 <= s0 ^ aad_lat;
                    perm_start_round <= 4'd6;
                    perm_num_rounds  <= 4'd6;
                    perm_start <= 1'b1;
                    state      <= ST_DEC_AAD_PERM;
                end

                ST_DEC_AAD_PERM: begin
                    if (perm_done) begin
                        s0 <= perm_out0; s1 <= perm_out1; s2 <= perm_out2;
                        s3 <= perm_out3; s4 <= perm_out4;
                        state <= ST_DEC_AAD_DOM;
                    end
                end

                ST_DEC_AAD_DOM: begin
                    s4        <= s4 ^ 64'h0000000000000001;
                    block_idx <= 4'd0;
                    state     <= ST_DEC_CT;
                end

                ST_DEC_CT: begin
                    if (block_idx < num_blocks_lat) begin
                        ptd_blk[block_idx] <= s0 ^ (dec_override_lat ?
                                                     pt_blk[block_idx] :
                                                     ct_blk[block_idx]);
                        s0 <= dec_override_lat ? pt_blk[block_idx] : ct_blk[block_idx];
                        if (block_idx < num_blocks_lat - 4'd1) begin
                            perm_start_round <= 4'd6;
                            perm_num_rounds  <= 4'd6;
                            perm_start       <= 1'b1;
                            block_idx        <= block_idx + 4'd1;
                            state            <= ST_DEC_CT_PERM;
                        end else begin
                            state <= ST_DEC_FINAL;
                        end
                    end else begin
                        state <= ST_DEC_FINAL;
                    end
                end

                ST_DEC_CT_PERM: begin
                    if (perm_done) begin
                        s0 <= perm_out0; s1 <= perm_out1; s2 <= perm_out2;
                        s3 <= perm_out3; s4 <= perm_out4;
                        state <= ST_DEC_CT;
                    end
                end

                ST_DEC_FINAL: begin
                    s1 <= s1 ^ key_lat[127:64];
                    s2 <= s2 ^ key_lat[63:0];
                    perm_start_round <= 4'd0;
                    perm_num_rounds  <= 4'd12;
                    perm_start <= 1'b1;
                    state      <= ST_DEC_FINAL_W;
                end

                ST_DEC_FINAL_W: begin
                    if (perm_done) begin
                        tag_match <= dec_override_lat ?
                            ({perm_out3 ^ key_lat[127:64],
                              perm_out4 ^ key_lat[63:0]} == dec_tag_lat) :
                            (tag_enc == {perm_out3 ^ key_lat[127:64],
                                         perm_out4 ^ key_lat[63:0]});
                        state <= ST_DONE;
                    end
                end

                ST_DONE: begin
                    done         <= 1'b1;
                    session_done <= 1'b1;
                    state        <= ST_IDLE;
                end

                default: state <= ST_IDLE;
            endcase
        end
    end
endmodule
