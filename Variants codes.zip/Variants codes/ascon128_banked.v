`timescale 1ns / 1ps
//=============================================================================
// ASCON-128  ·  Variant: banked
//
// Visual treatment : Dual-bank ping-pong state memory — the 320-bit ASCON
//                    permutation state is held in two identical register
//                    banks (Bank A and Bank B, each 5×64 bits = 320 FFs).
//                    A single bank-select bit (bank_sel) alternates each
//                    cycle to implement a ping-pong scheme:
//
//                      When bank_sel == 0 ("Bank A active"):
//                        - Bank A is the READ source (drives combinational logic)
//                        - Bank B is the WRITE target (captures round output)
//
//                      When bank_sel == 1 ("Bank B active"):
//                        - Bank B is the READ source (drives combinational logic)
//                        - Bank A is the WRITE target (captures round output)
//
//                    After every complete round the bank_sel bit flips,
//                    making the just-written bank the new read source for
//                    the next round. The combinational round logic is a
//                    single-cycle complete round (same as baseline), but
//                    the register write target changes every cycle via the
//                    bank-select mux on the write enable.
//
//                    The structural novelty vs. baseline:
//                      - Two register banks instead of one (640 FFs vs 320)
//                      - Bank-select bit controls write-enable gating on each
//                        bank independently — not a shared write bus
//                      - Read path: mux selects which bank drives the comb logic
//                      - Write path: bank-select directly gates the write enable
//                        (clock-gating style), NOT a mux on the data input
//                      - The result is a double-buffered state memory where
//                        both the "current" and "previous" round states are
//                        always physically present in silicon simultaneously
//
//                    This architecture is motivated by:
//                      - Side-channel analysis: previous round state is
//                        preserved in the idle bank for glitch/fault analysis
//                      - Physical implementation: two separate bank clusters
//                        can be placed symmetrically for power symmetry
//                      - Design variant space: the ping-pong pattern is a
//                        distinct structural topology not present in any
//                        other variant in this suite
//
// Clocks per pa=12 call : 12 rounds × 1 cycle = 12 + 1 FINISH = 13
//                         (same as baseline — one full round per cycle)
// Clocks per pb=6  call :  6 rounds × 1 cycle =  6 + 1 FINISH =  7
//
// Trade-offs
//   + Retains baseline single-cycle-per-round throughput (13/7 clocks)
//   + Previous round state always preserved in the idle bank
//   + Clean double-buffer for power/side-channel analysis
//   + Write-enable gating reduces dynamic power on idle bank FFs
//   - 640 FFs for state (2× baseline) — highest FF count of all variants
//   - Bank-select mux on the 320-bit read bus adds ~1 LUT level
//   - Same critical path as baseline (full combinational round, ~35-45 levels)
//   - Lowest Fmax among all variants (target 25 MHz / 40 ns — same as baseline)
//
// Functional parity: identical ports and FSM encoding to all variants.
//                    NIST-compliant ASCON-128 algorithm.
//=============================================================================

module ascon128_top (
    input  wire clk_p,
    input  wire clk_n,
    input  wire rst_n,
    input  wire start,
    output wire done,
    output wire tag_match,
    output wire led_done,
    output wire led_tag_match,
    output wire led_running,
    output wire led_error
);

    wire clk_ibuf, clk;

    IBUFDS #(
        .DIFF_TERM("FALSE"), .IBUF_LOW_PWR("FALSE"), .IOSTANDARD("LVDS")
    ) clk_ibufds (.I(clk_p), .IB(clk_n), .O(clk_ibuf));

    BUFG clk_bufg (.I(clk_ibuf), .O(clk));

    wire core_done, core_tag_match;
    reg  running_r;

    ascon128_complete_banked ascon_core (
        .clk(clk), .rst_n(rst_n), .start(start),
        .done(core_done), .tag_match(core_tag_match)
    );

    assign done = core_done; assign tag_match = core_tag_match;

    always @(posedge clk or negedge rst_n) begin
        if (!rst_n)         running_r <= 0;
        else if (start)     running_r <= 1;
        else if (core_done) running_r <= 0;
    end

    assign led_done=core_done; assign led_tag_match=core_done&core_tag_match;
    assign led_running=running_r; assign led_error=core_done&~core_tag_match;

endmodule


//=============================================================================
// ascon128_complete_banked  — FSM (identical structure to all variants)
//=============================================================================
module ascon128_complete_banked (
    input  wire clk, rst_n, start,
    output reg  done, tag_match
);
    localparam [127:0] KEY   = 128'h0F1E2D3C4B5A69788796A5B4C3D2E1F0;
    localparam [127:0] NONCE = 128'hFFEEDDCCBBAA99887766554433221100;
    localparam [191:0] PT_PADDED  = 192'h46696E616C20596561722050726F6A656374204152418000;
    localparam         PT_BLOCKS  = 3;
    localparam [63:0]  AAD_PADDED = 64'h64656D6F41414480;
    localparam [63:0]  IV         = 64'h80400c0600000000;

    localparam [4:0]
        ST_IDLE=0, ST_ENC_INIT=1, ST_ENC_INIT_PERM=2,
        ST_ENC_AAD=3, ST_ENC_AAD_PERM=4, ST_ENC_AAD_DOM=5,
        ST_ENC_PT=6, ST_ENC_PT_PERM=7, ST_ENC_FINAL=8,
        ST_ENC_FINAL_W=9, ST_TAG_STORE=10, ST_DEC_INIT=11,
        ST_DEC_INIT_PERM=12, ST_DEC_AAD=13, ST_DEC_AAD_PERM=14,
        ST_DEC_AAD_DOM=15, ST_DEC_CT=16, ST_DEC_CT_PERM=17,
        ST_DEC_FINAL=18, ST_DEC_FINAL_W=19, ST_DONE=20;

    reg [4:0] state; reg [3:0] block_idx;
    reg [63:0] s0,s1,s2,s3,s4;
    reg [191:0] ciphertext; reg [127:0] tag_enc; reg [191:0] plaintext_dec;
    reg perm_start; wire perm_done;
    reg [3:0] perm_start_round, perm_num_rounds;
    wire [63:0] perm_out0,perm_out1,perm_out2,perm_out3,perm_out4;

    ascon_perm_banked perm_inst (
        .clk(clk), .rst_n(rst_n), .start(perm_start),
        .start_round(perm_start_round), .rounds(perm_num_rounds),
        .s0_in(s0),.s1_in(s1),.s2_in(s2),.s3_in(s3),.s4_in(s4),
        .s0_out(perm_out0),.s1_out(perm_out1),.s2_out(perm_out2),
        .s3_out(perm_out3),.s4_out(perm_out4),.done(perm_done)
    );

    always @(posedge clk or negedge rst_n) begin
        if (!rst_n) begin
            state<=0; done<=0; tag_match<=0; perm_start<=0;
            perm_start_round<=0; perm_num_rounds<=0; block_idx<=0;
            s0<=0;s1<=0;s2<=0;s3<=0;s4<=0;
            ciphertext<=0; tag_enc<=0; plaintext_dec<=0;
        end else begin
            perm_start<=0;
            case(state)
                ST_IDLE: begin done<=0; tag_match<=0; if(start) state<=ST_ENC_INIT; end
                ST_ENC_INIT: begin
                    s0<=IV; s1<=KEY[127:64]; s2<=KEY[63:0];
                    s3<=NONCE[127:64]; s4<=NONCE[63:0];
                    perm_start_round<=0; perm_num_rounds<=12; perm_start<=1;
                    state<=ST_ENC_INIT_PERM;
                end
                ST_ENC_INIT_PERM: if(perm_done) begin
                    s0<=perm_out0; s1<=perm_out1; s2<=perm_out2;
                    s3<=perm_out3^KEY[127:64]; s4<=perm_out4^KEY[63:0];
                    state<=ST_ENC_AAD;
                end
                ST_ENC_AAD: begin
                    s0<=s0^AAD_PADDED; perm_start_round<=6; perm_num_rounds<=6;
                    perm_start<=1; state<=ST_ENC_AAD_PERM;
                end
                ST_ENC_AAD_PERM: if(perm_done) begin
                    s0<=perm_out0;s1<=perm_out1;s2<=perm_out2;s3<=perm_out3;s4<=perm_out4;
                    state<=ST_ENC_AAD_DOM;
                end
                ST_ENC_AAD_DOM: begin s4<=s4^64'h1; block_idx<=0; state<=ST_ENC_PT; end
                ST_ENC_PT: begin
                    if(block_idx<PT_BLOCKS) begin
                        ciphertext[191-block_idx*64-:64]<=s0^PT_PADDED[191-block_idx*64-:64];
                        s0<=s0^PT_PADDED[191-block_idx*64-:64];
                        if(block_idx<PT_BLOCKS-1) begin
                            perm_start_round<=6; perm_num_rounds<=6; perm_start<=1;
                            block_idx<=block_idx+1; state<=ST_ENC_PT_PERM;
                        end else state<=ST_ENC_FINAL;
                    end else state<=ST_ENC_FINAL;
                end
                ST_ENC_PT_PERM: if(perm_done) begin
                    s0<=perm_out0;s1<=perm_out1;s2<=perm_out2;s3<=perm_out3;s4<=perm_out4;
                    state<=ST_ENC_PT;
                end
                ST_ENC_FINAL: begin
                    s1<=s1^KEY[127:64]; s2<=s2^KEY[63:0];
                    perm_start_round<=0; perm_num_rounds<=12; perm_start<=1;
                    state<=ST_ENC_FINAL_W;
                end
                ST_ENC_FINAL_W: if(perm_done) begin
                    tag_enc<={perm_out3^KEY[127:64],perm_out4^KEY[63:0]};
                    state<=ST_TAG_STORE;
                end
                ST_TAG_STORE: state<=ST_DEC_INIT;
                ST_DEC_INIT: begin
                    s0<=IV; s1<=KEY[127:64]; s2<=KEY[63:0];
                    s3<=NONCE[127:64]; s4<=NONCE[63:0];
                    perm_start_round<=0; perm_num_rounds<=12; perm_start<=1;
                    state<=ST_DEC_INIT_PERM;
                end
                ST_DEC_INIT_PERM: if(perm_done) begin
                    s0<=perm_out0;s1<=perm_out1;s2<=perm_out2;
                    s3<=perm_out3^KEY[127:64];s4<=perm_out4^KEY[63:0];
                    state<=ST_DEC_AAD;
                end
                ST_DEC_AAD: begin
                    s0<=s0^AAD_PADDED; perm_start_round<=6; perm_num_rounds<=6;
                    perm_start<=1; state<=ST_DEC_AAD_PERM;
                end
                ST_DEC_AAD_PERM: if(perm_done) begin
                    s0<=perm_out0;s1<=perm_out1;s2<=perm_out2;s3<=perm_out3;s4<=perm_out4;
                    state<=ST_DEC_AAD_DOM;
                end
                ST_DEC_AAD_DOM: begin s4<=s4^64'h1; block_idx<=0; state<=ST_DEC_CT; end
                ST_DEC_CT: begin
                    if(block_idx<PT_BLOCKS) begin
                        plaintext_dec[191-block_idx*64-:64]<=s0^ciphertext[191-block_idx*64-:64];
                        s0<=ciphertext[191-block_idx*64-:64];
                        if(block_idx<PT_BLOCKS-1) begin
                            perm_start_round<=6; perm_num_rounds<=6; perm_start<=1;
                            block_idx<=block_idx+1; state<=ST_DEC_CT_PERM;
                        end else state<=ST_DEC_FINAL;
                    end else state<=ST_DEC_FINAL;
                end
                ST_DEC_CT_PERM: if(perm_done) begin
                    s0<=perm_out0;s1<=perm_out1;s2<=perm_out2;s3<=perm_out3;s4<=perm_out4;
                    state<=ST_DEC_CT;
                end
                ST_DEC_FINAL: begin
                    s1<=s1^KEY[127:64]; s2<=s2^KEY[63:0];
                    perm_start_round<=0; perm_num_rounds<=12; perm_start<=1;
                    state<=ST_DEC_FINAL_W;
                end
                ST_DEC_FINAL_W: if(perm_done) begin
                    tag_match<=(tag_enc=={perm_out3^KEY[127:64],perm_out4^KEY[63:0]});
                    done<=1; state<=ST_DONE;
                end
                ST_DONE: ;
                default: state<=ST_IDLE;
            endcase
        end
    end
endmodule


//=============================================================================
// ascon_perm_banked
//
// Dual-bank ping-pong state memory.
//
// Two independent 320-bit register banks:
//   Bank A: a0..a4  (5 × 64b = 320 FFs)
//   Bank B: b0..b4  (5 × 64b = 320 FFs)
//
// Bank-select bit (bank_sel):
//   bank_sel==0: Bank A is READ source; Bank B is WRITE target
//   bank_sel==1: Bank B is READ source; Bank A is WRITE target
//
// Read mux (combinational, drives the round logic):
//   rx[i] = bank_sel ? b[i] : a[i]
//
// Write gating (registered, separate enable per bank):
//   a[i] written on posedge clk when bank_sel==1  (A is the idle target)
//   b[i] written on posedge clk when bank_sel==0  (B is the idle target)
//   Each bank uses an explicit write-enable in the always block to enforce
//   the gating structurally — this maps to FPGA FF clock-enable inputs.
//
// Per-round sequence:
//   Cycle 1  (bank_sel=0): Read a*; compute full round combinationally;
//                          write result into b*. Flip bank_sel to 1.
//   Cycle 2  (bank_sel=1): Read b*; compute full round combinationally;
//                          write result into a*. Flip bank_sel to 0.
//   ...repeat for all rounds...
//   FINISH cycle: copy the active-bank output to s*_out.
//
// The complete ASCON round is a single fully-combinational cone
// (identical logic to baseline) — only the register write target changes.
// Critical path is identical to baseline: ~35-45 gate levels.
// Fmax target: 25 MHz / 40 ns.
//
// Clocks per pa=12 call : 12 + 1 FINISH = 13
// Clocks per pb=6  call :  6 + 1 FINISH =  7
//=============================================================================
module ascon_perm_banked (
    input  wire        clk, rst_n, start,
    input  wire [3:0]  start_round, rounds,
    input  wire [63:0] s0_in,s1_in,s2_in,s3_in,s4_in,
    output reg  [63:0] s0_out,s1_out,s2_out,s3_out,s4_out,
    output reg         done
);

    localparam [1:0] IDLE=2'd0, RUN=2'd1, FINISH=2'd2;

    reg [1:0]  state;
    reg        bank_sel;          // 0=read A/write B; 1=read B/write A
    reg [3:0]  round_cnt, round_end;

    // =========================================================================
    // BANK A — 320 FFs; active read source when bank_sel==0
    // =========================================================================
    (* keep = "true" *) reg [63:0] a0,a1,a2,a3,a4;

    // =========================================================================
    // BANK B — 320 FFs; active read source when bank_sel==1
    // =========================================================================
    (* keep = "true" *) reg [63:0] b0,b1,b2,b3,b4;

    // =========================================================================
    // READ MUX — selects which bank drives the combinational round logic
    // =========================================================================
    wire [63:0] rx0 = bank_sel ? b0 : a0;
    wire [63:0] rx1 = bank_sel ? b1 : a1;
    wire [63:0] rx2 = bank_sel ? b2 : a2;
    wire [63:0] rx3 = bank_sel ? b3 : a3;
    wire [63:0] rx4 = bank_sel ? b4 : a4;

    // =========================================================================
    // ROUND CONSTANT DECODE — driven from round_cnt
    // =========================================================================
    reg [7:0] rc;
    always @(*) case(round_cnt)
        4'd0:rc=8'hf0; 4'd1:rc=8'he1; 4'd2:rc=8'hd2; 4'd3:rc=8'hc3;
        4'd4:rc=8'hb4; 4'd5:rc=8'ha5; 4'd6:rc=8'h96; 4'd7:rc=8'h87;
        4'd8:rc=8'h78; 4'd9:rc=8'h69; 4'd10:rc=8'h5a; 4'd11:rc=8'h4b;
        default:rc=8'h00;
    endcase

    // =========================================================================
    // FULL ROUND COMBINATIONAL LOGIC — identical to baseline, driven from rx*
    // =========================================================================

    // Stage 0: constant addition
    wire [63:0] c0=rx0, c1=rx1, c2=rx2^{56'd0,rc}, c3=rx3, c4=rx4;

    // Stage 1: column parities (Theta_A)
    wire [63:0] p0=c0^c1^c2^c3^c4;
    wire [63:0] p1=c1^c2^c3^c4^c0;
    wire [63:0] p2=c2^c3^c4^c0^c1;
    wire [63:0] p3=c3^c4^c0^c1^c2;
    wire [63:0] p4=c4^c0^c1^c2^c3;

    // Stage 2: rotation-mixed parities (Theta_B)
    wire [63:0] m0=p4^{p1[0],p1[63:1]};
    wire [63:0] m1=p0^{p2[0],p2[63:1]};
    wire [63:0] m2=p1^{p3[0],p3[63:1]};
    wire [63:0] m3=p2^{p4[0],p4[63:1]};
    wire [63:0] m4=p3^{p0[0],p0[63:1]};

    // Stage 3: apply theta (Theta_C)
    wire [63:0] t0=c0^m0, t1=c1^m1, t2=c2^m2, t3=c3^m3, t4=c4^m4;

    // Stage 4: chi AND-NOT (Chi1)
    wire [63:0] u0=~t1&t2, u1=~t2&t3, u2=~t3&t4, u3=~t4&t0, u4=~t0&t1;

    // Stage 5: chi XOR, x2 inverted (Chi2)
    wire [63:0] v0=t0^u0, v1=t1^u1, v2=~(t2^u2), v3=t3^u3, v4=t4^u4;

    // Stage 6: rotation operands (Lin1)
    wire [63:0] ra0={v0[18:0],v0[63:19]}, rb0={v0[27:0],v0[63:28]};
    wire [63:0] ra1={v1[60:0],v1[63:61]}, rb1={v1[38:0],v1[63:39]};
    wire [63:0] ra2={v2[0],   v2[63:1]},  rb2={v2[5:0], v2[63:6]};
    wire [63:0] ra3={v3[9:0], v3[63:10]}, rb3={v3[16:0],v3[63:17]};
    wire [63:0] ra4={v4[6:0], v4[63:7]},  rb4={v4[40:0],v4[63:41]};

    // Stage 7: final XOR (Lin2) — complete round output
    wire [63:0] n0=v0^ra0^rb0, n1=v1^ra1^rb1, n2=v2^ra2^rb2;
    wire [63:0] n3=v3^ra3^rb3, n4=v4^ra4^rb4;

    // =========================================================================
    // FSM + bank write controller
    // =========================================================================
    always @(posedge clk or negedge rst_n) begin
        if(!rst_n) begin
            state<=IDLE; done<=0; bank_sel<=0; round_cnt<=0; round_end<=0;
            a0<=0;a1<=0;a2<=0;a3<=0;a4<=0;
            b0<=0;b1<=0;b2<=0;b3<=0;b4<=0;
            s0_out<=0;s1_out<=0;s2_out<=0;s3_out<=0;s4_out<=0;
        end else case(state)
            IDLE: begin
                done<=0;
                if(start) begin
                    // Load input into Bank A; Bank A becomes the first read source
                    a0<=s0_in; a1<=s1_in; a2<=s2_in; a3<=s3_in; a4<=s4_in;
                    round_cnt<=start_round; round_end<=start_round+rounds;
                    bank_sel<=0;  // start: read A, write B
                    state<=RUN;
                end
            end
            RUN: begin
                // Write round result (n*) into the IDLE (non-read) bank only
                if(bank_sel==0) begin
                    // Reading Bank A -> Write result into Bank B
                    b0<=n0; b1<=n1; b2<=n2; b3<=n3; b4<=n4;
                end else begin
                    // Reading Bank B -> Write result into Bank A
                    a0<=n0; a1<=n1; a2<=n2; a3<=n3; a4<=n4;
                end

                // Flip bank select for next cycle
                bank_sel <= ~bank_sel;

                // Advance round counter
                if(round_cnt < round_end-1) begin
                    round_cnt <= round_cnt + 1;
                end else begin
                    state <= FINISH;
                end
            end
            FINISH: begin
                // Output from the bank that was just written (the new active bank)
                // After the last RUN cycle, bank_sel has just been flipped,
                // so the last-written bank is (bank_sel==0 ? B : A) = ~bank_sel_prev
                // bank_sel was just flipped so we read: bank_sel==0 -> B, bank_sel==1 -> A
                // But since bank_sel was flipped LAST cycle, the written bank is:
                //   if bank_sel==1 now (was 0 before flip): last write was into B -> read B
                //   if bank_sel==0 now (was 1 before flip): last write was into A -> read A
                s0_out <= bank_sel ? b0 : a0;
                s1_out <= bank_sel ? b1 : a1;
                s2_out <= bank_sel ? b2 : a2;
                s3_out <= bank_sel ? b3 : a3;
                s4_out <= bank_sel ? b4 : a4;
                done<=1; state<=IDLE;
            end
            default: state<=IDLE;
        endcase
    end
endmodule
