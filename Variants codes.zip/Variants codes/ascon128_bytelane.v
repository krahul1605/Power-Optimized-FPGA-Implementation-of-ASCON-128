`timescale 1ns / 1ps
//=============================================================================
// ASCON-128  ·  Variant: bytelane
//
// Visual treatment : Byte-lane parallel S-box — the Chi substitution layer
//                    is decomposed into 8 independent 8-bit lanes. Each lane
//                    processes bits [8k+7 : 8k] across all five state words
//                    simultaneously. Eight dedicated combinational S-box slices
//                    (lane_chi[0..7]) each cover 8 bit-positions of the
//                    5×64-bit state, computing 8 × 5-bit ASCON S-boxes in
//                    parallel (40 S-boxes per cycle across the full state).
//
//                    The S-box for bit position j is:
//                      new_x0[j] = x0[j] ^ (~x1[j] & x2[j])
//                      new_x1[j] = x1[j] ^ (~x2[j] & x3[j])
//                      new_x2[j] = ~(x2[j] ^ (~x3[j] & x4[j]))
//                      new_x3[j] = x3[j] ^ (~x4[j] & x0[j])
//                      new_x4[j] = x4[j] ^ (~x0[j] & x1[j])
//
//                    Per-round execution:
//
//     BL_CONST  (1 cyc): Round constant XOR into x2 only.
//                        No lane parallelism — trivial 8-bit XOR.
//
//     BL_THETA  (1 cyc): Full Theta (parity + rotation + apply) in one stage.
//                        Standard 64-bit datapath, same as soft/tristate theta.
//
//     BL_CHI    (1 cyc): All 8 byte-lanes execute simultaneously.
//                        Each lane_chi[k] computes 8 S-boxes for bits [8k+7:8k].
//                        The 8 lane results are assembled back into x0..x4
//                        via byte concatenation (no mux — direct assembly).
//                        x2 is inverted per ASCON spec (done per-lane in each
//                        8-bit chi slice).
//
//     BL_LIN    (1 cyc): Full Linear diffusion. Standard 64-bit rotations.
//
//                    The structural novelty is BL_CHI: rather than one 64-bit
//                    Chi cone, there are 8 independent 8-bit Chi cones that
//                    are all simultaneously active. Their outputs are byte-
//                    concatenated into the 64-bit result. This creates a
//                    "multi-lane" structure where the AND-NOT critical path is
//                    8× shorter per lane (8 bits vs 64 bits) though total
//                    gate count is the same. On FPGAs, each 8-bit lane maps
//                    to a single 4-LUT column, enabling dense packing.
//
// Clocks per pa=12 call : 12 × 4 = 48 + 1 FINISH = 49
// Clocks per pb=6  call :  6 × 4 = 24 + 1 FINISH = 25
//
// Trade-offs
//   + BL_CHI: 8 parallel 8-bit lanes map to one LUT column each on FPGA
//   + Chi critical path is shortened per lane (8-bit, ~3 LUT levels)
//   + Byte-lane structure visible in placement — clean column assignment
//   + BL_THETA remains the overall Fmax bottleneck (full 64-bit parity)
//   - 8 lane instantiations increase logic replication slightly (8× chi cones)
//   - Byte assembly at BL_CHI output adds 1 mux level for concatenation
//
// Functional parity: identical ports and FSM encoding to all variants.
//                    NIST-compliant ASCON-128 algorithm.
//=============================================================================

module ascon128_top (
    input  wire clk_p, clk_n, rst_n, start,
    output wire done, tag_match,
    output wire led_done, led_tag_match, led_running, led_error
);
    wire clk_ibuf, clk;
    IBUFDS #(.DIFF_TERM("FALSE"),.IBUF_LOW_PWR("FALSE"),.IOSTANDARD("LVDS"))
        clk_ibufds(.I(clk_p),.IB(clk_n),.O(clk_ibuf));
    BUFG clk_bufg(.I(clk_ibuf),.O(clk));
    wire core_done, core_tag_match;
    reg  running_r;
    ascon128_complete_bytelane ascon_core(.clk(clk),.rst_n(rst_n),.start(start),
        .done(core_done),.tag_match(core_tag_match));
    assign done=core_done; assign tag_match=core_tag_match;
    always @(posedge clk or negedge rst_n)
        if(!rst_n) running_r<=0;
        else if(start) running_r<=1;
        else if(core_done) running_r<=0;
    assign led_done=core_done; assign led_tag_match=core_done&core_tag_match;
    assign led_running=running_r; assign led_error=core_done&~core_tag_match;
endmodule

module ascon128_complete_bytelane (
    input  wire clk, rst_n, start,
    output reg  done, tag_match
);
    localparam [127:0] KEY   = 128'h0F1E2D3C4B5A69788796A5B4C3D2E1F0;
    localparam [127:0] NONCE = 128'hFFEEDDCCBBAA99887766554433221100;
    localparam [191:0] PT_PADDED  = 192'h46696E616C20596561722050726F6A656374204152418000;
    localparam         PT_BLOCKS  = 3;
    localparam [63:0]  AAD_PADDED = 64'h64656D6F41414480;
    localparam [63:0]  IV         = 64'h80400c0600000000;
    localparam [4:0]
        ST_IDLE=0,ST_ENC_INIT=1,ST_ENC_INIT_PERM=2,ST_ENC_AAD=3,ST_ENC_AAD_PERM=4,
        ST_ENC_AAD_DOM=5,ST_ENC_PT=6,ST_ENC_PT_PERM=7,ST_ENC_FINAL=8,ST_ENC_FINAL_W=9,
        ST_TAG_STORE=10,ST_DEC_INIT=11,ST_DEC_INIT_PERM=12,ST_DEC_AAD=13,
        ST_DEC_AAD_PERM=14,ST_DEC_AAD_DOM=15,ST_DEC_CT=16,ST_DEC_CT_PERM=17,
        ST_DEC_FINAL=18,ST_DEC_FINAL_W=19,ST_DONE=20;
    reg [4:0] state; reg [3:0] block_idx;
    reg [63:0] s0,s1,s2,s3,s4;
    reg [191:0] ciphertext; reg [127:0] tag_enc; reg [191:0] plaintext_dec;
    reg perm_start; wire perm_done;
    reg [3:0] perm_start_round, perm_num_rounds;
    wire [63:0] perm_out0,perm_out1,perm_out2,perm_out3,perm_out4;
    ascon_perm_bytelane perm_inst(
        .clk(clk),.rst_n(rst_n),.start(perm_start),
        .start_round(perm_start_round),.rounds(perm_num_rounds),
        .s0_in(s0),.s1_in(s1),.s2_in(s2),.s3_in(s3),.s4_in(s4),
        .s0_out(perm_out0),.s1_out(perm_out1),.s2_out(perm_out2),
        .s3_out(perm_out3),.s4_out(perm_out4),.done(perm_done));
    always @(posedge clk or negedge rst_n) begin
        if(!rst_n) begin
            state<=0;done<=0;tag_match<=0;perm_start<=0;
            perm_start_round<=0;perm_num_rounds<=0;block_idx<=0;
            s0<=0;s1<=0;s2<=0;s3<=0;s4<=0;ciphertext<=0;tag_enc<=0;plaintext_dec<=0;
        end else begin
            perm_start<=0;
            case(state)
                ST_IDLE: begin done<=0;tag_match<=0;if(start) state<=ST_ENC_INIT; end
                ST_ENC_INIT: begin s0<=IV;s1<=KEY[127:64];s2<=KEY[63:0];s3<=NONCE[127:64];s4<=NONCE[63:0];
                    perm_start_round<=0;perm_num_rounds<=12;perm_start<=1;state<=ST_ENC_INIT_PERM; end
                ST_ENC_INIT_PERM: if(perm_done) begin s0<=perm_out0;s1<=perm_out1;s2<=perm_out2;
                    s3<=perm_out3^KEY[127:64];s4<=perm_out4^KEY[63:0];state<=ST_ENC_AAD; end
                ST_ENC_AAD: begin s0<=s0^AAD_PADDED;perm_start_round<=6;perm_num_rounds<=6;
                    perm_start<=1;state<=ST_ENC_AAD_PERM; end
                ST_ENC_AAD_PERM: if(perm_done) begin s0<=perm_out0;s1<=perm_out1;s2<=perm_out2;
                    s3<=perm_out3;s4<=perm_out4;state<=ST_ENC_AAD_DOM; end
                ST_ENC_AAD_DOM: begin s4<=s4^64'h1;block_idx<=0;state<=ST_ENC_PT; end
                ST_ENC_PT: begin
                    if(block_idx<PT_BLOCKS) begin
                        ciphertext[191-block_idx*64-:64]<=s0^PT_PADDED[191-block_idx*64-:64];
                        s0<=s0^PT_PADDED[191-block_idx*64-:64];
                        if(block_idx<PT_BLOCKS-1) begin perm_start_round<=6;perm_num_rounds<=6;
                            perm_start<=1;block_idx<=block_idx+1;state<=ST_ENC_PT_PERM;
                        end else state<=ST_ENC_FINAL;
                    end else state<=ST_ENC_FINAL; end
                ST_ENC_PT_PERM: if(perm_done) begin s0<=perm_out0;s1<=perm_out1;s2<=perm_out2;
                    s3<=perm_out3;s4<=perm_out4;state<=ST_ENC_PT; end
                ST_ENC_FINAL: begin s1<=s1^KEY[127:64];s2<=s2^KEY[63:0];
                    perm_start_round<=0;perm_num_rounds<=12;perm_start<=1;state<=ST_ENC_FINAL_W; end
                ST_ENC_FINAL_W: if(perm_done) begin tag_enc<={perm_out3^KEY[127:64],perm_out4^KEY[63:0]};
                    state<=ST_TAG_STORE; end
                ST_TAG_STORE: state<=ST_DEC_INIT;
                ST_DEC_INIT: begin s0<=IV;s1<=KEY[127:64];s2<=KEY[63:0];s3<=NONCE[127:64];s4<=NONCE[63:0];
                    perm_start_round<=0;perm_num_rounds<=12;perm_start<=1;state<=ST_DEC_INIT_PERM; end
                ST_DEC_INIT_PERM: if(perm_done) begin s0<=perm_out0;s1<=perm_out1;s2<=perm_out2;
                    s3<=perm_out3^KEY[127:64];s4<=perm_out4^KEY[63:0];state<=ST_DEC_AAD; end
                ST_DEC_AAD: begin s0<=s0^AAD_PADDED;perm_start_round<=6;perm_num_rounds<=6;
                    perm_start<=1;state<=ST_DEC_AAD_PERM; end
                ST_DEC_AAD_PERM: if(perm_done) begin s0<=perm_out0;s1<=perm_out1;s2<=perm_out2;
                    s3<=perm_out3;s4<=perm_out4;state<=ST_DEC_AAD_DOM; end
                ST_DEC_AAD_DOM: begin s4<=s4^64'h1;block_idx<=0;state<=ST_DEC_CT; end
                ST_DEC_CT: begin
                    if(block_idx<PT_BLOCKS) begin
                        plaintext_dec[191-block_idx*64-:64]<=s0^ciphertext[191-block_idx*64-:64];
                        s0<=ciphertext[191-block_idx*64-:64];
                        if(block_idx<PT_BLOCKS-1) begin perm_start_round<=6;perm_num_rounds<=6;
                            perm_start<=1;block_idx<=block_idx+1;state<=ST_DEC_CT_PERM;
                        end else state<=ST_DEC_FINAL;
                    end else state<=ST_DEC_FINAL; end
                ST_DEC_CT_PERM: if(perm_done) begin s0<=perm_out0;s1<=perm_out1;s2<=perm_out2;
                    s3<=perm_out3;s4<=perm_out4;state<=ST_DEC_CT; end
                ST_DEC_FINAL: begin s1<=s1^KEY[127:64];s2<=s2^KEY[63:0];
                    perm_start_round<=0;perm_num_rounds<=12;perm_start<=1;state<=ST_DEC_FINAL_W; end
                ST_DEC_FINAL_W: if(perm_done) begin
                    tag_match<=(tag_enc=={perm_out3^KEY[127:64],perm_out4^KEY[63:0]});
                    done<=1;state<=ST_DONE; end
                ST_DONE: ;
                default: state<=ST_IDLE;
            endcase
        end
    end
endmodule

//=============================================================================
// ascon_perm_bytelane
//
// Four-phase per-round pipeline with byte-lane parallel Chi.
//
// BL_CONST: x2 ^= rc (single XOR, trivial)
// BL_THETA: standard full Theta (parity+rotation+apply), ~8-10 levels
// BL_CHI  : 8 independent 8-bit lanes each compute 8 S-boxes
// BL_LIN  : standard full Linear (two rotations + XOR)
//
// Byte-lane Chi structure for lane k (bits [8k+7:8k]):
//   chi_x0[8k+7:8k] = x0[8k+7:8k] ^ (~x1[8k+7:8k] & x2[8k+7:8k])
//   chi_x1[8k+7:8k] = x1[8k+7:8k] ^ (~x2[8k+7:8k] & x3[8k+7:8k])
//   chi_x2[8k+7:8k] = ~(x2[8k+7:8k] ^ (~x3[8k+7:8k] & x4[8k+7:8k]))
//   chi_x3[8k+7:8k] = x3[8k+7:8k] ^ (~x4[8k+7:8k] & x0[8k+7:8k])
//   chi_x4[8k+7:8k] = x4[8k+7:8k] ^ (~x0[8k+7:8k] & x1[8k+7:8k])
//
// The 8 lane outputs are concatenated: chi_x0 = {lane7_x0, lane6_x0, ..., lane0_x0}
// This is purely combinational and maps to a flat parallel structure.
//=============================================================================
module ascon_perm_bytelane (
    input  wire        clk, rst_n, start,
    input  wire [3:0]  start_round, rounds,
    input  wire [63:0] s0_in,s1_in,s2_in,s3_in,s4_in,
    output reg  [63:0] s0_out,s1_out,s2_out,s3_out,s4_out,
    output reg         done
);
    localparam [1:0] IDLE=2'd0, RUN=2'd1, FINISH=2'd2;
    localparam [1:0] BL_CONST=2'd0, BL_THETA=2'd1, BL_CHI=2'd2, BL_LIN=2'd3;

    reg [1:0] state, bl_phase;
    reg [3:0] round_cnt, round_end;
    reg [63:0] x0,x1,x2,x3,x4;

    reg [7:0] rc;
    always @(*) case(round_cnt)
        4'd0:rc=8'hf0; 4'd1:rc=8'he1; 4'd2:rc=8'hd2; 4'd3:rc=8'hc3;
        4'd4:rc=8'hb4; 4'd5:rc=8'ha5; 4'd6:rc=8'h96; 4'd7:rc=8'h87;
        4'd8:rc=8'h78; 4'd9:rc=8'h69; 4'd10:rc=8'h5a; 4'd11:rc=8'h4b;
        default:rc=8'h00;
    endcase

    // -------------------------------------------------------------------------
    // BL_THETA combinational cone
    // -------------------------------------------------------------------------
    wire [63:0] tp0=x0^x1^x2^x3^x4, tp1=x1^x2^x3^x4^x0;
    wire [63:0] tp2=x2^x3^x4^x0^x1, tp3=x3^x4^x0^x1^x2, tp4=x4^x0^x1^x2^x3;
    wire [63:0] tm0=tp4^{tp1[0],tp1[63:1]}, tm1=tp0^{tp2[0],tp2[63:1]};
    wire [63:0] tm2=tp1^{tp3[0],tp3[63:1]}, tm3=tp2^{tp4[0],tp4[63:1]};
    wire [63:0] tm4=tp3^{tp0[0],tp0[63:1]};
    wire [63:0] tt0=x0^tm0, tt1=x1^tm1, tt2=x2^tm2, tt3=x3^tm3, tt4=x4^tm4;

    // -------------------------------------------------------------------------
    // BL_CHI — 8 independent byte lanes (generated structurally)
    // Each lane: 8-bit slice of (x0..x4) -> 8-bit slice of chi output
    // -------------------------------------------------------------------------
    // Lane outputs assembled via generate
    wire [63:0] chi0_w, chi1_w, chi2_w, chi3_w, chi4_w;

    genvar k;
    generate
        for(k=0; k<8; k=k+1) begin : BYTE_LANE
            // 8-bit slices from each state word
            wire [7:0] b0 = x0[8*k+7:8*k];
            wire [7:0] b1 = x1[8*k+7:8*k];
            wire [7:0] b2 = x2[8*k+7:8*k];
            wire [7:0] b3 = x3[8*k+7:8*k];
            wire [7:0] b4 = x4[8*k+7:8*k];
            // 8-bit Chi computation per lane
            assign chi0_w[8*k+7:8*k] = b0 ^ (~b1 & b2);
            assign chi1_w[8*k+7:8*k] = b1 ^ (~b2 & b3);
            assign chi2_w[8*k+7:8*k] = ~(b2 ^ (~b3 & b4));  // inverted per spec
            assign chi3_w[8*k+7:8*k] = b3 ^ (~b4 & b0);
            assign chi4_w[8*k+7:8*k] = b4 ^ (~b0 & b1);
        end
    endgenerate

    // -------------------------------------------------------------------------
    // BL_LIN combinational cone
    // -------------------------------------------------------------------------
    wire [63:0] ln0=x0^{x0[18:0],x0[63:19]}^{x0[27:0],x0[63:28]};
    wire [63:0] ln1=x1^{x1[60:0],x1[63:61]}^{x1[38:0],x1[63:39]};
    wire [63:0] ln2=x2^{x2[0],   x2[63:1]} ^{x2[5:0], x2[63:6]};
    wire [63:0] ln3=x3^{x3[9:0], x3[63:10]}^{x3[16:0],x3[63:17]};
    wire [63:0] ln4=x4^{x4[6:0], x4[63:7]} ^{x4[40:0],x4[63:41]};

    always @(posedge clk or negedge rst_n) begin
        if(!rst_n) begin
            state<=IDLE;done<=0;bl_phase<=BL_CONST;round_cnt<=0;round_end<=0;
            x0<=0;x1<=0;x2<=0;x3<=0;x4<=0;
            s0_out<=0;s1_out<=0;s2_out<=0;s3_out<=0;s4_out<=0;
        end else case(state)
            IDLE: begin
                done<=0;
                if(start) begin
                    x0<=s0_in;x1<=s1_in;x2<=s2_in;x3<=s3_in;x4<=s4_in;
                    round_cnt<=start_round;round_end<=start_round+rounds;
                    bl_phase<=BL_CONST;state<=RUN;
                end
            end
            RUN: begin
                case(bl_phase)
                    BL_CONST: begin x2<=x2^{56'd0,rc}; bl_phase<=BL_THETA; end
                    BL_THETA: begin x0<=tt0;x1<=tt1;x2<=tt2;x3<=tt3;x4<=tt4; bl_phase<=BL_CHI; end
                    BL_CHI:   begin x0<=chi0_w;x1<=chi1_w;x2<=chi2_w;x3<=chi3_w;x4<=chi4_w; bl_phase<=BL_LIN; end
                    BL_LIN: begin
                        x0<=ln0;x1<=ln1;x2<=ln2;x3<=ln3;x4<=ln4;
                        bl_phase<=BL_CONST;
                        if(round_cnt<round_end-1) round_cnt<=round_cnt+1;
                        else state<=FINISH;
                    end
                    default: bl_phase<=BL_CONST;
                endcase
            end
            FINISH: begin s0_out<=x0;s1_out<=x1;s2_out<=x2;s3_out<=x3;s4_out<=x4;done<=1;state<=IDLE; end
            default: state<=IDLE;
        endcase
    end
endmodule
