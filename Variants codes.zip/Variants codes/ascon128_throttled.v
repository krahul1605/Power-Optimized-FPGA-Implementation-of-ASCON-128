`timescale 1ns / 1ps
//=============================================================================
// ASCON-128 · Variant: throttled
//
// Variable-rate engine — automatically selects pipeline depth based on the
// number of rounds requested:
//   rounds==12 (pa): uses 4-stage pipeline (Const+Theta | Chi | Lin | NOP)
//                    → 4 cycles/round, 48+1=49 clocks total
//   rounds==6  (pb): uses 2-stage pipeline (Const+Theta+Chi | Lin)
//                    → 2 cycles/round, 12+1=13 clocks total
//   default:         falls back to 1-cycle (full round like baseline)
//
// The stage_mode register (2 bits) is set at perm_start and drives a mux
// that selects which pipeline configuration the next cycle executes.
// Structurally: three combinational cones are always live (theta, chi, lin);
// the stage_mode register controls which subset writes to x* each cycle.
//
// Clocks pa=12: 49 (4-stage mode)  Clocks pb=6: 13 (2-stage mode)
// Fmax: 100 MHz (both modes — critical path is theta in all cases)
//=============================================================================

module ascon128_top (
    input  wire clk_p,clk_n,rst_n,start,
    output wire done,tag_match,led_done,led_tag_match,led_running,led_error
);
    wire clk_ibuf,clk; reg rr;
    IBUFDS #(.DIFF_TERM("FALSE"),.IBUF_LOW_PWR("FALSE"),.IOSTANDARD("LVDS"))
        u0(.I(clk_p),.IB(clk_n),.O(clk_ibuf));
    BUFG u1(.I(clk_ibuf),.O(clk));
    wire cd,ct;
    ascon128_complete_throttled ac(.clk(clk),.rst_n(rst_n),.start(start),.done(cd),.tag_match(ct));
    assign done=cd;assign tag_match=ct;
    always @(posedge clk or negedge rst_n) if(!rst_n) rr<=0; else if(start) rr<=1; else if(cd) rr<=0;
    assign led_done=cd;assign led_tag_match=cd&ct;assign led_running=rr;assign led_error=cd&~ct;
endmodule

module ascon128_complete_throttled(input wire clk,rst_n,start,output reg done,tag_match);
    localparam [127:0] KEY=128'h0F1E2D3C4B5A69788796A5B4C3D2E1F0,NONCE=128'hFFEEDDCCBBAA99887766554433221100;
    localparam [191:0] PT_PADDED=192'h46696E616C20596561722050726F6A656374204152418000;
    localparam PT_BLOCKS=3;localparam [63:0] AAD_PADDED=64'h64656D6F41414480,IV=64'h80400c0600000000;
    localparam [4:0] ST_IDLE=0,ST_ENC_INIT=1,ST_ENC_INIT_PERM=2,ST_ENC_AAD=3,ST_ENC_AAD_PERM=4,
        ST_ENC_AAD_DOM=5,ST_ENC_PT=6,ST_ENC_PT_PERM=7,ST_ENC_FINAL=8,ST_ENC_FINAL_W=9,
        ST_TAG_STORE=10,ST_DEC_INIT=11,ST_DEC_INIT_PERM=12,ST_DEC_AAD=13,ST_DEC_AAD_PERM=14,
        ST_DEC_AAD_DOM=15,ST_DEC_CT=16,ST_DEC_CT_PERM=17,ST_DEC_FINAL=18,ST_DEC_FINAL_W=19,ST_DONE=20;
    reg [4:0] state;reg [3:0] block_idx;
    reg [63:0] s0,s1,s2,s3,s4;
    reg [191:0] ciphertext;reg [127:0] tag_enc;reg [191:0] plaintext_dec;
    reg perm_start;wire perm_done;
    reg [3:0] perm_start_round,perm_num_rounds;
    wire [63:0] po0,po1,po2,po3,po4;
    ascon_perm_throttled pi(.clk(clk),.rst_n(rst_n),.start(perm_start),
        .start_round(perm_start_round),.rounds(perm_num_rounds),
        .s0_in(s0),.s1_in(s1),.s2_in(s2),.s3_in(s3),.s4_in(s4),
        .s0_out(po0),.s1_out(po1),.s2_out(po2),.s3_out(po3),.s4_out(po4),.done(perm_done));
    always @(posedge clk or negedge rst_n) begin
        if(!rst_n) begin state<=0;done<=0;tag_match<=0;perm_start<=0;perm_start_round<=0;perm_num_rounds<=0;block_idx<=0;
            s0<=0;s1<=0;s2<=0;s3<=0;s4<=0;ciphertext<=0;tag_enc<=0;plaintext_dec<=0;
        end else begin perm_start<=0;
            case(state)
                ST_IDLE:begin done<=0;tag_match<=0;if(start) state<=ST_ENC_INIT;end
                ST_ENC_INIT:begin s0<=IV;s1<=KEY[127:64];s2<=KEY[63:0];s3<=NONCE[127:64];s4<=NONCE[63:0];
                    perm_start_round<=0;perm_num_rounds<=12;perm_start<=1;state<=ST_ENC_INIT_PERM;end
                ST_ENC_INIT_PERM:if(perm_done)begin s0<=po0;s1<=po1;s2<=po2;s3<=po3^KEY[127:64];s4<=po4^KEY[63:0];state<=ST_ENC_AAD;end
                ST_ENC_AAD:begin s0<=s0^AAD_PADDED;perm_start_round<=6;perm_num_rounds<=6;perm_start<=1;state<=ST_ENC_AAD_PERM;end
                ST_ENC_AAD_PERM:if(perm_done)begin s0<=po0;s1<=po1;s2<=po2;s3<=po3;s4<=po4;state<=ST_ENC_AAD_DOM;end
                ST_ENC_AAD_DOM:begin s4<=s4^64'h1;block_idx<=0;state<=ST_ENC_PT;end
                ST_ENC_PT:begin
                    if(block_idx<PT_BLOCKS)begin
                        ciphertext[191-block_idx*64-:64]<=s0^PT_PADDED[191-block_idx*64-:64];
                        s0<=s0^PT_PADDED[191-block_idx*64-:64];
                        if(block_idx<PT_BLOCKS-1)begin perm_start_round<=6;perm_num_rounds<=6;perm_start<=1;
                            block_idx<=block_idx+1;state<=ST_ENC_PT_PERM;end else state<=ST_ENC_FINAL;
                    end else state<=ST_ENC_FINAL;end
                ST_ENC_PT_PERM:if(perm_done)begin s0<=po0;s1<=po1;s2<=po2;s3<=po3;s4<=po4;state<=ST_ENC_PT;end
                ST_ENC_FINAL:begin s1<=s1^KEY[127:64];s2<=s2^KEY[63:0];perm_start_round<=0;perm_num_rounds<=12;perm_start<=1;state<=ST_ENC_FINAL_W;end
                ST_ENC_FINAL_W:if(perm_done)begin tag_enc<={po3^KEY[127:64],po4^KEY[63:0]};state<=ST_TAG_STORE;end
                ST_TAG_STORE:state<=ST_DEC_INIT;
                ST_DEC_INIT:begin s0<=IV;s1<=KEY[127:64];s2<=KEY[63:0];s3<=NONCE[127:64];s4<=NONCE[63:0];
                    perm_start_round<=0;perm_num_rounds<=12;perm_start<=1;state<=ST_DEC_INIT_PERM;end
                ST_DEC_INIT_PERM:if(perm_done)begin s0<=po0;s1<=po1;s2<=po2;s3<=po3^KEY[127:64];s4<=po4^KEY[63:0];state<=ST_DEC_AAD;end
                ST_DEC_AAD:begin s0<=s0^AAD_PADDED;perm_start_round<=6;perm_num_rounds<=6;perm_start<=1;state<=ST_DEC_AAD_PERM;end
                ST_DEC_AAD_PERM:if(perm_done)begin s0<=po0;s1<=po1;s2<=po2;s3<=po3;s4<=po4;state<=ST_DEC_AAD_DOM;end
                ST_DEC_AAD_DOM:begin s4<=s4^64'h1;block_idx<=0;state<=ST_DEC_CT;end
                ST_DEC_CT:begin
                    if(block_idx<PT_BLOCKS)begin
                        plaintext_dec[191-block_idx*64-:64]<=s0^ciphertext[191-block_idx*64-:64];
                        s0<=ciphertext[191-block_idx*64-:64];
                        if(block_idx<PT_BLOCKS-1)begin perm_start_round<=6;perm_num_rounds<=6;perm_start<=1;
                            block_idx<=block_idx+1;state<=ST_DEC_CT_PERM;end else state<=ST_DEC_FINAL;
                    end else state<=ST_DEC_FINAL;end
                ST_DEC_CT_PERM:if(perm_done)begin s0<=po0;s1<=po1;s2<=po2;s3<=po3;s4<=po4;state<=ST_DEC_CT;end
                ST_DEC_FINAL:begin s1<=s1^KEY[127:64];s2<=s2^KEY[63:0];perm_start_round<=0;perm_num_rounds<=12;perm_start<=1;state<=ST_DEC_FINAL_W;end
                ST_DEC_FINAL_W:if(perm_done)begin tag_match<=(tag_enc=={po3^KEY[127:64],po4^KEY[63:0]});done<=1;state<=ST_DONE;end
                ST_DONE:;default:state<=ST_IDLE;
            endcase end end
endmodule

//=============================================================================
// ascon_perm_throttled
// stage_mode determined at start by rounds:
//   MODE_4 (rounds==12): 4 stages/round — TH, CHI, LIN, IDLE(NOP)
//   MODE_2 (rounds==6) : 2 stages/round — TH+CHI fused, LIN
//   MODE_1 (default)   : 1 stage/round  — full round (baseline)
//=============================================================================
module ascon_perm_throttled (
    input  wire       clk,rst_n,start,
    input  wire [3:0] start_round,rounds,
    input  wire [63:0] s0_in,s1_in,s2_in,s3_in,s4_in,
    output reg  [63:0] s0_out,s1_out,s2_out,s3_out,s4_out,
    output reg        done
);
    localparam [1:0] IDLE_ST=2'd0,RUN=2'd1,FINISH=2'd2;
    localparam [1:0] MODE_4=2'd0,MODE_2=2'd1,MODE_1=2'd2;
    // Stage sub-encodings for MODE_4 (2-bit sub_stage 0..3)
    localparam [1:0] S4_TH=2'd0,S4_CHI=2'd1,S4_LIN=2'd2,S4_NOP=2'd3;
    // Stage sub-encodings for MODE_2 (1-bit sub_stage 0..1)
    localparam S2_THCHI=1'b0,S2_LIN=1'b1;

    reg [1:0] state,stage_mode,sub_stage;
    reg [3:0] round_cnt,round_end;
    reg [63:0] x0,x1,x2,x3,x4;
    // Theta intermediate for MODE_4
    reg [63:0] th0,th1,th2,th3,th4;
    // Chi intermediate for MODE_4 and MODE_2
    reg [63:0] ch0,ch1,ch2,ch3,ch4;

    reg [7:0] rc;
    always @(*) case(round_cnt)
        4'd0:rc=8'hf0;4'd1:rc=8'he1;4'd2:rc=8'hd2;4'd3:rc=8'hc3;
        4'd4:rc=8'hb4;4'd5:rc=8'ha5;4'd6:rc=8'h96;4'd7:rc=8'h87;
        4'd8:rc=8'h78;4'd9:rc=8'h69;4'd10:rc=8'h5a;4'd11:rc=8'h4b;
        default:rc=8'h00;
    endcase

    // Theta cone driven from x*
    wire [63:0] tp0=x0^x1^x2^x3^x4,tp1=x1^x2^x3^x4^x0,tp2=x2^x3^x4^x0^x1,tp3=x3^x4^x0^x1^x2,tp4=x4^x0^x1^x2^x3;
    wire [63:0] tm0=tp4^{tp1[0],tp1[63:1]},tm1=tp0^{tp2[0],tp2[63:1]},tm2=tp1^{tp3[0],tp3[63:1]};
    wire [63:0] tm3=tp2^{tp4[0],tp4[63:1]},tm4=tp3^{tp0[0],tp0[63:1]};
    wire [63:0] tt0=x0^tm0,tt1=x1^tm1,tt2=x2^tm2,tt3=x3^tm3,tt4=x4^tm4;

    // Chi cone driven from th* (MODE_4) or x* (MODE_2,1)
    wire [63:0] ci0=(stage_mode==MODE_4)?th0:x0, ci1=(stage_mode==MODE_4)?th1:x1;
    wire [63:0] ci2=(stage_mode==MODE_4)?th2:x2, ci3=(stage_mode==MODE_4)?th3:x3;
    wire [63:0] ci4=(stage_mode==MODE_4)?th4:x4;
    wire [63:0] tc0=ci0^(~ci1&ci2),tc1=ci1^(~ci2&ci3);
    wire [63:0] tc2=~(ci2^(~ci3&ci4)),tc3=ci3^(~ci4&ci0),tc4=ci4^(~ci0&ci1);

    // Linear cone driven from ch* (MODE_4) or tc* direct (MODE_2) or v* (MODE_1)
    wire [63:0] li0=(stage_mode==MODE_4)?ch0:tc0, li1=(stage_mode==MODE_4)?ch1:tc1;
    wire [63:0] li2=(stage_mode==MODE_4)?ch2:tc2, li3=(stage_mode==MODE_4)?ch3:tc3;
    wire [63:0] li4=(stage_mode==MODE_4)?ch4:tc4;
    wire [63:0] ln0=li0^{li0[18:0],li0[63:19]}^{li0[27:0],li0[63:28]};
    wire [63:0] ln1=li1^{li1[60:0],li1[63:61]}^{li1[38:0],li1[63:39]};
    wire [63:0] ln2=li2^{li2[0],li2[63:1]}^{li2[5:0],li2[63:6]};
    wire [63:0] ln3=li3^{li3[9:0],li3[63:10]}^{li3[16:0],li3[63:17]};
    wire [63:0] ln4=li4^{li4[6:0],li4[63:7]}^{li4[40:0],li4[63:41]};

    // Full round cone for MODE_1 (baseline path through x*)
    wire [63:0] fx2=x2^{56'd0,rc};
    wire [63:0] fp0=x0^x1^fx2^x3^x4,fp1=x1^fx2^x3^x4^x0,fp2=fx2^x3^x4^x0^x1,fp3=x3^x4^x0^x1^fx2,fp4=x4^x0^x1^fx2^x3;
    wire [63:0] fm0=fp4^{fp1[0],fp1[63:1]},fm1=fp0^{fp2[0],fp2[63:1]},fm2=fp1^{fp3[0],fp3[63:1]};
    wire [63:0] fm3=fp2^{fp4[0],fp4[63:1]},fm4=fp3^{fp0[0],fp0[63:1]};
    wire [63:0] ft0=x0^fm0,ft1=x1^fm1,ft2=fx2^fm2,ft3=x3^fm3,ft4=x4^fm4;
    wire [63:0] fu0=~ft1&ft2,fu1=~ft2&ft3,fu2=~ft3&ft4,fu3=~ft4&ft0,fu4=~ft0&ft1;
    wire [63:0] fv0=ft0^fu0,fv1=ft1^fu1,fv2=~(ft2^fu2),fv3=ft3^fu3,fv4=ft4^fu4;
    wire [63:0] fn0=fv0^{fv0[18:0],fv0[63:19]}^{fv0[27:0],fv0[63:28]};
    wire [63:0] fn1=fv1^{fv1[60:0],fv1[63:61]}^{fv1[38:0],fv1[63:39]};
    wire [63:0] fn2=fv2^{fv2[0],fv2[63:1]}^{fv2[5:0],fv2[63:6]};
    wire [63:0] fn3=fv3^{fv3[9:0],fv3[63:10]}^{fv3[16:0],fv3[63:17]};
    wire [63:0] fn4=fv4^{fv4[6:0],fv4[63:7]}^{fv4[40:0],fv4[63:41]};

    always @(posedge clk or negedge rst_n) begin
        if(!rst_n) begin state<=IDLE_ST;done<=0;stage_mode<=MODE_1;sub_stage<=0;round_cnt<=0;round_end<=0;
            x0<=0;x1<=0;x2<=0;x3<=0;x4<=0;th0<=0;th1<=0;th2<=0;th3<=0;th4<=0;ch0<=0;ch1<=0;ch2<=0;ch3<=0;ch4<=0;
            s0_out<=0;s1_out<=0;s2_out<=0;s3_out<=0;s4_out<=0;
        end else case(state)
            IDLE_ST: begin done<=0;
                if(start) begin
                    x0<=s0_in;x1<=s1_in;x2<=s2_in;x3<=s3_in;x4<=s4_in;
                    round_cnt<=start_round;round_end<=start_round+rounds;
                    stage_mode<=(rounds==12)?MODE_4:(rounds==6)?MODE_2:MODE_1;
                    sub_stage<=0;state<=RUN;
                end end
            RUN: begin
                case(stage_mode)
                    MODE_4: begin
                        case(sub_stage)
                            S4_TH:  begin x2<=x2^{56'd0,rc};th0<=tt0;th1<=tt1;th2<=tt2;th3<=tt3;th4<=tt4;sub_stage<=S4_CHI;end
                            S4_CHI: begin ch0<=tc0;ch1<=tc1;ch2<=tc2;ch3<=tc3;ch4<=tc4;sub_stage<=S4_LIN;end
                            S4_LIN: begin x0<=ln0;x1<=ln1;x2<=ln2;x3<=ln3;x4<=ln4;sub_stage<=S4_NOP;end
                            S4_NOP: begin sub_stage<=S4_TH;
                                if(round_cnt<round_end-1) round_cnt<=round_cnt+1; else state<=FINISH;end
                            default:sub_stage<=S4_TH;
                        endcase end
                    MODE_2: begin
                        case(sub_stage[0])
                            S2_THCHI: begin x2<=x2^{56'd0,rc};x0<=tc0;x1<=tc1;x2<=tc2;x3<=tc3;x4<=tc4;sub_stage<=1;end
                            S2_LIN:   begin x0<=ln0;x1<=ln1;x2<=ln2;x3<=ln3;x4<=ln4;sub_stage<=0;
                                if(round_cnt<round_end-1) round_cnt<=round_cnt+1; else state<=FINISH;end
                            default:sub_stage<=0;
                        endcase end
                    default: begin // MODE_1
                        x0<=fn0;x1<=fn1;x2<=fn2;x3<=fn3;x4<=fn4;
                        if(round_cnt<round_end-1) round_cnt<=round_cnt+1; else state<=FINISH;
                    end
                endcase end
            FINISH:begin s0_out<=x0;s1_out<=x1;s2_out<=x2;s3_out<=x3;s4_out<=x4;done<=1;state<=IDLE_ST;end
            default:state<=IDLE_ST;
        endcase end
endmodule
