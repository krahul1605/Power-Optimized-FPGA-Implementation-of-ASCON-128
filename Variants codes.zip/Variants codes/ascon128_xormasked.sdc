#==============================================================================
# ASCON-128 · Variant: xormasked
# SDC for Cadence Genus Synthesis
# Architecture: XOR-masked storage: physical regs hold x_i XOR MASK_i; round on unmasked values; re-mask on write
# Fmax: 22 MHz/45 ns   Clocks: pa=12:13  pb=6:7
#==============================================================================
create_clock -period 45.000 -name sys_clk -waveform {0.000 22.5000} [get_ports clk_p]
set_clock_uncertainty -setup 0.200 [get_clocks sys_clk]
set_clock_uncertainty -hold  0.100 [get_clocks sys_clk]
set_clock_transition  -rise  0.100 [get_clocks sys_clk]
set_clock_transition  -fall  0.100 [get_clocks sys_clk]
set_input_delay  -clock sys_clk -max 1.000 [get_ports rst_n]
set_input_delay  -clock sys_clk -min 0.200 [get_ports rst_n]
set_input_delay  -clock sys_clk -max 1.000 [get_ports start]
set_input_delay  -clock sys_clk -min 0.200 [get_ports start]
set_output_delay -clock sys_clk -max 1.000 [get_ports done]
set_output_delay -clock sys_clk -min 0.200 [get_ports done]
set_output_delay -clock sys_clk -max 1.000 [get_ports tag_match]
set_output_delay -clock sys_clk -min 0.200 [get_ports tag_match]
set_output_delay -clock sys_clk -max 1.000 [get_ports led_done]
set_output_delay -clock sys_clk -min 0.200 [get_ports led_done]
set_output_delay -clock sys_clk -max 1.000 [get_ports led_tag_match]
set_output_delay -clock sys_clk -min 0.200 [get_ports led_tag_match]
set_output_delay -clock sys_clk -max 1.000 [get_ports led_running]
set_output_delay -clock sys_clk -min 0.200 [get_ports led_running]
set_output_delay -clock sys_clk -max 1.000 [get_ports led_error]
set_output_delay -clock sys_clk -min 0.200 [get_ports led_error]
set_false_path -from [get_ports rst_n]
set_driving_cell -lib_cell INVX1 -no_design_rule [get_ports {start rst_n}]
set_load 2.0 [get_ports {done tag_match led_done led_tag_match led_running led_error}]
#==============================================================================
# END - ascon128_xormasked.sdc
#==============================================================================
