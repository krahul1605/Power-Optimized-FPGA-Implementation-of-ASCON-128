#==============================================================================
# ASCON-128  ·  Variant: retimed
# SDC for Cadence Genus Synthesis
#
# Permutation architecture: Intra-Chi retimed pipeline.
#   A register cut-point is inserted inside the Chi substitution layer,
#   at the AND-NOT gate boundary. This creates a 4-stage asymmetric
#   pipeline per round with three distinct register banks:
#     x0..x4 : primary state (updated in STAGE_RC and STAGE_CL)
#     t0..t4 : post-theta intermediate (updated in STAGE_TH)
#     u0..u4 : AND-NOT intermediate — the retiming register bank
#              (updated in STAGE_AND, the unique structural feature)
#
# Stage-by-stage timing breakdown:
#
#   STAGE_RC  (rt_stage=0): x2_reg -> XOR(rc) -> x2_reg
#     Path depth: ~1 gate level. Estimated: ~1-2 ns.
#     Very large positive timing slack at 125 MHz.
#
#   STAGE_TH  (rt_stage=1): x*_reg -> XOR_tree(parities,3 levels) ->
#                            rotate XOR -> apply XOR -> t*_reg
#     Path depth: ~8-10 gate levels. Estimated: ~7-8 ns.
#     This is CLOSE TO THE CLOCK PERIOD — the theta bottleneck.
#
#   STAGE_AND (rt_stage=2): t*_reg -> AND-NOT -> u*_reg
#     Path depth: ~2 gate levels. Estimated: ~1-2 ns.
#     Very large positive timing slack.
#
#   STAGE_CL  (rt_stage=3): t*_reg + u*_reg -> XOR -> [INV for t2] ->
#                            ROT(rA) -> XOR -> ROT(rB) -> XOR -> x*_reg
#     Path depth: ~5-7 gate levels. Estimated: ~5-7 ns.
#     Moderate slack (2-3 ns at 125 MHz).
#
# The common clock period is sized by STAGE_TH (deepest stage).
# Fmax target: 125 MHz / 8 ns.
#
# Clocks per pa=12 call : 12 × 4 = 48 + 1 FINISH = 49
# Clocks per pb=6  call :  6 × 4 = 24 + 1 FINISH = 25
#
# Synthesis guidance:
#   The (* keep = "true" *) pragmas on t* and u* register declarations
#   prevent Genus from absorbing these banks into adjacent logic cones.
#   This is essential to preserve the retiming cut-point inside Chi.
#   If the tool ignores RTL attributes, use set_dont_merge on the
#   corresponding net names below.
#==============================================================================

#------------------------------------------------------------------------------
# 1. CLOCK DEFINITION
#    125 MHz / 8 ns — sized by STAGE_TH (Theta bottleneck)
#------------------------------------------------------------------------------
create_clock -period 8.000 \
             -name sys_clk \
             -waveform {0.000 4.000} \
             [get_ports clk_p]

#------------------------------------------------------------------------------
# 2. CLOCK UNCERTAINTY
#------------------------------------------------------------------------------
set_clock_uncertainty -setup 0.200 [get_clocks sys_clk]
set_clock_uncertainty -hold  0.100 [get_clocks sys_clk]

#------------------------------------------------------------------------------
# 3. CLOCK TRANSITION
#------------------------------------------------------------------------------
set_clock_transition -rise 0.100 [get_clocks sys_clk]
set_clock_transition -fall 0.100 [get_clocks sys_clk]

#------------------------------------------------------------------------------
# 4. INPUT DELAYS
#------------------------------------------------------------------------------
set_input_delay -clock sys_clk -max 2.000 [get_ports rst_n]
set_input_delay -clock sys_clk -min 0.500 [get_ports rst_n]
set_input_delay -clock sys_clk -max 2.000 [get_ports start]
set_input_delay -clock sys_clk -min 0.500 [get_ports start]

#------------------------------------------------------------------------------
# 5. OUTPUT DELAYS
#------------------------------------------------------------------------------
set_output_delay -clock sys_clk -max 2.000 [get_ports done]
set_output_delay -clock sys_clk -min 0.500 [get_ports done]
set_output_delay -clock sys_clk -max 2.000 [get_ports tag_match]
set_output_delay -clock sys_clk -min 0.500 [get_ports tag_match]
set_output_delay -clock sys_clk -max 2.000 [get_ports led_done]
set_output_delay -clock sys_clk -min 0.500 [get_ports led_done]
set_output_delay -clock sys_clk -max 2.000 [get_ports led_tag_match]
set_output_delay -clock sys_clk -min 0.500 [get_ports led_tag_match]
set_output_delay -clock sys_clk -max 2.000 [get_ports led_running]
set_output_delay -clock sys_clk -min 0.500 [get_ports led_running]
set_output_delay -clock sys_clk -max 2.000 [get_ports led_error]
set_output_delay -clock sys_clk -min 0.500 [get_ports led_error]

#------------------------------------------------------------------------------
# 6. ASYNCHRONOUS RESET - FALSE PATH
#------------------------------------------------------------------------------
set_false_path -from [get_ports rst_n]

#------------------------------------------------------------------------------
# 7. RETIMING REGISTER PRESERVATION
#    The u*_reg bank (AND-NOT intermediate) and t*_reg bank (post-theta)
#    are the retiming registers that must not be merged or optimized away.
#    Preserve them to maintain the intended structural cut points.
#------------------------------------------------------------------------------
# set_dont_touch [get_cells {t*_reg*}]
# set_dont_touch [get_cells {u*_reg*}]

#------------------------------------------------------------------------------
# 8. STAGE-SPECIFIC PATH BUDGETS (informational)
#    STAGE_TH  budget: 8.000 - 0.200 - 0.100 = 7.700 ns  (x* -> t*)
#    STAGE_CL  budget: 8.000 - 0.200 - 0.100 = 7.700 ns  (t*+u* -> x*)
#    STAGE_AND budget: 8.000 - 0.200 - 0.100 = 7.700 ns  (t* -> u*)
#    STAGE_RC  budget: 8.000 - 0.200 - 0.100 = 7.700 ns  (x2 -> x2)
#
#    Optional: constrain STAGE_CL's Chi-XOR+Linear fused path explicitly
#    to aid the tool in distributing effort between STAGE_TH and STAGE_CL:
#------------------------------------------------------------------------------
# set_max_delay 7.700 -from [get_cells {t*_reg* u*_reg*}] -to [get_cells {x*_reg*}]
# set_max_delay 7.700 -from [get_cells {x*_reg*}] -to [get_cells {t*_reg*}]

#------------------------------------------------------------------------------
# 9. DRIVING CELL / OUTPUT LOAD
#------------------------------------------------------------------------------
set_driving_cell -lib_cell INVX1 -no_design_rule [get_ports {start rst_n}]
set_load 5.0 [get_ports {done tag_match led_done led_tag_match led_running led_error}]

#------------------------------------------------------------------------------
# 10. OPERATING CONDITIONS (uncomment and set for target library)
#------------------------------------------------------------------------------
# set_operating_conditions -library <lib> TYPICAL

#==============================================================================
# END - ascon128_retimed.sdc
#==============================================================================
