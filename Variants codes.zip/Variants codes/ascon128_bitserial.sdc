#==============================================================================
# ASCON-128  ·  Variant: bitserial
# SDC for Cadence Genus Synthesis
#
# Permutation architecture: Bit-serial — the 5×64-bit ASCON state lives in
#   five 64-bit shift registers. One bit-position is processed per clock cycle
#   across all five lanes simultaneously. The combinational compute slice is
#   minimal: 5-bit constant inject, 5-bit THETA parity (with rotation taps),
#   5-bit CHI AND-NOT, and XOR back into the shift register MSB. No full-width
#   64-bit logic is active at any cycle — only 5 bits are computed per clock.
#
# Timing impact vs baseline:
#   - Critical path: 5-bit slice only (~3-5 XOR/AND levels + shift tap mux).
#     This is the shortest per-cycle combinational path of all variants.
#   - Clock period target: 5.000 ns (200 MHz) — enabled by the tiny slice.
#   - Multicycle paths: NOT applicable — single pipeline FF per shift step.
#   - Input/output delays: 2.0/0.5 ns; generous at 200 MHz (must be tightened
#     for board implementation, but adequate for synthesis closure).
#
# Throughput:
#   pa=12 call: 12 rounds × 64 bit-cycles = 768 cycles + 1 FINISH = 769 cycles
#   pb=6  call:  6 rounds × 64 bit-cycles = 384 cycles + 1 FINISH = 385 cycles
#   At 200 MHz: pa≈3.85 μs, pb≈1.93 μs per permutation call.
#
# Synthesis guidance for Genus:
#   - High effort allowed: critical path is trivially short, runtime is fast.
#   - Map shift registers explicitly to SRL16/SRL32 on FPGA, or scan-chain
#     registers on ASIC to minimize area.
#   - Rotation taps on the shift register are purely wiring (no logic gates).
#   - Do not retime across the shift register boundary (would corrupt serial order).
#==============================================================================

#------------------------------------------------------------------------------
# 1. CLOCK DEFINITION
#    200 MHz / 5 ns — bit-serial slice allows maximum Fmax
#------------------------------------------------------------------------------
create_clock -period 5.000 \
             -name sys_clk \
             -waveform {0.000 2.500} \
             [get_ports clk_p]

#------------------------------------------------------------------------------
# 2. CLOCK UNCERTAINTY
#    Tight jitter budget appropriate for 200 MHz; board-sourced LVDS.
#    ZCU104 board jitter spec ~50 ps at 200 MHz; use 0.150 ns setup margin.
#------------------------------------------------------------------------------
set_clock_uncertainty -setup 0.150 [get_clocks sys_clk]
set_clock_uncertainty -hold  0.100 [get_clocks sys_clk]

#------------------------------------------------------------------------------
# 3. CLOCK TRANSITION
#    Fast edge rate for 200 MHz LVDS clock input.
#------------------------------------------------------------------------------
set_clock_transition -rise 0.050 [get_clocks sys_clk]
set_clock_transition -fall 0.050 [get_clocks sys_clk]

#------------------------------------------------------------------------------
# 4. INPUT DELAYS
#    2.0 ns leaves 2.85 ns internal at 5 ns period — generous for the
#    tiny 5-bit slice path. Board delay budget allows this conservatively.
#------------------------------------------------------------------------------
set_input_delay -clock sys_clk -max 2.000 [get_ports rst_n]
set_input_delay -clock sys_clk -min 0.500 [get_ports rst_n]
set_input_delay -clock sys_clk -max 2.000 [get_ports start]
set_input_delay -clock sys_clk -min 0.500 [get_ports start]

#------------------------------------------------------------------------------
# 5. OUTPUT DELAYS
#------------------------------------------------------------------------------
set_output_delay -clock sys_clk -max 2.000 [get_ports done]
set_output_delay -clock sys_clk -min 0.500 [get_ports done]
set_output_delay -clock sys_clk -max 2.000 [get_ports tag_match]
set_output_delay -clock sys_clk -min 0.500 [get_ports tag_match]
set_output_delay -clock sys_clk -max 2.000 [get_ports led_done]
set_output_delay -clock sys_clk -min 0.500 [get_ports led_done]
set_output_delay -clock sys_clk -max 2.000 [get_ports led_tag_match]
set_output_delay -clock sys_clk -min 0.500 [get_ports led_tag_match]
set_output_delay -clock sys_clk -max 2.000 [get_ports led_running]
set_output_delay -clock sys_clk -min 0.500 [get_ports led_running]
set_output_delay -clock sys_clk -max 2.000 [get_ports led_error]
set_output_delay -clock sys_clk -min 0.500 [get_ports led_error]

#------------------------------------------------------------------------------
# 6. ASYNCHRONOUS RESET — FALSE PATH
#------------------------------------------------------------------------------
set_false_path -from [get_ports rst_n]

#------------------------------------------------------------------------------
# 7. CRITICAL PATH BUDGET
#    The bit-serial slice per cycle:
#      Constant inject (1 XOR, conditional on bit_cnt<8) → THETA parity (5-in
#      XOR tree, ~3 levels) → CHI AND-NOT + XOR (2 levels) → MSB write.
#    Estimated gate depth: ~6-8 levels total (~1.5-2.0 ns in typical library).
#    Budget: 5.000 - 0.150 (unc) - 0.050 (trans) = 4.800 ns available.
#    Comfortable margin — 200 MHz is achievable even at slow process corner.
#
#    Rotation taps: implemented as fixed wire connections into the shift
#    register array (not computed each cycle). These are false paths from the
#    shift register read-back if synthesis identifies them as new logic paths.
#    Cap them explicitly if needed:
#------------------------------------------------------------------------------
# set_max_delay 4.800 -from [get_cells {sr*_reg*}] -to [get_cells {sr*_reg*}]

#------------------------------------------------------------------------------
# 8. SHIFT REGISTER INFERENCE GUIDANCE
#    Instruct Genus to infer shift registers (SRL on FPGA, scanchain on ASIC).
#    This avoids unrolling the 64-deep shifts into individual FF chains which
#    would explode register count and degrade placement quality.
#    Uncomment the appropriate technology attribute:
#------------------------------------------------------------------------------
# set_attribute use_srl_for_reg true [get_db designs ascon_perm_bitserial]

#------------------------------------------------------------------------------
# 9. MULTICYCLE PATHS (NONE)
#    All paths are single-cycle. No multicycle constraints required.
#    The shift register operates every clock cycle; bit_cnt is updated every
#    cycle; the LFSR-equivalent constant inject fires once every 8 cycles but
#    the path itself is gated combinationally (no multi-cycle timing relaxation).
#------------------------------------------------------------------------------

#------------------------------------------------------------------------------
# 10. DRIVING CELL / OUTPUT LOAD
#------------------------------------------------------------------------------
set_driving_cell -lib_cell INVX1 -no_design_rule [get_ports {start rst_n}]
set_load 5.0 [get_ports {done tag_match led_done led_tag_match led_running led_error}]

#------------------------------------------------------------------------------
# 11. OPERATING CONDITIONS
#      Synthesis at typical corner; sign-off at slow for 200 MHz target.
#      Uncomment and set library condition as appropriate.
#------------------------------------------------------------------------------
# set_operating_conditions -library <lib> TYPICAL

#==============================================================================
# END - ascon128_bitserial.sdc
#==============================================================================
