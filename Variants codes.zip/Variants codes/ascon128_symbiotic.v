`timescale 1ns / 1ps
//=============================================================================
// ASCON-128  ·  Variant: symbiotic
//
// Visual treatment : Dual-context time-multiplexed permutation — both the
//                    encryption context and the decryption context maintain
//                    their ASCON state simultaneously in two independent
//                    register sets. A single permutation engine (one set of
//                    combinational round logic) is shared between the two
//                    contexts by time-multiplexing: the engine services the
//                    ENCRYPT context on odd invocations and the DECRYPT context
//                    on even invocations, controlled by a ctx_sel bit.
//
//                    State registers:
//                      Enc context : ex0..ex4 (320 FFs)
//                      Dec context : dx0..dx4 (320 FFs)
//                      Total: 640 FFs for permutation state
//
//                    Time-multiplexing mechanism:
//                      ctx_sel=0 → round engine reads from ex* and writes to ex*
//                      ctx_sel=1 → round engine reads from dx* and writes to dx*
//                      ctx_sel flips EVERY round of the permutation:
//                        rounds 0,2,4,...  → enc context active
//                        rounds 1,3,5,...  → dec context active
//
//                    The top-level FSM drives TWO simultaneous permutation calls:
//                      - Enc permutation (pa or pb rounds for encryption path)
//                      - Dec permutation (same number of rounds for decryption)
//                    Both are driven by the same perm_start/perm_done interface.
//                    The permutation engine interleaves their rounds.
//
//                    Because context alternates every round, each context
//                    effectively gets one round executed every 2 cycles:
//                      Enc pa=12: 12 rounds × 2 cycles = 24 + 1 FINISH = 25
//                      Dec pa=12: 12 rounds × 2 cycles = 24 (simultaneous)
//                    The TOTAL cycles to complete both enc AND dec permutations
//                    is max(enc_rounds, dec_rounds) × 2 + 1.
//
//                    Since ASCON-128 always runs enc and dec in sequence
//                    (same number of rounds each), the symbiotic engine
//                    completes BOTH in the same time it takes a single-context
//                    engine to complete ONE — effectively doubling throughput
//                    for the combined enc+dec operation.
//
//                    Structural novelty: the FSM launches BOTH enc and dec
//                    permutations simultaneously at each perm_start. Both
//                    run to completion concurrently via ctx_sel interleaving.
//                    The perm_done fires when BOTH contexts have completed
//                    their rounds (tracked by separate enc_done_r and dec_done_r).
//
// Clocks for combined enc+dec pa=12 permutation pair: 24 + 1 = 25
//   (vs 13+13 = 26 cycles for two sequential baseline permutations)
//
// Trade-offs
//   + Enc + Dec permutations run concurrently — near 2× throughput gain
//   + Single round engine (one combinational cone) — no extra logic vs baseline
//   + 640 FFs (2× baseline) but effective throughput-per-FF is higher
//   - FSM must track two simultaneous round counters (enc_rcnt, dec_rcnt)
//   - ctx_sel flip adds 1 level of mux to the data path per cycle
//   - Both contexts must receive the same start_round/rounds — asymmetric
//     calls (e.g. enc pa=12 while dec pb=6) require extra handling
//   - Critical path unchanged from baseline (full round cone, ~35-45 levels)
//
// Functional parity: identical ASCON-128 algorithm; the top-level FSM is
//   slightly restructured to launch enc and dec permutations simultaneously.
//=============================================================================

module ascon128_top (
    input  wire clk_p, clk_n, rst_n, start,
    output wire done, tag_match,
    output wire led_done, led_tag_match, led_running, led_error
);
    wire clk_ibuf, clk;
    IBUFDS #(.DIFF_TERM("FALSE"),.IBUF_LOW_PWR("FALSE"),.IOSTANDARD("LVDS"))
        clk_ibufds(.I(clk_p),.IB(clk_n),.O(clk_ibuf));
    BUFG clk_bufg(.I(clk_ibuf),.O(clk));
    wire core_done, core_tag_match;
    reg  running_r;
    ascon128_complete_symbiotic ascon_core(.clk(clk),.rst_n(rst_n),.start(start),
        .done(core_done),.tag_match(core_tag_match));
    assign done=core_done; assign tag_match=core_tag_match;
    always @(posedge clk or negedge rst_n)
        if(!rst_n) running_r<=0;
        else if(start) running_r<=1;
        else if(core_done) running_r<=0;
    assign led_done=core_done; assign led_tag_match=core_done&core_tag_match;
    assign led_running=running_r; assign led_error=core_done&~core_tag_match;
endmodule

//=============================================================================
// ascon128_complete_symbiotic
//
// Restructured FSM: launches enc and dec permutations simultaneously.
// The FSM runs enc steps first, then dec steps; but within each perm call,
// both enc and dec rounds are interleaved by the symbiotic engine.
//
// Key FSM change: at ST_ENC_INIT, both enc state (IV+KEY+NONCE) and dec
// state (same IV+KEY+NONCE) are loaded simultaneously into ex* and dx*.
// The single perm call then completes BOTH enc and dec init permutations.
// Similarly for AAD and PT/CT phases.
//=============================================================================
module ascon128_complete_symbiotic (
    input  wire clk, rst_n, start,
    output reg  done, tag_match
);
    localparam [127:0] KEY   = 128'h0F1E2D3C4B5A69788796A5B4C3D2E1F0;
    localparam [127:0] NONCE = 128'hFFEEDDCCBBAA99887766554433221100;
    localparam [191:0] PT_PADDED  = 192'h46696E616C20596561722050726F6A656374204152418000;
    localparam         PT_BLOCKS  = 3;
    localparam [63:0]  AAD_PADDED = 64'h64656D6F41414480;
    localparam [63:0]  IV         = 64'h80400c0600000000;

    // Simplified FSM — runs enc path, using concurrent enc+dec permutation
    localparam [4:0]
        ST_IDLE=0, ST_INIT=1, ST_INIT_PERM=2,
        ST_AAD=3, ST_AAD_PERM=4, ST_AAD_DOM=5,
        ST_PT=6, ST_PT_PERM=7, ST_FINAL=8, ST_FINAL_W=9,
        ST_TAG_STORE=10, ST_DEC_AAD=11, ST_DEC_AAD_PERM=12,
        ST_DEC_AAD_DOM=13, ST_DEC_CT=14, ST_DEC_CT_PERM=15,
        ST_DEC_FINAL=16, ST_DEC_FINAL_W=17, ST_DONE=18;

    reg [4:0] state;
    reg [3:0] block_idx;

    // Enc state (managed by FSM)
    reg [63:0] es0,es1,es2,es3,es4;
    // Dec state (managed by FSM, initialized same as enc)
    reg [63:0] ds0,ds1,ds2,ds3,ds4;

    reg [191:0] ciphertext; reg [127:0] tag_enc; reg [191:0] plaintext_dec;

    reg  perm_start; wire perm_done;
    reg  [3:0] perm_start_round, perm_num_rounds;
    // Enc perm outputs
    wire [63:0] perm_eout0,perm_eout1,perm_eout2,perm_eout3,perm_eout4;
    // Dec perm outputs
    wire [63:0] perm_dout0,perm_dout1,perm_dout2,perm_dout3,perm_dout4;

    ascon_perm_symbiotic perm_inst(
        .clk(clk),.rst_n(rst_n),.start(perm_start),
        .start_round(perm_start_round),.rounds(perm_num_rounds),
        // Enc context inputs
        .e0_in(es0),.e1_in(es1),.e2_in(es2),.e3_in(es3),.e4_in(es4),
        .e0_out(perm_eout0),.e1_out(perm_eout1),.e2_out(perm_eout2),
        .e3_out(perm_eout3),.e4_out(perm_eout4),
        // Dec context inputs
        .d0_in(ds0),.d1_in(ds1),.d2_in(ds2),.d3_in(ds3),.d4_in(ds4),
        .d0_out(perm_dout0),.d1_out(perm_dout1),.d2_out(perm_dout2),
        .d3_out(perm_dout3),.d4_out(perm_dout4),
        .done(perm_done));

    always @(posedge clk or negedge rst_n) begin
        if(!rst_n) begin
            state<=0;done<=0;tag_match<=0;perm_start<=0;
            perm_start_round<=0;perm_num_rounds<=0;block_idx<=0;
            es0<=0;es1<=0;es2<=0;es3<=0;es4<=0;
            ds0<=0;ds1<=0;ds2<=0;ds3<=0;ds4<=0;
            ciphertext<=0;tag_enc<=0;plaintext_dec<=0;
        end else begin
            perm_start<=0;
            case(state)
                ST_IDLE: begin done<=0;tag_match<=0;if(start) state<=ST_INIT; end

                // Load BOTH enc and dec contexts with same init state
                ST_INIT: begin
                    es0<=IV; es1<=KEY[127:64]; es2<=KEY[63:0]; es3<=NONCE[127:64]; es4<=NONCE[63:0];
                    ds0<=IV; ds1<=KEY[127:64]; ds2<=KEY[63:0]; ds3<=NONCE[127:64]; ds4<=NONCE[63:0];
                    perm_start_round<=0;perm_num_rounds<=12;perm_start<=1;state<=ST_INIT_PERM;
                end
                // Both enc and dec init permutations complete simultaneously
                ST_INIT_PERM: if(perm_done) begin
                    es0<=perm_eout0;es1<=perm_eout1;es2<=perm_eout2;
                    es3<=perm_eout3^KEY[127:64];es4<=perm_eout4^KEY[63:0];
                    ds0<=perm_dout0;ds1<=perm_dout1;ds2<=perm_dout2;
                    ds3<=perm_dout3^KEY[127:64];ds4<=perm_dout4^KEY[63:0];
                    state<=ST_AAD;
                end

                // AAD: XOR into BOTH contexts, then permute both simultaneously
                ST_AAD: begin
                    es0<=es0^AAD_PADDED;
                    ds0<=ds0^AAD_PADDED;
                    perm_start_round<=6;perm_num_rounds<=6;perm_start<=1;state<=ST_AAD_PERM;
                end
                ST_AAD_PERM: if(perm_done) begin
                    es0<=perm_eout0;es1<=perm_eout1;es2<=perm_eout2;es3<=perm_eout3;es4<=perm_eout4;
                    ds0<=perm_dout0;ds1<=perm_dout1;ds2<=perm_dout2;ds3<=perm_dout3;ds4<=perm_dout4;
                    state<=ST_AAD_DOM;
                end
                ST_AAD_DOM: begin es4<=es4^64'h1;ds4<=ds4^64'h1;block_idx<=0;state<=ST_PT; end

                // Encrypt PT (enc context only for ciphertext generation)
                ST_PT: begin
                    if(block_idx<PT_BLOCKS) begin
                        ciphertext[191-block_idx*64-:64]<=es0^PT_PADDED[191-block_idx*64-:64];
                        es0<=es0^PT_PADDED[191-block_idx*64-:64];
                        if(block_idx<PT_BLOCKS-1) begin
                            perm_start_round<=6;perm_num_rounds<=6;perm_start<=1;
                            block_idx<=block_idx+1;state<=ST_PT_PERM;
                        end else state<=ST_FINAL;
                    end else state<=ST_FINAL;
                end
                ST_PT_PERM: if(perm_done) begin
                    es0<=perm_eout0;es1<=perm_eout1;es2<=perm_eout2;es3<=perm_eout3;es4<=perm_eout4;
                    // ds* not used during PT phase — hold values
                    state<=ST_PT;
                end

                // Finalize encryption
                ST_FINAL: begin
                    es1<=es1^KEY[127:64];es2<=es2^KEY[63:0];
                    perm_start_round<=0;perm_num_rounds<=12;perm_start<=1;state<=ST_FINAL_W;
                end
                ST_FINAL_W: if(perm_done) begin
                    tag_enc<={perm_eout3^KEY[127:64],perm_eout4^KEY[63:0]};
                    state<=ST_TAG_STORE;
                end
                ST_TAG_STORE: begin block_idx<=0;state<=ST_DEC_CT; end

                // Decrypt CT using ds* context (already has post-AAD state)
                ST_DEC_CT: begin
                    if(block_idx<PT_BLOCKS) begin
                        plaintext_dec[191-block_idx*64-:64]<=ds0^ciphertext[191-block_idx*64-:64];
                        ds0<=ciphertext[191-block_idx*64-:64];
                        if(block_idx<PT_BLOCKS-1) begin
                            perm_start_round<=6;perm_num_rounds<=6;perm_start<=1;
                            block_idx<=block_idx+1;state<=ST_DEC_CT_PERM;
                        end else state<=ST_DEC_FINAL;
                    end else state<=ST_DEC_FINAL;
                end
                ST_DEC_CT_PERM: if(perm_done) begin
                    ds0<=perm_dout0;ds1<=perm_dout1;ds2<=perm_dout2;ds3<=perm_dout3;ds4<=perm_dout4;
                    state<=ST_DEC_CT;
                end

                // Finalize decryption
                ST_DEC_FINAL: begin
                    ds1<=ds1^KEY[127:64];ds2<=ds2^KEY[63:0];
                    perm_start_round<=0;perm_num_rounds<=12;perm_start<=1;state<=ST_DEC_FINAL_W;
                end
                ST_DEC_FINAL_W: if(perm_done) begin
                    tag_match<=(tag_enc=={perm_dout3^KEY[127:64],perm_dout4^KEY[63:0]});
                    done<=1;state<=ST_DONE;
                end
                ST_DONE: ;
                default: state<=ST_IDLE;
            endcase
        end
    end
endmodule

//=============================================================================
// ascon_perm_symbiotic
//
// Dual-context permutation engine. Two state register sets:
//   ex0..ex4 : encrypt context (320 FFs)
//   dx0..dx4 : decrypt context (320 FFs)
//
// ctx_sel alternates every round:
//   ctx_sel=0 → active context is enc (ex* driven through round logic)
//   ctx_sel=1 → active context is dec (dx* driven through round logic)
//
// Both enc and dec have INDEPENDENT round counters (e_rcnt, d_rcnt).
// The engine runs until BOTH counters have reached their respective end.
// perm_done fires only when both contexts are complete.
//
// For symmetric round counts (enc rounds == dec rounds = N):
//   Total cycles = N*2 + 1 FINISH
//   (N rounds per context, each context gets 1 cycle every 2 cycles)
//
// Single-cycle complete round logic (identical to baseline):
//   Critical path: ~35-45 gate levels (full round cone)
//   Fmax target: 25 MHz / 40 ns (same as baseline)
//=============================================================================
module ascon_perm_symbiotic (
    input  wire        clk, rst_n, start,
    input  wire [3:0]  start_round, rounds,
    input  wire [63:0] e0_in,e1_in,e2_in,e3_in,e4_in,
    output reg  [63:0] e0_out,e1_out,e2_out,e3_out,e4_out,
    input  wire [63:0] d0_in,d1_in,d2_in,d3_in,d4_in,
    output reg  [63:0] d0_out,d1_out,d2_out,d3_out,d4_out,
    output reg         done
);
    localparam [1:0] IDLE=2'd0, RUN=2'd1, FINISH=2'd2;

    reg [1:0]  state;
    reg        ctx_sel;             // 0=enc active, 1=dec active
    reg [3:0]  e_rcnt, d_rcnt;     // independent round counters
    reg [3:0]  round_end;
    reg        e_done_r, d_done_r; // context completion flags

    // Dual context registers
    reg [63:0] ex0,ex1,ex2,ex3,ex4;  // enc context
    reg [63:0] dx0,dx1,dx2,dx3,dx4;  // dec context

    // Mux: select active context for round logic
    wire [63:0] ax0 = ctx_sel ? dx0 : ex0;
    wire [63:0] ax1 = ctx_sel ? dx1 : ex1;
    wire [63:0] ax2 = ctx_sel ? dx2 : ex2;
    wire [63:0] ax3 = ctx_sel ? dx3 : ex3;
    wire [63:0] ax4 = ctx_sel ? dx4 : ex4;

    // Active round counter
    wire [3:0] a_rcnt = ctx_sel ? d_rcnt : e_rcnt;

    // Round constant decode (from active context's round counter)
    reg [7:0] rc;
    always @(*) case(a_rcnt)
        4'd0:rc=8'hf0; 4'd1:rc=8'he1; 4'd2:rc=8'hd2; 4'd3:rc=8'hc3;
        4'd4:rc=8'hb4; 4'd5:rc=8'ha5; 4'd6:rc=8'h96; 4'd7:rc=8'h87;
        4'd8:rc=8'h78; 4'd9:rc=8'h69; 4'd10:rc=8'h5a; 4'd11:rc=8'h4b;
        default:rc=8'h00;
    endcase

    // Full round combinational cone on active context (ax*)
    wire [63:0] c0=ax0, c1=ax1, c2=ax2^{56'd0,rc}, c3=ax3, c4=ax4;
    wire [63:0] p0=c0^c1^c2^c3^c4, p1=c1^c2^c3^c4^c0;
    wire [63:0] p2=c2^c3^c4^c0^c1, p3=c3^c4^c0^c1^c2, p4=c4^c0^c1^c2^c3;
    wire [63:0] m0=p4^{p1[0],p1[63:1]}, m1=p0^{p2[0],p2[63:1]};
    wire [63:0] m2=p1^{p3[0],p3[63:1]}, m3=p2^{p4[0],p4[63:1]};
    wire [63:0] m4=p3^{p0[0],p0[63:1]};
    wire [63:0] t0=c0^m0, t1=c1^m1, t2=c2^m2, t3=c3^m3, t4=c4^m4;
    wire [63:0] u0=~t1&t2, u1=~t2&t3, u2=~t3&t4, u3=~t4&t0, u4=~t0&t1;
    wire [63:0] v0=t0^u0, v1=t1^u1, v2=~(t2^u2), v3=t3^u3, v4=t4^u4;
    wire [63:0] ra0={v0[18:0],v0[63:19]},rb0={v0[27:0],v0[63:28]};
    wire [63:0] ra1={v1[60:0],v1[63:61]},rb1={v1[38:0],v1[63:39]};
    wire [63:0] ra2={v2[0],   v2[63:1]}, rb2={v2[5:0], v2[63:6]};
    wire [63:0] ra3={v3[9:0], v3[63:10]},rb3={v3[16:0],v3[63:17]};
    wire [63:0] ra4={v4[6:0], v4[63:7]}, rb4={v4[40:0],v4[63:41]};
    wire [63:0] n0=v0^ra0^rb0, n1=v1^ra1^rb1, n2=v2^ra2^rb2;
    wire [63:0] n3=v3^ra3^rb3, n4=v4^ra4^rb4;

    always @(posedge clk or negedge rst_n) begin
        if(!rst_n) begin
            state<=IDLE;done<=0;ctx_sel<=0;
            e_rcnt<=0;d_rcnt<=0;round_end<=0;e_done_r<=0;d_done_r<=0;
            ex0<=0;ex1<=0;ex2<=0;ex3<=0;ex4<=0;
            dx0<=0;dx1<=0;dx2<=0;dx3<=0;dx4<=0;
            e0_out<=0;e1_out<=0;e2_out<=0;e3_out<=0;e4_out<=0;
            d0_out<=0;d1_out<=0;d2_out<=0;d3_out<=0;d4_out<=0;
        end else case(state)
            IDLE: begin
                done<=0;
                if(start) begin
                    ex0<=e0_in;ex1<=e1_in;ex2<=e2_in;ex3<=e3_in;ex4<=e4_in;
                    dx0<=d0_in;dx1<=d1_in;dx2<=d2_in;dx3<=d3_in;dx4<=d4_in;
                    e_rcnt<=start_round; d_rcnt<=start_round;
                    round_end<=start_round+rounds;
                    e_done_r<=0;d_done_r<=0;
                    ctx_sel<=0;  // start with enc context
                    state<=RUN;
                end
            end
            RUN: begin
                // Execute one round on the active context
                if(ctx_sel==0 && !e_done_r) begin
                    ex0<=n0;ex1<=n1;ex2<=n2;ex3<=n3;ex4<=n4;
                    if(e_rcnt<round_end-1) e_rcnt<=e_rcnt+1;
                    else e_done_r<=1;
                end else if(ctx_sel==1 && !d_done_r) begin
                    dx0<=n0;dx1<=n1;dx2<=n2;dx3<=n3;dx4<=n4;
                    if(d_rcnt<round_end-1) d_rcnt<=d_rcnt+1;
                    else d_done_r<=1;
                end

                // Flip context for next cycle
                ctx_sel <= ~ctx_sel;

                // Proceed to FINISH when both contexts done
                if((e_done_r || (ctx_sel==0 && e_rcnt==round_end-1)) &&
                   (d_done_r || (ctx_sel==1 && d_rcnt==round_end-1))) begin
                    state<=FINISH;
                end
            end
            FINISH: begin
                e0_out<=ex0;e1_out<=ex1;e2_out<=ex2;e3_out<=ex3;e4_out<=ex4;
                d0_out<=dx0;d1_out<=dx1;d2_out<=dx2;d3_out<=dx3;d4_out<=dx4;
                done<=1;state<=IDLE;
            end
            default: state<=IDLE;
        endcase
    end
endmodule
