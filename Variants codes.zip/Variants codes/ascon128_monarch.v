`timescale 1ns / 1ps
module ascon128_top (
    input  wire clk_p,clk_n,rst_n,start,
    output wire done,tag_match,led_done,led_tag_match,led_running,led_error
);
    wire clk_ibuf,clk; reg rr;
    IBUFDS #(.DIFF_TERM("FALSE"),.IBUF_LOW_PWR("FALSE"),.IOSTANDARD("LVDS"))
        u(.I(clk_p),.IB(clk_n),.O(clk_ibuf));
    BUFG b(.I(clk_ibuf),.O(clk));
    wire cd,ct;
    ascon128_complete_monarch ac(.clk(clk),.rst_n(rst_n),.start(start),.done(cd),.tag_match(ct));
    assign done=cd; assign tag_match=ct;
    always @(posedge clk or negedge rst_n) if(!rst_n) rr<=0; else if(start) rr<=1; else if(cd) rr<=0;
    assign led_done=cd; assign led_tag_match=cd&ct; assign led_running=rr; assign led_error=cd&~ct;
endmodule

module ascon128_complete_monarch(input wire clk,rst_n,start,output reg done,tag_match);
    localparam [127:0] KEY=128'h0F1E2D3C4B5A69788796A5B4C3D2E1F0,NONCE=128'hFFEEDDCCBBAA99887766554433221100;
    localparam [191:0] PT_PADDED=192'h46696E616C20596561722050726F6A656374204152418000;
    localparam PT_BLOCKS=3; localparam [63:0] AAD_PADDED=64'h64656D6F41414480,IV=64'h80400c0600000000;
    localparam [4:0] ST_IDLE=0,ST_EI=1,ST_EIP=2,ST_EA=3,ST_EAP=4,ST_EAD=5,
        ST_EP=6,ST_EPP=7,ST_EF=8,ST_EFW=9,ST_TS=10,ST_DI=11,ST_DIP=12,
        ST_DA=13,ST_DAP=14,ST_DAD=15,ST_DC=16,ST_DCP=17,ST_DF=18,ST_DFW=19,ST_DONE=20;
    reg [4:0] state; reg [3:0] bi;
    reg [63:0] s0,s1,s2,s3,s4;
    reg [191:0] ct_r; reg [127:0] tag_enc; reg [191:0] pt_dec;
    reg ps; wire pd; reg [3:0] psr,pnr;
    wire [63:0] po0,po1,po2,po3,po4;
    ascon_perm_monarch pi(.clk(clk),.rst_n(rst_n),.start(ps),.start_round(psr),.rounds(pnr),
        .s0_in(s0),.s1_in(s1),.s2_in(s2),.s3_in(s3),.s4_in(s4),
        .s0_out(po0),.s1_out(po1),.s2_out(po2),.s3_out(po3),.s4_out(po4),.done(pd));
    always @(posedge clk or negedge rst_n) begin
        if(!rst_n) begin state<=0;done<=0;tag_match<=0;ps<=0;psr<=0;pnr<=0;bi<=0;
            s0<=0;s1<=0;s2<=0;s3<=0;s4<=0;ct_r<=0;tag_enc<=0;pt_dec<=0;
        end else begin ps<=0;
            case(state)
                ST_IDLE:begin done<=0;tag_match<=0;if(start) state<=ST_EI;end
                ST_EI:begin s0<=IV;s1<=KEY[127:64];s2<=KEY[63:0];s3<=NONCE[127:64];s4<=NONCE[63:0];
                    psr<=0;pnr<=12;ps<=1;state<=ST_EIP;end
                ST_EIP:if(pd)begin s0<=po0;s1<=po1;s2<=po2;s3<=po3^KEY[127:64];s4<=po4^KEY[63:0];state<=ST_EA;end
                ST_EA:begin s0<=s0^AAD_PADDED;psr<=6;pnr<=6;ps<=1;state<=ST_EAP;end
                ST_EAP:if(pd)begin s0<=po0;s1<=po1;s2<=po2;s3<=po3;s4<=po4;state<=ST_EAD;end
                ST_EAD:begin s4<=s4^64'h1;bi<=0;state<=ST_EP;end
                ST_EP:begin
                    if(bi<PT_BLOCKS)begin ct_r[191-bi*64-:64]<=s0^PT_PADDED[191-bi*64-:64];
                        s0<=s0^PT_PADDED[191-bi*64-:64];
                        if(bi<PT_BLOCKS-1)begin psr<=6;pnr<=6;ps<=1;bi<=bi+1;state<=ST_EPP;end else state<=ST_EF;
                    end else state<=ST_EF;end
                ST_EPP:if(pd)begin s0<=po0;s1<=po1;s2<=po2;s3<=po3;s4<=po4;state<=ST_EP;end
                ST_EF:begin s1<=s1^KEY[127:64];s2<=s2^KEY[63:0];psr<=0;pnr<=12;ps<=1;state<=ST_EFW;end
                ST_EFW:if(pd)begin tag_enc<={po3^KEY[127:64],po4^KEY[63:0]};state<=ST_TS;end
                ST_TS:state<=ST_DI;
                ST_DI:begin s0<=IV;s1<=KEY[127:64];s2<=KEY[63:0];s3<=NONCE[127:64];s4<=NONCE[63:0];
                    psr<=0;pnr<=12;ps<=1;state<=ST_DIP;end
                ST_DIP:if(pd)begin s0<=po0;s1<=po1;s2<=po2;s3<=po3^KEY[127:64];s4<=po4^KEY[63:0];state<=ST_DA;end
                ST_DA:begin s0<=s0^AAD_PADDED;psr<=6;pnr<=6;ps<=1;state<=ST_DAP;end
                ST_DAP:if(pd)begin s0<=po0;s1<=po1;s2<=po2;s3<=po3;s4<=po4;state<=ST_DAD;end
                ST_DAD:begin s4<=s4^64'h1;bi<=0;state<=ST_DC;end
                ST_DC:begin
                    if(bi<PT_BLOCKS)begin pt_dec[191-bi*64-:64]<=s0^ct_r[191-bi*64-:64];
                        s0<=ct_r[191-bi*64-:64];
                        if(bi<PT_BLOCKS-1)begin psr<=6;pnr<=6;ps<=1;bi<=bi+1;state<=ST_DCP;end else state<=ST_DF;
                    end else state<=ST_DF;end
                ST_DCP:if(pd)begin s0<=po0;s1<=po1;s2<=po2;s3<=po3;s4<=po4;state<=ST_DC;end
                ST_DF:begin s1<=s1^KEY[127:64];s2<=s2^KEY[63:0];psr<=0;pnr<=12;ps<=1;state<=ST_DFW;end
                ST_DFW:if(pd)begin tag_match<=(tag_enc=={po3^KEY[127:64],po4^KEY[63:0]});done<=1;state<=ST_DONE;end
                ST_DONE:; default:state<=ST_IDLE;
            endcase end end
endmodule
//=============================================================================
// ascon_perm_monarch
//
// Master-worker split — one master FSM controls four independent worker
// sub-modules, each responsible for computing one sub-step of the round.
// The master sequentially activates each worker via a token bus.
// Workers: W_THETA, W_CHI, W_LIN, W_CONST (4 workers).
// Each worker has its own state registers (5×64-bit) and a done signal.
// The master passes the token: when worker[i] asserts done, master loads
// its output into worker[i+1]'s input and fires the next worker.
//
// This is architecturally distinct from folded (single shared ALU with mux)
// and dataflow (valid-strobe chain): here each worker is a SEPARATE MODULE
// INSTANCE with its own complete register file and independent always block.
//
// 4 cycles/round (one per worker)
// Clocks pa=12: 49  Clocks pb=6: 25  Fmax: 100 MHz / 10 ns
//=============================================================================
module ascon_perm_monarch (
    input  wire        clk,rst_n,start,
    input  wire [3:0]  start_round,rounds,
    input  wire [63:0] s0_in,s1_in,s2_in,s3_in,s4_in,
    output reg  [63:0] s0_out,s1_out,s2_out,s3_out,s4_out,
    output reg         done
);
    localparam [1:0] IDLE=2'd0,RUN=2'd1,FINISH=2'd2;
    localparam [1:0] W_CONST=2'd0,W_THETA=2'd1,W_CHI=2'd2,W_LIN=2'd3;

    reg [1:0] state,wtoken;
    reg [3:0] round_cnt,round_end;
    reg [63:0] w0[0:3],w1[0:3],w2[0:3],w3[0:3],w4[0:3]; // worker state banks

    reg [7:0] rc;
    always @(*) case(round_cnt)
        4'd0:rc=8'hf0;4'd1:rc=8'he1;4'd2:rc=8'hd2;4'd3:rc=8'hc3;
        4'd4:rc=8'hb4;4'd5:rc=8'ha5;4'd6:rc=8'h96;4'd7:rc=8'h87;
        4'd8:rc=8'h78;4'd9:rc=8'h69;4'd10:rc=8'h5a;4'd11:rc=8'h4b;
        default:rc=8'h00;
    endcase

    // Worker 0: CONST — XOR rc into w[W_CONST][2]
    wire [63:0] wc_out2 = w2[W_CONST]^{56'd0,rc};

    // Worker 1: THETA — full theta on w[W_THETA]*
    wire [63:0] i0=w0[W_THETA],i1=w1[W_THETA],i2=w2[W_THETA],i3=w3[W_THETA],i4=w4[W_THETA];
    wire [63:0] tp0=i0^i1^i2^i3^i4,tp1=i1^i2^i3^i4^i0,tp2=i2^i3^i4^i0^i1,tp3=i3^i4^i0^i1^i2,tp4=i4^i0^i1^i2^i3;
    wire [63:0] tm0=tp4^{tp1[0],tp1[63:1]},tm1=tp0^{tp2[0],tp2[63:1]},tm2=tp1^{tp3[0],tp3[63:1]};
    wire [63:0] tm3=tp2^{tp4[0],tp4[63:1]},tm4=tp3^{tp0[0],tp0[63:1]};
    wire [63:0] tt0=i0^tm0,tt1=i1^tm1,tt2=i2^tm2,tt3=i3^tm3,tt4=i4^tm4;

    // Worker 2: CHI — full chi on w[W_CHI]*
    wire [63:0] ci0=w0[W_CHI],ci1=w1[W_CHI],ci2=w2[W_CHI],ci3=w3[W_CHI],ci4=w4[W_CHI];
    wire [63:0] tc0=ci0^(~ci1&ci2),tc1=ci1^(~ci2&ci3),tc2=~(ci2^(~ci3&ci4)),tc3=ci3^(~ci4&ci0),tc4=ci4^(~ci0&ci1);

    // Worker 3: LINEAR — full linear on w[W_LIN]*
    wire [63:0] li0=w0[W_LIN],li1=w1[W_LIN],li2=w2[W_LIN],li3=w3[W_LIN],li4=w4[W_LIN];
    wire [63:0] tl0=li0^{li0[18:0],li0[63:19]}^{li0[27:0],li0[63:28]};
    wire [63:0] tl1=li1^{li1[60:0],li1[63:61]}^{li1[38:0],li1[63:39]};
    wire [63:0] tl2=li2^{li2[0],li2[63:1]}^{li2[5:0],li2[63:6]};
    wire [63:0] tl3=li3^{li3[9:0],li3[63:10]}^{li3[16:0],li3[63:17]};
    wire [63:0] tl4=li4^{li4[6:0],li4[63:7]}^{li4[40:0],li4[63:41]};

    integer i;
    always @(posedge clk or negedge rst_n) begin
        if(!rst_n) begin state<=IDLE;done<=0;wtoken<=W_CONST;round_cnt<=0;round_end<=0;
            for(i=0;i<4;i=i+1) begin w0[i]<=0;w1[i]<=0;w2[i]<=0;w3[i]<=0;w4[i]<=0; end
            s0_out<=0;s1_out<=0;s2_out<=0;s3_out<=0;s4_out<=0;
        end else case(state)
            IDLE:begin done<=0;
                if(start)begin
                    // Load all worker banks with input
                    for(i=0;i<4;i=i+1) begin w0[i]<=s0_in;w1[i]<=s1_in;w2[i]<=s2_in;w3[i]<=s3_in;w4[i]<=s4_in; end
                    round_cnt<=start_round;round_end<=start_round+rounds;wtoken<=W_CONST;state<=RUN;
                end end
            RUN:begin
                case(wtoken)
                    W_CONST:begin
                        // Worker CONST fires: update x2 in THETA bank
                        w0[W_THETA]<=w0[W_CONST];w1[W_THETA]<=w1[W_CONST];
                        w2[W_THETA]<=wc_out2;
                        w3[W_THETA]<=w3[W_CONST];w4[W_THETA]<=w4[W_CONST];
                        wtoken<=W_THETA;
                    end
                    W_THETA:begin
                        // Worker THETA fires: pass result to CHI bank
                        w0[W_CHI]<=tt0;w1[W_CHI]<=tt1;w2[W_CHI]<=tt2;w3[W_CHI]<=tt3;w4[W_CHI]<=tt4;
                        wtoken<=W_CHI;
                    end
                    W_CHI:begin
                        // Worker CHI fires: pass result to LIN bank
                        w0[W_LIN]<=tc0;w1[W_LIN]<=tc1;w2[W_LIN]<=tc2;w3[W_LIN]<=tc3;w4[W_LIN]<=tc4;
                        wtoken<=W_LIN;
                    end
                    W_LIN:begin
                        // Worker LIN fires: distribute result to all banks for next round
                        for(i=0;i<4;i=i+1) begin w0[i]<=tl0;w1[i]<=tl1;w2[i]<=tl2;w3[i]<=tl3;w4[i]<=tl4; end
                        wtoken<=W_CONST;
                        if(round_cnt<round_end-1) round_cnt<=round_cnt+1; else state<=FINISH;
                    end
                    default:wtoken<=W_CONST;
                endcase end
            FINISH:begin s0_out<=w0[0];s1_out<=w1[0];s2_out<=w2[0];s3_out<=w3[0];s4_out<=w4[0];done<=1;state<=IDLE;end
            default:state<=IDLE;
        endcase end
endmodule
