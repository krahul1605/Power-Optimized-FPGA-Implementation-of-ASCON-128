`timescale 1ns / 1ps
module ascon128_top (
    input  wire clk_p,clk_n,rst_n,start,
    output wire done,tag_match,led_done,led_tag_match,led_running,led_error
);
    wire clk_ibuf,clk; reg rr;
    IBUFDS #(.DIFF_TERM("FALSE"),.IBUF_LOW_PWR("FALSE"),.IOSTANDARD("LVDS"))
        u(.I(clk_p),.IB(clk_n),.O(clk_ibuf));
    BUFG b(.I(clk_ibuf),.O(clk));
    wire cd,ct;
    ascon128_complete_fibonacci ac(.clk(clk),.rst_n(rst_n),.start(start),.done(cd),.tag_match(ct));
    assign done=cd; assign tag_match=ct;
    always @(posedge clk or negedge rst_n) if(!rst_n) rr<=0; else if(start) rr<=1; else if(cd) rr<=0;
    assign led_done=cd; assign led_tag_match=cd&ct; assign led_running=rr; assign led_error=cd&~ct;
endmodule

module ascon128_complete_fibonacci(input wire clk,rst_n,start,output reg done,tag_match);
    localparam [127:0] KEY=128'h0F1E2D3C4B5A69788796A5B4C3D2E1F0,NONCE=128'hFFEEDDCCBBAA99887766554433221100;
    localparam [191:0] PT_PADDED=192'h46696E616C20596561722050726F6A656374204152418000;
    localparam PT_BLOCKS=3; localparam [63:0] AAD_PADDED=64'h64656D6F41414480,IV=64'h80400c0600000000;
    localparam [4:0] ST_IDLE=0,ST_EI=1,ST_EIP=2,ST_EA=3,ST_EAP=4,ST_EAD=5,
        ST_EP=6,ST_EPP=7,ST_EF=8,ST_EFW=9,ST_TS=10,ST_DI=11,ST_DIP=12,
        ST_DA=13,ST_DAP=14,ST_DAD=15,ST_DC=16,ST_DCP=17,ST_DF=18,ST_DFW=19,ST_DONE=20;
    reg [4:0] state; reg [3:0] bi;
    reg [63:0] s0,s1,s2,s3,s4;
    reg [191:0] ct_r; reg [127:0] tag_enc; reg [191:0] pt_dec;
    reg ps; wire pd; reg [3:0] psr,pnr;
    wire [63:0] po0,po1,po2,po3,po4;
    ascon_perm_fibonacci pi(.clk(clk),.rst_n(rst_n),.start(ps),.start_round(psr),.rounds(pnr),
        .s0_in(s0),.s1_in(s1),.s2_in(s2),.s3_in(s3),.s4_in(s4),
        .s0_out(po0),.s1_out(po1),.s2_out(po2),.s3_out(po3),.s4_out(po4),.done(pd));
    always @(posedge clk or negedge rst_n) begin
        if(!rst_n) begin state<=0;done<=0;tag_match<=0;ps<=0;psr<=0;pnr<=0;bi<=0;
            s0<=0;s1<=0;s2<=0;s3<=0;s4<=0;ct_r<=0;tag_enc<=0;pt_dec<=0;
        end else begin ps<=0;
            case(state)
                ST_IDLE:begin done<=0;tag_match<=0;if(start) state<=ST_EI;end
                ST_EI:begin s0<=IV;s1<=KEY[127:64];s2<=KEY[63:0];s3<=NONCE[127:64];s4<=NONCE[63:0];
                    psr<=0;pnr<=12;ps<=1;state<=ST_EIP;end
                ST_EIP:if(pd)begin s0<=po0;s1<=po1;s2<=po2;s3<=po3^KEY[127:64];s4<=po4^KEY[63:0];state<=ST_EA;end
                ST_EA:begin s0<=s0^AAD_PADDED;psr<=6;pnr<=6;ps<=1;state<=ST_EAP;end
                ST_EAP:if(pd)begin s0<=po0;s1<=po1;s2<=po2;s3<=po3;s4<=po4;state<=ST_EAD;end
                ST_EAD:begin s4<=s4^64'h1;bi<=0;state<=ST_EP;end
                ST_EP:begin
                    if(bi<PT_BLOCKS)begin ct_r[191-bi*64-:64]<=s0^PT_PADDED[191-bi*64-:64];
                        s0<=s0^PT_PADDED[191-bi*64-:64];
                        if(bi<PT_BLOCKS-1)begin psr<=6;pnr<=6;ps<=1;bi<=bi+1;state<=ST_EPP;end else state<=ST_EF;
                    end else state<=ST_EF;end
                ST_EPP:if(pd)begin s0<=po0;s1<=po1;s2<=po2;s3<=po3;s4<=po4;state<=ST_EP;end
                ST_EF:begin s1<=s1^KEY[127:64];s2<=s2^KEY[63:0];psr<=0;pnr<=12;ps<=1;state<=ST_EFW;end
                ST_EFW:if(pd)begin tag_enc<={po3^KEY[127:64],po4^KEY[63:0]};state<=ST_TS;end
                ST_TS:state<=ST_DI;
                ST_DI:begin s0<=IV;s1<=KEY[127:64];s2<=KEY[63:0];s3<=NONCE[127:64];s4<=NONCE[63:0];
                    psr<=0;pnr<=12;ps<=1;state<=ST_DIP;end
                ST_DIP:if(pd)begin s0<=po0;s1<=po1;s2<=po2;s3<=po3^KEY[127:64];s4<=po4^KEY[63:0];state<=ST_DA;end
                ST_DA:begin s0<=s0^AAD_PADDED;psr<=6;pnr<=6;ps<=1;state<=ST_DAP;end
                ST_DAP:if(pd)begin s0<=po0;s1<=po1;s2<=po2;s3<=po3;s4<=po4;state<=ST_DAD;end
                ST_DAD:begin s4<=s4^64'h1;bi<=0;state<=ST_DC;end
                ST_DC:begin
                    if(bi<PT_BLOCKS)begin pt_dec[191-bi*64-:64]<=s0^ct_r[191-bi*64-:64];
                        s0<=ct_r[191-bi*64-:64];
                        if(bi<PT_BLOCKS-1)begin psr<=6;pnr<=6;ps<=1;bi<=bi+1;state<=ST_DCP;end else state<=ST_DF;
                    end else state<=ST_DF;end
                ST_DCP:if(pd)begin s0<=po0;s1<=po1;s2<=po2;s3<=po3;s4<=po4;state<=ST_DC;end
                ST_DF:begin s1<=s1^KEY[127:64];s2<=s2^KEY[63:0];psr<=0;pnr<=12;ps<=1;state<=ST_DFW;end
                ST_DFW:if(pd)begin tag_match<=(tag_enc=={po3^KEY[127:64],po4^KEY[63:0]});done<=1;state<=ST_DONE;end
                ST_DONE:; default:state<=ST_IDLE;
            endcase end end
endmodule
//=============================================================================
// ascon_perm_fibonacci
//
// Fibonacci-depth pipeline — each round uses a pipeline depth determined by
// the Fibonacci sequence, capped at 5 stages:
//   Round 0: depth 1, Round 1: depth 1, Round 2: depth 2,
//   Round 3: depth 3, Round 4: depth 5, Round 5: depth 5 (cap),
//   Round 6: depth 1 (cycle resets), ...
// Pattern repeats mod-6: [1,1,2,3,5,5]
//
// Depth meanings:
//   1 = single-cycle full round (baseline)
//   2 = Theta | Chi+Lin
//   3 = Theta | Chi | Lin
//   5 = Const | Theta | Chi_AND | Chi_XOR | Lin
//
// Round depths for pa=12 (rounds 0-11):
//   0:1, 1:1, 2:2, 3:3, 4:5, 5:5, 6:1, 7:1, 8:2, 9:3, 10:5, 11:5
//   Total: (2+2)×1 + 2×2 + 2×3 + 2×5 = 4+4+6+10 = 24+1 = 25 cycles
//
// Fmax: 25 MHz (rounds 0,1,6,7 set the period via full baseline cone)
//=============================================================================
module ascon_perm_fibonacci (
    input  wire        clk,rst_n,start,
    input  wire [3:0]  start_round,rounds,
    input  wire [63:0] s0_in,s1_in,s2_in,s3_in,s4_in,
    output reg  [63:0] s0_out,s1_out,s2_out,s3_out,s4_out,
    output reg         done
);
    localparam [1:0] IDLE=2'd0,RUN=2'd1,FINISH=2'd2;
    localparam [2:0] FB_CONST=3'd0,FB_THETA=3'd1,FB_CHI_A=3'd2,FB_CHI_X=3'd3,FB_LIN=3'd4;

    reg [1:0] state;
    reg [2:0] fb_sub;
    reg [3:0] round_cnt,round_end;
    reg [63:0] x0,x1,x2,x3,x4;
    (* keep="true" *) reg [63:0] th0,th1,th2,th3,th4;
    (* keep="true" *) reg [63:0] ca0,ca1,ca2,ca3,ca4;

    // Fibonacci depth table mod-6: depths [1,1,2,3,5,5]
    function [2:0] fib_depth; input [3:0] r;
        case(r % 6)
            0,1:  fib_depth=3'd1;
            2:    fib_depth=3'd2;
            3:    fib_depth=3'd3;
            4,5:  fib_depth=3'd5;
            default:fib_depth=3'd1;
        endcase
    endfunction

    reg [7:0] rc;
    always @(*) case(round_cnt)
        4'd0:rc=8'hf0;4'd1:rc=8'he1;4'd2:rc=8'hd2;4'd3:rc=8'hc3;
        4'd4:rc=8'hb4;4'd5:rc=8'ha5;4'd6:rc=8'h96;4'd7:rc=8'h87;
        4'd8:rc=8'h78;4'd9:rc=8'h69;4'd10:rc=8'h5a;4'd11:rc=8'h4b;
        default:rc=8'h00;
    endcase

    // Baseline full round (depth 1)
    wire [63:0] bc2=x2^{56'd0,rc};
    wire [63:0] bp0=x0^x1^bc2^x3^x4,bp1=x1^bc2^x3^x4^x0,bp2=bc2^x3^x4^x0^x1,bp3=x3^x4^x0^x1^bc2,bp4=x4^x0^x1^bc2^x3;
    wire [63:0] bm0=bp4^{bp1[0],bp1[63:1]},bm1=bp0^{bp2[0],bp2[63:1]},bm2=bp1^{bp3[0],bp3[63:1]};
    wire [63:0] bm3=bp2^{bp4[0],bp4[63:1]},bm4=bp3^{bp0[0],bp0[63:1]};
    wire [63:0] bt0=x0^bm0,bt1=x1^bm1,bt2=bc2^bm2,bt3=x3^bm3,bt4=x4^bm4;
    wire [63:0] bu0=~bt1&bt2,bu1=~bt2&bt3,bu2=~bt3&bt4,bu3=~bt4&bt0,bu4=~bt0&bt1;
    wire [63:0] bv0=bt0^bu0,bv1=bt1^bu1,bv2=~(bt2^bu2),bv3=bt3^bu3,bv4=bt4^bu4;
    wire [63:0] bn0=bv0^{bv0[18:0],bv0[63:19]}^{bv0[27:0],bv0[63:28]};
    wire [63:0] bn1=bv1^{bv1[60:0],bv1[63:61]}^{bv1[38:0],bv1[63:39]};
    wire [63:0] bn2=bv2^{bv2[0],bv2[63:1]}^{bv2[5:0],bv2[63:6]};
    wire [63:0] bn3=bv3^{bv3[9:0],bv3[63:10]}^{bv3[16:0],bv3[63:17]};
    wire [63:0] bn4=bv4^{bv4[6:0],bv4[63:7]}^{bv4[40:0],bv4[63:41]};
    // Theta from x*
    wire [63:0] tp0=x0^x1^x2^x3^x4,tp1=x1^x2^x3^x4^x0,tp2=x2^x3^x4^x0^x1,tp3=x3^x4^x0^x1^x2,tp4=x4^x0^x1^x2^x3;
    wire [63:0] tm0=tp4^{tp1[0],tp1[63:1]},tm1=tp0^{tp2[0],tp2[63:1]},tm2=tp1^{tp3[0],tp3[63:1]};
    wire [63:0] tm3=tp2^{tp4[0],tp4[63:1]},tm4=tp3^{tp0[0],tp0[63:1]};
    wire [63:0] tt0=x0^tm0,tt1=x1^tm1,tt2=x2^tm2,tt3=x3^tm3,tt4=x4^tm4;
    // Chi AND-NOT from th*
    wire [63:0] ta0=~th1&th2,ta1=~th2&th3,ta2=~th3&th4,ta3=~th4&th0,ta4=~th0&th1;
    // Chi XOR from th* and ca*
    wire [63:0] tv0=th0^ca0,tv1=th1^ca1,tv2=~(th2^ca2),tv3=th3^ca3,tv4=th4^ca4;
    // Chi+Lin fused from th* (depth 2)
    wire [63:0] tc0=th0^(~th1&th2),tc1=th1^(~th2&th3),tc2=~(th2^(~th3&th4)),tc3=th3^(~th4&th0),tc4=th4^(~th0&th1);
    wire [63:0] tl0=tc0^{tc0[18:0],tc0[63:19]}^{tc0[27:0],tc0[63:28]};
    wire [63:0] tl1=tc1^{tc1[60:0],tc1[63:61]}^{tc1[38:0],tc1[63:39]};
    wire [63:0] tl2=tc2^{tc2[0],tc2[63:1]}^{tc2[5:0],tc2[63:6]};
    wire [63:0] tl3=tc3^{tc3[9:0],tc3[63:10]}^{tc3[16:0],tc3[63:17]};
    wire [63:0] tl4=tc4^{tc4[6:0],tc4[63:7]}^{tc4[40:0],tc4[63:41]};
    // Lin from chi_xor tv*
    wire [63:0] fl0=tv0^{tv0[18:0],tv0[63:19]}^{tv0[27:0],tv0[63:28]};
    wire [63:0] fl1=tv1^{tv1[60:0],tv1[63:61]}^{tv1[38:0],tv1[63:39]};
    wire [63:0] fl2=tv2^{tv2[0],tv2[63:1]}^{tv2[5:0],tv2[63:6]};
    wire [63:0] fl3=tv3^{tv3[9:0],tv3[63:10]}^{tv3[16:0],tv3[63:17]};
    wire [63:0] fl4=tv4^{tv4[6:0],tv4[63:7]}^{tv4[40:0],tv4[63:41]};

    wire [2:0] cur_depth = fib_depth(round_cnt);

    task adv; begin
        fb_sub<=FB_CONST;
        if(round_cnt<round_end-1) round_cnt<=round_cnt+1; else state<=FINISH;
    end endtask

    always @(posedge clk or negedge rst_n) begin
        if(!rst_n) begin state<=IDLE;done<=0;fb_sub<=0;round_cnt<=0;round_end<=0;
            x0<=0;x1<=0;x2<=0;x3<=0;x4<=0;th0<=0;th1<=0;th2<=0;th3<=0;th4<=0;ca0<=0;ca1<=0;ca2<=0;ca3<=0;ca4<=0;
            s0_out<=0;s1_out<=0;s2_out<=0;s3_out<=0;s4_out<=0;
        end else case(state)
            IDLE:begin done<=0;
                if(start)begin x0<=s0_in;x1<=s1_in;x2<=s2_in;x3<=s3_in;x4<=s4_in;
                    round_cnt<=start_round;round_end<=start_round+rounds;fb_sub<=FB_CONST;state<=RUN;end end
            RUN:begin
                case(cur_depth)
                    3'd1:begin // Full baseline
                        x0<=bn0;x1<=bn1;x2<=bn2;x3<=bn3;x4<=bn4; adv; end
                    3'd2:begin // Theta|Chi+Lin
                        case(fb_sub)
                            FB_CONST:begin x2<=x2^{56'd0,rc};th0<=tt0;th1<=tt1;th2<=tt2;th3<=tt3;th4<=tt4;fb_sub<=FB_LIN;end
                            FB_LIN:  begin x0<=tl0;x1<=tl1;x2<=tl2;x3<=tl3;x4<=tl4;adv;end
                            default:fb_sub<=FB_CONST;
                        endcase end
                    3'd3:begin // Theta|Chi|Lin
                        case(fb_sub)
                            FB_CONST:begin x2<=x2^{56'd0,rc};th0<=tt0;th1<=tt1;th2<=tt2;th3<=tt3;th4<=tt4;fb_sub<=FB_CHI_X;end
                            FB_CHI_X:begin ca0<=ta0;ca1<=ta1;ca2<=ta2;ca3<=ta3;ca4<=ta4;fb_sub<=FB_LIN;end
                            FB_LIN:  begin x0<=fl0;x1<=fl1;x2<=fl2;x3<=fl3;x4<=fl4;adv;end
                            default:fb_sub<=FB_CONST;
                        endcase end
                    default:begin // depth 5: Const|Theta|Chi_AND|Chi_XOR|Lin
                        case(fb_sub)
                            FB_CONST: begin x2<=x2^{56'd0,rc};fb_sub<=FB_THETA;end
                            FB_THETA: begin th0<=tt0;th1<=tt1;th2<=tt2;th3<=tt3;th4<=tt4;fb_sub<=FB_CHI_A;end
                            FB_CHI_A: begin ca0<=ta0;ca1<=ta1;ca2<=ta2;ca3<=ta3;ca4<=ta4;fb_sub<=FB_CHI_X;end
                            FB_CHI_X: begin x0<=tv0;x1<=tv1;x2<=tv2;x3<=tv3;x4<=tv4;
                                            th0<=tv0;th1<=tv1;th2<=tv2;th3<=tv3;th4<=tv4;fb_sub<=FB_LIN;end
                            FB_LIN:   begin x0<=fl0;x1<=fl1;x2<=fl2;x3<=fl3;x4<=fl4;adv;end
                            default:fb_sub<=FB_CONST;
                        endcase end
                endcase end
            FINISH:begin s0_out<=x0;s1_out<=x1;s2_out<=x2;s3_out<=x3;s4_out<=x4;done<=1;state<=IDLE;end
            default:state<=IDLE;
        endcase end
endmodule
