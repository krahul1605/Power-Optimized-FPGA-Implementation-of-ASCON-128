`timescale 1ns / 1ps
//=============================================================================
// ASCON-128  ·  Variant: pipelined
//
// Visual treatment : Fully pipelined 8-stage — every one of the 8 ASCON
//                    sub-steps (CONST, THETA_A, THETA_B, THETA_C, CHI1, CHI2,
//                    LIN1, LIN2) gets its own registered stage. This is the
//                    maximum register insertion point — exactly one pipeline
//                    register barrier between every pair of adjacent sub-steps.
//                    No two sub-steps share a combinational cone.
//
//                    This produces the shortest possible critical path per
//                    stage (each stage contains exactly ONE sub-step), enabling
//                    the highest Fmax of all variants. The round counter is
//                    carried through the pipeline as a sideband signal to
//                    generate the correct round constant at each CONST stage.
//
// Clocks per pa=12 call : 12 rounds × 8 sub-steps = 96 + 1 FINISH = 97
// Clocks per pb=6  call :  6 rounds × 8 sub-steps = 48 + 1 FINISH = 49
//
// Trade-offs
//   + Maximum Fmax — shortest combinational path (single sub-step per stage)
//   + Heaviest-path sub-step (CHI1: AND-NOT) is fully isolated
//   + Balanced with LIN1 and LIN2 each getting their own stage
//   - Maximum register count: 7 intermediate pipeline register banks
//   - Highest area of all pipeline variants
//   - Target 200 MHz / 5 ns
//
// Functional parity: identical ports and FSM encoding to all variants.
//                    NIST-compliant ASCON-128 algorithm.
//=============================================================================

module ascon128_top (
    input  wire clk_p,
    input  wire clk_n,
    input  wire rst_n,
    input  wire start,
    output wire done,
    output wire tag_match,
    output wire led_done,
    output wire led_tag_match,
    output wire led_running,
    output wire led_error
);

    wire clk_ibuf, clk;

    IBUFDS #(
        .DIFF_TERM("FALSE"), .IBUF_LOW_PWR("FALSE"), .IOSTANDARD("LVDS")
    ) clk_ibufds (.I(clk_p), .IB(clk_n), .O(clk_ibuf));

    BUFG clk_bufg (.I(clk_ibuf), .O(clk));

    wire core_done, core_tag_match;
    reg  running_r;

    ascon128_complete_pipelined ascon_core (
        .clk(clk), .rst_n(rst_n), .start(start),
        .done(core_done), .tag_match(core_tag_match)
    );

    assign done = core_done; assign tag_match = core_tag_match;

    always @(posedge clk or negedge rst_n) begin
        if (!rst_n)         running_r <= 0;
        else if (start)     running_r <= 1;
        else if (core_done) running_r <= 0;
    end

    assign led_done=core_done; assign led_tag_match=core_done&core_tag_match;
    assign led_running=running_r; assign led_error=core_done&~core_tag_match;

endmodule


//=============================================================================
// ascon128_complete_pipelined  — FSM
//=============================================================================
module ascon128_complete_pipelined (
    input  wire clk, rst_n, start,
    output reg  done, tag_match
);
    localparam [127:0] KEY   = 128'h0F1E2D3C4B5A69788796A5B4C3D2E1F0;
    localparam [127:0] NONCE = 128'hFFEEDDCCBBAA99887766554433221100;
    localparam [191:0] PT_PADDED  = 192'h46696E616C20596561722050726F6A656374204152418000;
    localparam         PT_BLOCKS  = 3;
    localparam [63:0]  AAD_PADDED = 64'h64656D6F41414480;
    localparam [63:0]  IV         = 64'h80400c0600000000;

    localparam [4:0]
        ST_IDLE=0, ST_ENC_INIT=1, ST_ENC_INIT_PERM=2,
        ST_ENC_AAD=3, ST_ENC_AAD_PERM=4, ST_ENC_AAD_DOM=5,
        ST_ENC_PT=6, ST_ENC_PT_PERM=7, ST_ENC_FINAL=8,
        ST_ENC_FINAL_W=9, ST_TAG_STORE=10, ST_DEC_INIT=11,
        ST_DEC_INIT_PERM=12, ST_DEC_AAD=13, ST_DEC_AAD_PERM=14,
        ST_DEC_AAD_DOM=15, ST_DEC_CT=16, ST_DEC_CT_PERM=17,
        ST_DEC_FINAL=18, ST_DEC_FINAL_W=19, ST_DONE=20;

    reg [4:0] state; reg [3:0] block_idx;
    reg [63:0] s0,s1,s2,s3,s4;
    reg [191:0] ciphertext; reg [127:0] tag_enc; reg [191:0] plaintext_dec;
    reg perm_start; wire perm_done;
    reg [3:0] perm_start_round, perm_num_rounds;
    wire [63:0] perm_out0,perm_out1,perm_out2,perm_out3,perm_out4;

    ascon_perm_pipelined perm_inst (
        .clk(clk), .rst_n(rst_n), .start(perm_start),
        .start_round(perm_start_round), .rounds(perm_num_rounds),
        .s0_in(s0),.s1_in(s1),.s2_in(s2),.s3_in(s3),.s4_in(s4),
        .s0_out(perm_out0),.s1_out(perm_out1),.s2_out(perm_out2),
        .s3_out(perm_out3),.s4_out(perm_out4),.done(perm_done)
    );

    always @(posedge clk or negedge rst_n) begin
        if (!rst_n) begin
            state<=0; done<=0; tag_match<=0; perm_start<=0;
            perm_start_round<=0; perm_num_rounds<=0; block_idx<=0;
            s0<=0;s1<=0;s2<=0;s3<=0;s4<=0;
            ciphertext<=0; tag_enc<=0; plaintext_dec<=0;
        end else begin
            perm_start<=0;
            case(state)
                ST_IDLE: begin done<=0; tag_match<=0; if(start) state<=ST_ENC_INIT; end
                ST_ENC_INIT: begin
                    s0<=IV; s1<=KEY[127:64]; s2<=KEY[63:0];
                    s3<=NONCE[127:64]; s4<=NONCE[63:0];
                    perm_start_round<=0; perm_num_rounds<=12; perm_start<=1;
                    state<=ST_ENC_INIT_PERM;
                end
                ST_ENC_INIT_PERM: if(perm_done) begin
                    s0<=perm_out0; s1<=perm_out1; s2<=perm_out2;
                    s3<=perm_out3^KEY[127:64]; s4<=perm_out4^KEY[63:0];
                    state<=ST_ENC_AAD;
                end
                ST_ENC_AAD: begin
                    s0<=s0^AAD_PADDED; perm_start_round<=6; perm_num_rounds<=6;
                    perm_start<=1; state<=ST_ENC_AAD_PERM;
                end
                ST_ENC_AAD_PERM: if(perm_done) begin
                    s0<=perm_out0;s1<=perm_out1;s2<=perm_out2;s3<=perm_out3;s4<=perm_out4;
                    state<=ST_ENC_AAD_DOM;
                end
                ST_ENC_AAD_DOM: begin s4<=s4^64'h1; block_idx<=0; state<=ST_ENC_PT; end
                ST_ENC_PT: begin
                    if(block_idx<PT_BLOCKS) begin
                        ciphertext[191-block_idx*64-:64]<=s0^PT_PADDED[191-block_idx*64-:64];
                        s0<=s0^PT_PADDED[191-block_idx*64-:64];
                        if(block_idx<PT_BLOCKS-1) begin
                            perm_start_round<=6; perm_num_rounds<=6; perm_start<=1;
                            block_idx<=block_idx+1; state<=ST_ENC_PT_PERM;
                        end else state<=ST_ENC_FINAL;
                    end else state<=ST_ENC_FINAL;
                end
                ST_ENC_PT_PERM: if(perm_done) begin
                    s0<=perm_out0;s1<=perm_out1;s2<=perm_out2;s3<=perm_out3;s4<=perm_out4;
                    state<=ST_ENC_PT;
                end
                ST_ENC_FINAL: begin
                    s1<=s1^KEY[127:64]; s2<=s2^KEY[63:0];
                    perm_start_round<=0; perm_num_rounds<=12; perm_start<=1;
                    state<=ST_ENC_FINAL_W;
                end
                ST_ENC_FINAL_W: if(perm_done) begin
                    tag_enc<={perm_out3^KEY[127:64],perm_out4^KEY[63:0]};
                    state<=ST_TAG_STORE;
                end
                ST_TAG_STORE: state<=ST_DEC_INIT;
                ST_DEC_INIT: begin
                    s0<=IV; s1<=KEY[127:64]; s2<=KEY[63:0];
                    s3<=NONCE[127:64]; s4<=NONCE[63:0];
                    perm_start_round<=0; perm_num_rounds<=12; perm_start<=1;
                    state<=ST_DEC_INIT_PERM;
                end
                ST_DEC_INIT_PERM: if(perm_done) begin
                    s0<=perm_out0;s1<=perm_out1;s2<=perm_out2;
                    s3<=perm_out3^KEY[127:64];s4<=perm_out4^KEY[63:0];
                    state<=ST_DEC_AAD;
                end
                ST_DEC_AAD: begin
                    s0<=s0^AAD_PADDED; perm_start_round<=6; perm_num_rounds<=6;
                    perm_start<=1; state<=ST_DEC_AAD_PERM;
                end
                ST_DEC_AAD_PERM: if(perm_done) begin
                    s0<=perm_out0;s1<=perm_out1;s2<=perm_out2;s3<=perm_out3;s4<=perm_out4;
                    state<=ST_DEC_AAD_DOM;
                end
                ST_DEC_AAD_DOM: begin s4<=s4^64'h1; block_idx<=0; state<=ST_DEC_CT; end
                ST_DEC_CT: begin
                    if(block_idx<PT_BLOCKS) begin
                        plaintext_dec[191-block_idx*64-:64]<=s0^ciphertext[191-block_idx*64-:64];
                        s0<=ciphertext[191-block_idx*64-:64];
                        if(block_idx<PT_BLOCKS-1) begin
                            perm_start_round<=6; perm_num_rounds<=6; perm_start<=1;
                            block_idx<=block_idx+1; state<=ST_DEC_CT_PERM;
                        end else state<=ST_DEC_FINAL;
                    end else state<=ST_DEC_FINAL;
                end
                ST_DEC_CT_PERM: if(perm_done) begin
                    s0<=perm_out0;s1<=perm_out1;s2<=perm_out2;s3<=perm_out3;s4<=perm_out4;
                    state<=ST_DEC_CT;
                end
                ST_DEC_FINAL: begin
                    s1<=s1^KEY[127:64]; s2<=s2^KEY[63:0];
                    perm_start_round<=0; perm_num_rounds<=12; perm_start<=1;
                    state<=ST_DEC_FINAL_W;
                end
                ST_DEC_FINAL_W: if(perm_done) begin
                    tag_match<=(tag_enc=={perm_out3^KEY[127:64],perm_out4^KEY[63:0]});
                    done<=1; state<=ST_DONE;
                end
                ST_DONE: ;
                default: state<=ST_IDLE;
            endcase
        end
    end
endmodule


//=============================================================================
// ascon_perm_pipelined
//
// 8-stage fully pipelined permutation — one register per sub-step.
// Pipeline stage map:
//   S0 (CONST)   : x2 XOR rc → c*         [register: c0..c4]
//   S1 (THETA_A) : column parities → p*    [register: p0..p4 + c* passthrough]
//   S2 (THETA_B) : rotation mix → m*       [register: m0..m4 + c* passthrough]
//   S3 (THETA_C) : apply theta → t*        [register: t0..t4]
//   S4 (CHI1)    : AND-NOT → u*            [register: u0..u4 + t* passthrough]
//   S5 (CHI2)    : chi XOR/INV → v*        [register: v0..v4]
//   S6 (LIN1)    : rotation operands → ra*, rb*  [register: ra*, rb*, v*]
//   S7 (LIN2)    : final XOR → x* (new)    [register: x0..x4]
//
// Round counter is pipelined as a sideband through all 8 stages.
// The FSM advances round_cnt only when state==S0 (start of new round).
//=============================================================================
module ascon_perm_pipelined (
    input  wire        clk, rst_n, start,
    input  wire [3:0]  start_round, rounds,
    input  wire [63:0] s0_in,s1_in,s2_in,s3_in,s4_in,
    output reg  [63:0] s0_out,s1_out,s2_out,s3_out,s4_out,
    output reg         done
);

    localparam [3:0] IDLE=4'd0, S0=4'd1, S1=4'd2, S2=4'd3, S3=4'd4,
                     S4=4'd5,   S5=4'd6, S6=4'd7, S7=4'd8, FINISH=4'd9;

    reg [3:0]  state;
    reg [3:0]  round_cnt, round_end;

    // Stage registers
    reg [63:0] x0,x1,x2,x3,x4;         // working state (input + S7 output)
    reg [63:0] c0,c1,c2,c3,c4;         // S0 output: after CONST
    reg [63:0] cp0,cp1,cp2,cp3,cp4;    // S1 input passthrough of c* for THETA_C
    reg [63:0] p0,p1,p2,p3,p4;         // S1 output: column parities
    reg [63:0] cm0,cm1,cm2,cm3,cm4;    // S2 input: c* carried from S1
    reg [63:0] m0,m1,m2,m3,m4;         // S2 output: rotation-mixed parities
    reg [63:0] t0,t1,t2,t3,t4;         // S3 output: theta result
    reg [63:0] u0,u1,u2,u3,u4;         // S4 output: CHI1 AND-NOT
    reg [63:0] tp0,tp1,tp2,tp3,tp4;    // S4 passthrough: t* for CHI2
    reg [63:0] v0,v1,v2,v3,v4;         // S5 output: CHI2 result
    reg [63:0] ra0,ra1,ra2,ra3,ra4;    // S6 output: first rotation
    reg [63:0] rb0,rb1,rb2,rb3,rb4;    // S6 output: second rotation
    reg [63:0] vp0,vp1,vp2,vp3,vp4;   // S6 passthrough: v* for LIN2

    // Round constant decode
    reg [7:0] rc;
    always @(*) case(round_cnt)
        4'd0:rc=8'hf0; 4'd1:rc=8'he1; 4'd2:rc=8'hd2; 4'd3:rc=8'hc3;
        4'd4:rc=8'hb4; 4'd5:rc=8'ha5; 4'd6:rc=8'h96; 4'd7:rc=8'h87;
        4'd8:rc=8'h78; 4'd9:rc=8'h69; 4'd10:rc=8'h5a; 4'd11:rc=8'h4b;
        default:rc=8'h00;
    endcase

    always @(posedge clk or negedge rst_n) begin
        if(!rst_n) begin
            state<=IDLE; done<=0; round_cnt<=0; round_end<=0;
            x0<=0;x1<=0;x2<=0;x3<=0;x4<=0;
            c0<=0;c1<=0;c2<=0;c3<=0;c4<=0;
            cp0<=0;cp1<=0;cp2<=0;cp3<=0;cp4<=0;
            p0<=0;p1<=0;p2<=0;p3<=0;p4<=0;
            cm0<=0;cm1<=0;cm2<=0;cm3<=0;cm4<=0;
            m0<=0;m1<=0;m2<=0;m3<=0;m4<=0;
            t0<=0;t1<=0;t2<=0;t3<=0;t4<=0;
            u0<=0;u1<=0;u2<=0;u3<=0;u4<=0;
            tp0<=0;tp1<=0;tp2<=0;tp3<=0;tp4<=0;
            v0<=0;v1<=0;v2<=0;v3<=0;v4<=0;
            ra0<=0;ra1<=0;ra2<=0;ra3<=0;ra4<=0;
            rb0<=0;rb1<=0;rb2<=0;rb3<=0;rb4<=0;
            vp0<=0;vp1<=0;vp2<=0;vp3<=0;vp4<=0;
            s0_out<=0;s1_out<=0;s2_out<=0;s3_out<=0;s4_out<=0;
        end else case(state)
            IDLE: begin
                done<=0;
                if(start) begin
                    x0<=s0_in;x1<=s1_in;x2<=s2_in;x3<=s3_in;x4<=s4_in;
                    round_cnt<=start_round; round_end<=start_round+rounds;
                    state<=S0;
                end
            end
            // S0: CONST — XOR rc into x2 only
            S0: begin
                c0<=x0; c1<=x1; c2<=x2^{56'd0,rc}; c3<=x3; c4<=x4;
                state<=S1;
            end
            // S1: THETA_A — column parities; passthrough c* for THETA_C
            S1: begin
                p0<=c0^c1^c2^c3^c4;
                p1<=c1^c2^c3^c4^c0;
                p2<=c2^c3^c4^c0^c1;
                p3<=c3^c4^c0^c1^c2;
                p4<=c4^c0^c1^c2^c3;
                cp0<=c0; cp1<=c1; cp2<=c2; cp3<=c3; cp4<=c4;
                state<=S2;
            end
            // S2: THETA_B — rotation-mixed parities; passthrough c* (now cp*)
            S2: begin
                m0<=p4^{p1[0],p1[63:1]};
                m1<=p0^{p2[0],p2[63:1]};
                m2<=p1^{p3[0],p3[63:1]};
                m3<=p2^{p4[0],p4[63:1]};
                m4<=p3^{p0[0],p0[63:1]};
                cm0<=cp0; cm1<=cp1; cm2<=cp2; cm3<=cp3; cm4<=cp4;
                state<=S3;
            end
            // S3: THETA_C — apply theta (c XOR m)
            S3: begin
                t0<=cm0^m0; t1<=cm1^m1; t2<=cm2^m2;
                t3<=cm3^m3; t4<=cm4^m4;
                state<=S4;
            end
            // S4: CHI1 — AND-NOT; passthrough t* for CHI2 XOR
            S4: begin
                u0<=~t1&t2; u1<=~t2&t3; u2<=~t3&t4;
                u3<=~t4&t0; u4<=~t0&t1;
                tp0<=t0; tp1<=t1; tp2<=t2; tp3<=t3; tp4<=t4;
                state<=S5;
            end
            // S5: CHI2 — XOR and invert x2
            S5: begin
                v0<=tp0^u0; v1<=tp1^u1; v2<=~(tp2^u2);
                v3<=tp3^u3; v4<=tp4^u4;
                state<=S6;
            end
            // S6: LIN1 — compute rotation operands; passthrough v*
            S6: begin
                ra0<={v0[18:0],v0[63:19]}; rb0<={v0[27:0],v0[63:28]};
                ra1<={v1[60:0],v1[63:61]}; rb1<={v1[38:0],v1[63:39]};
                ra2<={v2[0],   v2[63:1]};  rb2<={v2[5:0], v2[63:6]};
                ra3<={v3[9:0], v3[63:10]}; rb3<={v3[16:0],v3[63:17]};
                ra4<={v4[6:0], v4[63:7]};  rb4<={v4[40:0],v4[63:41]};
                vp0<=v0; vp1<=v1; vp2<=v2; vp3<=v3; vp4<=v4;
                state<=S7;
            end
            // S7: LIN2 — final XOR; latch new state
            S7: begin
                x0<=vp0^ra0^rb0; x1<=vp1^ra1^rb1; x2<=vp2^ra2^rb2;
                x3<=vp3^ra3^rb3; x4<=vp4^ra4^rb4;
                if(round_cnt < round_end-1) begin
                    round_cnt<=round_cnt+1;
                    state<=S0;
                end else begin
                    state<=FINISH;
                end
            end
            FINISH: begin
                s0_out<=x0;s1_out<=x1;s2_out<=x2;
                s3_out<=x3;s4_out<=x4; done<=1; state<=IDLE;
            end
            default: state<=IDLE;
        endcase
    end
endmodule