#==============================================================================
# ASCON-128  ·  Variant: rotary
# SDC for Cadence Genus Synthesis
#
# Permutation architecture: Barrel-shift word-order rotation.
#   5-entry register file rf[0..4] + 3-bit wrot counter (0..4).
#   Logical word i mapped to rf[(i+wrot)%5]. wrot advances mod-5 each round.
#   Full single-cycle round (identical cone to baseline) + 5-way indexed mux.
#
#   Critical path: rf[*]_reg -> 5-way mux (1-2 LUT levels) -> full round cone
#                  (~35-45 gate levels) -> rf[*]_reg write (through wrot-indexed CE)
#   Total: ~36-47 gate levels  (~1 extra level vs baseline for the read mux)
#   Fmax target: 22 MHz / 45 ns
#
# Clocks pa=12: 12 + 1 = 13   Clocks pb=6: 6 + 1 = 7
#==============================================================================
create_clock -period 45.000 -name sys_clk -waveform {0.000 22.500} [get_ports clk_p]
set_clock_uncertainty -setup 0.500 [get_clocks sys_clk]
set_clock_uncertainty -hold  0.300 [get_clocks sys_clk]
set_clock_transition -rise 0.200 [get_clocks sys_clk]
set_clock_transition -fall 0.200 [get_clocks sys_clk]
set_input_delay -clock sys_clk -max 2.000 [get_ports rst_n]
set_input_delay -clock sys_clk -min 0.500 [get_ports rst_n]
set_input_delay -clock sys_clk -max 2.000 [get_ports start]
set_input_delay -clock sys_clk -min 0.500 [get_ports start]
set_output_delay -clock sys_clk -max 2.000 [get_ports done]
set_output_delay -clock sys_clk -min 0.500 [get_ports done]
set_output_delay -clock sys_clk -max 2.000 [get_ports tag_match]
set_output_delay -clock sys_clk -min 0.500 [get_ports tag_match]
set_output_delay -clock sys_clk -max 2.000 [get_ports led_done]
set_output_delay -clock sys_clk -min 0.500 [get_ports led_done]
set_output_delay -clock sys_clk -max 2.000 [get_ports led_tag_match]
set_output_delay -clock sys_clk -min 0.500 [get_ports led_tag_match]
set_output_delay -clock sys_clk -max 2.000 [get_ports led_running]
set_output_delay -clock sys_clk -min 0.500 [get_ports led_running]
set_output_delay -clock sys_clk -max 2.000 [get_ports led_error]
set_output_delay -clock sys_clk -min 0.500 [get_ports led_error]
set_false_path -from [get_ports rst_n]
set_driving_cell -lib_cell INVX1 -no_design_rule [get_ports {start rst_n}]
set_load 5.0 [get_ports {done tag_match led_done led_tag_match led_running led_error}]
# set_operating_conditions -library <lib> TYPICAL
#==============================================================================
# END - ascon128_rotary.sdc
#==============================================================================
